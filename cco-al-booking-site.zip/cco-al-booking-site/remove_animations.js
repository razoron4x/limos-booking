const fs = require('fs');
const path = require('path');

const pagesDir = path.join(__dirname, 'src', 'pages');

const files = fs.readdirSync(pagesDir).filter(f => f.endsWith('.tsx'));

for (const file of files) {
  const filePath = path.join(pagesDir, file);
  let content = fs.readFileSync(filePath, 'utf-8');

  // Remove top animated line
  content = content.replace(/<div className="absolute top-0 left-0 right-0 h-\[2px\] overflow-hidden rounded-full bg-gradient-to-r from-transparent via-primary\/30 to-transparent">\s*<div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-primary to-transparent animate-glow-line"><\/div>\s*<div className="absolute top-0 left-1\/2 -translate-x-1\/2 w-1\/2 h-\[2px\] bg-primary blur-\[4px\] animate-pulse"><\/div>\s*<\/div>/g, '<div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>');

  // Remove bottom animated line
  content = content.replace(/<div className="absolute bottom-0 left-0 right-0 h-\[2px\] overflow-hidden rounded-full bg-gradient-to-r from-transparent via-primary\/30 to-transparent">\s*<div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-primary to-transparent animate-glow-line" style={{ animationDelay: '1\.5s' }}><\/div>\s*<div className="absolute top-0 left-1\/2 -translate-x-1\/2 w-1\/2 h-\[2px\] bg-primary blur-\[4px\] animate-pulse"><\/div>\s*<\/div>/g, '<div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>');

  // Remove background glow emulating from boxes
  content = content.replace(/<div className="absolute inset-0 bg-primary\/5 blur-\[80px\] rounded-full pointer-events-none animate-pulse"><\/div>/g, '');

  // Remove services section glow
  content = content.replace(/<div className="absolute right-0 top-0 w-1\/2 h-full bg-primary\/5 blur-\[150px\] rounded-full pointer-events-none"><\/div>/g, '');

  // Remove radial gradient from CTA
  content = content.replace(/<div className="absolute inset-0 bg-\[radial-gradient\(ellipse_at_center,_var\(--tw-gradient-stops\)\)\] from-primary\/10 via-transparent to-transparent"><\/div>/g, '');

  // Remove group-hover:animate-pulse
  content = content.replace(/ group-hover:animate-pulse/g, '');

  fs.writeFileSync(filePath, content, 'utf-8');
}

console.log('Removed animations from all pages.');

const { execSync } = require('child_process');
execSync('node update_reviews_stretch.js');
console.log('Script executed');

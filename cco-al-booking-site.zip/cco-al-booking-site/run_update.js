import { execSync } from 'child_process';
execSync('node update_reviews.js');

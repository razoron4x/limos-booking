const fs = require("fs");

function fixFile(path) {
  let s = fs.readFileSync(path, "utf8");

  // 1. Add useState import
  s = s.replace(
    'import { Button } from "@/components/ui/button";',
    'import { useState } from "react";\nimport { Button } from "@/components/ui/button";'
  );

  // 2. Add state hook
  s = s.replace(
    /const Service\w+ = \(\) => \{\n  return \(/,
    (m) =>
      m.replace(
        "  return (",
        "  const [expandedCard, setExpandedCard] = useState<number | null>(null);\n  return ("
      )
  );

  // 3. Replace static "Tap to expand" cards with interactive versions
  // Card 0 (first card with cursor-default rounded-xl)
  s = s.replace(
    /<div className="flex items-start gap-4 p-6 border border-primary\/20 bg-gradient-to-br from-primary\/5 to-zinc-900\/30 transition-all duration-300 hover:shadow-\[0_0_30px_rgba\(212,175,55,0\.15\)\] hover:border-primary\/40 cursor-default rounded-xl">\s*<(\w+) className="w-6 h-6 text-primary shrink-0 mt-1" \/>\s*<div>\s*<h3 className="text-xl font-bold text-white mb-2">\s*([\s\S]*?)\s*<\/h3>\s*<p className="text-white\/60 font-light hidden sm:block">\s*([\s\S]*?)\s*<\/p>\s*<p className="text-xs text-primary\/70 sm:hidden mt-1">\s*Tap to expand\s*<\/p>\s*<\/div>\s*<\/div>/,
    (full, icon, title, body) => {
      const t = title.trim();
      return [
        `<div`,
        `  className={\`flex items-start gap-4 p-6 border border-primary/20 bg-gradient-to-br from-primary/5 to-zinc-900/30 transition-all duration-300 hover:shadow-[0_0_30px_rgba(212,175,55,0.15)] hover:border-primary/40 cursor-pointer sm:cursor-default rounded-xl \${expandedCard === 0 ? "border-primary/40" : ""}\`}`,
        `  onClick={() => setExpandedCard(expandedCard === 0 ? null : 0)}`,
        `>`,
        `  <${icon} className="w-6 h-6 text-primary shrink-0 mt-1" />`,
        `  <div className="flex-1">`,
        `    <h3`,
        `      className={\`text-xl font-bold text-white mb-2 transition-all duration-300 \${expandedCard === 0 ? "text-base sm:text-xl -translate-y-1" : ""}\`}`,
        `    >`,
        `      ${t}`,
        `    </h3>`,
        `    <p`,
        `      className={\`text-white/60 font-light transition-all duration-300 overflow-hidden \${expandedCard === 0 ? "max-h-40 opacity-100" : "max-h-0 opacity-0 sm:max-h-[200px] sm:opacity-100"}\`}`,
        `    >`,
        `      ${body.trim()}`,
        `    </p>`,
        `    <span className="text-xs text-primary/70 sm:hidden cursor-pointer mt-1 select-none block">`,
        `      {expandedCard === 0 ? "Tap to collapse" : "Tap to expand"}`,
        `    </span>`,
        `  </div>`,
        `</div>`,
      ].join("\n");
    }
  );

  // Card 1 & 2 (cards with cursor-default rounded-xl, no gradient border)
  let cardIdx = 1;
  s = s.replace(
    /<div className="flex items-start gap-4 p-6 border border-white\/5 bg-zinc-900\/30 transition-all duration-300 hover:shadow-\[0_0_25px_rgba\(212,175,55,0\.12\)\] hover:border-primary\/30 hover:bg-zinc-900\/50 cursor-default rounded-xl">\s*<(\w+) className="w-6 h-6 text-primary shrink-0 mt-1" \/>\s*<div>\s*<h3 className="text-xl font-bold text-white mb-2">\s*([\s\S]*?)\s*<\/h3>\s*<p className="text-white\/60 font-light hidden sm:block">\s*([\s\S]*?)\s*<\/p>\s*<p className="text-xs text-primary\/70 sm:hidden mt-1">\s*Tap to expand\s*<\/p>\s*<\/div>\s*<\/div>/g,
    (full, icon, title, body) => {
      const idx = cardIdx++;
      const t = title.trim();
      return [
        `<div`,
        `  className={\`flex items-start gap-4 p-6 border border-white/5 bg-zinc-900/30 transition-all duration-300 hover:shadow-[0_0_25px_rgba(212,175,55,0.12)] hover:border-primary/30 hover:bg-zinc-900/50 cursor-pointer sm:cursor-default rounded-xl \${expandedCard === ${idx} ? "border-primary/40" : ""}\`}`,
        `  onClick={() => setExpandedCard(expandedCard === ${idx} ? null : ${idx})}`,
        `>`,
        `  <${icon} className="w-6 h-6 text-primary shrink-0 mt-1" />`,
        `  <div className="flex-1">`,
        `    <h3`,
        `      className={\`text-xl font-bold text-white mb-2 transition-all duration-300 \${expandedCard === ${idx} ? "text-base sm:text-xl -translate-y-1" : ""}\`}`,
        `    >`,
        `      ${t}`,
        `    </h3>`,
        `    <p`,
        `      className={\`text-white/60 font-light transition-all duration-300 overflow-hidden \${expandedCard === ${idx} ? "max-h-40 opacity-100" : "max-h-0 opacity-0 sm:max-h-[200px] sm:opacity-100"}\`}`,
        `    >`,
        `      ${body.trim()}`,
        `    </p>`,
        `    <span className="text-xs text-primary/70 sm:hidden cursor-pointer mt-1 select-none block">`,
        `      {expandedCard === ${idx} ? "Tap to collapse" : "Tap to expand"}`,
        `    </span>`,
        `  </div>`,
        `</div>`,
      ].join("\n");
    }
  );

  fs.writeFileSync(path, s);
  console.log(
    "Done",
    path,
    "hasState:",
    s.includes("setExpandedCard"),
    "staticTapLeft:",
    (s.match(/>\s*Tap to expand\s*<\/p>/g) || []).length
  );
}

fixFile("src/pages/ServiceFootball.tsx");
fixFile("src/pages/ServiceHomecoming.tsx");

// Chat widget configuration — sourced from the connected integration selection.
export const CHAT_WIDGET_CONFIG = {
  chatWidgetId: "6ada7ec6efcd72a99d2cecde",
  locationId: "VtoYJw6KZ00sCHlfIEzl",
  coreUrl: "https://widgets.leadconnectorhq.com/chat-widget-core/core.esm.js",
  marketplaceUrl: "https://services.leadconnectorhq.com",
  source: "ai-studio-native",
  chatType: "emailChat" as "emailChat" | "liveChat",
};

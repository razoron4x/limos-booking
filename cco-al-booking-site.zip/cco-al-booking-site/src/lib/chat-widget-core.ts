// Chat widget core loader — loads the ES module at runtime after first paint.
let corePromise: Promise<any> | null = null;

export const loadChatCore = (url: string) =>
  (corePromise ??= import(/* @vite-ignore */ url));

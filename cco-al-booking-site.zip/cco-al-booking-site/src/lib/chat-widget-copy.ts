// Chat widget copy — site-owned presentation strings.
export const CHAT_WIDGET_COPY = {
  heading: "Get a fast quote.",
  subHeading: "Drop your email and we'll reply.",
  teaser: "Need a quote? Send us a message.",
  thankYou: "Thanks! Our team will reach out immediately!",
  launcherAriaLabel: "Open chat",
  closeAriaLabel: "Close chat",
};

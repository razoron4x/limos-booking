// CRM form tracking helper — posts form submissions to the connected CRM.
// Standard fields use standard CRM keys; custom fields use registered custom-field IDs.

type StandardTrackingFieldKey = string;
type RegisteredCustomFieldId = string;
type TrackingCustomField = { value?: unknown; label: string };
type TrackingFileField = { file?: File; label: string };
type TrackingImageDataField = { dataUrl?: string; label: string };

export const CRM_CONFIG = {
  trackingId: "tk_73fb2ce383c44c798dcf5403a6d500e5",
  locationId: "VtoYJw6KZ00sCHlfIEzl",
  projectId: "1792719026995615993",
  formId: "ZEF66Xejp42uMD3oDqx3",
};

export const postTrackingEvent = (
  trackingPayload: Record<string, unknown> & {
    formData: Record<StandardTrackingFieldKey, unknown>;
    formLabels: Record<StandardTrackingFieldKey, string>;
  },
  options: {
    customFields?: Record<RegisteredCustomFieldId, TrackingCustomField>;
    fileFields?: Record<RegisteredCustomFieldId, TrackingFileField>;
    imageDataFields?: Record<RegisteredCustomFieldId, TrackingImageDataField>;
  } = {},
) => {
  const { customFields = {}, fileFields = {}, imageDataFields = {} } = options;
  const eventPayload = {
    ...trackingPayload,
    formData: { ...trackingPayload.formData },
    formLabels: { ...trackingPayload.formLabels },
  };
  const body = new FormData();

  for (const [key, field] of Object.entries(customFields)) {
    if (field.value === undefined || field.value === "") continue;
    eventPayload.formData[key] = field.value;
    eventPayload.formLabels[key] = field.label;
  }

  for (const [key, field] of Object.entries(imageDataFields)) {
    const dataUrl = field.dataUrl;
    if (!dataUrl) continue;
    if (!dataUrl.startsWith("data:image/")) {
      throw new Error("Image data field must be a data:image/* base64 string");
    }
    eventPayload.formData[key] = dataUrl;
    eventPayload.formLabels[key] = field.label;
  }

  for (const [key, field] of Object.entries(fileFields)) {
    const file = field.file;
    if (!file) continue;
    if (file.size > 50 * 1024 * 1024) {
      throw new Error("File must be 50 MB or smaller");
    }
    eventPayload.formData[key] = {
      filename: file.name,
      size: file.size,
      type: file.type || "application/octet-stream",
    };
    eventPayload.formLabels[key] = field.label;
    body.append(key, file, file.name);
  }

  for (const key of Object.keys(eventPayload.formData)) {
    eventPayload.formLabels[key] ||= key;
  }

  body.append("event", JSON.stringify(eventPayload));

  return fetch("https://backend.leadconnectorhq.com/external-tracking/events", {
    method: "POST",
    headers: {
      version: "2021-07-28",
    },
    body,
  }).catch(() => {}); // Fire-and-forget — don't block form UX
};

/**
 * Captures the gclid (Google Click ID) from the landing URL and persists it
 * in sessionStorage so it survives client-side navigation between pages.
 * Returns undefined when no gclid is present (e.g. organic/direct traffic).
 */
export const getGclid = (): string | undefined => {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const gclid = urlParams.get("gclid");
    if (gclid) {
      try {
        sessionStorage.setItem("gclid", gclid);
      } catch {}
      return gclid;
    }
    try {
      const stored = sessionStorage.getItem("gclid");
      if (stored) return stored;
    } catch {}
  } catch {}
  return undefined;
};

export type QuoteFormData = {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  quoteOrReservation: string;
  newOrExisting: string;
  passengers: string;
  childSeats: string;
  numCarSeats: string;
  kidsAge: string;
  vehicleRequested: string;
  tripType: string;
  pickupAddress: string;
  dropoffAddress: string;
  dateOfPickup: string;
  timeOfPickup: string;
  returnDate: string;
  returnTime: string;
  returnPickupAddress: string;
  returnDropoffAddress: string;
};

export const submitQuoteToCRM = async (data: QuoteFormData) => {
  // Submit to external tracking endpoint — captures form submission, creates contact/lead, and logs all custom fields
  const trackingPayload = {
    type: "external_form_submission",
    timestamp: Date.now(),
    formId: CRM_CONFIG.formId,
    formData: {
      first_name: data.firstName,
      last_name: data.lastName,
      email: data.email,
      phone: data.phone,
    },
    formLabels: {
      first_name: "First Name",
      last_name: "Last Name",
      email: "Email",
      phone: "Phone",
    },
    url: window.location.href,
    title: document.title,
    path: window.location.pathname,
    userAgent: navigator.userAgent,
    trackingId: CRM_CONFIG.trackingId,
    locationId: CRM_CONFIG.locationId,
    projectId: CRM_CONFIG.projectId,
    sessionId: crypto.randomUUID(),
    properties: {
      deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent)
        ? "mobile"
        : "desktop",
      source: "ai_studio",
      projectId: CRM_CONFIG.projectId,
      formName: "Addison Limos Website Form - Copy",
    },
  };

  await postTrackingEvent(trackingPayload, {
    customFields: {
      mGdJADvY89TGko5eCKy7: {
        value: data.quoteOrReservation,
        label: "Quote or Reservation",
      },
      x1YU7UVf6ckYnarvdlUQ: {
        value: data.newOrExisting,
        label: "New or Existing Customer",
      },
      L3hnJfT44Qg3EYZL7j1v: {
        value: data.passengers,
        label: "How Many Passengers",
      },
      jN6xyqaLZbibc0ZuLD3K: {
        value: data.childSeats,
        label: "Need Child Car Seats",
      },
      sfxy2NxVeoZdp0lfxwo3: {
        value: data.numCarSeats,
        label: "Number of Car Seats",
      },
      lAhA8pMlyIJ1iMoDHw1Y: { value: data.kidsAge, label: "Kids Age" },
      GjBpPhDrMPUk2KOYCzuf: {
        value: data.vehicleRequested,
        label: "Vehicle Requested",
      },
      mL0dRw8WiUILXYINqTje: {
        value: data.tripType,
        label: "Trip Type",
      },
      tGgdaZWV1LMrV8efnse9: {
        value: data.pickupAddress,
        label: "Initial Pickup Address",
      },
      NrpBGSUrEPwUnkPvdt9T: {
        value: data.dropoffAddress,
        label: "Initial Drop Off Address",
      },
      cHetRbT2poaIfiiyJk0O: {
        value: data.dropoffAddress,
        label: "Dropoff Address",
      },
      RLseVtL867s9RRWzmZAl: {
        value: data.dateOfPickup,
        label: "Date of Pickup",
      },
      GAcplVGT6Y5CzLdh5sgD: {
        value: data.timeOfPickup,
        label: "Time of Pickup",
      },
      RjRvUbmVvhOLRcybr0ef: {
        value: data.returnDate,
        label: "Return Date of Pickup",
      },
      Dbs1liDJNus890c3ZqLJ: {
        value: data.returnTime,
        label: "Return Time of Pickup",
      },
      mnwPfv8kzcJpHhfRE3Na: {
        value: data.returnPickupAddress,
        label: "Return Pickup Address",
      },
      ERMDPmChU9wDouonlNvZ: {
        value: data.returnDropoffAddress,
        label: "Return Dropoff Address",
      },
      contact_gclid: {
        value: getGclid(),
        label: "GCLID",
      },
    },
  });
};

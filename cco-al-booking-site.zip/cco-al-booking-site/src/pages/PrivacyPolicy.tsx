import { Link } from "react-router-dom";
import { SEOHead } from "@/components/SEOHead";

const PrivacyPolicy = () => {
  return (
    <div className="min-h-screen bg-background pt-32 pb-24">
      <SEOHead
        title="Privacy Policy"
        description="Addison Xpress Car & Limo Service's Privacy Policy."
        canonical="https://addisonlimos.com/privacy-policy"
      />
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-4xl md:text-5xl font-serif font-bold text-white mb-8">
          Addison Xpress Car & Limo Service's
          <br />
          <span className="text-primary">Privacy Policy</span>
        </h1>
        <div className="prose prose-invert prose-lg max-w-none text-white/70 font-light leading-relaxed space-y-6">
          <p>
            This privacy policy ("Policy") explains how Addison Limos ("We",
            "Us", or "Our") collects, uses, shares, and protects personal
            information that we collect from you ("You") when you use
            https://addisonlimos.com ("Website").
          </p>

          <h2 className="text-2xl font-serif font-bold text-white mt-8 mb-4">
            1. Information We Collect
          </h2>
          <p>
            We collect information about you in a range of forms, including
            personal data. As used in this Policy, “personal data” is as defined
            in the General Data Protection Regulation, this includes any
            information which, either alone or in combination with other
            information we process about you, identifies you as an individual,
            including, for example, your name, postal address, email address,
            and telephone number.
          </p>

          <h2 className="text-2xl font-serif font-bold text-white mt-8 mb-4">
            2. How We Use Your Information
          </h2>
          <p>
            We use the information we collect for several purposes, including:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>To provide, maintain, improve, and expand our Website.</li>
            <li>To understand and analyze how you use our Website.</li>
            <li>
              To develop new products, services, features, and functionality.
            </li>
            <li>
              To communicate with you, either directly or through one of our
              partners, for customer service, to provide you with updates and
              other information relating to the Website, and for marketing and
              promotional purposes.
            </li>
          </ul>

          <h2 className="text-2xl font-serif font-bold text-white mt-8 mb-4">
            3. How We Share Your Information
          </h2>
          <p>
            We may share the information that we collect in various ways,
            including:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              With vendors, consultants, and other service providers who need
              access to such information to carry out work on our behalf.
            </li>
            <li>
              In response to a request for information if we believe disclosure
              is in accordance with any applicable law, regulation, or legal
              process.
            </li>
            <li>
              If we believe your actions are inconsistent with our user
              agreements or policies, or to protect the rights, property, and
              safety of Addison Limos or others.
            </li>
          </ul>

          <h2 className="text-2xl font-serif font-bold text-white mt-8 mb-4">
            4. How We Protect Your Information
          </h2>
          <p>
            We care about the security of your information and employ physical,
            administrative, and technological safeguards designed to preserve
            the integrity and security of all information collected through our
            Website. However, no security system is impenetrable and we cannot
            guarantee the security of our systems 100%.
          </p>

          <h2 className="text-2xl font-serif font-bold text-white mt-8 mb-4">
            5. Children's Privacy
          </h2>
          <p>
            Our Website is not intended for use by children under the age of 13
            and we do not knowingly collect or use personal information from
            children under 13.
          </p>

          <h2 className="text-2xl font-serif font-bold text-white mt-8 mb-4">
            6. Your Rights
          </h2>
          <p>
            Depending on your country or region, you may have certain rights
            regarding your personal information. These could include the right
            to access, correct, delete, or restrict the use of your personal
            information, or object to certain uses of your personal information.
          </p>

          <h2 className="text-2xl font-serif font-bold text-white mt-8 mb-4">
            7. Changes to This Privacy Policy
          </h2>
          <p>
            We may amend this Policy from time to time. We will post any changes
            to this Policy on our Website, and the changes become effective from
            the date they are posted on the Website.
          </p>

          <h2 className="text-2xl font-serif font-bold text-white mt-8 mb-4">
            8. Contact Us
          </h2>
          <p>
            If you have any questions about this Policy, please contact us at{" "}
            <a
              href="mailto:sunny@addisonlimos.com"
              className="text-primary hover:underline"
            >
              sunny@addisonlimos.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;

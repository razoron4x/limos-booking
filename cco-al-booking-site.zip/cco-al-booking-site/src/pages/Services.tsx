import { Link } from "react-router-dom";
import { SEOHead } from "@/components/SEOHead";
import {
  Clock,
  Shield,
  Star,
  Trophy,
  Users,
  Ticket,
  Music,
  Gift,
  Map,
  Lightbulb,
  MapPin,
  Crown,
  Bus,
  HeartPulse,
  Heart,
  Wine,
  Ghost,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const services = [
  {
    title: "Halloween Night Limo Service",
    desc: "Premium Halloween night transportation for costume galas, haunted nights out, bar crawls, and private parties across DFW. Arrive in style and ride home safe.",
    icon: Ghost,
    link: "/service-halloween",
    cta: "Learn More",
  },
  {
    title: "Airport Transfers & Shuttle",
    desc: "Dedicated FBO staging and real-time flight tracking for DFW International, Dallas Love Field, and Addison Airport (ADS). Experience seamless, stress-free arrivals and departures.",
    icon: Clock,
    link: "/service-airport",
    cta: "Learn More",
  },

  {
    title: "Special Events & Celebrations",
    desc: "Tailored luxury packages for weddings, proms, homecomings, concerts, and milestone birthday parties. Make your entrance as memorable as the event itself.",
    icon: Star,
    link: "/service-events",
    cta: "Learn More",
  },
  {
    title: "Wedding Chauffeur",
    desc: "Make your special day unforgettable with our luxury wedding transportation. Elegant limousines, professional chauffeurs, and flawless coordination for your Dallas wedding.",
    icon: Heart,
    link: "/service-wedding",
    cta: "Learn More",
  },
  {
    title: "Group Transportation",
    desc: "Spacious and comfortable travel solutions for large parties. Whether it's a corporate retreat, family reunion, or group outing, our Sprinter vans and buses ensure everyone travels together in luxury.",
    icon: Users,
    link: "/service-group",
    cta: "Learn More",
  },
  {
    title: "Sporting Events & Concerts",
    desc: "Skip the parking hassle and arrive at the game or show like a VIP. Premium tailgating transport, stadium transfers, and concert limousine services.",
    icon: Ticket,
    link: "/service-sporting-concerts",
    cta: "Learn More",
  },
  {
    title: "Birthday Services",
    desc: "Celebrate another year in absolute style. From intimate luxury sedans to party-ready stretch limos, we provide the perfect ride for unforgettable birthday celebrations.",
    icon: Gift,
    link: "/service-birthday",
    cta: "Learn More",
  },
  {
    title: "City Tours",
    desc: "Discover the best of Dallas-Fort Worth from the comfort of a luxury vehicle. Customized itineraries covering historical landmarks, cultural districts, and premium dining spots.",
    icon: Map,
    link: "/service-city-tours",
    cta: "Learn More",
  },
  {
    title: "Wine Tours",
    desc: "Sip and savor Texas wine country in luxury. Private chauffeur-driven vineyard tours with safe, stylish round-trip transportation from DFW.",
    icon: Wine,
    link: "/service-wine-tours",
    cta: "Learn More",
  },
  {
    title: "Holiday Light Tours",
    desc: "Experience the magic of the holiday season with private, chauffeur-driven tours of the most spectacular festive light displays across the DFW metroplex.",
    icon: Lightbulb,
    link: "/service-holiday-lights",
    cta: "Learn More",
  },
  {
    title: "Point to Point",
    desc: "Direct, uninterrupted luxury travel from your exact location to your destination. Transparent flat-rate pricing and guaranteed punctuality for any distance.",
    icon: MapPin,
    link: "/service-point-to-point",
    cta: "Learn More",
  },
  {
    title: "VIP Service",
    desc: "Discreet, high-security transportation for celebrities, dignitaries, and high-net-worth individuals. Featuring privacy partitions and specially trained executive protection chauffeurs.",
    icon: Crown,
    link: "/service-vip",
    cta: "Learn More",
  },
  {
    title: "Shuttle Service",
    desc: "Reliable, recurring or one-time shuttle solutions for employee commutes, hotel guests, convention attendees, or campus transportation needs.",
    icon: Bus,
    link: "/service-shuttle",
    cta: "Learn More",
  },
  {
    title: "Medical & Donor Transport",
    desc: "Discreet, time-critical, and comfortable transportation for patients, medical professionals, and organ donor transfers.",
    icon: HeartPulse,
    link: "/service-medical-transport",
    cta: "Learn More",
  },
  {
    title: "Funeral & Family Services",
    desc: "Respectful, elegant, and reliable transportation services for funerals, including stretch limousine and family transport.",
    icon: Heart,
    link: "/service-funeral",
    cta: "Learn More",
  },
];

const Services = () => {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/30 pt-32 pb-24">
      <SEOHead
        title="Luxury Transportation Services | Addison Limos"
        description="Explore our comprehensive range of luxury ground transportation services in Dallas, including airport transfers, corporate travel, weddings, and special events."
        canonical="https://addisonlimos.com/services"
      />

      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6">
            Our Services
          </h1>
          <p className="text-xl text-white/60 max-w-3xl mx-auto font-light leading-relaxed">
            From executive airport transfers to unforgettable milestone
            celebrations, our premium fleet and professional chauffeurs provide
            tailored transportation solutions designed to exceed the
            expectations of the most discerning travelers.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Link
              key={index}
              to={service.link}
              className="flex flex-col p-5 border border-white/5 bg-zinc-900/40 hover:bg-zinc-900/80 transition-all duration-300 group cursor-pointer hover:border-primary/30 h-full"
            >
              <div className="w-12 h-12 bg-primary/10 flex items-center justify-center border border-primary/20 mb-4 group-hover:scale-110 transition-transform duration-300">
                <service.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-white font-serif group-hover:text-primary transition-colors mb-2 leading-tight">
                {service.title}
              </h3>
              <p className="text-white/60 leading-snug font-light text-sm mb-5 flex-grow">
                {service.desc}
              </p>
              <div className="inline-flex items-center text-primary font-medium group-hover:text-primary/80 transition-colors mt-auto text-sm">
                {service.cta} <ChevronRight className="w-4 h-4 ml-1" />
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-20 text-center">
          <h2 className="text-3xl font-serif font-bold text-white mb-6">
            Ready to Book Your Ride?
          </h2>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/quote"
              onClick={() => (window as any).gtag_report_conversion?.()}
            >
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg rounded-none h-14 px-10 shadow-[0_0_20px_rgba(212,175,55,0.2)] w-full sm:w-auto"
              >
                Get a Quote
              </Button>
            </Link>
            <a
              href="tel:9726083680"
              onClick={() => (window as any).gtag_report_conversion?.()}
            >
              <Button
                size="lg"
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground text-lg rounded-none h-14 px-10 w-full sm:w-auto"
              >
                Call Now
              </Button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;

import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { SEOHead } from "@/components/SEOHead";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Lock, ArrowLeft, Eye, EyeOff, User, Loader2 } from "lucide-react";
import { toast } from "sonner";

const STAFF_USERNAME = "limomorgan3";
const STAFF_PASSWORD = "addisonlimos9699";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast.error("Please enter your username and password.");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      if (username.trim() === STAFF_USERNAME && password === STAFF_PASSWORD) {
        toast.success(`Welcome back, ${STAFF_USERNAME}.`);
        navigate("/dashboard");
      } else {
        toast.error("Invalid username or password.");
      }
    }, 900);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 py-24">
      <SEOHead
        title="Staff Sign In"
        description="Addison Limos staff sign-in portal."
        noIndex
      />
      <div className="w-full max-w-md">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8 text-sm"
        >
          <ArrowLeft className="w-4 h-4" /> Back to portal
        </Link>
        <div className="border border-border bg-card p-8 sm:p-10">
          <div className="text-center mb-8">
            <div className="w-14 h-14 mx-auto flex items-center justify-center border border-primary/30 bg-primary/10 mb-5">
              <Lock className="w-7 h-7 text-primary" />
            </div>
            <h1 className="text-2xl font-serif font-bold text-foreground">
              Addison Limos Staff
            </h1>
            <p className="text-muted-foreground text-sm mt-1 font-light">
              Sign in to the booking portal
            </p>
          </div>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-foreground">
                Username
              </Label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your username"
                  className="rounded-none bg-transparent border-border pl-10"
                  autoComplete="username"
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-foreground">
                  Password
                </Label>
                <button
                  type="button"
                  onClick={() =>
                    toast.info(
                      "Contact dispatch to reset your portal password.",
                    )
                  }
                  className="text-xs text-muted-foreground hover:text-primary transition-colors"
                >
                  Forgot?
                </button>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="rounded-none bg-transparent border-border pr-11"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-none h-12"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Signing in…
                </>
              ) : (
                "Sign In"
              )}
            </Button>
          </form>
          <p className="text-xs text-muted-foreground text-center mt-6 font-light">
            Authorized Addison Limos personnel only. All activity is logged.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;

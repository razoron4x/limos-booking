import { SEOHead } from "@/components/SEOHead";
import { PrivateCarHero } from "@/components/PrivateCarHero";
import { PrivateCarSections } from "@/components/PrivateCarSections";
import { PrivateCarFleetAndReviews } from "@/components/PrivateCarFleetAndReviews";
import { PrivateCarFaqAndCta } from "@/components/PrivateCarFaqAndCta";

const ogImage =
  "https://vibe.filesafe.space/1792719026995615993/assets/f363bfea-960a-4e61-ae98-b3d6e7b23870.png";

const faqs = [
  {
    question: "What's included in private car service?",
    answer:
      "Private car service includes a professionally uniformed chauffeur, luxury vehicle of your choice, complimentary bottled water, climate control to your preference, real-time GPS tracking, flight monitoring for airport pickups, and door-to-door service with luggage assistance.",
  },
  {
    question: "How is this different from a regular taxi or rideshare?",
    answer:
      "Unlike taxis or rideshares, our private car service provides a pre-booked dedicated vehicle and chauffeur who arrives early, never surge-prices, maintains consistent luxury standards, offers flight tracking for seamless airport transfers, and provides a discreet, professional experience with no shared rides or unexpected stops.",
  },
  {
    question: "What vehicles are available for private car service?",
    answer:
      "Our fleet includes Lincoln Navigator SUVs for executive comfort, Chrysler 300 Stretch Limos for special occasions, Mercedes Sprinter Executive vans for group travel, and Mercedes Sprinter Limos for larger parties. All vehicles feature premium leather interiors, ambient lighting, and climate control.",
  },
  {
    question: "Do you offer hourly or flat-rate pricing?",
    answer:
      "We offer both options. Hourly rates are ideal for multi-stop itineraries, events, or when you need a dedicated driver for several hours. Flat-rate point-to-point pricing is perfect for airport transfers, one-way trips, or known routes with no surprises at payment.",
  },
  {
    question: "Can I book recurring transportation?",
    answer:
      "Absolutely. Many clients set up weekly or daily schedules for commutes, client transport, or executive travel. We offer corporate accounts with consolidated billing, automated scheduling, and dedicated account management for recurring needs.",
  },
  {
    question: "What areas do you serve?",
    answer:
      "We provide private car service across the entire Dallas-Fort Worth metroplex including Dallas, Fort Worth, Addison, Plano, Frisco, Irving, Grapevine, Arlington, Richardson, McKinney, and all surrounding cities. We also serve DFW International Airport, Dallas Love Field, and Addison Airport.",
  },
  {
    question: "How far in advance should I book?",
    answer:
      "While we can often accommodate same-day requests depending on availability, we recommend booking at least 24 hours in advance for standard reservations. For airport transfers during peak travel times, special events, or holidays, booking 3-5 days ahead ensures your preferred vehicle and time slot.",
  },
  {
    question: "What happens if my flight is delayed or cancelled?",
    answer:
      "We monitor all flights in real-time using advanced tracking systems. If your flight is delayed, we automatically adjust your pickup time at no extra charge. For cancellations, we offer flexible rescheduling. You never pay for waiting time caused by airline delays.",
  },
  {
    question: "Can I make special requests for my ride?",
    answer:
      "Yes. We accommodate preferences like vehicle type, child seats, specific temperature settings, preferred routes, multiple stops, or privacy partitions for executive clients. Add any notes during booking or call us directly to arrange personalized details.",
  },
];

const PrivateCarService = () => {
  return (
    <div className="min-h-screen bg-white text-zinc-900 font-sans selection:bg-primary/30">
      <SEOHead
        title="Private Car Service Dallas | Luxury Chauffeur & Driver"
        description="Premium private car service in Dallas-Fort Worth. Dedicated luxury vehicle, professional chauffeur, flat-rate pricing, and 24/7 availability. Book your private driver today."
        canonical="https://addisonlimos.com/service-private-car"
        ogImage={ogImage}
        schemaJson={{
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "Service",
              name: "Private Car Service Dallas",
              provider: {
                "@type": "LimousineService",
                name: "Addison Limos",
                telephone: "972-608-3680",
                url: "https://addisonlimos.com",
              },
              areaServed: [
                { "@type": "City", name: "Dallas" },
                { "@type": "City", name: "Fort Worth" },
                { "@type": "City", name: "Addison" },
                { "@type": "City", name: "Plano" },
                { "@type": "City", name: "Frisco" },
                { "@type": "City", name: "Irving" },
              ],
              serviceType: "PrivateCarService",
            },
          ],
        }}
      />

      <PrivateCarHero />

      <PrivateCarSections />

      <PrivateCarFleetAndReviews />

      <PrivateCarFaqAndCta faqs={faqs} />
    </div>
  );
};

export default PrivateCarService;

import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { SEOHead } from "@/components/SEOHead";

const ThankYou = () => {
  useEffect(() => {
    if (typeof (window as any).gtag_report_conversion === "function") {
      (window as any).gtag_report_conversion();
    }
  }, []);

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center p-4">
      <SEOHead
        title="Thank You"
        description="Your request has been successfully submitted."
        noIndex={true}
      />
      <div className="text-center max-w-md bg-zinc-900/50 border border-white/10 p-12 backdrop-blur-sm relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary/20 via-primary to-primary/20"></div>
        <CheckCircle className="w-16 h-16 text-primary mx-auto mb-6" />
        <h1 className="text-4xl font-serif font-bold text-white mb-4">
          Thank You
        </h1>
        <p className="text-white/70 font-light mb-8 text-lg">
          Your request has been successfully submitted. Our concierge team will
          review your details and contact you shortly.
        </p>
        <Link to="/">
          <Button
            size="lg"
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-none h-14 shadow-[0_0_20px_rgba(212,175,55,0.2)]"
          >
            Return to Home
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default ThankYou;

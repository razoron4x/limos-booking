import { Link } from "react-router-dom";
import { SEOHead } from "@/components/SEOHead";

const DrugAlcoholPolicy = () => {
  return (
    <div className="min-h-screen bg-background pt-32 pb-24">
      <SEOHead
        title="Drug and Alcohol Policy"
        description="Addison Xpress Car & Limo Service's Drug and Alcohol Policy."
        canonical="https://addisonlimos.com/drug-alcohol-policy"
      />
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-4xl md:text-5xl font-serif font-bold text-white mb-8">
          Addison Xpress Car & Limo Service's
          <br />
          <span className="text-primary">Drug and Alcohol Policy</span>
        </h1>
        <div className="prose prose-invert prose-lg max-w-none text-white/70 font-light leading-relaxed space-y-6">
          <p>
            In Compliance with the Drug-Free workplace Act of 1988, Addison
            Xpress Car & Limo Service "Addison Limos" has a longstanding
            commitment to provide a safe, quality oriented and productive work
            environment consistent with the standards of the community in which
            the company operates. Alcohol and drug abuse poses a threat to the
            health and safety of Addison Xpress Car & Limo Service "Addison
            Limos" employees and to the security of the company's equipment and
            facilities. For these reasons, Addison Xpress Car & Limo Service
            "Addison Limos" is committed to the elimination of drug and alcohol
            use in the workplace.
          </p>
        </div>
      </div>
    </div>
  );
};

export default DrugAlcoholPolicy;

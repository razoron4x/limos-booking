import { SEOHead } from "@/components/SEOHead";
import { HomeHeroSection } from "@/components/HomeHero";
import { PortalFeatures } from "@/components/PortalFeatures";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Lock, ArrowRight } from "lucide-react";

const PortalAccess = () => (
  <section className="relative border-t border-border bg-background py-24">
    <div className="container mx-auto px-4">
      <div className="max-w-2xl mx-auto text-center border border-border bg-card p-10 sm:p-14">
        <div className="w-14 h-14 mx-auto flex items-center justify-center border border-primary/30 bg-primary/10 mb-6">
          <Lock className="w-7 h-7 text-primary" />
        </div>
        <h2 className="text-2xl sm:text-3xl font-serif font-bold text-foreground mb-3">
          Authorized Personnel Only
        </h2>
        <p className="text-muted-foreground font-light mb-8">
          This portal is restricted to Addison Limos staff. Use your dispatch
          credentials to sign in. Need an account? Contact the operations team.
        </p>
        <Link to="/login" className="inline-block">
          <Button
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-none h-12 px-8"
          >
            Sign In
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </Link>
      </div>
    </div>
  </section>
);

const Index = () => {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      <SEOHead
        title="Staff Booking Portal"
        description="Addison Limos internal staff booking and dispatch portal. Authorized personnel only."
      />
      <HomeHeroSection />
      <PortalFeatures />
      <PortalAccess />
    </div>
  );
};

export default Index;

import FootballMosaic from "@/components/FootballMosaic";
import FootballWhyChoose from "@/components/FootballWhyChoose";
import FootballReviews from "@/components/FootballReviews";
import FootballExploreOptions from "@/components/FootballExploreOptions";
import { FootballQuoteForm } from "@/components/FootballQuoteForm";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Trophy,
  Users,
  Clock,
  Star,
  ChevronRight,
  ArrowLeft,
  Phone,
  MapPin,
} from "lucide-react";
import { Link } from "react-router-dom";
import { vehicles } from "@/data/vehicles";
import { SEOHead } from "@/components/SEOHead";
import CompactServiceArea from "@/components/CompactServiceArea";

const faqs = [
  {
    question:
      "What stadiums and venues does Addison Limos serve for football games?",
    answer:
      "We provide football group transportation to AT&T Stadium (Dallas Cowboys), Cotton Bowl Stadium, Ford Center in Frisco, and every major DFW football venue. Our chauffeurs know the best VIP drop-off points, tailgate access roads, and post-game pickup zones to keep your group moving.",
  },
  {
    question:
      "How many passengers can your football transportation accommodate?",
    answer:
      "Our fleet handles groups of any size. The H2 Hummer limo seats 14–18 passengers, the Mercedes Sprinter Limo holds 12–14, and our Mercedes Sprinter Vans carry larger squads. For entire teams, booster clubs, or corporate groups, we coordinate multiple vehicles so everyone arrives together.",
  },
  {
    question: "Can we tailgate or pre-game inside the vehicle?",
    answer:
      "Absolutely. Our Hummer and Sprinter limos feature surround sound, LED lighting, wet bars, and cooler bins. Perfect for building team spirit on the way to the stadium. Your group can start the celebration the moment you step onboard.",
  },
  {
    question: "Do you handle post-game pickup after the game ends?",
    answer:
      "Yes. We coordinate a pre-arranged pickup time and location so your chauffeur is waiting the moment the final whistle blows. No surge pricing, no waiting in rideshare lines, and no navigating packed parking lots. Just a comfortable ride home.",
  },
  {
    question: "How far in advance should I book football game transportation?",
    answer:
      "Football season is our busiest time. We recommend booking at least 2 to 3 weeks in advance for Cowboys home games, college matchups, and playoff events. Same-day requests are accommodated whenever the fleet allows. Call 972-608-3680 for availability.",
  },
  {
    question:
      "Is football group transportation available for youth and school teams?",
    answer:
      "Yes. We transport youth leagues, high school teams, booster clubs, and traveling fan groups with the same professional chauffeurs and safety standards. Parents and coaches appreciate the reliable, supervised door-to-door service.",
  },
];

const ServiceFootball = () => {
  return (
    <div className="min-h-screen bg-[#0d0d0d] text-foreground font-sans selection:bg-primary/30">
      <SEOHead
        title="Football Group Transportation | Addison Limos"
        description="Premium football group transportation in Dallas-Fort Worth. Luxury limos and Sprinter vans for Cowboys games, tailgating, and team travel. Book your game-day ride today."
        canonical="https://addisonlimos.com/service-football"
        schemaJson={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "Football Group Transportation",
          provider: {
            "@type": "LocalBusiness",
            name: "Addison Limos",
            telephone: "972-608-3680",
            address: {
              "@type": "PostalAddress",
              addressLocality: "Addison",
              addressRegion: "TX",
              postalCode: "75001",
              addressCountry: "US",
            },
          },
          areaServed: "Dallas-Fort Worth Metroplex",
          description:
            "Premium football group transportation for Cowboys games, tailgating, team travel, and fan groups across DFW.",
        }}
      />

      {/* Header Section */}
      <section className="pt-20 pb-16 px-4 relative border-b border-white/5 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-b from-primary/10 to-transparent pointer-events-none"></div>
        <div className="absolute inset-0 z-0 opacity-20">
          <img
            src="https://vibe.filesafe.space/1792719026995615993/assets/1e2d4c78-44ea-4385-a5a5-6c4b7a9c9038.png"
            alt="Football group transportation at stadium"
            className="w-full h-full object-cover"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0d0d0d] via-[#0d0d0d]/80 to-transparent"></div>
        </div>
        <div className="container mx-auto relative z-10">
          <Link
            to="/services"
            className="inline-flex items-center text-white/60 hover:text-primary transition-colors mb-8 group"
          >
            <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Services
          </Link>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-3xl flex flex-col">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/15 border border-primary/30 mb-6 self-start">
                <Trophy className="w-4 h-4 text-primary" />
                <span className="text-xs font-bold tracking-widest uppercase text-primary">
                  Football Season Special
                </span>
              </div>
              <div className="order-2 md:order-1 mt-6 md:mt-0">
                <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-white mb-6 leading-tight">
                  Football Group
                  <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-yellow-400 to-primary">
                    Transportation
                  </span>
                </h1>
                <p className="text-lg md:text-xl text-white/70 font-medium leading-relaxed italic">
                  The right ride for any crew. Pro chauffeurs, zero stress. Game
                  day handled.
                </p>
              </div>
            </div>
            <Link to="/quote?service=Football%20Group%20Transportation">
              <Button
                size="lg"
                className="bg-gradient-to-b from-yellow-500 via-primary to-yellow-600 text-black hover:from-yellow-400 hover:via-yellow-500 hover:to-yellow-500 text-lg rounded-none h-14 px-8 shadow-[0_0_25px_rgba(212,175,55,0.4)] whitespace-nowrap font-bold border border-yellow-400/40"
              >
                Book Your Ride
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <FootballQuoteForm />

      <FootballMosaic />

      {/* Why Fans Choose - Compact Trust Strip */}
      <section className="bg-zinc-900 border-y border-zinc-800 py-5">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { value: "24/7", label: "Game-Day Availability" },
              { value: "20+", label: "Years Serving DFW" },
              { value: "18", label: "Passengers Per Vehicle" },
              { value: "4.8★", label: "Average Rating" },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-2xl md:text-2xl font-serif font-bold text-primary leading-none mb-0.5">
                  {stat.value}
                </div>
                <div className="text-[10px] text-white/70 uppercase tracking-wider font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <FootballWhyChoose />

      {/* Recommended Fleet Section */}
      <section className="py-24 bg-[#0d0d0d] relative border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Built for Your Squad
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
              The most popular vehicles for football game day and tailgate
              transportation.
            </p>
          </div>

          <div className="relative py-12">
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>

            <p className="text-center text-sm text-white/40 mb-3 relative z-10">
              Tap the vehicle to expand
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10 max-w-6xl mx-auto">
              {[
                "h2-hummer-stretch-limo",
                "mercedes-sprinter-limo",
                "mercedes-sprinter-van",
              ]
                .map((id) => vehicles.find((v) => v.id === id))
                .filter(Boolean)
                .map((vehicle, i) => (
                  <Card
                    key={i}
                    className="bg-zinc-900/50 border-white/5 overflow-hidden group rounded-none relative"
                  >
                    <div className="aspect-[16/9] overflow-hidden relative group/carousel">
                      <Carousel opts={{ loop: true }} className="w-full h-full">
                        <CarouselContent className="h-full ml-0">
                          {vehicle.images.map((img, idx) => (
                            <CarouselItem
                              key={idx}
                              className="pl-0 h-full relative overflow-hidden"
                            >
                              <Link
                                to={`/fleet/${vehicle.id}`}
                                className="block w-full h-full cursor-pointer overflow-hidden"
                              >
                                <img
                                  src={img}
                                  alt={`${vehicle.title} view ${idx + 1}`}
                                  className={`w-full h-full transition-transform duration-1000 opacity-80 group-hover:opacity-100 group-hover:scale-105 ${vehicle.id === "luxury-black-stretch-limo" ? (idx === 1 ? "object-cover object-bottom -translate-y-6 sm:-translate-y-8" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-12 sm:-translate-y-16" : "object-cover object-center") : vehicle.id === "mercedes-sprinter-limo" ? (idx === 1 ? "object-cover object-bottom -translate-y-24 sm:-translate-y-40" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-8 sm:-translate-y-12" : "object-cover object-center") : vehicle.id === "mercedes-sprinter-van" ? (idx === 1 ? "object-cover object-bottom -translate-y-24 sm:-translate-y-40" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-8 sm:-translate-y-12" : "object-cover object-center") : "object-cover object-center"}`}
                                />
                              </Link>
                            </CarouselItem>
                          ))}
                        </CarouselContent>
                        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/50 to-transparent pointer-events-none z-10"></div>
                        <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                        <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                      </Carousel>
                    </div>
                    <CardContent className="absolute bottom-0 left-0 p-6 w-full z-30 pointer-events-none">
                      <h3 className="text-2xl font-serif font-bold text-white mb-2 group-hover:text-primary transition-colors drop-shadow-md">
                        <Link
                          to={`/fleet/${vehicle.id}`}
                          className="pointer-events-auto hover:text-primary transition-colors"
                        >
                          {vehicle.title}
                        </Link>
                      </h3>
                      <p className="text-sm text-white/70 font-light">
                        {vehicle.capacity}
                      </p>
                    </CardContent>
                  </Card>
                ))}
            </div>

            <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>
          </div>

          <div className="mt-10 flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/fleet" className="w-full sm:w-auto">
              <Button className="w-full h-14 bg-gradient-to-b from-zinc-800/40 to-zinc-950 border border-white/10 hover:border-primary/40 text-white text-base tracking-wide rounded-none group relative overflow-hidden transition-all duration-500 shadow-2xl hover:shadow-[0_0_30px_rgba(212,175,55,0.15)]">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
                <span className="relative z-10 flex items-center justify-center">
                  View Full Fleet
                  <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </span>
              </Button>
            </Link>
            <Link
              to="/quote?service=Football%20Group%20Transportation"
              className="w-full sm:w-auto"
            >
              <Button className="w-full h-14 bg-gradient-to-b from-yellow-500 via-primary to-yellow-600 text-black hover:from-yellow-400 hover:via-yellow-500 hover:to-yellow-500 text-base font-bold rounded-none shadow-[0_0_25px_rgba(212,175,55,0.3)] border border-yellow-400/40">
                Get a Quote
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Commitment & Chauffeurs Section */}
      <section className="py-24 px-4 bg-[#0d0d0d] relative border-t border-white/5">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16">
            <div className="space-y-6">
              <div className="aspect-[4/3] overflow-hidden border border-white/5 relative group rounded-xl">
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/attachments/da8cb189-97a1-4aab-a770-94af37245fd4.jpg"
                  alt="White H2 Hummer limo parked at AT&T Stadium for game day drop-off"
                  className="w-full h-full object-cover object-center opacity-80 group-hover:scale-105 transition-transform duration-700"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent"></div>
              </div>
              <h2 className="text-3xl font-serif font-bold text-white">
                Professional Game-Day Chauffeurs
              </h2>
              <p className="text-white/60 font-light leading-relaxed text-lg">
                Our experienced chauffeurs know every stadium access road, VIP
                gate, and post-game pickup zone in DFW. They handle the traffic,
                the parking, and the logistics so your group can focus on the
                game. Fully vetted, professionally uniformed, and committed to
                getting you there and back safely.
              </p>
            </div>

            <div className="space-y-6">
              <div className="aspect-[4/3] overflow-hidden border border-white/5 relative group rounded-xl">
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/assets/5ae05287-68b0-4384-80b3-b522851542b5.png"
                  alt="Mercedes Sprinter and Hummer limo at The Star Frisco"
                  className="w-full h-full object-cover object-center opacity-80 group-hover:scale-105 transition-transform duration-700"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent"></div>
              </div>
              <h2 className="text-3xl font-serif font-bold text-white">
                Tailgate in Style
              </h2>
              <p className="text-white/60 font-light leading-relaxed text-lg">
                Why wait until you reach the lot? Our Hummer and Sprinter limos
                come loaded with surround sound, LED lighting, wet bars, and
                cooler bins. Build team spirit on the ride over, then step out
                refreshed and ready at the VIP gate. Game day starts the moment
                you board.
              </p>
            </div>
          </div>

          <div className="mt-16 flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/quote?service=Football%20Group%20Transportation">
              <Button
                size="lg"
                className="w-full sm:w-auto bg-gradient-to-b from-yellow-500 via-primary to-yellow-600 text-black hover:from-yellow-400 hover:via-yellow-500 hover:to-yellow-500 text-lg rounded-none h-14 px-10 shadow-[0_0_25px_rgba(212,175,55,0.3)] font-bold border border-yellow-400/40"
              >
                Book Your Game-Day Ride
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <a
              href="tel:9726083680"
              onClick={() => (window as any).gtag_report_conversion?.()}
            >
              <Button
                size="lg"
                variant="outline"
                className="w-full sm:w-auto border-white/20 text-white hover:bg-white/10 text-lg rounded-none h-14 px-10 bg-transparent"
              >
                <Phone className="w-5 h-5 mr-3" />
                Call 972-608-3680
              </Button>
            </a>
          </div>
        </div>
      </section>

      <FootballReviews />

      {/* FAQ Section */}
      <section className="py-24 bg-zinc-950 border-t border-white/5">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Football Transportation FAQ
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
              Everything you need to know about booking football group
              transportation with Addison Limos.
            </p>
          </div>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, i) => (
              <AccordionItem
                key={i}
                value={`item-${i}`}
                className="border-white/10"
              >
                <AccordionTrigger className="text-left text-base sm:text-lg font-serif text-white hover:text-primary transition-colors">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-white/60 font-light leading-relaxed text-sm sm:text-base">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          <div className="text-center mt-12">
            <p className="text-white/60 mb-6 text-lg font-light">
              Ready to rally your crew?
            </p>
            <a
              href="tel:9726083680"
              className="inline-block"
              onClick={() => (window as any).gtag_report_conversion?.()}
            >
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-none px-8 h-12">
                <Phone className="w-4 h-4 mr-2" />
                Call 972-608-3680
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Venues We Serve */}
      <section className="py-20 bg-zinc-950 border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                DFW Football Venues
              </span>
            </div>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Venues We Serve
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
            {[
              {
                name: "AT&T Stadium",
                detail: "Dallas Cowboys home games & major events",
              },
              {
                name: "Cotton Bowl Stadium",
                detail: "Classic matchups & college football",
              },
              {
                name: "Ford Center, Frisco",
                detail: "High school & youth football championships",
              },
              {
                name: "Gerald J. Ford Stadium (SMU)",
                detail: "SMU Mustangs home games",
              },
              {
                name: "Amon G. Carter Stadium (TCU)",
                detail: "TCU Horned Frogs game days",
              },
              {
                name: "Custom Pickups",
                detail: "Watch parties, sports bars & private venues",
              },
            ].map((venue, i) => (
              <div
                key={i}
                className="p-6 border border-white/5 bg-zinc-900/40 hover:border-primary/30 hover:bg-zinc-900/60 transition-all duration-300 rounded-xl group"
              >
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-primary shrink-0 mt-1 group-hover:scale-110 transition-transform" />
                  <div>
                    <h3 className="text-lg font-serif font-bold text-white mb-1">
                      {venue.name}
                    </h3>
                    <p className="text-sm text-white/50 font-light">
                      {venue.detail}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <FootballExploreOptions />

      <CompactServiceArea />
    </div>
  );
};

export default ServiceFootball;

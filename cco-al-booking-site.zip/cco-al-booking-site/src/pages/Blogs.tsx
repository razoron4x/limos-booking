import { Link } from "react-router-dom";
import { blogs } from "@/data/blogs";
import { Calendar, User } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";

const Blogs = () => {
  return (
    <div className="min-h-screen bg-background pt-32 pb-24">
      <SEOHead
        title="Luxury Travel Journal"
        description="Insights, tips, and news from Dallas-Fort Worth's premier transportation service."
        canonical="https://addisonlimos.com/blogs"
      />
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-white mb-6">
            Luxury Travel <span className="text-primary">Journal</span>
          </h1>
          <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
            Insights, tips, and news from Dallas-Fort Worth's premier
            transportation service.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[...blogs]
            .sort(
              (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime(),
            )
            .map((blog) => (
              <Link
                key={blog.id}
                to={`/blogs/${blog.slug}`}
                className="group block bg-zinc-900/50 border border-white/5 hover:border-primary/30 transition-all overflow-hidden flex flex-col h-full"
              >
                <div className="aspect-video overflow-hidden">
                  <img
                    src={blog.imageUrl}
                    alt={blog.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="p-6 flex flex-col flex-1">
                  <div className="flex items-center gap-4 text-xs text-white/40 mb-4">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5" /> {blog.date}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5" /> {blog.author}
                    </span>
                  </div>
                  <h2 className="text-xl font-serif font-bold text-white mb-3 group-hover:text-primary transition-colors line-clamp-2">
                    {blog.title}
                  </h2>
                  <p className="text-white/60 text-sm leading-relaxed font-light line-clamp-3 mb-6 flex-1">
                    {blog.excerpt}
                  </p>
                  <div className="text-primary text-sm font-medium inline-flex items-center mt-auto">
                    Read Article{" "}
                    <span className="ml-1 group-hover:translate-x-1 transition-transform">
                      →
                    </span>
                  </div>
                </div>
              </Link>
            ))}
        </div>
      </div>
    </div>
  );
};

export default Blogs;

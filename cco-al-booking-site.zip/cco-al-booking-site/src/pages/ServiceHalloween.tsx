import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Ghost, ChevronRight, ArrowLeft, Phone, MapPin } from "lucide-react";
import { Link } from "react-router-dom";
import { vehicles } from "@/data/vehicles";
import { SEOHead } from "@/components/SEOHead";
import CompactServiceArea from "@/components/CompactServiceArea";
import HalloweenMosaic from "@/components/HalloweenMosaic";
import HalloweenWhyChoose from "@/components/HalloweenWhyChoose";
import HalloweenReviews from "@/components/HalloweenReviews";
import HalloweenVenues from "@/components/HalloweenVenues";
import HalloweenExploreOptions from "@/components/HalloweenExploreOptions";
import { HalloweenQuoteForm } from "@/components/HalloweenQuoteForm";

const faqs = [
  {
    question:
      "What types of vehicles do you offer for Halloween night transportation?",
    answer:
      "Our Halloween fleet includes the H2 Hummer Limo for crews of 14–18, the Chrysler 300 Stretch Limo for an intimate group, and Mercedes Sprinter Limos and Vans for larger parties. Every vehicle features premium sound systems, LED lighting, and plush leather seating so the fright night starts the moment you board.",
  },
  {
    question:
      "How many passengers can your Halloween transportation accommodate?",
    answer:
      "We handle Halloween groups of any size. The H2 Hummer limo holds 14–18, the Chrysler 300 stretch seats up to 10, and our Mercedes Sprinter Limos and Vans carry 12–14 or more. For entire friend groups or party crews, we coordinate multiple vehicles so everyone arrives together in style.",
  },
  {
    question:
      "Can we decorate the limo for a Halloween party or costume night?",
    answer:
      "Yes. We welcome tasteful Halloween decorations. Just let us know in advance so we can coordinate. Many of our groups add festive accents for the big night. We simply ask that decorations not damage the vehicle's interior or exterior.",
  },
  {
    question: "Do you handle late-night pickup after the Halloween event ends?",
    answer:
      "Absolutely. We coordinate a pre-arranged pickup time and location so your chauffeur is waiting the moment the party winds down. No surge pricing, no waiting in rideshare lines, and no navigating packed parking lots. Just a safe, comfortable ride home.",
  },
  {
    question:
      "How far in advance should I book Halloween night transportation?",
    answer:
      "Halloween is one of our busiest nights of the year. We recommend booking at least 2 to 3 weeks in advance to secure your preferred vehicle and time slot, especially for popular weekend nights. Same-day requests are accommodated whenever the fleet allows. Call 972-608-3680 for availability.",
  },
  {
    question:
      "Do you provide Halloween transportation for bar crawls and nightclub events?",
    answer:
      "Yes. We coordinate safe, stylish rides between multiple stops on a crawl, to nightclub Halloween nights in Deep Ellum and Uptown, and to private mansion parties across DFW. Your chauffeur handles every pickup so you can focus on the night.",
  },
];

const ServiceHalloween = () => {
  return (
    <div className="min-h-screen bg-[#0d0d0d] text-foreground font-sans selection:bg-primary/30">
      <SEOHead
        title="Halloween Limo & Transportation | Addison Limos"
        description="Premium Halloween night limousine and group transportation in Dallas-Fort Worth. Luxury limos and Sprinter vans for costume galas, haunted nights out, and Halloween parties. Book your fright-night ride today."
        canonical="https://addisonlimos.com/service-halloween"
        ogImage="https://vibe.filesafe.space/1792719026995615993/assets/d781ff2a-413a-47d3-a19d-87750b79734f.png"
        schemaJson={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "Halloween Limousine Transportation",
          provider: {
            "@type": "LocalBusiness",
            name: "Addison Limos",
            telephone: "972-608-3680",
            address: {
              "@type": "PostalAddress",
              addressLocality: "Addison",
              addressRegion: "TX",
              postalCode: "75001",
              addressCountry: "US",
            },
          },
          areaServed: "Dallas-Fort Worth Metroplex",
          description:
            "Premium Halloween night limousine and group transportation for costume galas, haunted nights out, and Halloween parties across DFW.",
        }}
      />

      {/* Header Section */}
      <section className="pt-20 pb-16 px-4 relative border-b border-white/5 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-b from-primary/10 to-transparent pointer-events-none"></div>
        <div className="absolute inset-0 z-0 opacity-20">
          <img
            src="https://vibe.filesafe.space/1792719026995615993/assets/e27b906c-967d-4ffb-ad48-d469bba7145d.png"
            alt="Black luxury limo at a Dallas Halloween night event drop-off"
            className="w-full h-full object-cover"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0d0d0d] via-[#0d0d0d]/80 to-transparent"></div>
        </div>
        <div className="container mx-auto relative z-10">
          <Link
            to="/service-events"
            className="inline-flex items-center text-white/60 hover:text-primary transition-colors mb-8 group"
          >
            <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Special Events
          </Link>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-3xl flex flex-col">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/15 border border-primary/30 mb-6 self-start">
                <Ghost className="w-4 h-4 text-primary" />
                <span className="text-xs font-bold tracking-widest uppercase text-primary">
                  Halloween Night Special
                </span>
              </div>
              <div className="order-2 md:order-1 mt-6 md:mt-0">
                <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-white mb-6 leading-tight">
                  Halloween
                  <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-yellow-400 to-primary">
                    Limousine Service
                  </span>
                </h1>
                <p className="text-lg md:text-xl text-white/70 font-medium leading-relaxed italic">
                  The ride makes the night. Zero stress, all thrills. Your
                  fright night elevated.
                </p>
              </div>
            </div>
            <Link to="/quote?service=Halloween%20Limo%20Service">
              <Button
                size="lg"
                className="bg-gradient-to-b from-yellow-500 via-primary to-yellow-600 text-black hover:from-yellow-400 hover:via-yellow-500 hover:to-yellow-500 text-lg rounded-none h-14 px-8 shadow-[0_0_25px_rgba(212,175,55,0.4)] whitespace-nowrap font-bold border border-yellow-400/40"
              >
                Book Your Ride
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <HalloweenQuoteForm />

      <HalloweenMosaic />

      {/* Why Families Choose - Compact Trust Strip */}
      <section className="bg-zinc-900 border-y border-zinc-800 py-5">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { value: "100%", label: "Vetted Chauffeurs" },
              { value: "20+", label: "Years Serving DFW" },
              { value: "18", label: "Passengers Per Vehicle" },
              { value: "4.8★", label: "Average Rating" },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-2xl md:text-2xl font-serif font-bold text-primary leading-none mb-0.5">
                  {stat.value}
                </div>
                <div className="text-[10px] text-white/70 uppercase tracking-wider font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <HalloweenWhyChoose />

      {/* Recommended Fleet Section */}
      <section className="py-24 bg-[#0d0d0d] relative border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Built for Your Crew
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
              The most popular vehicles for Halloween costume galas, party
              nights, and haunted outings.
            </p>
          </div>

          <div className="relative py-12">
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>

            <p className="text-center text-sm text-white/40 mb-3 relative z-10">
              Tap the vehicle to expand
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10 max-w-6xl mx-auto">
              {[
                "h2-hummer-stretch-limo",
                "luxury-black-stretch-limo",
                "mercedes-sprinter-limo",
              ]
                .map((id) => vehicles.find((v) => v.id === id))
                .filter(Boolean)
                .map((vehicle, i) => (
                  <Card
                    key={i}
                    className="bg-zinc-900/50 border-white/5 overflow-hidden group rounded-none relative"
                  >
                    <div className="aspect-[16/9] overflow-hidden relative group/carousel">
                      <Carousel opts={{ loop: true }} className="w-full h-full">
                        <CarouselContent className="h-full ml-0">
                          {vehicle.images.map((img, idx) => (
                            <CarouselItem
                              key={idx}
                              className="pl-0 h-full relative overflow-hidden"
                            >
                              <Link
                                to={`/fleet/${vehicle.id}`}
                                className="block w-full h-full cursor-pointer overflow-hidden"
                              >
                                <img
                                  src={img}
                                  alt={`${vehicle.title} view ${idx + 1}`}
                                  className={`w-full h-full transition-transform duration-1000 opacity-80 group-hover:opacity-100 group-hover:scale-105 ${vehicle.id === "luxury-black-stretch-limo" ? (idx === 1 ? "object-cover object-bottom -translate-y-6 sm:-translate-y-8" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-12 sm:-translate-y-16" : "object-cover object-center") : vehicle.id === "mercedes-sprinter-limo" ? (idx === 1 ? "object-cover object-bottom -translate-y-24 sm:-translate-y-40" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-8 sm:-translate-y-12" : "object-cover object-center") : "object-cover object-center"}`}
                                />
                              </Link>
                            </CarouselItem>
                          ))}
                        </CarouselContent>
                        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/50 to-transparent pointer-events-none z-10"></div>
                        <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                        <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                      </Carousel>
                    </div>
                    <CardContent className="absolute bottom-0 left-0 p-6 w-full z-30 pointer-events-none">
                      <h3 className="text-2xl font-serif font-bold text-white mb-2 group-hover:text-primary transition-colors drop-shadow-md">
                        <Link
                          to={`/fleet/${vehicle.id}`}
                          className="pointer-events-auto hover:text-primary transition-colors"
                        >
                          {vehicle.title}
                        </Link>
                      </h3>
                      <p className="text-sm text-white/70 font-light">
                        {vehicle.capacity}
                      </p>
                    </CardContent>
                  </Card>
                ))}
            </div>

            <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>
          </div>

          <div className="mt-10 flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/fleet" className="w-full sm:w-auto">
              <Button className="w-full h-14 bg-gradient-to-b from-zinc-800/40 to-zinc-950 border border-white/10 hover:border-primary/40 text-white text-base tracking-wide rounded-none group relative overflow-hidden transition-all duration-500 shadow-2xl hover:shadow-[0_0_30px_rgba(212,175,55,0.15)]">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
                <span className="relative z-10 flex items-center justify-center">
                  View Full Fleet
                  <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </span>
              </Button>
            </Link>
            <Link
              to="/quote?service=Halloween%20Limo%20Service"
              className="w-full sm:w-auto"
            >
              <Button className="w-full h-14 bg-gradient-to-b from-yellow-500 via-primary to-yellow-600 text-black hover:from-yellow-400 hover:via-yellow-500 hover:to-yellow-500 text-base font-bold rounded-none shadow-[0_0_25px_rgba(212,175,55,0.3)] border border-yellow-400/40">
                Get a Quote
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Commitment & Chauffeurs Section */}
      <section className="py-24 px-4 bg-[#0d0d0d] relative border-t border-white/5">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16">
            <div className="space-y-6">
              <div className="aspect-[4/3] overflow-hidden border border-white/5 relative group rounded-xl">
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/assets/19932b36-670d-47dc-b593-bfd7f26448ae.png"
                  alt="Chauffeur opening limo door for guests arriving at a Halloween event in Dallas"
                  className="w-full h-full object-cover object-center opacity-80 group-hover:scale-105 transition-transform duration-700"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent"></div>
              </div>
              <h2 className="text-3xl font-serif font-bold text-white">
                Professional Halloween Night Chauffeurs
              </h2>
              <p className="text-white/60 font-light leading-relaxed text-lg">
                Our experienced chauffeurs know every DFW venue, gala, haunted
                attraction, and nightlife district. They handle the traffic, the
                parking, and the timing so your group can focus on the night.
                Fully vetted, professionally uniformed, and committed to getting
                everyone there and home safely.
              </p>
            </div>

            <div className="space-y-6">
              <div className="aspect-[4/3] overflow-hidden border border-white/5 relative group rounded-xl">
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/assets/20741c21-4a2e-4a90-be6f-77196c6d9f14.png"
                  alt="Luxury limo interior with orange and purple LED lighting for a Halloween night out"
                  className="w-full h-full object-cover object-center opacity-80 group-hover:scale-105 transition-transform duration-700"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent"></div>
              </div>
              <h2 className="text-3xl font-serif font-bold text-white">
                Celebrate Onboard
              </h2>
              <p className="text-white/60 font-light leading-relaxed text-lg">
                Why wait until you reach the party? Our Hummer and Sprinter
                limos come loaded with surround sound, LED lighting, wet bars,
                and cooler bins. Build the Halloween hype on the ride over, then
                step out at the venue like the main event. Halloween starts the
                moment you board.
              </p>
            </div>
          </div>

          <div className="mt-16 flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/quote?service=Halloween%20Limo%20Service">
              <Button
                size="lg"
                className="w-full sm:w-auto bg-gradient-to-b from-yellow-500 via-primary to-yellow-600 text-black hover:from-yellow-400 hover:via-yellow-500 hover:to-yellow-500 text-lg rounded-none h-14 px-10 shadow-[0_0_25px_rgba(212,175,55,0.3)] font-bold border border-yellow-400/40"
              >
                Book Your Halloween Ride
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <a
              href="tel:9726083680"
              onClick={() => (window as any).gtag_report_conversion?.()}
            >
              <Button
                size="lg"
                variant="outline"
                className="w-full sm:w-auto border-white/20 text-white hover:bg-white/10 text-lg rounded-none h-14 px-10 bg-transparent"
              >
                <Phone className="w-5 h-5 mr-3" />
                Call 972-608-3680
              </Button>
            </a>
          </div>
        </div>
      </section>

      <HalloweenReviews />

      {/* FAQ Section */}
      <section className="py-24 bg-zinc-950 border-t border-white/5">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Halloween Transportation FAQ
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
              Everything you need to know about booking Halloween night
              limousine transportation with Addison Limos.
            </p>
          </div>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, i) => (
              <AccordionItem
                key={i}
                value={`item-${i}`}
                className="border-white/10"
              >
                <AccordionTrigger className="text-left text-base sm:text-lg font-serif text-white hover:text-primary transition-colors">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-white/60 font-light leading-relaxed text-sm sm:text-base">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          <div className="text-center mt-12">
            <p className="text-white/60 mb-6 text-lg font-light">
              Ready to own Halloween night?
            </p>
            <a
              href="tel:9726083680"
              className="inline-block"
              onClick={() => (window as any).gtag_report_conversion?.()}
            >
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-none px-8 h-12">
                <Phone className="w-4 h-4 mr-2" />
                Call 972-608-3680
              </Button>
            </a>
          </div>
        </div>
      </section>

      <HalloweenVenues />

      <HalloweenExploreOptions />

      <CompactServiceArea />
    </div>
  );
};

export default ServiceHalloween;

import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import {
  Phone,
  Briefcase,
  ChevronRight,
  Star,
  ArrowRight,
  MessageSquare,
} from "lucide-react";
import { Link } from "react-router-dom";
import { vehicles } from "@/data/vehicles";
import { SEOHead } from "@/components/SEOHead";
import CompactServiceArea from "@/components/CompactServiceArea";
import { CorporateHeroSection } from "@/components/CorporateHeroSection";
import { CorporateServicesOccasions } from "@/components/CorporateServicesOccasions";
import { CorporateAirportMosaic } from "@/components/CorporateAirportMosaic";
import { CorporateAccountsSection } from "@/components/CorporateAccountsSection";
import { CorporateFooterBadges } from "@/components/CorporateFooterBadges";
import { CorporateWhyChoose } from "@/components/CorporateWhyChoose";
import { CorporateOccasionsGrid } from "@/components/CorporateOccasionsGrid";

const ogImage =
  "https://vibe.filesafe.space/1792719026995615993/attachments/51e6ee25-b03c-4a29-9660-4da2bb28ed9e.webp";

const Corporate = () => {
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://link.dreamsapi.com/js/form_embed.js";
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return (
    <div className="min-h-screen bg-white text-zinc-900 font-sans selection:bg-primary/30">
      <SEOHead
        title="Corporate Travel & Executive Chauffeur | Addison Limos"
        description="Punctual, compliant, confidential executive chauffeur services in DFW. $1.5M+ commercial insurance, multi-account billing, real-time flight tracking, and simple corporate invoicing."
        canonical="https://addisonlimos.com/corporate"
        ogImage={ogImage}
        schemaJson={{
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "Service",
              name: "Corporate Travel & Executive Chauffeur Services",
              provider: {
                "@type": "LimousineService",
                name: "Addison Limos",
                telephone: "972-608-3680",
                url: "https://addisonlimos.com",
                address: {
                  "@type": "PostalAddress",
                  addressLocality: "Addison",
                  addressRegion: "TX",
                  postalCode: "75001",
                  addressCountry: "US",
                },
              },
              areaServed: [
                { "@type": "City", name: "Dallas" },
                { "@type": "City", name: "Fort Worth" },
                { "@type": "City", name: "Addison" },
                { "@type": "City", name: "Plano" },
                { "@type": "City", name: "Frisco" },
                { "@type": "City", name: "Irving" },
                { "@type": "City", name: "Grapevine" },
              ],
              serviceType: "Corporate Transportation",
              description:
                "Executive chauffeur services for C-suite executives, corporate guests, and business travel managers across the Dallas-Fort Worth metroplex.",
            },
            {
              "@type": "FAQPage",
              mainEntity: [
                {
                  "@type": "Question",
                  name: "Does Addison Limos offer corporate accounts with simple invoicing?",
                  acceptedAnswer: {
                    "@type": "Answer",
                    text: "Yes. We offer centralized corporate accounts with simple consolidated invoicing, monthly reporting, and multi-passenger booking from a single administrative dashboard.",
                  },
                },
                {
                  "@type": "Question",
                  name: "What insurance coverage does Addison Limos carry for corporate clients?",
                  acceptedAnswer: {
                    "@type": "Answer",
                    text: "We maintain $1.5M+ commercial liability insurance coverage, exceeding standard requirements for corporate duty-of-care compliance.",
                  },
                },
                {
                  "@type": "Question",
                  name: "Do you offer multi-account billing for corporate clients?",
                  acceptedAnswer: {
                    "@type": "Answer",
                    text: "Yes. We provide automated itemized electronic receipts post-ride and support multi-client billing with cost allocation by department, plus consolidated monthly statements for easy reconciliation.",
                  },
                },
                {
                  "@type": "Question",
                  name: "Do you offer meet and greet service at DFW International Airport?",
                  acceptedAnswer: {
                    "@type": "Answer",
                    text: "Yes. Our professional chauffeurs wait inside the terminal with digital name signs, handle luggage, and guide guests directly to the vehicle. We also provide real-time flight tracking with automatic pickup adjustments.",
                  },
                },
              ],
            },
          ],
        }}
      />

      {/* 1. HIGH-IMPACT EXECUTIVE HERO SECTION */}
      <CorporateHeroSection />

      {/* 2. CORPORATE AIRPORT MOSAIC */}
      <CorporateAirportMosaic />

      {/* 3. CORPORATE SERVICES FOR EVERY OCCASION */}
      <CorporateServicesOccasions />

      {/* 4. CENTRALIZED CORPORATE ACCOUNTS & BILLING */}
      <CorporateAccountsSection />

      {/* 5. WHY CHOOSE CORPORATE */}
      <CorporateWhyChoose />

      {/* 6. FLEET INTEGRATION & EXECUTIVE OPTIONS */}
      <section className="py-24 bg-zinc-50 relative border-t border-zinc-200">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Briefcase className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                Executive Fleet
              </span>
            </div>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-zinc-900 mb-6">
              Executive Vehicle Options
            </h2>
            <p className="text-zinc-600 max-w-2xl mx-auto text-xl font-normal">
              From solo executive travel to corporate group shuttles, our fleet
              is configured for productivity, comfort, and discretion.
            </p>
          </div>

          {/* Fleet Carousel */}
          <div className="relative py-12">
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent shadow-[0_0_12px_rgba(212,175,55,0.8)]"></div>
            <p className="text-center text-sm text-zinc-400 mb-3 relative z-10">
              Tap the vehicle to expand
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
              {[
                vehicles.find((v) => v.id === "lincoln-navigator-suv")!,
                vehicles.find((v) => v.id === "mercedes-sprinter-executive")!,
                vehicles.find((v) => v.id === "mercedes-sprinter-limo")!,
              ].map((vehicle, i) => (
                <Card
                  key={i}
                  className="bg-zinc-800 border-zinc-700 overflow-hidden group rounded-none relative"
                >
                  <div className="aspect-[16/9] overflow-hidden relative group/carousel">
                    <Carousel opts={{ loop: true }} className="w-full h-full">
                      <CarouselContent className="h-full ml-0">
                        {vehicle.images.map((img, idx) => (
                          <CarouselItem
                            key={idx}
                            className="pl-0 h-full relative"
                          >
                            <Link
                              to={`/fleet/${vehicle.id}`}
                              className="block w-full h-full cursor-pointer"
                            >
                              <img
                                src={img}
                                alt={`${vehicle.title} view ${idx + 1}`}
                                loading="lazy"
                                className={`w-full h-full transition-transform duration-1000 opacity-80 group-hover:opacity-100 group-hover:scale-105 ${
                                  vehicle.id === "luxury-black-stretch-limo"
                                    ? idx === 1
                                      ? "object-cover object-bottom -translate-y-6 sm:-translate-y-8"
                                      : idx === 2 || idx === 3
                                        ? "object-cover object-bottom -translate-y-12 sm:-translate-y-16"
                                        : "object-cover object-center"
                                    : vehicle.id === "mercedes-sprinter-limo" ||
                                        vehicle.id === "mercedes-sprinter-van"
                                      ? idx === 1
                                        ? "object-cover object-bottom -translate-y-24 sm:-translate-y-40"
                                        : idx === 2 || idx === 3
                                          ? "object-cover object-bottom -translate-y-8 sm:-translate-y-12"
                                          : "object-cover object-center"
                                      : "object-cover object-center"
                                }`}
                              />
                            </Link>
                          </CarouselItem>
                        ))}
                      </CarouselContent>
                      <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/50 to-transparent pointer-events-none z-10"></div>
                      <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                      <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                    </Carousel>
                  </div>
                  <CardContent className="absolute bottom-0 left-0 p-4 pb-2 sm:p-6 w-full z-30 pointer-events-none">
                    <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-1 group-hover:text-primary transition-colors drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                      <Link
                        to={`/fleet/${vehicle.id}`}
                        className="pointer-events-auto hover:text-primary transition-colors"
                      >
                        {vehicle.shortTitle}
                      </Link>
                    </h3>
                    <p className="text-sm text-white/80 font-light drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                      {vehicle.capacity}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent shadow-[0_0_12px_rgba(212,175,55,0.8)]"></div>
          </div>

          <div className="mt-10 flex justify-center">
            <Link to="/fleet" className="w-full max-w-sm">
              <Button className="w-full h-14 bg-gradient-to-r from-amber-200 via-yellow-500 to-amber-200 bg-[length:200%_100%] hover:bg-[position:100%_0] text-zinc-900 font-bold text-base tracking-wide rounded-none group relative overflow-hidden transition-all duration-500 shadow-2xl shadow-primary/20 hover:shadow-[0_0_30px_rgba(212,175,55,0.4)] border border-amber-300/50">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
                <span className="relative z-10 flex items-center justify-center">
                  View Full Fleet
                  <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </span>
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* 6. CORPORATE REVIEWS SLIDER */}
      <section className="py-24 bg-white border-t border-zinc-200">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-zinc-900 mb-6">
              Trusted by Corporate Clients
            </h2>
            <p className="text-zinc-600 max-w-2xl mx-auto text-xl font-normal">
              Corporate-grade reliability. White-glove execution. Addison Limos
              gets your team there every time.
            </p>

            {/* Award Badge */}
            <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full border border-zinc-300 bg-zinc-100 backdrop-blur-sm pl-5 pr-5 mb-6 mt-[50px]">
              <Star className="w-4 h-4 text-primary fill-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-zinc-700">
                Winner of Addison Magazine's Readers Choice Award
              </span>
            </div>

            {/* Stats Box - Compact */}
            <div className="flex flex-row items-center justify-center gap-6 sm:gap-8 bg-zinc-800 border border-zinc-700 p-2.5 sm:p-3 max-w-sm mx-auto backdrop-blur-sm">
              <div className="text-center flex-1">
                <div className="text-xl sm:text-2xl font-serif font-bold text-white mb-0.5">
                  4.8
                </div>
                <div className="flex items-center justify-center gap-0.5 mb-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-3 h-3 text-primary fill-primary"
                    />
                  ))}
                </div>
                <div className="text-[10px] text-white/70 uppercase tracking-wider font-medium">
                  Average Rating
                </div>
              </div>
              <div className="h-8 w-px bg-zinc-700"></div>
              <div className="text-center flex-1">
                <div className="text-xl sm:text-2xl font-serif font-bold text-white mb-0.5">
                  160+
                </div>
                <div className="text-[10px] text-white/70 uppercase tracking-wider font-medium mt-3">
                  Verified Reviews
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-10">
            {[
              {
                quote:
                  "As an executive assistant I have used Addison Limos multiple times for my executives and company guests. They have been phenomenal every time.",
                author: "Maliha Asalati",
                role: "Executive Assistant",
              },
              {
                quote:
                  "I have used Addison Limos twice to transport customers to and from business dinners. Both times the experience could not have been better. The Mercedes Sprinters were spotless and perfect for our groups.",
                author: "Amy O'Malley",
                role: "Corporate Client",
              },
              {
                quote:
                  "I have used Addison Limos multiple times for work events. Friendly, reliable, and great communication. They are my go-to for corporate travel.",
                author: "Andrea Woodworth",
                role: "Business Event Host",
              },
            ].map((review, i) => (
              <div
                key={i}
                className="bg-zinc-800 border border-zinc-700 p-8 shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(5)].map((_, idx) => (
                      <Star
                        key={idx}
                        className="w-4 h-4 text-primary fill-primary"
                      />
                    ))}
                  </div>
                  <p className="text-white/80 font-normal leading-relaxed text-base italic mb-6">
                    "{review.quote}"
                  </p>
                </div>
                <div className="border-t border-zinc-700 pt-4">
                  <div className="font-bold text-white text-base">
                    {review.author}
                  </div>
                  <div className="text-xs text-white/60 font-light">
                    {review.role}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-center">
            <Link to="/reviews">
              <Button
                variant="outline"
                className="border-zinc-300 bg-zinc-100 text-zinc-900 hover:bg-zinc-200 hover:text-zinc-900 font-bold px-8 h-12 rounded-none transition-all shadow-sm"
              >
                View All Reviews
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* 7. PERFECT FOR EVERY OCCASION GRID */}
      <CorporateOccasionsGrid />

      {/* 8. FINAL CTA & FOOTER INTEGRATION */}
      <section className="py-24 bg-zinc-900 border-t border-zinc-800">
        <div className="container mx-auto px-4">
          <div className="bg-zinc-900 border border-primary/30 p-12 md:p-20 text-center relative overflow-hidden backdrop-blur-sm">
            <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent"></div>
            <div className="relative z-10">
              <h2 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6">
                Elevate your company's travel standards today.
              </h2>
              <p className="text-2xl text-white/80 mb-10 max-w-2xl mx-auto font-medium">
                Set up your corporate account or call direct for immediate
                booking inquiries.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center px-2 sm:px-0">
                <Link
                  to="/quote?service=Corporate%20Account"
                  onClick={() => (window as any).gtag_report_conversion?.()}
                >
                  <Button
                    size="lg"
                    className="w-full sm:w-auto bg-primary text-primary-foreground hover:bg-primary/90 text-sm sm:text-lg rounded-none h-14 sm:h-16 px-4 sm:px-12 shadow-[0_0_20px_rgba(212,175,55,0.2)] text-center whitespace-normal"
                  >
                    <span className="sm:hidden">Get Quote Now</span>
                    <span className="hidden sm:inline">
                      Set Up Your Corporate Account
                    </span>
                    <ArrowRight className="w-5 h-5 ml-2 shrink-0" />
                  </Button>
                </Link>
                <a
                  href="tel:9726083680"
                  onClick={() => (window as any).gtag_report_conversion?.()}
                >
                  <Button
                    size="lg"
                    variant="outline"
                    className="w-full sm:w-auto border-white/20 text-white hover:bg-white/10 text-base sm:text-lg rounded-none h-14 sm:h-16 px-6 sm:px-12 bg-transparent backdrop-blur-sm transition-all text-center whitespace-nowrap"
                  >
                    <Phone className="w-5 h-5 mr-2 shrink-0" />
                    Call 972-608-3680
                  </Button>
                </a>
              </div>

              {/* License & Permit Badges */}
              <CorporateFooterBadges />
            </div>
          </div>
        </div>
      </section>

      <CompactServiceArea />
    </div>
  );
};

export default Corporate;

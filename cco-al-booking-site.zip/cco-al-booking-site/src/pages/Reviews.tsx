import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, Star, Award, MessageSquare } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";

const googleReviews = [
  {
    name: "Amy O'Malley",
    text: "I have used Addison Limos twice now to transport customers to and from business dinners in the Grapevine / Coppell area. Both times the experience could not have been better! The Mercedes Sprinters were spotless and perfect for our groups...",
  },
  {
    name: "Alli Enzo",
    text: "The customer service was amazing, from the first phone call to the final drop-off, you were treated like your reservation was the most important thing they needed to do that day. Our party had several major changes during the trip and they...",
  },
  {
    name: "Betty Becker",
    text: "Once again I cannot say enough good things about Addison car and Limo service. The communication is wonderful , pricing is competitive , car was immaculate and the drivers are fantastic. Dale met me at the airport today and what a genuinely...",
  },
  {
    name: "Michelle Corcoran",
    text: "Sunny and his team always take such good care of our needs, but he went over and above to help make my son and his friend’s prom experience awesome - being chauffeured around in a limo was the cherry on top! Big thanks also to Jessica for making the booking experience so easy.",
  },
  {
    name: "Thumbless Man",
    text: "I had an amazing experience with Addison Limos! From start to finish, everything was handled professionally and smoothly. The booking process was easy, and their customer service was responsive and helpful with all my questions...",
  },
  {
    name: "Center God",
    text: "Booked Addison Limos for prom and it was honestly one of the best decisions we made. The limo showed up right on time, super clean, and looked amazing. The driver was really chill but still professional, which made the whole experience even better. It made the night feel way more special. Definitely recommend for prom or any big event!",
  },
  {
    name: "ahmed",
    text: "We used Addison Limos for our wedding and everything was flawless. The driver was early, extremely professional, and made sure everything stayed on schedule. The vehicle was spotless and added such a classy touch to the day. Highly recommend for anyone planning a big event.",
  },
  {
    name: "Larry Bennett",
    text: "I had an exceptional experience with Dallas Black Car Service this weekend. They...",
  },
  {
    name: "Hadi Hassan",
    text: "I booked Addison Limos for a special date night and it completely elevated the experience. The ride was smooth, the car was spotless, and the driver was very respectful and professional. It added such a classy touch to the evening. Highly recommend if you want to make an occasion feel extra special",
  },
  {
    name: "Calvin Klien",
    text: "Booked a limo for my birthday and Addison Limos did not disappoint! The vibe was perfect, the car was super nice inside, and the driver made sure we had a great time the whole night. Everything felt safe, smooth, and well organized. 10/10 experience!",
  },
  {
    name: "GPT Buy",
    text: "We used Addison Limos for a corporate event and were very impressed. The service was punctual, professional, and well-coordinated. The vehicle was in excellent condition and provided a comfortable, upscale experience for our guests. Would absolutely use them again for future events.",
  },
  {
    name: "Ruth Rodriguez",
    text: "Exceptional customer service. Sonny saved me, my son needed a ride to his prom at the Perot Museum and came through! I am beyond grateful! Still in awe of how easy & smooth the process was. Thank you for the great service.",
  },
  {
    name: "Linda Patterson",
    text: "We have a lot of limo drivers. We travel a lot because of who my husband is in 21 years into doing this Sunny was our super best driver. I laughed all the way from the airport to the hotel. He’s a safe entertaining real person.",
  },
  {
    name: "TX3 MM",
    text: "Highly recommend! Limo arrived clean and on time. Limo Driver safely transported our large party to various spots and he was easy to reach for pick ups. Bottled water and a USB cable were provided and the riders enjoyed their special...",
  },
  {
    name: "Judy Viegas",
    text: "Denis was very professional and a great driver. The vehicle was very clean and roomy. We will definitely use Addison Limo Service again. They are very easy to work with.",
  },
  {
    name: "Micah Embrey",
    text: "WOW! Stop searching! These are the pros you want to book with! From the last minute, same day booking- to the express, door to door, VIP treatment- Addison Xpress Car & Limo are who you want to book with! Our driver, Amin- was extremely...",
  },
  {
    name: "Kelli Watkins",
    text: "We have used this company for many years and they will continue to be our go to car service in Dallas. Mr. Sunny and the staff are kind, helpful and aim to please. Thank you Addison Limos and Mr. Sunny, we appreciate you!",
  },
  {
    name: "Chris Randall",
    text: "Great experience! Driver was on time and sprinter limo was great! Clean and just as promised Driver was very friendly and accommodating...",
  },
  {
    name: "natalie malakieh",
    text: "I had an amazing experience with Addison Xpress Car & Limo Service! From start to finish, everything was seamless and professional. The booking process was easy, and their communication was clear and timely. …",
  },
  {
    name: "sheena P",
    text: "Excellent service! I secured a limo for my daughter and her friends for prom. Dale was a wonderful driver and even showed the kids how to operate the music for the duration of their ride. In addition, communication was top notch during …",
  },
  {
    name: "Bobby Elliott",
    text: "Our driver Deniz made our event happen. He was very punctual for every stop as we trekked across town. The Vehicle was very nice and clean as well.",
  },
  {
    name: "Justin Thompson",
    text: "Can’t say enough good things about this company. Was struggling to find an airport transfer for my family that included a toddler seat. After many phone calls and no luck with Uber or Lyft, Addison Xpress answered on the first ring, told me …",
  },
  {
    name: "Nicole Klasnick",
    text: "We had an excellent experience with Addison Xpress Car and Limo Service! The vans were clean and the drivers were professional and friendly. What stood out the most was how accommodating they were with our changing schedules. They remained …",
  },
  {
    name: "Sana Chaudhary",
    text: "Wonderful service! Very professional and prompt at responding to all my inquiries. I highly recommend their limo service and would definitely book with them again. For reference, I booked their Hummer limo. A beautiful and very clean vehicle.",
  },
  {
    name: "Rhonda Steer",
    text: "We thoroughly enjoyed our stretch Hummer experience. Professional, courteous driver with a great sense of humour.",
  },
  {
    name: "Jorge Cebollada",
    text: "Great service from Titus! Would definitly reccomend to everyone! Such a nice guy too! Thank you again! 🙂",
  },
  {
    name: "Phillip Nguyen",
    text: "Addison Limo provided shuttle service for my wedding guests this past memorial day weekend to and from our hotel and wedding venue. Booking was easy, quick, and response time via email and texting regarding questions I had during and after …",
  },
  {
    name: "manju valluri",
    text: "Jennifer was wonderful and great from chat to booking the trip. Very prompt and courteous. She helped me to find the best vehicle for my daughter’s sweet sixteen birthday. We will submit another review once after the service has been completed. Looking forward for the trip.",
  },
  {
    name: "patricia blakney",
    text: "No questions! Serino and Sonny were absolutely stupendous and 100 percent magnificent! We will definitely call upon you all again, especially for NEW YEARS, so keep us …",
  },
  {
    name: "Brett Bower",
    text: "Dale was a fantastic driver and was able to accommodate our every need. He was able to take us the scenic route to our destination and helped us get the music going. Would highly recommend booking with Addison Xpress",
  },
  {
    name: "Candice Hill",
    text: "Best of the best! We used them for my daughter’s prom and the driver, Thomas was so kind and took good care of my daughter and her friends! Highly recommend and will definitely be using them again!! Scheduling with Jennifer was easy and she is so amazing!!!!!!!!",
  },
  {
    name: "Melissa Thomas",
    text: "I hired Addison Limos to transport me and a group of my girlfriends to/from Grapevine for a wine tour. It was important to me that we arrived safely and on time. The vehicle was in great condition and provided adequate space for the 8 of …",
  },
  {
    name: "Phil Camm",
    text: "Exceptional service! From the first inquiry to the day of pick up, the communication was clear and …",
  },
  {
    name: "Kayla Williams",
    text: "Addison Limo is always very professional, punctual and responsive. We use them regularly for airport service and they did an amazing job for the prom! We highly recommend them!",
  },
  {
    name: "Christi Saji",
    text: "Great experience with the limo service for our wedding! They arrived on time, got us to our church/venue on time and promptly. Drivers were extremely friendly and accommodating! Highly recommend!",
  },
  {
    name: "Pamela Dunham",
    text: "We had such a great experience with Addison Limos! Everyone involved was exceptionally professional and made our Bridal Party Celebration so easy to book. Our driver was on time, every time! The limo was beautiful, stocked with ice and cold …",
  },
  {
    name: "Cyndee Scott",
    text: "We used Addison Limo for transportation to my Dad's funeral recently. Every step of the way they made it easy and smooth from making the reservation with Jennifer - she was kind and informative. Then Friday Regan (our driver) arrived …",
  },
  {
    name: "Darlene W",
    text: "Noor gets a 5/5 score from my family! He was courtesy, considered, patient, and held great conversation with my husband. Although we had 4 strong men to help with the bags, he still chip in and help. …",
  },
  {
    name: "G Lee",
    text: "Addison Limos Rocks. It was Concert Night in Fort Worth. Due to a situation with them, our ride was upgraded at no charge. I mentioned try to come as early as possible. Our Driver showed up an hour early and no extra charge. We made it …",
  },
  {
    name: "Leroy",
    text: "First time patron so very skeptical to say the least. With that aside Jennifer stepped in and did an outstanding job of ensuring everything was planned and coordinated perfectly. Noah was our driver and let’s just say he went above and …",
  },
  {
    name: "Danielle Mondine",
    text: "Someone hacked my page and wrote a bad review!!! This was NOT ME!!! Addison Limos made my baby's birthday unforgettable 🥰🥰🥰",
  },
  {
    name: "Betty Gomez",
    text: "I am new in Dallas and retired. My son very busy so I google and I pick Addison, called Jennifer has been the best helping me with price, cars and driver. I ask to have one that is not a speeder. I went on my first trip driver took me to …",
  },
  {
    name: "Lindsay Jensen",
    text: "What a truly amazing experience we had with Addison Xpress Limo. Highly recommended!",
  },
  {
    name: "Andrea Woodworth",
    text: "I have used Addison Limos 3-4 times over the last two years for various work events. Sunny has been our driver every time and is friendly, reliable, and communicates great with guests. They are easy to work with and have become my “go-to” for events.",
  },
  {
    name: "carshowkings408",
    text: "I ordered car service for when I arrived in Dallas. Due to the current rental car crisis, I figured this was a better solution for my needs. Our driver Sunny was very welcoming and professional. The car was extremely clean and he was prompt …",
  },
  {
    name: "Cynthia Albertson",
    text: "Addison Limos was so prompt and paid such great attention to detail in making sure we knew where our limo was. Kept in great contact and our driver was amazing! The whole experience was wonderful. Will call again for sure! Thank you Addison Limo for helping make a birthday so special! …",
  },
  {
    name: "Elora Kibler",
    text: "First time using Addison Limo. Driver (Sunny) was such a pleasure. He was early, so polite and accommodating. Jennifer in the office was great as well. I have already canceled my airport shuttle in two weeks and will be rebooking here! …",
  },
  {
    name: "Savannah W",
    text: "I am blown away by the outstanding customer service I received booking with this company! They are ABSOLUTELY amazing! I will definitely be booking with them again in the future. The communication and quick responses to all of my questions …",
  },
  {
    name: "Sherry Morris",
    text: "Celebrated a friends milestone birthday over the weekend with a wine tour and we used Addison Limos to get us to Grapevine. The driver was prompt, professional and accommodating. The hummer limo was spacious and clean. Would definitely use …",
  },
  {
    name: "Dana Payton",
    text: "We were overly pleased with the prompt communication from the minute of our first booking to our very last same day booking of transportation. Sunny was our driver and was absolutely amazing. From safe driving, friendliness, going out of …",
  },
  {
    name: "Kelly Payette",
    text: "Addison Xpress Car and Limo is literally the best. We rented the stretched white hummer limo for a very reasonable price. It was clean and the driver was so professional and fun! I highly recommend this company!",
  },
  {
    name: "Maliha Asalati",
    text: "As an executive assistant I have worked with many luxury car & limo services.I have used Addison Limo services multiple times for my executives and company guests. They have been phenomenal every time. From ease of booking, understanding …",
  },
  {
    name: "Courtney Sparks",
    text: "Less than 24 hours before our event a competitor left us high and dry. I reached out to Addison Limos and received a quote and got booked within an hour. The driver the day of the event, Dale, was kind, respectful, accommodating and ensured …",
  },
  {
    name: "Nikki Wright",
    text: "We recently had the pleasure of being transported while in town for a sporting event. They went above and beyond for our parents & athletes after a traumatic turn of events. They accommodated their schedules for us and were very considerate of making our athletes feel extra special. Can’t recommend enough!!",
  },
  {
    name: "dsvj2009",
    text: "I recently needed a ride to the airport and had four large bags. Addison Limo made sure that I had enough room for the bags and unlike other car services, the Addison Limo driver loaded my heavy bags. He was extremely professional and …",
  },
  {
    name: "LabsR1st",
    text: "I cannot recommend Addison Limos highly enough. I am a repeat customer and will continue to use them every chance I get!! Sunny is so professional and caring (he’s taken care of getting me from place to place) and I look forward to seeing …",
  },
  {
    name: "Jennifer Brown",
    text: "Excellent communication from the start, I probably emailed the company 10 times with questions before I actually booked our limo, and they always responded almost immediately. This was for our daughter's Sweet 16 birthday and we wanted …",
  },
  {
    name: "J L",
    text: "This was my first time using Addison Xpress Limo Service. I wanted to celebrate my birthday riding a Limo to dinner. This was a last minute decision. I call and spoke with Sonny, great guy. I explained what I required for the night and he …",
  },
  {
    name: "Dalton Thompson",
    text: "Great communication, detailed planning, a fair price, and a wonderful experience for my daughter’s birthday. I could not have asked for more with the stretch hummer limo experience. Well done and would highly recommend to anyone looking for limo service or experience.",
  },
  {
    name: "Heather Carroll",
    text: "Our weekend in Dallas was amazing. We came here for NCA, which is an extremely busy weekend. 27,000 athletes plus their family come here for this event. Having this company available the entire stay was not only amazing but extremely …",
  },
  {
    name: "Amy F",
    text: "They were amazing from the quote to the event. Our driver Mirwais was amazing. He had to deal with Dallas traffic with a stars game. Our Airbnb was directly across from the arena and it made it impossible to get around. He never lost his …",
  },
  {
    name: "Sarah Mannarelli",
    text: "The service they provided to our cheer program was impeccable. They were so amazing and accommodating at a moments notice. They went above and beyond and far exceeded our expectations! 100/10 would recommend them!",
  },
  {
    name: "Kate Dominguez",
    text: "Fantastic service. This team really went above and beyond for us on a recent trip to Dallas. They provided great service to and from the airport, loaned us their infant and booster seats (which we needed for car trips while in Dallas) at …",
  },
  {
    name: "Rachel Thompson",
    text: "Great experience! Respectful and professional driver who made our travels an easy and enjoyable experience.",
  },
  {
    name: "Kathy Jones",
    text: "It was very easy to book the limo, and Sunny was very good about keeping me posted throughout the process. They were on time, very respectful, and gave us a great ride. Noor was our wonderful driver.",
  },
  {
    name: "Tonya Payne",
    text: "This service was the best. From start to finish everything ran smoothly. The driver, Noah, was very punctual and did a fantastic job. My daughter and everyone else enjoyed the ride. I would definitely use them again!",
  },
  {
    name: "King Mufasa",
    text: "I recently booked a hummer limo for my friend’s birthday as we have been stuck at home during this pandemic. Addison Limos were the highlight of our 2020. Limo was extremely stylish, clean and showed up 15 minutes early. Professional driver …",
  },
  {
    name: "Jackie Damrau",
    text: "Addison Limos is an awesome service. They were on time for both reservations, very professional covers, and super clean vehicles.",
  },
  {
    name: "L Jordan",
    text: "The cost, vehicle, and service was outstanding! Noah kept us up to date every pickup and every drop off for the kids. He was amazing! So glad we chose Addison Limos!",
  },
  {
    name: "glen andrews",
    text: "This was a special surprise for my wife. my daughter and I set this up. the driver was named Sunny, he didn't just take them to the hotel as I expected, to the girls excitement he drove around downtown …",
  },
  {
    name: "Nicole Russ",
    text: "We used Addison limo for my daughter’s 13th birthday!!! It was such a wonderful experience. Sunny was awesome and so helpful setting everything up. The girls had a blast. Thank you!",
  },
  {
    name: "Cheryl Jahoda",
    text: "I was very pleased with the service we received from Addison Limo’s. Both our drivers were professional and good conversationalists. All in all a very nice …",
  },
  {
    name: "Witness Lal",
    text: "Best Dallas limousine service for prom! We used Addison Limos for my son's high school prom. We searched for local Dallas prom limousine service's, but the service we received from the initial phone call to my son being the last of the 18 …",
  },
  {
    name: "Richard Ogle",
    text: "I have been using Addison Limo for a few years mostly for work trips to and from the airport. However, I have also used them for personal use for myself and for extended family members who fly to Dallas from out of town and are not …",
  },
  {
    name: "Ray McCoy",
    text: "Addison Limos provided an awesome experience for our group! Jennifer was great to work with and made the reservation process super easy. I highly recommend Addison Limos as they are professional and are focused on providing excellent customer service and an overall great experience! …",
  },
  {
    name: "Julie Kreisler",
    text: "We have been clients of Sunny and the Addison Limo team for 4 years now. We love the variety of vehicles in their fleet and their willingness to always accommodate our requests. Hands down the best transportation company we’ve used! …",
  },
  {
    name: "Chris Miller",
    text: "Addison Limos was fantastic to work with. Our driver Sonny was the best!! He made the night so fun! We would definitely use them again. …",
  },
  {
    name: "Michael Bailey",
    text: "I had the pleasure of using Addison Express Limos recently. Sonny took great care of my clients. His staff is impeccable, clean modern vehicles. Absolutely the only transportation company I will use in Dallas. Thanks Guys!",
  },
  {
    name: "Patty Turner",
    text: "We rented the Mercedes Sprinter for prom. The driver was on time, courteous and made it fun for the kids. The vehicle was very nice... clean and modern. Thank you for making their night fun! …",
  },
  {
    name: "Kim Davis",
    text: "The night started a little slow but ended well. The manager was very attentive and had good communication. Our driver Dale was awesome and took good care of us!! We will definitely use their service again. 😊",
  },
  {
    name: "IZEAR HOUSTON",
    text: "We had a blessing brought to us by an Xmas gift to my wife who at over 50 years old. She was raised from birth by her grandparents in Louisiana near Vicksburg, MS. She didn't know who her father was or she had any siblings. Thanks to our …",
  },
  {
    name: "joni skinner",
    text: "We rode in the Hummer H2 for 2 days and the limo was clean and stocked with ice, water, glasses on both days. Our driver Sonny was amazing - he was on time and very personable and attentive. Thank you Sonny for everything you did for me and my family. …",
  },
  {
    name: "Zak Diaz",
    text: "went to dfw car rental and none of them helped me out with my family a total of 6. but when i called right away they came. the best car service i had since i came out here to the U.S and im from the island relocating thank you guys coming from me and my family.",
  },
  {
    name: "Mary Pat Finn",
    text: "Addison Limos: These people are pro's, prompt, courteous and vehicles are perfection. Easy to book reservations and customer service is outstanding. Book w the Best: Addison Limos will get you there in reliably.",
  },
  {
    name: "Nancy WuGhafoori",
    text: "I always use Addison Limo whenever I am in Dallas. It’s a great company with super polite staffs. The vehicle is always clean and they are always on time. Highly recommend. …",
  },
  {
    name: "Manpreet Chhabra",
    text: "The service was excellent and we loved the lighting and interiors. The ride was smooth and we will recommend to our friends and family to use their service in future.",
  },
  {
    name: "Doric Earle",
    text: "We had the same driver as we had 18 months ago. He remember us and was great. Friendly but not overly so. SUV was clean, on time and we arrived at DFW as we requested. …",
  },
  {
    name: "Mano Gak",
    text: "Addison Limos offers one of the best services in town. They are extremely professional, friendly & punctual! Their prices are affordable and reasonable. I only use Addison Limos and highly recommend them to everyone.",
  },
  {
    name: "Susan Clerici",
    text: "I had an amazing experience with this company and Sonny. The day of the pickup I woke up sick. This company allowed me to cancel and sent texts asking how I was. Class act. I will definitely use this service in the future.",
  },
  {
    name: "JC (SnowCrash-2112)",
    text: "This company is GREAT! We've used them for a company excursion with about 10 people, and have used them for airport trips several times now. Reliable, easy to make appointments! Strongly recommended!",
  },
  {
    name: "Theseus Smith",
    text: "Best Dallas limo sevice! We used Addison limos to bring us to Cowboys stadium for a football game they were absultely the best. Affordable rates, clean limo, and first class service. Highly recommended!",
  },
  {
    name: "Deanna Musgrove",
    text: "Sunny has taken care of my work and personal transportation needs. Has always been on time, super friendly! Not to mention will occasionally go out of the way to whataburger for a late night foodie. Also the friendly text at holidays! He goes out of his way for sure! …",
  },
];

const Reviews = () => {
  return (
    <div className="min-h-screen bg-[#0d0d0d] text-foreground font-sans selection:bg-primary/30">
      <SEOHead
        title="Client Reviews & Testimonials"
        description="Read what our clients have to say about Dallas-Fort Worth's premier 5-star private ground transportation."
        canonical="https://addisonlimos.com/reviews"
      />
      {/* Hero Section */}
      <section className="pt-32 pb-16 px-4 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none"></div>
        <div className="container mx-auto text-center relative z-10">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-white mb-6">
            The Standard of Distinction.
            <br />
            <span className="text-primary">Rated 5 Stars.</span>
          </h1>
          <p className="text-lg md:text-xl text-white/60 max-w-3xl mx-auto font-light mb-12">
            Read why corporate executives, event planners, and private clients
            across Dallas-Fort Worth consistently choose Addison Limos for
            flawless ground transportation.
          </p>

          <div className="flex justify-center mb-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-primary/20 backdrop-blur-sm">
              <Star className="w-4 h-4 text-primary fill-primary" />
              <span className="text-xs sm:text-sm font-semibold tracking-widest uppercase text-white/90 text-center">
                Winner of Addison Magazine's Readers Choice Award
              </span>
            </div>
          </div>

          <div className="flex flex-row items-center justify-center gap-4 sm:gap-12 bg-zinc-900/50 border border-white/10 p-4 sm:p-6 rounded-none max-w-2xl mx-auto backdrop-blur-sm">
            <div className="text-center flex-1">
              <div className="text-3xl sm:text-4xl font-serif font-bold text-white mb-1 sm:mb-2">
                4.8
              </div>
              <div className="flex items-center justify-center gap-1 mb-1 sm:mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className="w-3 h-3 sm:w-5 sm:h-5 text-primary fill-primary"
                  />
                ))}
              </div>
              <div className="text-[10px] sm:text-sm text-white/60 uppercase tracking-widest">
                Average Rating
              </div>
            </div>
            <div className="w-px h-16 sm:h-20 bg-white/10 shrink-0"></div>
            <div className="text-center flex-1">
              <div className="text-3xl sm:text-4xl font-serif font-bold text-white mb-1 sm:mb-2">
                160+
              </div>
              <div className="flex items-center justify-center gap-1 mb-1 sm:mb-2">
                <MessageSquare className="w-3 h-3 sm:w-5 sm:h-5 text-primary" />
              </div>
              <div className="text-[10px] sm:text-sm text-white/60 uppercase tracking-widest">
                Verified Reviews
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Reviews Showcase */}
      <section className="py-20 px-2 sm:px-4 relative">
        <div className="container mx-auto px-0 sm:px-4">
          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-1.5 sm:gap-8 -mx-1 sm:mx-0">
            {[...googleReviews]
              .sort((a, b) => a.text.length - b.text.length)
              .map((review, i) => (
                <Card
                  key={i}
                  className="bg-zinc-900/40 border-white/5 rounded-none hover:bg-zinc-900/60 transition-all duration-300 group"
                >
                  <CardContent className="p-2 sm:p-8 flex flex-col h-full">
                    <div className="flex items-center gap-0.5 sm:gap-1 mb-2 sm:mb-6">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className="w-2.5 h-2.5 sm:w-4 sm:h-4 text-primary fill-primary"
                        />
                      ))}
                    </div>
                    <p className="text-[11px] sm:text-base text-white/80 font-light leading-relaxed mb-2 sm:mb-8 italic flex-grow">
                      "{review.text}"
                    </p>
                    <div className="flex items-center gap-1.5 sm:gap-4 mt-auto pt-2 sm:pt-4 border-t border-white/5">
                      <div className="w-6 h-6 sm:w-12 sm:h-12 bg-primary/10 rounded-full flex items-center justify-center border border-primary/20 shrink-0">
                        <span className="text-primary font-serif font-bold text-[10px] sm:text-lg">
                          {review.name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div className="min-w-0">
                        <div className="text-white font-medium text-[11px] sm:text-base truncate">
                          {review.name}
                        </div>
                        <div className="text-[9px] sm:text-xs text-white/50">
                          Google Review
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </div>
      </section>

      {/* Leave a Review CTA */}
      <section className="py-24 bg-zinc-950 border-t border-white/5">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6">
            Share Your Experience
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto text-lg font-light mb-10">
            We pride ourselves on delivering 5-star service. If you recently
            traveled with us, we would love to hear about your journey.
          </p>
          <a
            href="https://www.google.com/search?q=addison+limos&rlz=1C1ONGR_enUS1150US1150&oq=addison+limos&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIQCAEQLhivARjHARiABBiOBTINCAIQABiGAxiABBiKBTINCAMQABiGAxiABBiKBTINCAQQABiGAxiABBiKBTIGCAUQRRg8MgYIBhBFGDwyBggHEEUYPNIBCDE0NzlqMGo0qAIAsAIA&sourceid=chrome&ie=UTF-8#lrd=0x864c2153e572c5e3:0x926cdf1be9a3012f,3,,,,"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button
              size="lg"
              className="bg-transparent border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground text-lg rounded-none h-14 px-10 transition-all duration-300"
            >
              Leave Us A Review on Google
            </Button>
          </a>
        </div>
      </section>
    </div>
  );
};

export default Reviews;

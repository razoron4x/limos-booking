import { useEffect } from "react";
import { SEOHead } from "@/components/SEOHead";
import { ShieldCheck } from "lucide-react";

const CcForm = () => {
  useEffect(() => {
    const existing = document.querySelector(
      'script[src="https://link.msgsndr.com/js/form_embed.js"]',
    );
    if (existing) return;
    const script = document.createElement("script");
    script.src = "https://link.msgsndr.com/js/form_embed.js";
    script.async = true;
    document.body.appendChild(script);
    return () => {
      script.remove();
    };
  }, []);

  return (
    <div className="relative min-h-screen bg-zinc-100 text-zinc-900 font-sans selection:bg-primary/30 pt-28 pb-16 overflow-hidden">
      <SEOHead
        title="Credit Card Submission"
        description="Secure credit card submission form for Addison Limos."
        canonical="https://addisonlimos.com/cc-form"
        noIndex={true}
      />

      {/* Elegant gold twisting wave/ribbon lines extending across the screen */}
      <svg
        className="pointer-events-none absolute inset-0 w-full h-full text-primary opacity-25"
        viewBox="0 0 1440 2400"
        preserveAspectRatio="none"
        fill="none"
        aria-hidden="true"
      >
        {Array.from({ length: 24 }).map((_, i) => {
          const offset = i * 14;
          const strokeOpacity = 0.15 + (i % 6) * 0.08;
          return (
            <path
              key={`wave-left-${i}`}
              d={`M ${-100 + offset} 0 C ${650 + offset * 0.8} 450, ${150 - offset * 0.5} 1100, ${850 + offset * 0.6} 1750 S ${300 + offset} 2300, ${700 + offset} 2500`}
              stroke="currentColor"
              strokeWidth="1.2"
              strokeOpacity={strokeOpacity}
            />
          );
        })}
        {Array.from({ length: 20 }).map((_, i) => {
          const offset = i * 16;
          const strokeOpacity = 0.12 + (i % 5) * 0.07;
          return (
            <path
              key={`wave-right-${i}`}
              d={`M ${1550 - offset} 100 C ${800 - offset * 0.7} 600, ${1350 + offset * 0.4} 1250, ${600 - offset * 0.5} 1850 S ${1100 - offset} 2250, ${900 - offset} 2500`}
              stroke="currentColor"
              strokeWidth="1"
              strokeOpacity={strokeOpacity}
            />
          );
        })}
      </svg>

      <div className="w-full relative z-10">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="mb-4 text-center">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-zinc-200 mb-2 shadow-sm">
              <ShieldCheck className="w-3.5 h-3.5 text-primary" />
              <span className="text-[11px] font-semibold tracking-wider uppercase text-zinc-700">
                Secure &amp; Encrypted
              </span>
            </div>
            <h1 className="text-3xl md:text-4xl font-serif font-bold text-zinc-900 tracking-tight">
              Credit Card Submission
            </h1>
          </div>

          <div className="rounded-lg overflow-hidden bg-white shadow-sm">
            <iframe
              src="https://api.leadconnectorhq.com/widget/form/sJ2dV1gvLHD1EJcD1S9q"
              style={{ width: "100%", height: "2126px", border: "none" }}
              id="inline-sJ2dV1gvLHD1EJcD1S9q"
              data-layout="{'id':'INLINE'}"
              data-trigger-type="alwaysShow"
              data-trigger-value=""
              data-activation-type="alwaysActivated"
              data-activation-value=""
              data-deactivation-type="neverDeactivate"
              data-deactivation-value=""
              data-form-name="Addison Xpress Car & Limo Service - CC Form"
              data-height="2126"
              data-layout-iframe-id="inline-sJ2dV1gvLHD1EJcD1S9q"
              data-form-id="sJ2dV1gvLHD1EJcD1S9q"
              data-cookie-consent="true"
              data-cookie-consent-provider="auto"
              title="Addison Xpress Car & Limo Service - CC Form"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CcForm;

import { ChevronLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { SEOHead } from "@/components/SEOHead";
import { CustomQuoteForm } from "@/components/CustomQuoteForm";

const Quote = () => {
  return (
    <div className="min-h-screen bg-zinc-950 text-foreground font-sans selection:bg-primary/30 py-12">
      <SEOHead
        title="Get a Quote"
        description="Request a quote or make a reservation for luxury ground transportation in Dallas-Fort Worth."
        canonical="https://addisonlimos.com/quote"
      />
      <div className="w-full">
        <div className="container mx-auto px-4 max-w-7xl">
          <Link
            to="/"
            className="inline-flex items-center text-white/60 hover:text-white mb-8 transition-colors"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Link>

          <div className="mb-10 text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                Quote & Reservation
              </span>
            </div>
            <h1 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4">
              Reserve Your Luxury Chauffeur
            </h1>
            <p className="text-white/60 font-light max-w-2xl mx-auto">
              Provide your travel details below and our concierge team will
              ensure a flawless experience.
            </p>
          </div>
        </div>

        <div className="container mx-auto px-4 max-w-[760px]">
          <CustomQuoteForm />
        </div>
      </div>
    </div>
  );
};

export default Quote;

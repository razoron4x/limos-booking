import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import {
  Wine,
  ChevronRight,
  ArrowLeft,
  Phone,
  MapPin,
  Clock,
} from "lucide-react";
import { Link } from "react-router-dom";
import { vehicles } from "@/data/vehicles";
import { SEOHead } from "@/components/SEOHead";
import CompactServiceArea from "@/components/CompactServiceArea";
import ServiceReviewsPreview from "@/components/ServiceReviewsPreview";
import {
  ServiceTopSections,
  ServiceExploreSection,
} from "@/components/ServiceSections";
import { serviceConfigs } from "@/data/serviceConfigs";

const ServiceWineTours = () => {
  return (
    <div className="min-h-screen bg-[#0d0d0d] text-foreground font-sans selection:bg-primary/30">
      <SEOHead
        title="Wine Tours & Vineyard Transportation | Addison Limos"
        description="Luxury wine tour transportation in Dallas-Fort Worth. Private chauffeur-driven vineyard tours to Texas Hill Country wineries with safe, stylish, and unforgettable wine tasting experiences."
        canonical="https://addisonlimos.com/service-wine-tours"
        ogImage="https://vibe.filesafe.space/1792719026995615993/assets/8929dfff-0003-4745-8528-a0800c6d65d7.png"
        schemaJson={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "Wine Tours & Vineyard Transportation",
          provider: {
            "@type": "LocalBusiness",
            name: "Addison Limos",
            telephone: "972-608-3680",
            address: {
              "@type": "PostalAddress",
              addressLocality: "Addison",
              addressRegion: "TX",
              postalCode: "75001",
              addressCountry: "US",
            },
          },
          areaServed: "Dallas-Fort Worth Metroplex",
          description:
            "Luxury wine tour transportation with private chauffeurs to Texas wineries and vineyards.",
        }}
      />
      {/* Header Section */}
      <section className="pt-32 pb-16 px-4 relative border-b border-white/5 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-b from-primary/10 to-transparent pointer-events-none"></div>
        <div className="absolute inset-0 z-0 opacity-20">
          <img
            src="https://vibe.filesafe.space/1792719026995615993/assets/8929dfff-0003-4745-8528-a0800c6d65d7.png"
            alt="Wine tour luxury transportation"
            className="w-full h-full object-cover"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0d0d0d] via-[#0d0d0d]/80 to-transparent"></div>
        </div>
        <div className="container mx-auto relative z-10">
          <Link
            to="/services"
            className="inline-flex items-center text-white/60 hover:text-primary transition-colors mb-8 group"
          >
            <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Services
          </Link>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-3xl flex flex-col">
              <div className="order-2 md:order-1 mt-6 md:mt-0">
                <h1 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6">
                  Wine Tours
                </h1>
                <p className="text-base md:text-xl text-white/70 font-light leading-relaxed">
                  <span className="md:hidden">
                    Texas wine country tours. Sip, savor. No driving required.
                  </span>
                  <span className="hidden md:inline">
                    Sip, savor, and explore Texas wine country in luxury.
                    Private chauffeur-driven vineyard tours with safe, stylish
                    round-trip transportation from Dallas-Fort Worth.
                  </span>
                </p>
              </div>
            </div>
            <Link to="/quote?service=Wine%20Tours">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg rounded-none h-14 px-8 shadow-[0_0_20px_rgba(212,175,55,0.2)] whitespace-nowrap"
              >
                Book Wine Tour
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <ServiceTopSections config={serviceConfigs.wineTours} />

      {/* Popular Wine Regions */}
      <section className="py-24 bg-zinc-950 relative border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Popular Wine Tour Destinations
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
              We transport your group to the finest wineries and tasting rooms
              across North Texas and beyond.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {[
              {
                name: "Grapevine Wine Trail",
                desc: "Explore historic downtown Grapevine's award-winning wineries and tasting rooms, just minutes from DFW.",
                time: "Half Day",
              },
              {
                name: "Texas Hill Country",
                desc: "A scenic drive to the heart of Texas wine country, Fredericksburg, Stonewall, and beyond.",
                time: "Full Day",
              },
              {
                name: "Bishop Arts & Urban Wineries",
                desc: "Discover Dallas's thriving urban wine scene with boutique tasting rooms and craft vineyards.",
                time: "4 Hours",
              },
            ].map((region, i) => (
              <div
                key={i}
                className="p-8 border border-white/5 bg-zinc-900/40 hover:bg-zinc-900/60 transition-all duration-300 group hover:border-primary/30"
              >
                <MapPin className="w-8 h-8 text-primary mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-xl font-serif font-bold text-white mb-3 group-hover:text-primary transition-colors">
                  {region.name}
                </h3>
                <p className="text-white/60 font-light leading-relaxed mb-4">
                  {region.desc}
                </p>
                <div className="flex items-center gap-2 text-sm text-primary/80">
                  <Clock className="w-4 h-4" />
                  <span className="font-medium">{region.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Recommended Fleet Section */}
      <section className="py-24 bg-[#0d0d0d] relative border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Ideal for Wine Tours
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
              Spacious, comfortable vehicles perfect for your wine country
              adventure.
            </p>
          </div>

          <div className="relative py-12">
            {/* Top Line */}
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>

            <p className="text-center text-sm text-white/40 mb-3 relative z-10">
              Tap the vehicle to expand
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10 max-w-6xl mx-auto">
              {[
                "mercedes-sprinter-limo",
                "lincoln-navigator-suv",
                "h2-hummer-stretch-limo",
              ]
                .map((id) => vehicles.find((v) => v.id === id))
                .filter(Boolean)
                .map((vehicle, i) => (
                  <Card
                    key={i}
                    className="bg-zinc-900/50 border-white/5 overflow-hidden group rounded-none relative"
                  >
                    <div className="aspect-[16/9] overflow-hidden relative group/carousel">
                      <Carousel opts={{ loop: true }} className="w-full h-full">
                        <CarouselContent className="h-full ml-0">
                          {vehicle.images.map((img, idx) => (
                            <CarouselItem
                              key={idx}
                              className="pl-0 h-full relative overflow-hidden"
                            >
                              <Link
                                to={`/fleet/${vehicle.id}`}
                                className="block w-full h-full cursor-pointer overflow-hidden"
                              >
                                <img
                                  src={img}
                                  alt={`${vehicle.title} view ${idx + 1}`}
                                  className={`w-full h-full transition-transform duration-1000 opacity-80 group-hover:opacity-100 group-hover:scale-105 ${vehicle.id === "luxury-black-stretch-limo" ? (idx === 1 ? "object-cover object-bottom -translate-y-6 sm:-translate-y-8" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-12 sm:-translate-y-16" : "object-cover object-center") : vehicle.id === "mercedes-sprinter-limo" ? (idx === 1 ? "object-cover object-bottom -translate-y-24 sm:-translate-y-40" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-8 sm:-translate-y-12" : "object-cover object-center") : vehicle.id === "mercedes-sprinter-van" ? (idx === 1 ? "object-cover object-bottom -translate-y-24 sm:-translate-y-40" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-8 sm:-translate-y-12" : "object-cover object-center") : "object-cover object-center"}`}
                                />
                              </Link>
                            </CarouselItem>
                          ))}
                        </CarouselContent>
                        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/50 to-transparent pointer-events-none z-10"></div>
                        <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                        <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                      </Carousel>
                    </div>
                    <CardContent className="absolute bottom-0 left-0 p-6 w-full z-30 pointer-events-none">
                      <h3 className="text-2xl font-serif font-bold text-white mb-2 group-hover:text-primary transition-colors drop-shadow-md">
                        <Link
                          to={`/fleet/${vehicle.id}`}
                          className="pointer-events-auto hover:text-primary transition-colors"
                        >
                          {vehicle.title}
                        </Link>
                      </h3>
                    </CardContent>
                  </Card>
                ))}
            </div>

            {/* Bottom Line */}
            <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>
          </div>

          <div className="mt-10 flex justify-center">
            <Link to="/fleet" className="w-full max-w-sm">
              <Button className="w-full h-14 bg-gradient-to-b from-zinc-800/40 to-zinc-950 border border-white/10 hover:border-primary/40 text-white text-base tracking-wide rounded-none group relative overflow-hidden transition-all duration-500 shadow-2xl hover:shadow-[0_0_30px_rgba(212,175,55,0.15)]">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
                <span className="relative z-10 flex items-center justify-center">
                  View Full Fleet
                  <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </span>
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section className="py-24 px-4 bg-zinc-950 relative border-t border-white/5">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16">
            {/* The Experience */}
            <div className="space-y-6">
              <div className="aspect-[4/3] overflow-hidden border border-white/5 relative group rounded-xl">
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/assets/8929dfff-0003-4745-8528-a0800c6d65d7.png"
                  alt="Luxury Wine Tour Experience"
                  className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent"></div>
              </div>
              <h2 className="text-3xl font-serif font-bold text-white">
                The Ultimate Wine Country Experience
              </h2>
              <p className="text-white/60 font-light leading-relaxed text-lg">
                Your private wine tour DFW adventure begins the moment you step
                into one of our luxury vehicles. With a dedicated wine tour
                chauffeur Dallas at your service, you'll visit handpicked Texas
                vineyards and tasting rooms without the stress of driving,
                parking, or navigating unfamiliar roads. Our luxury vineyard
                transportation DFW service is designed for groups of all sizes.
                from intimate couples' getaways to bachelorette parties and
                corporate wine retreats.
              </p>
            </div>

            {/* Why Choose Us */}
            <div className="space-y-6">
              <div className="aspect-[4/3] overflow-hidden border border-white/5 relative group rounded-xl">
                <img
                  src="https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png"
                  alt="Safe and Reliable Wine Tour Transportation"
                  className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent"></div>
              </div>
              <h2 className="text-3xl font-serif font-bold text-white">
                Why Choose Addison Limos
              </h2>
              <p className="text-white/60 font-light leading-relaxed text-lg">
                With over 20 years of experience serving the Dallas-Fort Worth
                metroplex, Addison Limos is the trusted name in private wine
                tour transportation. Our professional chauffeurs are
                background-checked, uniformly dressed, and trained to provide a
                discreet, first-class experience. Every vehicle in our fleet is
                meticulously maintained with climate control, premium seating,
                and immaculate interiors. When you book a Texas winery limo
                service with us, you're guaranteed punctual, safe, and stylish
                transportation from pickup to final drop-off.
              </p>
            </div>
          </div>

          <div className="mt-16 flex justify-center">
            <a
              href="tel:9726083680"
              onClick={() => (window as any).gtag_report_conversion?.()}
            >
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg rounded-none h-14 px-10 shadow-[0_0_20px_rgba(212,175,55,0.2)] whitespace-nowrap group"
              >
                <Phone className="w-5 h-5 mr-3" />
                Call 972-608-3680
              </Button>
            </a>
          </div>
        </div>
      </section>

      <ServiceReviewsPreview />

      <ServiceExploreSection config={serviceConfigs.wineTours} />

      <CompactServiceArea />
    </div>
  );
};

export default ServiceWineTours;

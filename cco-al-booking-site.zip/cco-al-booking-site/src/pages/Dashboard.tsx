import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  CalendarCheck,
  Receipt,
  CalendarDays,
  Users,
  LogOut,
  Menu,
  X,
} from "lucide-react";
import { SEOHead } from "@/components/SEOHead";
import { OverviewSection } from "@/components/dashboard/OverviewSection";
import { BookingsSection } from "@/components/dashboard/BookingsSection";
import { InvoicesSection } from "@/components/dashboard/InvoicesSection";
import { CalendarSection } from "@/components/dashboard/CalendarSection";
import { AccountsSection } from "@/components/dashboard/AccountsSection";

type SectionKey =
  "overview" | "bookings" | "invoices" | "calendar" | "accounts";

const nav: { key: SectionKey; label: string; icon: typeof LayoutDashboard }[] =
  [
    { key: "overview", label: "Overview", icon: LayoutDashboard },
    { key: "bookings", label: "Bookings", icon: CalendarCheck },
    { key: "invoices", label: "Invoices", icon: Receipt },
    { key: "calendar", label: "Calendar", icon: CalendarDays },
    { key: "accounts", label: "Accounts", icon: Users },
  ];

export const Dashboard = () => {
  const [active, setActive] = useState<SectionKey>("overview");
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  const handleSignOut = () => {
    navigate("/");
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      <div className="px-6 py-6 border-b border-border">
        <span className="text-xl font-serif font-bold tracking-wider text-foreground">
          ADDISON <span className="text-primary">LIMOS</span>
        </span>
        <p className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground mt-1">
          Staff Portal
        </p>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1">
        {nav.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => {
              setActive(key);
              setMobileOpen(false);
            }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm transition-colors ${
              active === key
                ? "bg-primary/10 text-primary border-l-2 border-primary"
                : "text-muted-foreground hover:text-foreground hover:bg-muted/40 border-l-2 border-transparent"
            }`}
          >
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </nav>

      <div className="px-3 py-4 border-t border-border">
        <div className="px-3 py-3 mb-2">
          <p className="text-xs text-muted-foreground">Signed in as</p>
          <p className="text-sm font-medium text-foreground">limomorgan3</p>
        </div>
        <button
          onClick={handleSignOut}
          className="w-full flex items-center gap-3 px-3 py-2.5 text-sm text-muted-foreground hover:text-destructive transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Sign out
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SEOHead
        title="Staff Dashboard"
        description="Addison Limos internal staff dashboard for bookings, invoices, calendar, and accounts."
        noIndex
      />

      {/* Mobile top bar */}
      <div className="lg:hidden sticky top-0 z-40 flex items-center justify-between border-b border-border bg-card px-4 py-3">
        <span className="font-serif font-bold tracking-wider text-foreground">
          ADDISON <span className="text-primary">LIMOS</span>
        </span>
        <button
          onClick={() => setMobileOpen(true)}
          className="text-muted-foreground hover:text-foreground"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5" />
        </button>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="w-72 max-w-[80vw] bg-card border-r border-border"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-end p-3">
              <button
                onClick={() => setMobileOpen(false)}
                className="text-muted-foreground hover:text-foreground"
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <SidebarContent />
          </div>
          <div
            className="flex-1 bg-background/80 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
        </div>
      )}

      <div className="flex">
        {/* Desktop sidebar */}
        <aside className="hidden lg:flex w-64 shrink-0 min-h-screen sticky top-0 border-r border-border bg-card">
          <div className="w-full">
            <SidebarContent />
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 min-w-0 px-6 sm:px-10 py-10 max-w-[1400px]">
          {active === "overview" && <OverviewSection />}
          {active === "bookings" && <BookingsSection />}
          {active === "invoices" && <InvoicesSection />}
          {active === "calendar" && <CalendarSection />}
          {active === "accounts" && <AccountsSection />}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;

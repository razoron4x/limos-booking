import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Phone,
  MapPin,
  Plane,
  Users,
  Star,
  CheckCircle2,
  ArrowRight,
  ChevronRight,
  ChevronDown,
  Clock,
  Shield,
  Navigation,
  Trophy,
  ChevronLeft,
} from "lucide-react";
import { useState, useCallback, useEffect } from "react";
import useEmblaCarousel from "embla-carousel-react";
import { vehicles } from "@/data/vehicles";
import { getCityBySlug } from "@/data/cities";
import { SEOHead } from "@/components/SEOHead";
import CompactServiceArea from "@/components/CompactServiceArea";
import NotFound from "./NotFound";
const ogImage =
  "https://vibe.filesafe.space/1792719026995615993/attachments/51e6ee25-b03c-4a29-9660-4da2bb28ed9e.webp";
const CityService = () => {
  const { citySlug } = useParams();
  const city = getCityBySlug(citySlug || "");
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  // Embla Carousel for Fleet section
  const [emblaRef, emblaApi] = useEmblaCarousel({
    align: "start",
    slidesToScroll: 1,
    containScroll: "trimSnaps",
    breakpoints: {
      "(min-width: 768px)": { slidesToScroll: 1 },
    },
  });

  if (!city) return <NotFound />;

  const services = [
    {
      title: "Airport Transfers",
      desc: `Reliable, flight-tracked chauffeur service to DFW International and Dallas Love Field. Meet-and-greet inside the terminal, curbside express pickups, and zero wait fees for delays.`,
      link: "/service-airport",
      img: "https://vibe.filesafe.space/1792719026995615993/attachments/105ccb92-8123-4ed8-84a9-4418d97c9941.webp",
    },
    {
      title: "Special Events & Nights Out",
      desc: `Arrive in style for concerts, galas, and celebrations across ${city.name}. Our luxury fleet and professional chauffeurs make every event a first-class experience.`,
      link: "/service-events",
      img: "https://vibe.filesafe.space/1792719026995615993/attachments/fba40358-8871-45b6-8d55-3e9f4c2c30b1.webp",
    },
    {
      title: "Group Transportation",
      desc: `Mercedes Sprinter vans and Sprinter limo buses for corporate groups, family gatherings, and event shuttles in ${city.name}. Up to 14 passengers in premium comfort.`,
      link: "/service-group",
      img: "https://vibe.filesafe.space/1792719026995615993/attachments/dfd0c52f-a532-4e35-9f71-57c8857e9e9f.webp",
    },
    city.fourthService,
  ];

  const faqSchema = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Service",
        name: `Luxury Chauffeur Service in ${city.name}, TX`,
        provider: {
          "@type": "LimousineService",
          name: "Addison Limos",
          telephone: "972-608-3680",
          url: "https://addisonlimos.com",
          address: {
            "@type": "PostalAddress",
            addressLocality: "Addison",
            addressRegion: "TX",
            postalCode: "75001",
            addressCountry: "US",
          },
        },
        areaServed: { "@type": "City", name: city.name },
        serviceType: "Luxury Chauffeur & Limo Service",
        description: city.metaDescription,
      },
      {
        "@type": "FAQPage",
        mainEntity: city.faqs.map((f) => ({
          "@type": "Question",
          name: f.question,
          acceptedAnswer: {
            "@type": "Answer",
            text: f.answer,
          },
        })),
      },
    ],
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/30">
      <SEOHead
        title={city.metaTitle}
        description={city.metaDescription}
        canonical={`https://addisonlimos.com/limo-service/${city.slug}`}
        ogImage={ogImage}
        schemaJson={faqSchema}
      />

      {/* ========================================
          1. HERO SECTION
          ======================================== */}
      <section className="relative min-h-[80vh] flex items-center pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src={city.heroImage}
            alt={`Luxury limo service in ${city.name}, TX`}
            className="w-full h-full object-cover opacity-40"
            fetchPriority="high"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/85 to-background/40"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
        </div>

        <div className="container relative z-10 mx-auto px-4">
          <div className="max-w-3xl">
            <div className="flex flex-wrap items-center gap-3 mb-8">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white/5 border border-primary/30 backdrop-blur-sm">
                <Star className="w-3.5 h-3.5 text-primary fill-primary" />
                <span className="text-[11px] font-semibold tracking-wide text-white/90 uppercase">
                  20+ Years of 5-Star Service
                </span>
              </div>
              <span className="text-white/20">|</span>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white/5 border border-primary/30 backdrop-blur-sm">
                <Shield className="w-3.5 h-3.5 text-primary" />
                <span className="text-[11px] font-semibold tracking-wide text-white/90 uppercase">
                  $1.5M+ Commercial Insurance
                </span>
              </div>
              <span className="text-white/20">|</span>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white/5 border border-primary/30 backdrop-blur-sm">
                <Clock className="w-3.5 h-3.5 text-primary" />
                <span className="text-[11px] font-semibold tracking-wide text-white/90 uppercase">
                  15-Min Early Arrival
                </span>
              </div>
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif font-bold text-white leading-[1.1] mb-6">
              {city.heroTitle}
            </h1>
            <p className="text-xl md:text-2xl text-white/80 mb-10 max-w-2xl leading-relaxed font-medium">
              {city.heroSubtitle}
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/quote"
                className="w-full sm:w-auto"
                onClick={() => (window as any).gtag_report_conversion?.()}
              >
                <Button
                  size="lg"
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 text-base rounded-none h-14 px-8 shadow-[0_0_20px_rgba(212,175,55,0.3)] transition-all hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] whitespace-nowrap"
                >
                  Get a Quote
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <a
                href="tel:9726083680"
                className="w-full sm:w-auto"
                onClick={() => (window as any).gtag_report_conversion?.()}
              >
                <Button
                  size="lg"
                  variant="outline"
                  className="w-full border-white/20 text-white hover:bg-white/10 text-base rounded-none h-14 px-8 bg-transparent backdrop-blur-sm transition-all whitespace-nowrap"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  Call 972-608-3680
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================
          2. SERVICES GRID (corporate-style)
          ======================================== */}
      <section className="py-24 bg-zinc-950 border-y border-white/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                {city.name} Services
              </span>
            </div>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Chauffeur services for every occasion in {city.name}
            </h2>
            <p className="text-white/70 max-w-2xl mx-auto text-xl font-medium italic tracking-wide">
              At Addison Limos, every mile is business class, and every arrival
              is effortless.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {services.map((service, i) => (
              <Link key={i} to={service.link} className="group block">
                <div className="relative aspect-[2/1] overflow-hidden border border-white/10 rounded-xl mb-4">
                  <img
                    src={service.img}
                    alt={service.title}
                    loading="lazy"
                    className="w-full h-full object-cover transition-all duration-700 ease-out group-hover:blur-sm group-hover:scale-110 rounded-xl"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-all duration-500 flex items-center justify-center rounded-xl">
                    <span className="opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-500 delay-100 inline-flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2 text-xs font-semibold tracking-wide uppercase rounded shadow-[0_0_20px_rgba(212,175,55,0.4)]">
                      View Now
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent pointer-events-none rounded-xl"></div>
                </div>
                <h3 className="text-lg font-serif font-bold text-white mb-1.5 group-hover:text-primary transition-colors duration-300">
                  {service.title}
                </h3>
                <p className="text-white/60 font-normal text-base leading-relaxed">
                  {service.desc}
                </p>
              </Link>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="mt-12 flex flex-col sm:flex-row gap-4 justify-center max-w-xl mx-auto">
            <Link
              to="/quote"
              onClick={() => (window as any).gtag_report_conversion?.()}
              className="w-full sm:w-auto"
            >
              <Button
                size="lg"
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 text-base rounded-none h-14 px-8 shadow-[0_0_20px_rgba(212,175,55,0.3)] transition-all hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] whitespace-nowrap"
              >
                Try Our Award-Winning Service
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <a
              href="tel:9726083680"
              onClick={() => (window as any).gtag_report_conversion?.()}
              className="w-full sm:w-auto"
            >
              <Button
                size="lg"
                variant="outline"
                className="w-full border-white/20 text-white hover:bg-white/10 text-base rounded-none h-14 px-8 bg-transparent backdrop-blur-sm transition-all whitespace-nowrap"
              >
                <Phone className="w-5 h-5 mr-2" />
                Call 972-608-3680
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* ========================================
          3. WHY CHOOSE SECTION (4-box grid + trust)
          ======================================== */}
      <section className="py-24 bg-background relative">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Navigation className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                {city.name} Excellence
              </span>
            </div>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6">
              Why {city.name} chooses Addison Limos
            </h2>
            <p className="text-white/70 max-w-2xl mx-auto text-xl font-normal">
              {city.heroDescription}
            </p>
          </div>

          {/* 4-Box Grid - Connected with proper borders */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border border-white/10 bg-zinc-950/50 mb-8">
            {/* Box 1: Safety & Compliance */}
            <div className="group p-6 md:p-8 border-b md:border-r border-white/10 hover:bg-zinc-900/50 transition-all duration-300 cursor-default">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-zinc-800/50 flex items-center justify-center border border-white/10 shrink-0 group-hover:bg-primary/10 group-hover:border-primary/20 transition-all">
                  <Shield className="w-6 h-6 text-white/70 group-hover:text-primary transition-colors" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-primary transition-colors">
                    Safety & Compliance
                  </h3>
                  <p className="text-white/60 text-sm leading-relaxed">
                    $1.5M+ commercial liability coverage, background-checked
                    chauffeurs, and NDA-compliant service for every {city.name}{" "}
                    ride.
                  </p>
                </div>
              </div>
            </div>

            {/* Box 2: Relentless Punctuality */}
            <div className="group p-6 md:p-8 border-b border-white/10 hover:bg-zinc-900/50 transition-all duration-300 cursor-default">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-zinc-800/50 flex items-center justify-center border border-white/10 shrink-0 group-hover:bg-primary/10 group-hover:border-primary/20 transition-all">
                  <Clock className="w-6 h-6 text-white/70 group-hover:text-primary transition-colors" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-primary transition-colors">
                    Relentless Punctuality
                  </h3>
                  <p className="text-white/60 text-sm leading-relaxed">
                    Our chauffeurs arrive a minimum of 15 minutes before
                    scheduled pickup in {city.name}. Live GPS tracking keeps you
                    informed every step of the way.
                  </p>
                </div>
              </div>
            </div>

            {/* Box 3: Guest-First Hospitality */}
            <div className="group p-6 md:p-8 border-b md:border-b-0 md:border-r border-white/10 hover:bg-zinc-900/50 transition-all duration-300 cursor-default">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-zinc-800/50 flex items-center justify-center border border-white/10 shrink-0 group-hover:bg-primary/10 group-hover:border-primary/20 transition-all">
                  <Star className="w-6 h-6 text-white/70 group-hover:text-primary transition-colors" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-primary transition-colors">
                    Guest-First Hospitality
                  </h3>
                  <p className="text-white/60 text-sm leading-relaxed">
                    From the first phone call to the final drop-off in{" "}
                    {city.name}, white-glove treatment at every touchpoint.
                    always responsive, never rushed.
                  </p>
                </div>
              </div>
            </div>

            {/* Box 4: Uncompromising Standards */}
            <div className="group p-6 md:p-8 hover:bg-zinc-900/50 transition-all duration-300 cursor-default">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-zinc-800/50 flex items-center justify-center border border-white/10 shrink-0 group-hover:bg-primary/10 group-hover:border-primary/20 transition-all">
                  <CheckCircle2 className="w-6 h-6 text-white/70 group-hover:text-primary transition-colors" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-primary transition-colors">
                    Uncompromising Standards
                  </h3>
                  <p className="text-white/60 text-sm leading-relaxed">
                    Our vehicles are immaculate, our chauffeurs are
                    professionally uniformed, and our service is flawless. every{" "}
                    {city.name} ride, without exception.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Trust Section */}
          <div className="bg-zinc-900/30 border border-white/10 p-6 md:p-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
              {/* Left: Trusted By Badges */}
              <div>
                <div className="text-[11px] font-semibold tracking-[0.2em] uppercase text-white/40 mb-4">
                  Trusted By
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-2 gap-3">
                  {[
                    "Fortune 500 Execs",
                    "DFW Event Planners",
                    "Corporate Travel Teams",
                    "Wedding Coordinators",
                  ].map((badge, i) => (
                    <div
                      key={i}
                      className="px-4 py-2.5 bg-zinc-800/40 border border-white/5 text-sm text-white/70 font-medium text-center"
                    >
                      {badge}
                    </div>
                  ))}
                </div>
              </div>

              {/* Right: Review Stats */}
              <div className="flex items-center gap-8 lg:gap-12 pl-0 lg:pl-8 lg:border-l border-white/10">
                <div className="text-center">
                  <div className="text-3xl font-serif font-bold text-white mb-1">
                    4.8
                  </div>
                  <div className="flex items-center justify-center gap-0.5 mb-1">
                    {[1, 2, 3, 4].map((s) => (
                      <Star
                        key={s}
                        className="w-3.5 h-3.5 text-primary fill-primary"
                      />
                    ))}
                    <Star className="w-3.5 h-3.5 text-primary fill-primary/50" />
                  </div>
                  <div className="text-[10px] uppercase tracking-widest text-white/50">
                    Google
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-serif font-bold text-white mb-1">
                    160+
                  </div>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="w-4 h-4 text-primary mx-auto mb-1"
                  >
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                  </svg>
                  <div className="text-[10px] uppercase tracking-widest text-white/50">
                    Reviews
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-serif font-bold text-white mb-1">
                    20+
                  </div>
                  <Trophy className="w-4 h-4 text-primary mx-auto mb-1" />
                  <div className="text-[10px] uppercase tracking-widest text-white/50">
                    Years
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* ========================================
          4. FLEET SECTION (carousel with slider buttons)
          ======================================== */}
      <section className="py-24 bg-background relative border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Users className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                Premium Fleet
              </span>
            </div>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Our {city.name} Fleet
            </h2>
            <p className="text-white/70 max-w-2xl mx-auto text-xl font-normal">
              From solo executive travel to group shuttles, our elite fleet is
              configured for comfort, productivity, and discretion.
            </p>
          </div>

          {/* Carousel Container */}
          <div className="max-w-6xl mx-auto relative">
            {/* Left Arrow Button */}
            <button
              onClick={() => emblaApi?.scrollPrev()}
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-12 z-20 w-12 h-12 bg-zinc-900/80 hover:bg-primary border border-white/10 hover:border-primary/40 flex items-center justify-center transition-all duration-300 group"
              aria-label="Previous vehicle"
            >
              <ChevronLeft className="w-5 h-5 text-white group-hover:text-primary-foreground transition-colors" />
            </button>

            {/* Carousel Viewport */}
            <div className="overflow-hidden" ref={emblaRef}>
              <div className="flex gap-4">
                {vehicles.map((vehicle, i) => (
                  <div
                    key={i}
                    className="flex-[0_0_100%] md:flex-[0_0_calc(33.333%-11px)] lg:flex-[0_0_calc(33.333%-11px)] min-w-0"
                  >
                    <Link
                      to={`/fleet/${vehicle.id}`}
                      className="block group h-full"
                    >
                      <Card className="bg-zinc-900/50 border-white/5 overflow-hidden h-full relative transition-all duration-500 hover:border-primary/30 hover:shadow-[0_0_40px_rgba(212,175,55,0.15)]">
                        <div className="aspect-[16/9] overflow-hidden relative">
                          <img
                            src={vehicle.images[0]}
                            alt={`${vehicle.title} in ${city.name}`}
                            loading="lazy"
                            className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity duration-700"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent pointer-events-none"></div>
                          <div className="absolute bottom-0 left-0 p-4 sm:p-6 w-full z-10 pointer-events-none">
                            <h3 className="text-lg sm:text-xl font-serif font-bold text-white mb-1 group-hover:text-primary transition-colors duration-300 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                              {vehicle.shortTitle}
                            </h3>
                            <p className="text-sm text-white/80 font-light drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                              {vehicle.capacity}
                            </p>
                          </div>
                        </div>
                      </Card>
                    </Link>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Arrow Button */}
            <button
              onClick={() => emblaApi?.scrollNext()}
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-12 z-20 w-12 h-12 bg-zinc-900/80 hover:bg-primary border border-white/10 hover:border-primary/40 flex items-center justify-center transition-all duration-300 group"
              aria-label="Next vehicle"
            >
              <ChevronRight className="w-5 h-5 text-white group-hover:text-primary-foreground transition-colors" />
            </button>
          </div>

          <div className="mt-4 text-center">
            <p className="text-sm text-white/40 italic tracking-wide">
              Tap the vehicle to expand
            </p>
          </div>

          <div className="mt-8 flex justify-center">
            <Link to="/fleet" className="w-full max-w-sm">
              <Button className="w-full h-14 bg-gradient-to-b from-zinc-800/40 to-zinc-950 border border-white/10 hover:border-primary/40 text-white text-base tracking-wide rounded-none group relative overflow-hidden transition-all duration-500 shadow-2xl hover:shadow-[0_0_30px_rgba(212,175,55,0.15)]">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
                <span className="relative z-10 flex items-center justify-center">
                  View Full Fleet
                  <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </span>
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* ========================================
          5. TRUST SECTION (image + text blocks)
          ======================================== */}
      <section className="py-24 bg-zinc-950 border-y border-white/5">
        <div className="container mx-auto px-4 space-y-20">
          {/* Block 1 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div className="aspect-[4/3] overflow-hidden border border-white/10 rounded-xl">
              <img
                src={city.trust1.image}
                alt={`Professional chauffeur service in ${city.name}`}
                loading="lazy"
                className="w-full h-full object-cover opacity-85"
              />
            </div>
            <div>
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6 leading-tight">
                {city.trust1.title}
              </h2>
              <p className="text-white/70 text-lg font-normal leading-relaxed mb-6">
                {city.trust1.text}
              </p>
              <ul className="space-y-3">
                {city.trust1.bullets.map((bullet, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-3 text-white/80 text-base"
                  >
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Block 2 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div className="aspect-[4/3] overflow-hidden border border-white/10 rounded-xl order-2 lg:order-1">
              <img
                src={
                  city.slug === "garland"
                    ? "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/bceddc76-1a3e-4adc-a1d7-7a07cc8c0340/standalone/a09fc80f-c97c-4f6e-a72b-fdba9d5557d2-generated-image-1785810555002-0.png"
                    : city.trust2.image
                }
                alt={`DFW airport transfers from ${city.name}`}
                loading="lazy"
                className="w-full h-full object-cover opacity-85"
              />
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6 leading-tight">
                {city.trust2.title}
              </h2>
              <p className="text-white/70 text-lg font-normal leading-relaxed mb-6">
                {city.trust2.text}
              </p>
              <ul className="space-y-3">
                {city.trust2.bullets.map((bullet, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-3 text-white/80 text-base"
                  >
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================
          6. FAQ SECTION (expandable)
          ======================================== */}
      <section className="py-24 bg-zinc-950 border-t border-white/5">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <CheckCircle2 className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                FAQ
              </span>
            </div>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              {city.name} Limo Service FAQ
            </h2>
            <p className="text-white/70 text-xl font-normal">
              Answers to common questions about chauffeur service in $
              {city.name}, TX.
            </p>
          </div>

          <div className="space-y-4">
            {city.faqs.map((faq, i) => (
              <div
                key={i}
                className={`border bg-zinc-900/40 transition-colors ${expandedFaq === i ? "border-primary/20" : "border-white/10"}`}
              >
                <button
                  onClick={() => setExpandedFaq(expandedFaq === i ? null : i)}
                  className="w-full p-6 flex items-start gap-3 text-left cursor-pointer hover:bg-white/[0.02] transition-colors"
                >
                  <span className="text-primary font-serif text-xl shrink-0">
                    {i + 1}.
                  </span>
                  <h3 className="text-lg font-bold text-white flex-1">
                    {faq.question}
                  </h3>
                  <ChevronDown
                    className={`w-5 h-5 text-primary shrink-0 transition-transform duration-300 ${expandedFaq === i ? "rotate-180" : ""}`}
                  />
                </button>
                {expandedFaq === i && (
                  <div className="px-6 pb-6 pl-[52px]">
                    <p className="text-white/70 text-base leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================
          7. FINAL CTA
          ======================================== */}
      <section className="py-24 bg-background border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="bg-zinc-900/80 border border-primary/20 p-12 md:p-20 text-center relative overflow-hidden backdrop-blur-sm">
            <div className="relative z-10">
              <h2 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6">
                Experience {city.name}'s finest chauffeur service.
              </h2>
              <p className="text-2xl text-white/80 mb-10 max-w-2xl mx-auto font-medium">
                Book your ride today or call direct for immediate assistance.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center px-2 sm:px-0">
                <Link
                  to="/quote"
                  onClick={() => (window as any).gtag_report_conversion?.()}
                >
                  <Button
                    size="lg"
                    className="w-full sm:w-auto bg-primary text-primary-foreground hover:bg-primary/90 text-base sm:text-lg rounded-none h-14 sm:h-16 px-4 sm:px-12 shadow-[0_0_20px_rgba(212,175,55,0.2)] text-center whitespace-nowrap"
                  >
                    Get a Quote
                    <ArrowRight className="w-5 h-5 ml-2 shrink-0" />
                  </Button>
                </Link>
                <a
                  href="tel:9726083680"
                  onClick={() => (window as any).gtag_report_conversion?.()}
                >
                  <Button
                    size="lg"
                    variant="outline"
                    className="w-full sm:w-auto border-white/20 text-white hover:bg-white/10 text-base sm:text-lg rounded-none h-14 sm:h-16 px-6 sm:px-12 bg-transparent backdrop-blur-sm transition-all text-center whitespace-nowrap"
                  >
                    <Phone className="w-5 h-5 mr-2 shrink-0" />
                    Call 972-608-3680
                  </Button>
                </a>
              </div>

              <div className="mt-12 pt-8 border-t border-white/10 flex flex-wrap justify-center gap-6">
                <div className="inline-flex items-center gap-2 text-white/40 text-xs font-light">
                  <Shield className="w-4 h-4 text-primary/60" />
                  <span>TxDOT Licensed & Insured</span>
                </div>
                <div className="inline-flex items-center gap-2 text-white/40 text-xs font-light">
                  <Plane className="w-4 h-4 text-primary/60" />
                  <span>DFW Airport Permitted</span>
                </div>
                <div className="inline-flex items-center gap-2 text-white/40 text-xs font-light">
                  <CheckCircle2 className="w-4 h-4 text-primary/60" />
                  <span>$1.5M+ Commercial Liability Coverage</span>
                </div>
                <div className="inline-flex items-center gap-2 text-white/40 text-xs font-light">
                  <Clock className="w-4 h-4 text-primary/60" />
                  <span>24/7 Dispatch & Reservations</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <CompactServiceArea />
    </div>
  );
};

export default CityService;

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Phone, Star, ChevronRight, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { vehicles } from "@/data/vehicles";
import { SEOHead } from "@/components/SEOHead";
import CompactServiceArea from "@/components/CompactServiceArea";
import {
  ServiceTopSections,
  ServiceExploreSection,
} from "@/components/ServiceSections";
import { serviceConfigs } from "@/data/serviceConfigs";

const ServiceHolidayLights = () => {
  return (
    <div className="min-h-screen bg-[#0d0d0d] text-foreground font-sans selection:bg-primary/30">
      <SEOHead
        title="Holiday Light Tours | Addison Limos"
        description="Experience the magic of the holiday season with private, chauffeur-driven tours of the most spectacular festive light displays across the DFW metroplex."
        canonical="https://addisonlimos.com/service-holiday-lights"
      />
      {/* Header Section */}
      <section className="pt-32 pb-16 px-4 relative border-b border-white/5 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-b from-primary/10 to-transparent pointer-events-none"></div>
        <div className="absolute inset-0 z-0 opacity-20">
          <img
            src="https://vibe.filesafe.space/1792719026995615993/attachments/98e642a1-d7bd-4b94-9cd9-4fd684dd040c.jpg"
            alt="Holiday light tour limo"
            className="w-full h-full object-cover"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0d0d0d] via-[#0d0d0d]/80 to-transparent"></div>
        </div>
        <div className="container mx-auto relative z-10">
          <Link
            to="/services"
            className="inline-flex items-center text-white/60 hover:text-primary transition-colors mb-8 group"
          >
            <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Services
          </Link>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-3xl flex flex-col">
              <div className="order-2 md:order-1 mt-6 md:mt-0">
                <h1 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6">
                  Holiday Light Tours
                </h1>
                <p className="text-base md:text-xl text-white/70 font-light leading-relaxed">
                  <span className="md:hidden">
                    Private tours of DFW's best holiday light displays.
                  </span>
                  <span className="hidden md:inline">
                    Experience the magic of the holiday season with private,
                    chauffeur-driven tours of the most spectacular festive light
                    displays across the DFW metroplex.
                  </span>
                </p>
              </div>
            </div>
            <Link to="/quote?service=Holiday%20Light%20Tours">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg rounded-none h-14 px-8 shadow-[0_0_20px_rgba(212,175,55,0.2)] whitespace-nowrap"
              >
                Book Light Tour
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <ServiceTopSections config={serviceConfigs.holidayLights} />

      {/* Recommended Fleet Section */}
      <section className="py-24 bg-zinc-950 relative border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Ideal for Light Tours
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
              Explore our most popular vehicles for festive sightseeing.
            </p>
          </div>

          <div className="relative py-12">
            {/* Top Line */}
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>

            <p className="text-center text-sm text-white/40 mb-3 relative z-10">
              Tap the vehicle to expand
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10 max-w-6xl mx-auto">
              {[
                "mercedes-sprinter-limo",
                "h2-hummer-stretch-limo",
                "luxury-black-stretch-limo",
              ]
                .map((id) => vehicles.find((v) => v.id === id))
                .filter(Boolean)
                .map((vehicle, i) => (
                  <Card
                    key={i}
                    className="bg-zinc-900/50 border-white/5 overflow-hidden group rounded-none relative"
                  >
                    <div className="aspect-[16/9] overflow-hidden relative group/carousel">
                      <Carousel opts={{ loop: true }} className="w-full h-full">
                        <CarouselContent className="h-full ml-0">
                          {vehicle.images.map((img, idx) => (
                            <CarouselItem
                              key={idx}
                              className="pl-0 h-full relative overflow-hidden"
                            >
                              <Link
                                to={`/fleet/${vehicle.id}`}
                                className="block w-full h-full cursor-pointer overflow-hidden"
                              >
                                <img
                                  src={img}
                                  alt={`${vehicle.title} view ${idx + 1}`}
                                  className={`w-full h-full transition-transform duration-1000 opacity-80 group-hover:opacity-100 group-hover:scale-105 ${vehicle.id === "luxury-black-stretch-limo" ? (idx === 1 ? "object-cover object-bottom -translate-y-6 sm:-translate-y-8" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-12 sm:-translate-y-16" : "object-cover object-center") : vehicle.id === "mercedes-sprinter-limo" ? (idx === 1 ? "object-cover object-bottom -translate-y-24 sm:-translate-y-40" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-8 sm:-translate-y-12" : "object-cover object-center") : vehicle.id === "mercedes-sprinter-van" ? (idx === 1 ? "object-cover object-bottom -translate-y-24 sm:-translate-y-40" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-8 sm:-translate-y-12" : "object-cover object-center") : "object-cover object-center"}`}
                                />
                              </Link>
                            </CarouselItem>
                          ))}
                        </CarouselContent>
                        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/50 to-transparent pointer-events-none z-10"></div>
                        <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                        <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                      </Carousel>
                    </div>
                    <CardContent className="absolute bottom-0 left-0 p-6 w-full z-30 pointer-events-none">
                      <h3 className="text-2xl font-serif font-bold text-white mb-2 group-hover:text-primary transition-colors drop-shadow-md">
                        <Link
                          to={`/fleet/${vehicle.id}`}
                          className="pointer-events-auto hover:text-primary transition-colors"
                        >
                          {vehicle.title}
                        </Link>
                      </h3>
                    </CardContent>
                  </Card>
                ))}
            </div>

            {/* Bottom Line */}
            <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>
          </div>

          <div className="mt-10 flex justify-center">
            <Link to="/fleet" className="w-full max-w-sm">
              <Button className="w-full h-14 bg-gradient-to-b from-zinc-800/40 to-zinc-950 border border-white/10 hover:border-primary/40 text-white text-base tracking-wide rounded-none group relative overflow-hidden transition-all duration-500 shadow-2xl hover:shadow-[0_0_30px_rgba(212,175,55,0.15)]">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
                <span className="relative z-10 flex items-center justify-center">
                  View Full Fleet
                  <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </span>
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Commitment & Chauffeurs Section */}
      <section className="py-24 px-4 bg-[#0d0d0d] relative border-t border-white/5">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16">
            {/* Our Commitment */}
            <div className="space-y-6">
              <div className="aspect-[4/3] overflow-hidden border border-white/5 relative group rounded-xl">
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/assets/e89d6a0f-238a-446c-be31-f39c5b4910fa.png"
                  alt="Magical Winter Wonderland Tours"
                  className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent"></div>
              </div>
              <h2 className="text-3xl font-serif font-bold text-white">
                Magical Winter Wonderland Tours
              </h2>
              <p className="text-white/60 font-light leading-relaxed text-lg">
                Immerse yourself in the holiday spirit with a guided Christmas
                light limo tour DFW showcasing the best festive light displays
                in the area. Gather your loved ones, sip hot cocoa, and enjoy
                the sparkling neighborhoods from the warmth of our luxury
                holiday light transportation, discovering the best displays on
                your Dallas holiday light tours with complete peace of mind.
              </p>
            </div>

            {/* Our Chauffeurs */}
            <div className="space-y-6">
              <div className="aspect-[4/3] overflow-hidden border border-white/5 relative group rounded-xl">
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/attachments/f7a9d407-0331-49c9-9708-0a92f1feb1f4.jpg"
                  alt="Your Guides to Festive Cheer"
                  className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent"></div>
              </div>
              <h2 className="text-3xl font-serif font-bold text-white">
                Your Guides to Festive Cheer
              </h2>
              <p className="text-white/60 font-light leading-relaxed text-lg">
                Our professional holiday light tour driver Dallas team knows
                exactly where the most spectacular holiday lights are shining.
                Your DFW Christmas light chauffeur navigates the busy winter
                streets safely and smoothly, ensuring your family's holiday
                tradition is filled with joy and wonder, providing an
                accommodating and secure guided festive light tour Dallas
                tailored exactly to your traditions.
              </p>
            </div>
          </div>

          <div className="mt-16 flex justify-center">
            <a
              href="tel:9726083680"
              onClick={() => (window as any).gtag_report_conversion?.()}
            >
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg rounded-none h-14 px-10 shadow-[0_0_20px_rgba(212,175,55,0.2)] whitespace-nowrap group"
              >
                <Phone className="w-5 h-5 mr-3" />
                Call 972-608-3680
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Reviews Preview Section */}
      <section className="py-24 bg-background relative border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary via-white to-white">
              5-Star Rated Award Winning Service
            </h2>
          </div>

          <div className="flex justify-center mb-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-primary/20 backdrop-blur-sm">
              <Star className="w-4 h-4 text-primary fill-primary" />
              <span className="text-xs sm:text-sm font-semibold tracking-widest uppercase text-white/90 text-center">
                Winner of Addison Magazine's Readers Choice Award
              </span>
            </div>
          </div>

          <div className="flex flex-row items-center justify-center gap-4 sm:gap-16 bg-zinc-900/50 border border-white/10 p-4 sm:p-8 rounded-none max-w-3xl mx-auto backdrop-blur-sm mb-12 sm:mb-16">
            <div className="text-center flex-1">
              <div className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-white mb-1 sm:mb-2">
                4.8
              </div>
              <div className="flex items-center justify-center gap-1 mb-1 sm:mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className="w-3 h-3 sm:w-5 sm:h-5 text-primary fill-primary"
                  />
                ))}
              </div>
              <div className="text-[10px] sm:text-sm text-white/60 uppercase tracking-widest">
                Average Rating
              </div>
            </div>
            <div className="w-px h-16 sm:h-20 bg-white/10 shrink-0"></div>
            <div className="text-center flex-1">
              <div className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-white mb-1 sm:mb-2">
                160+
              </div>
              <div className="flex items-center justify-center gap-1 mb-1 sm:mb-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-3 h-3 sm:w-5 sm:h-5 text-primary"
                >
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
              </div>
              <div className="text-[10px] sm:text-sm text-white/60 uppercase tracking-widest">
                Verified Reviews
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-8 mb-12 -mx-2 sm:mx-0">
            {[
              {
                name: "Amy O'Malley",
                text: "I have used Addison Limos twice now to transport customers to and from business dinners in the Grapevine / Coppell area. Both times the experience could not have been better! The Mercedes Sprinters were spotless and perfect for our groups...",
              },
              {
                name: "Alli Enzo",
                text: "The customer service was amazing, from the first phone call to the final drop-off, you were treated like your reservation was the most important thing they needed to do that day. Our party had several major changes during the trip and they...",
              },
              {
                name: "Betty Becker",
                text: "Once again I cannot say enough good things about Addison car and Limo service. The communication is wonderful , pricing is competitive , car was immaculate and the drivers are fantastic. Dale met me at the airport today and what a genuinely...",
              },
            ].map((review, i) => (
              <Card
                key={i}
                className={`bg-zinc-900/40 border-white/5 rounded-none hover:bg-zinc-900/60 transition-all duration-300 group ${i >= 3 ? "hidden md:block" : ""}`}
              >
                <CardContent className="p-3 sm:p-8 flex flex-col h-full">
                  <div className="flex items-center gap-0.5 mb-2 sm:mb-6">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className="w-3 h-3 sm:w-4 sm:h-4 text-primary fill-primary"
                      />
                    ))}
                  </div>
                  <p className="text-sm sm:text-base text-white/80 font-light leading-relaxed mb-3 sm:mb-8 italic flex-grow">
                    "{review.text}"
                  </p>
                  <div className="flex items-center gap-2 sm:gap-4 mt-auto pt-3 sm:pt-4 border-t border-white/5">
                    <div className="w-8 h-8 sm:w-12 sm:h-12 bg-primary/10 rounded-full flex items-center justify-center border border-primary/20 shrink-0">
                      <span className="text-primary font-serif font-bold text-sm sm:text-lg">
                        {review.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <div className="text-white font-medium text-sm sm:text-base">
                        {review.name}
                      </div>
                      <div className="text-[10px] sm:text-xs text-white/50">
                        Google Review
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Link to="/reviews">
              <Button
                size="lg"
                className="bg-transparent border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground text-base tracking-wide rounded-none h-14 px-10 transition-all duration-300"
              >
                See All Reviews
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <ServiceExploreSection config={serviceConfigs.holidayLights} />

      <CompactServiceArea />
    </div>
  );
};

export default ServiceHolidayLights;

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Phone,
  Users,
  Check,
  ChevronRight,
  ArrowLeft,
  X,
  ChevronLeft,
  Play,
  Images,
} from "lucide-react";
import { Link, useParams, Navigate } from "react-router-dom";
import { vehicles } from "@/data/vehicles";
import { SEOHead } from "@/components/SEOHead";
import CompactServiceArea from "@/components/CompactServiceArea";
import { VehiclePopularEvents } from "@/components/VehiclePopularEvents";
import { PrivateCarQuoteForm } from "@/components/PrivateCarQuoteForm";

const vehicleFormConfig: Record<
  string,
  {
    prefix: string;
    name: string;
    heading: string;
    hourlyOnly?: boolean;
    noForm?: boolean;
  }
> = {
  "h2-hummer-stretch-limo": {
    prefix: "h2-hummer",
    name: "H2 Hummer",
    heading: "Reserve the H2 Hummer Limo",
    hourlyOnly: true,
  },
  "mercedes-sprinter-limo": {
    prefix: "sprinter-limo",
    name: "Sprinter Limo",
    heading: "Reserve the Mercedes Sprinter Limo",
    hourlyOnly: true,
  },
  "luxury-black-stretch-limo": {
    prefix: "stretch-limo",
    name: "Stretch Limo",
    heading: "Reserve the Chrysler 300 Stretch Limo",
    hourlyOnly: true,
  },
  "lincoln-navigator-suv": {
    prefix: "private-car",
    name: "Private Car",
    heading: "Reserve the Lincoln Navigator",
  },
  "mercedes-sprinter-executive": {
    prefix: "sprinter-executive",
    name: "Sprinter Executive",
    heading: "Reserve the Sprinter Executive",
    hourlyOnly: true,
  },
  "mercedes-sprinter-van": {
    prefix: "sprinter-van",
    name: "Sprinter Van",
    heading: "Reserve the Mercedes Sprinter Van",
  },
};

const VehicleDetail = () => {
  const { id } = useParams<{ id: string }>();
  const vehicle = vehicles.find((v) => v.id === id);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  if (!vehicle) {
    return <Navigate to="/fleet" replace />;
  }

  return (
    <div className="min-h-screen bg-[#0d0d0d] text-foreground font-sans selection:bg-primary/30">
      <SEOHead
        title={`${vehicle.title} | Luxury Fleet`}
        description={vehicle.desc}
        canonical={`https://addisonlimos.com/fleet/${vehicle.id}`}
        ogImage={vehicle.images[0]}
        schemaJson={{
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: (vehicle.faqs || []).map((faq) => ({
            "@type": "Question",
            name: faq.question,
            acceptedAnswer: {
              "@type": "Answer",
              text: faq.answer,
            },
          })),
        }}
      />
      {/* Header Section */}
      <section className="pt-32 pb-16 px-4 relative border-b border-white/5">
        <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none"></div>
        <div className="container mx-auto relative z-10">
          <Link
            to="/fleet"
            className="inline-flex items-center text-white/60 hover:text-primary transition-colors mb-8 group"
          >
            <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Fleet
          </Link>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h1 className="text-4xl md:text-6xl font-serif font-bold text-white mb-4">
                {vehicle.title}
              </h1>
              <div className="flex items-center gap-3">
                <div className="bg-white/5 border border-white/10 px-4 py-2 flex items-center gap-2">
                  <Users className="w-5 h-5 text-primary" />
                  <span className="text-white font-medium tracking-wide">
                    {vehicle.capacity}
                  </span>
                </div>
              </div>
            </div>
            <Link to={`/quote?vehicle=${encodeURIComponent(vehicle.title)}`}>
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg rounded-none h-14 px-8 shadow-[0_0_20px_rgba(212,175,55,0.2)]"
              >
                Reserve This Vehicle
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* Left Col: Images */}
            <div className="lg:col-span-6">
              <div className="aspect-[16/9] overflow-hidden relative group/carousel border border-white/5 bg-zinc-900/50">
                <Carousel opts={{ loop: true }} className="w-full h-full">
                  <CarouselContent className="h-full ml-0">
                    {vehicle.images.map((img, idx) => (
                      <CarouselItem
                        key={idx}
                        className="pl-0 h-full relative overflow-hidden"
                      >
                        <img
                          src={img}
                          alt={`${vehicle.title} view ${idx + 1}`}
                          className={`w-full h-full transition-transform duration-1000 ${
                            vehicle.id === "luxury-black-stretch-limo"
                              ? idx === 1
                                ? "object-cover object-bottom -translate-y-6 sm:-translate-y-8"
                                : idx === 2 || idx === 3
                                  ? "object-cover object-bottom -translate-y-12 sm:-translate-y-16"
                                  : "object-cover object-center"
                              : vehicle.id === "mercedes-sprinter-limo"
                                ? idx === 1
                                  ? "object-cover object-bottom -translate-y-36 sm:-translate-y-60"
                                  : idx === 2
                                    ? "object-cover object-bottom -translate-y-12 sm:-translate-y-20"
                                    : idx === 3
                                      ? "object-cover object-bottom -translate-y-20 sm:-translate-y-32"
                                      : "object-cover object-center"
                                : vehicle.id === "mercedes-sprinter-van"
                                  ? idx === 1
                                    ? "object-cover object-bottom -translate-y-36 sm:-translate-y-60"
                                    : idx === 2
                                      ? "object-cover object-bottom -translate-y-12 sm:-translate-y-20"
                                      : idx === 3
                                        ? "object-cover object-bottom -translate-y-20 sm:-translate-y-32"
                                        : "object-cover object-center"
                                  : "object-cover object-center"
                          }`}
                        />
                      </CarouselItem>
                    ))}
                  </CarouselContent>
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/80 via-transparent to-transparent pointer-events-none z-10"></div>
                  <CarouselPrevious className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                  <CarouselNext className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                </Carousel>
              </div>

              <div className="text-xs text-white/40 text-center mt-4 mb-2 uppercase tracking-widest">
                Tap to enlarge
              </div>
              <div className="grid grid-cols-3 gap-4">
                {vehicle.images.slice(0, 8).map((img, idx) => {
                  const extraCount = vehicle.images.length - 8;
                  const isLastVisible = idx === 7 && extraCount > 0;
                  return (
                    <div
                      key={idx}
                      onClick={() => setLightboxIndex(idx)}
                      className="aspect-[16/9] border border-white/5 overflow-hidden bg-zinc-900/50 cursor-pointer hover:border-primary/50 transition-colors relative group"
                    >
                      <img
                        src={img}
                        alt={`${vehicle.title} thumbnail ${idx + 1}`}
                        className="w-full h-full object-cover object-center opacity-80 group-hover:opacity-100 transition-opacity"
                      />
                      {isLastVisible && (
                        <div className="absolute inset-0 bg-black/60 group-hover:bg-black/70 flex flex-col items-center justify-center gap-1 transition-colors">
                          <Images className="w-6 h-6 text-primary" />
                          <span className="text-white font-semibold text-sm">
                            +{extraCount}
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })}
                {(vehicle as any).video && (
                  <div
                    onClick={() => setLightboxIndex(vehicle.images.length)}
                    className="aspect-[16/9] border border-white/5 overflow-hidden bg-zinc-900/50 cursor-pointer hover:border-primary/50 transition-colors relative group"
                  >
                    <img
                      src={(vehicle as any).videoThumbnail}
                      alt={`${vehicle.title} video`}
                      className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-12 h-12 rounded-full bg-primary/90 flex items-center justify-center text-black shadow-[0_0_15px_rgba(212,175,55,0.5)] group-hover:scale-110 transition-transform">
                        <Play className="w-5 h-5 ml-1" fill="currentColor" />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {(vehicle.id === "h2-hummer-stretch-limo" ||
                vehicle.id === "mercedes-sprinter-limo" ||
                vehicle.id === "luxury-black-stretch-limo" ||
                vehicle.id === "lincoln-navigator-suv") && (
                <div className="mt-10 bg-zinc-900/40 border border-white/5 p-8 rounded-xl">
                  <h4 className="text-xl font-serif font-bold text-white mb-2">
                    Need a Custom Quote?
                  </h4>
                  <p className="text-white/60 mb-6 font-light">
                    Get a custom quote for point-to-point or round trip
                    transportation with the {vehicle.title}.
                  </p>
                  <div className="flex flex-col gap-4">
                    <Link
                      to={`/quote?vehicle=${encodeURIComponent(vehicle.title)}`}
                      className="block w-full"
                    >
                      <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-none h-14 text-base font-medium">
                        Get a Quote
                      </Button>
                    </Link>
                    <a
                      href="tel:9726083680"
                      className="block w-full"
                      onClick={() => (window as any).gtag_report_conversion?.()}
                    >
                      <Button
                        variant="outline"
                        className="w-full border-white/20 text-white hover:bg-white/10 rounded-none h-14 text-base bg-transparent font-medium"
                      >
                        <Phone className="w-4 h-4 mr-2" />
                        Call 972-608-3680
                      </Button>
                    </a>
                  </div>
                </div>
              )}
            </div>

            {/* Right Col: Details */}
            <div className="lg:col-span-6 space-y-10">
              <div>
                <h3 className="text-2xl font-serif font-bold text-white mb-4">
                  Vehicle Overview
                </h3>
                <p className="text-white/70 font-light leading-relaxed text-lg">
                  {vehicle.desc}
                </p>
              </div>

              <div>
                <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-3 sm:mb-4">
                  Premium Amenities
                </h3>
                <ul className="grid grid-cols-2 gap-1.5 sm:gap-2.5">
                  {vehicle.amenities.map((amenity, j) => (
                    <li
                      key={j}
                      className="flex items-center gap-1.5 sm:gap-2.5 px-2 sm:px-3 py-1.5 sm:py-2 bg-zinc-900/40 border border-white/5 rounded-sm min-h-[38px] sm:min-h-[44px]"
                    >
                      <Check className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-primary shrink-0" />
                      <span className="text-[11px] sm:text-xs md:text-sm text-white/85 font-light leading-tight">
                        {amenity}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              {!vehicleFormConfig[vehicle.id]?.noForm && (
                <div className="bg-zinc-800 border border-zinc-700 p-4 lg:p-6 rounded-2xl overflow-hidden pb-[36px] lg:pb-6">
                  <PrivateCarQuoteForm
                    formIdPrefix={
                      vehicleFormConfig[vehicle.id]?.prefix ?? vehicle.id
                    }
                    formNamePrefix={
                      vehicleFormConfig[vehicle.id]?.name ?? vehicle.title
                    }
                    heading={vehicleFormConfig[vehicle.id]?.heading}
                    subheading="One way, round trip, or hourly — get an instant quote."
                    hourlyOnly={vehicleFormConfig[vehicle.id]?.hourlyOnly}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Vehicle-Specific FAQ Section */}
      {vehicle.faqs && vehicle.faqs.length > 0 && (
        <section className="py-24 px-4 bg-zinc-950 border-t border-white/5">
          <div className="container mx-auto max-w-3xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
                {vehicle.title} FAQs
              </h2>
              <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
                Common questions about renting the {vehicle.title} in
                Dallas-Fort Worth.
              </p>
            </div>
            <Accordion type="single" collapsible className="w-full">
              {vehicle.faqs.map((faq, i) => (
                <AccordionItem
                  key={i}
                  value={`item-${i}`}
                  className="border-white/10"
                >
                  <AccordionTrigger className="text-left text-base sm:text-lg font-serif text-white hover:text-primary transition-colors">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-white/60 font-light leading-relaxed text-sm sm:text-base">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
            <div className="text-center mt-12">
              <p className="text-white/60 mb-6 text-lg font-light">
                Ready to book the {vehicle.title}?
              </p>
              <a
                href="tel:9726083680"
                className="inline-block"
                onClick={() => (window as any).gtag_report_conversion?.()}
              >
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-none px-8 h-12">
                  <Phone className="w-4 h-4 mr-2" />
                  Call 972-608-3680
                </Button>
              </a>
            </div>
          </div>
        </section>
      )}

      {/* Popular Events Section */}
      <VehiclePopularEvents vehicle={vehicle} />

      <CompactServiceArea />

      {lightboxIndex !== null && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4 backdrop-blur-sm"
          onClick={() => setLightboxIndex(null)}
        >
          <button
            className="absolute top-6 right-6 text-white/70 hover:text-white bg-black/50 hover:bg-primary/20 p-2 rounded-full transition-all"
            onClick={(e) => {
              e.stopPropagation();
              setLightboxIndex(null);
            }}
          >
            <X className="w-8 h-8" />
          </button>

          <button
            className="absolute left-4 md:left-10 top-1/2 -translate-y-1/2 text-white/70 hover:text-white bg-black/50 hover:bg-primary/20 p-3 rounded-full transition-all"
            onClick={(e) => {
              e.stopPropagation();
              const total =
                vehicle.images.length + ((vehicle as any).video ? 1 : 0);
              setLightboxIndex((lightboxIndex - 1 + total) % total);
            }}
          >
            <ChevronLeft className="w-8 h-8" />
          </button>

          {lightboxIndex === vehicle.images.length && (vehicle as any).video ? (
            <div
              className="w-full max-w-6xl aspect-video bg-black rounded-lg overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <iframe
                src={(vehicle as any).video}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          ) : (
            <img
              src={vehicle.images[lightboxIndex]}
              alt={`${vehicle.title} fullscreen`}
              className="max-w-full max-h-[90vh] object-contain shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            />
          )}

          <button
            className="absolute right-4 md:right-10 top-1/2 -translate-y-1/2 text-white/70 hover:text-white bg-black/50 hover:bg-primary/20 p-3 rounded-full transition-all"
            onClick={(e) => {
              e.stopPropagation();
              const total =
                vehicle.images.length + ((vehicle as any).video ? 1 : 0);
              setLightboxIndex((lightboxIndex + 1) % total);
            }}
          >
            <ChevronRight className="w-8 h-8" />
          </button>

          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-white/50 text-sm tracking-widest font-medium">
            {lightboxIndex + 1} /{" "}
            {vehicle.images.length + ((vehicle as any).video ? 1 : 0)}
          </div>
        </div>
      )}
    </div>
  );
};

export default VehicleDetail;

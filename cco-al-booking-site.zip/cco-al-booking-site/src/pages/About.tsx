import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Phone,
  Star,
  Shield,
  Clock,
  Award,
  Users,
  TrendingUp,
  Heart,
  CheckCircle2,
  ChevronRight,
  MapPin,
} from "lucide-react";
import { Link } from "react-router-dom";
import { SEOHead } from "@/components/SEOHead";
import CompactServiceArea from "@/components/CompactServiceArea";

const milestones = [
  {
    year: "2003",
    title: "Founded in Addison, TX",
    desc: "Addison Limos begins operations with a single stretch limousine and a commitment to punctuality.",
  },
  {
    year: "2008",
    title: "Corporate Division Launched",
    desc: "Expanded into executive chauffeur services with dedicated corporate accounts and Net-30 billing.",
  },
  {
    year: "2014",
    title: "Fleet Modernization",
    desc: "Introduced Mercedes Sprinter Limos and Executive Vans to meet growing group travel demand across DFW.",
  },
  {
    year: "2019",
    title: "Readers Choice Award",
    desc: "Named Addison Magazine's Readers Choice for premier luxury transportation, a distinction we continue to uphold.",
  },
  {
    year: "2026",
    title: "FIFA World Cup Transportation",
    desc: "Selected to handle complex logistics during the DFW World Cup, navigating record crowds with zero delays.",
  },
];

const values = [
  {
    icon: Shield,
    title: "Safety & Compliance",
    desc: "$1.5M+ commercial liability coverage, background-checked chauffeurs, and a zero-tolerance drug & alcohol policy. Every vehicle is inspected to exceed industry standards.",
  },
  {
    icon: Clock,
    title: "Relentless Punctuality",
    desc: "Our chauffeurs arrive a minimum of 15 minutes before every scheduled pickup. We monitor flights, traffic, and weather so your timeline is never compromised.",
  },
  {
    icon: Heart,
    title: "Guest-First Hospitality",
    desc: "From the first phone call to the final drop-off, every interaction is treated with white-glove care. We answer our phones 24/7. No call centers, no hold music.",
  },
  {
    icon: Award,
    title: "Uncompromising Standards",
    desc: "Our vehicles are immaculate, our chauffeurs are professionally uniformed, and our service is held to a 5-star benchmark that has earned 160+ verified Google reviews.",
  },
];

const stats = [
  { value: "20+", label: "Years of Service" },
  { value: "160+", label: "5-Star Reviews" },
  { value: "ELITE", label: "Fleet" },
  { value: "24/7", label: "Availability" },
];

const About = () => {
  const [activeValueTab, setActiveValueTab] = useState(0);
  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/30">
      <SEOHead
        title="About Addison Limos | 20+ Years of Luxury Chauffeur Service in DFW"
        description="Learn about Addison Limos, Dallas-Fort Worth's premier 5-star private ground transportation company. 20+ years of excellence, $1.5M+ commercial coverage, and a fleet built for corporate standards."
        canonical="https://addisonlimos.com/about"
        schemaJson={{
          "@context": "https://schema.org",
          "@type": "AboutPage",
          name: "About Addison Limos",
          url: "https://addisonlimos.com/about",
          mainEntity: {
            "@type": "LimousineService",
            name: "Addison Limos",
            url: "https://addisonlimos.com",
            telephone: "972-608-3680",
            priceRange: "$$$",
            foundingDate: "2003",
            areaServed: "Dallas-Fort Worth Metroplex",
            address: {
              "@type": "PostalAddress",
              addressLocality: "Addison",
              addressRegion: "TX",
              postalCode: "75001",
              addressCountry: "US",
            },
          },
        }}
      />

      {/* Hero */}
      <section className="relative min-h-[70vh] flex items-center pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://vibe.filesafe.space/1792719026995615993/attachments/af133c99-d0b1-4918-a338-94a0cefc553b.webp"
            alt="Addison Limos luxury fleet"
            className="w-full h-full object-cover opacity-30"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/85 to-background/40"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
        </div>

        <div className="container relative z-10 mx-auto px-4">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-8">
              <Star className="w-3.5 h-3.5 text-primary fill-primary" />
              <span className="text-[10px] sm:text-xs font-semibold tracking-widest uppercase text-white/90">
                Established 2003 • Addison, Texas
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif font-bold text-white leading-[1.15] mb-6">
              Two Decades of <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/60">
                Excellence in Motion.
              </span>
            </h1>

            <p className="text-lg md:text-xl text-white/70 mb-10 max-w-2xl leading-relaxed font-light">
              For over 20 years, Addison Limos has set the standard for luxury
              ground transportation across the Dallas-Fort Worth metroplex. What
              began with a single stretch limousine has grown into a premier
              fleet trusted by Fortune 500 executives, discerning couples, and
              families celebrating life's most important moments.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/quote"
                className="w-full sm:w-auto"
                onClick={() => (window as any).gtag_report_conversion?.()}
              >
                <Button
                  size="lg"
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 text-base sm:text-lg rounded-none h-14 px-8 shadow-[0_0_20px_rgba(212,175,55,0.3)] transition-all hover:shadow-[0_0_30px_rgba(212,175,55,0.5)]"
                >
                  Get Quote
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <a
                href="tel:9726083680"
                className="w-full sm:w-auto"
                onClick={() => (window as any).gtag_report_conversion?.()}
              >
                <Button
                  size="lg"
                  variant="outline"
                  className="w-full border-white/20 text-white hover:bg-white/10 text-base sm:text-lg rounded-none h-14 px-8 bg-transparent backdrop-blur-sm transition-all"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  Call 972-608-3680
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="py-16 bg-zinc-950 border-y border-white/5">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <div key={i} className="text-center group">
                <div className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/60 mb-3 group-hover:scale-110 transition-transform duration-300 inline-block">
                  {stat.value}
                </div>
                <div className="text-xs sm:text-sm text-white/50 uppercase tracking-widest font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Users className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                Our Story
              </span>
            </div>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Built on Trust, Driven by Excellence
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto text-lg font-light leading-relaxed">
              Addison Limos was founded on a simple principle: luxury
              transportation should be effortless, reliable, and genuinely
              personal. Two decades later, that principle still guides every
              ride.
            </p>
          </div>

          <div className="space-y-8 text-white/70 leading-relaxed text-lg font-light">
            <p>
              In 2003, we started with a single stretch limousine and a phone
              that never stopped ringing. The Dallas-Fort Worth metroplex was
              growing fast, and businesses, families, and event planners needed
              a transportation partner they could count on, not just for a nice
              car, but for a complete experience that began the moment they
              picked up the phone.
            </p>
            <p>
              Over the years, we've carefully expanded our fleet to include the
              Chrysler 300 Stretch Limo, H2 Hummer Limo, Mercedes Sprinter Limos
              and Executive Vans, and Lincoln Navigator SUVs, each selected for
              its comfort, reliability, and ability to meet the exacting
              standards of our corporate and private clients. Every vehicle in
              our fleet is meticulously maintained, professionally detailed, and
              operated by chauffeurs who understand that discretion is just as
              important as punctuality.
            </p>
            <p>
              When the FIFA World Cup came to DFW in 2026, we were entrusted
              with navigating some of the most complex transportation logistics
              the region had ever seen. Record crowds, unpredictable traffic,
              and tight schedules. Our team handled it all without a single
              missed pickup. That level of performance under pressure is what
              separates a ride from a reputation.
            </p>
            <p>
              Today, with 160+ verified 5-star Google reviews and the Addison
              Magazine Readers Choice Award, Addison Limos stands as one of the
              most trusted names in DFW luxury transportation. But we're not
              done growing. We continue to invest in our fleet, our technology,
              and our people to ensure that the next 20 years are even better
              than the first.
            </p>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-24 bg-zinc-950 border-y border-white/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <TrendingUp className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                Our Journey
              </span>
            </div>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Milestones That Shaped Us
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
              Two decades of growth, innovation, and unwavering commitment to
              our clients.
            </p>
          </div>

          <div className="max-w-3xl mx-auto relative">
            {/* Vertical line */}
            <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-primary/40 via-primary/20 to-transparent md:-translate-x-px"></div>

            <div className="space-y-12">
              {milestones.map((m, i) => (
                <div
                  key={i}
                  className={`relative flex items-start gap-6 md:gap-0 ${i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}
                >
                  {/* Dot */}
                  <div className="absolute left-4 md:left-1/2 w-3 h-3 rounded-full bg-primary border-2 border-zinc-950 md:-translate-x-1.5 mt-2 z-10 shadow-[0_0_10px_rgba(212,175,55,0.4)]"></div>

                  {/* Content */}
                  <div
                    className={`pl-12 md:pl-0 md:w-1/2 ${i % 2 === 0 ? "md:pr-12 md:text-right" : "md:pl-12"}`}
                  >
                    <div className="bg-zinc-900/60 border border-white/10 p-6 hover:border-primary/30 transition-all duration-300 group hover:shadow-[0_0_20px_rgba(212,175,55,0.1)]">
                      <div className="text-primary font-serif font-bold text-2xl mb-2 group-hover:scale-105 transition-transform inline-block">
                        {m.year}
                      </div>
                      <h3 className="text-white font-serif font-bold text-lg mb-2">
                        {m.title}
                      </h3>
                      <p className="text-white/60 text-sm font-light leading-relaxed">
                        {m.desc}
                      </p>
                    </div>
                  </div>
                  {/* Spacer */}
                  <div className="hidden md:block md:w-1/2"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Values Interactive Section */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Award className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                What We Stand For
              </span>
            </div>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              The Addison Limos Standard
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
              Four principles that have guided every decision for over two
              decades.
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <div className="bg-zinc-900/40 border border-white/10 backdrop-blur-sm overflow-hidden">
              {/* Tab Headers */}
              <div className="grid grid-cols-2 border-b border-white/10">
                {values.map((v, i) => (
                  <button
                    key={i}
                    onMouseEnter={() => setActiveValueTab(i)}
                    onClick={() => setActiveValueTab(i)}
                    id={`value-tab-${i}`}
                    className={`p-5 md:p-6 text-left transition-all duration-300 cursor-pointer group ${activeValueTab === i ? "bg-primary/15 border-b-2 border-b-primary" : "hover:bg-white/[0.03]"} ${i === 1 || i === 3 ? "border-l border-white/5" : ""}`}
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-10 h-10 flex items-center justify-center shrink-0 transition-all duration-300 ${activeValueTab === i ? "bg-primary/20" : "bg-white/[0.05] group-hover:bg-primary/15"}`}
                      >
                        <v.icon
                          className={`w-5 h-5 transition-colors ${activeValueTab === i ? "text-primary" : "text-white/50 group-hover:text-primary"}`}
                        />
                      </div>
                      <div>
                        <h3
                          className={`font-serif font-bold text-sm md:text-base transition-colors ${activeValueTab === i ? "text-white" : "text-white/70 group-hover:text-white"}`}
                        >
                          {v.title}
                        </h3>
                        <p className="text-[11px] text-white/30 mt-1 hidden sm:block line-clamp-1">
                          {v.desc.substring(0, 50)}...
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>

              {/* Trusted By & Quick Stats */}
              <div className="p-6 md:p-8 border-t border-white/5 bg-gradient-to-t from-zinc-900/80 to-transparent">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
                  {/* Trusted By */}
                  <div>
                    <p className="text-[11px] uppercase tracking-widest text-white/30 mb-3 font-medium">
                      Trusted By
                    </p>
                    <div className="flex items-center gap-5 flex-wrap">
                      {[
                        "Fortune 500 Execs",
                        "DFW Event Planners",
                        "Corporate Travel Teams",
                        "Wedding Coordinators",
                      ].map((client, idx) => (
                        <span
                          key={idx}
                          className="text-xs sm:text-sm text-white/50 font-light border border-white/5 px-3 py-1.5 rounded bg-white/[0.02]"
                        >
                          {client}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Divider */}
                  <div className="hidden sm:block w-px h-12 bg-white/10 shrink-0"></div>

                  {/* Quick Stats */}
                  <div className="flex items-center gap-6 sm:gap-8">
                    <div className="text-center">
                      <div className="text-xl sm:text-2xl font-serif font-bold text-white">
                        4.8
                      </div>
                      <div className="flex items-center gap-0.5 justify-center mt-0.5">
                        {[1, 2, 3, 4].map((s) => (
                          <Star
                            key={s}
                            className="w-3 h-3 text-primary fill-primary"
                          />
                        ))}
                        <Star className="w-3 h-3 text-primary fill-primary/50" />
                      </div>
                      <p className="text-[10px] uppercase tracking-wider text-white/30 mt-1">
                        Google
                      </p>
                    </div>
                    <div className="text-center">
                      <div className="text-xl sm:text-2xl font-serif font-bold text-white">
                        160+
                      </div>
                      <CheckCircle2 className="w-3.5 h-3.5 text-primary mx-auto mt-0.5" />
                      <p className="text-[10px] uppercase tracking-wider text-white/30 mt-1">
                        Reviews
                      </p>
                    </div>
                    <div className="text-center">
                      <div className="text-xl sm:text-2xl font-serif font-bold text-white">
                        20+
                      </div>
                      <Award className="w-3.5 h-3.5 text-primary mx-auto mt-0.5" />
                      <p className="text-[10px] uppercase tracking-wider text-white/30 mt-1">
                        Years
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Award Badge Section */}
      <section className="py-20 bg-zinc-950 border-y border-white/5">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-primary/10 border border-primary/30 backdrop-blur-sm mb-8">
              <Award className="w-5 h-5 text-primary" />
              <span className="text-sm sm:text-base font-semibold tracking-wider uppercase text-white">
                Addison Magazine Readers Choice Award
              </span>
            </div>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6">
              Recognized by Our Community
            </h2>
            <p className="text-white/60 text-lg font-light leading-relaxed mb-8">
              We're proud to be named Addison Magazine's Readers Choice for
              luxury transportation, a distinction voted on by the very
              community we serve. It's a testament to the trust our clients
              place in us, and a reminder that every ride matters.
            </p>
            <div className="flex flex-row items-center justify-center gap-8 sm:gap-16 bg-zinc-900/50 border border-white/10 p-6 sm:p-8 max-w-xl mx-auto backdrop-blur-sm">
              <div className="text-center flex-1">
                <div className="text-4xl sm:text-5xl font-serif font-bold text-white mb-2">
                  4.8
                </div>
                <div className="flex items-center justify-center gap-1 mb-2">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star
                      key={s}
                      className="w-4 h-4 text-primary fill-primary"
                    />
                  ))}
                </div>
                <div className="text-xs text-white/50 uppercase tracking-widest">
                  Google Rating
                </div>
              </div>
              <div className="w-px h-16 bg-white/10 shrink-0"></div>
              <div className="text-center flex-1">
                <div className="text-4xl sm:text-5xl font-serif font-bold text-white mb-2">
                  160+
                </div>
                <div className="flex items-center justify-center gap-1 mb-2">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                </div>
                <div className="text-xs text-white/50 uppercase tracking-widest">
                  Verified Reviews
                </div>
              </div>
            </div>
            <div className="mt-8">
              <Link to="/reviews">
                <Button
                  variant="outline"
                  className="border-primary text-primary hover:bg-primary hover:text-primary-foreground rounded-none px-8 h-12 transition-all duration-300"
                >
                  Read All Reviews
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Compact Service Area */}
      <CompactServiceArea />

      {/* Final CTA */}
      <section className="bg-background pt-32 pb-12">
        <div className="container mx-auto px-4">
          <div className="bg-zinc-900/80 border border-primary/20 p-12 md:p-20 text-center relative overflow-hidden backdrop-blur-sm">
            <div className="relative z-10">
              <h2 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6">
                Experience the Addison Difference.
              </h2>
              <p className="text-xl text-white/70 mb-10 max-w-2xl mx-auto font-light">
                Two decades of excellence. One standard: yours.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  to="/quote"
                  onClick={() => (window as any).gtag_report_conversion?.()}
                >
                  <Button
                    size="lg"
                    className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg rounded-none h-16 px-12 shadow-[0_0_20px_rgba(212,175,55,0.2)]"
                  >
                    Get Quote
                  </Button>
                </Link>
                <a
                  href="tel:9726083680"
                  onClick={() => (window as any).gtag_report_conversion?.()}
                >
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-white/20 text-white hover:bg-white/10 text-lg rounded-none h-16 px-12 bg-transparent backdrop-blur-sm"
                  >
                    <Phone className="w-5 h-5 mr-2" />
                    Call 972-608-3680
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;

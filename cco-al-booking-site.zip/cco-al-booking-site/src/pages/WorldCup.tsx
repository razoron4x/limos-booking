import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Phone,
  ChevronRight,
  Shield,
  Star,
  Trophy,
  Calendar,
  MapPin,
} from "lucide-react";
import { Link } from "react-router-dom";
import { SEOHead } from "@/components/SEOHead";

// ARCHIVED PAGE - Saved for future use when World Cup returns
const WorldCup = () => {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/30">
      <SEOHead
        title="World Cup 2026 Luxury Transport | Addison Limos"
        description="Premium VIP ground transportation for the 2026 World Cup in Dallas. Exclusive stadium shuttles, corporate hospitality fleet services, and dedicated private chauffeurs."
        canonical="https://addisonlimos.com/world-cup"
        noIndex={true} // Hidden from search engines since it's archived
        schemaJson={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "World Cup 2026 Luxury Transport",
          provider: {
            "@type": "Organization",
            name: "Addison Limos",
          },
        }}
      />

      {/* Hero Section */}
      <section className="relative min-h-[70vh] flex items-center pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://vibe.filesafe.space/1792719026995615993/attachments/a4be8580-32d6-4522-ab39-1c09cc6041d3.jpg"
            alt="Luxury World Cup Transport"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
        </div>

        <div className="container relative z-10 mx-auto px-4">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-6">
              <Trophy className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-white/90">
                Exclusive Event Transportation
              </span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-white leading-[1.1] mb-6">
              World Cup 2026 <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/60">
                Luxury Transport
              </span>
            </h1>

            <p className="text-lg md:text-xl text-white/70 mb-10 max-w-2xl leading-relaxed font-light">
              Premium ground transportation for the global stage. Exclusive VIP
              stadium shuttles, corporate hospitality fleet services, and
              dedicated 24/7 private chauffeurs for international travelers.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/quote"
                onClick={() => (window as any).gtag_report_conversion?.()}
              >
                <Button
                  size="lg"
                  className="bg-primary text-primary-foreground hover:bg-primary/90 text-base rounded-none h-14 px-8 shadow-[0_0_20px_rgba(212,175,55,0.3)]"
                >
                  Reserve Your Fleet
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <a
                href="tel:9726083680"
                className="w-full sm:w-auto"
                onClick={() => (window as any).gtag_report_conversion?.()}
              >
                <Button
                  size="lg"
                  variant="outline"
                  className="w-full border-white/20 text-white hover:bg-white/10 text-base rounded-none h-14 px-8 bg-transparent backdrop-blur-sm"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  Call 972-608-3680
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 bg-background relative z-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6">
                Ultimate Match Day Experience
              </h2>
              <p className="text-white/70 leading-relaxed font-light mb-6">
                When the world comes to Dallas, ensure your transportation
                matches the magnitude of the event. We provide seamless,
                high-end logistics for corporate sponsors, VIP guests, and
                passionate fans demanding the absolute best in ground
                transportation.
              </p>
              <ul className="space-y-4 mb-8">
                {[
                  "Dedicated stadium routing and drop-off coordination",
                  "Multi-vehicle fleet management for large corporate groups",
                  "24/7 standby chauffeur service for international delegates",
                  "Airport-to-hotel-to-stadium seamless transfers",
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                      <Shield className="w-3.5 h-3.5 text-primary" />
                    </div>
                    <span className="text-white/80 font-light">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <img
                src="https://vibe.filesafe.space/1792719026995615993/attachments/6479e94d-ce65-4b8d-98b6-ba73b2b3847e.jpg"
                alt="Luxury Sprinter Interior"
                className="w-full h-64 object-cover object-center"
              />
              <img
                src="https://vibe.filesafe.space/1792719026995615993/attachments/2adf5de8-75b3-4a7f-be66-84e36abaeb01.jpg"
                alt="Luxury SUV Fleet"
                className="w-full h-64 object-cover object-center mt-8"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default WorldCup;

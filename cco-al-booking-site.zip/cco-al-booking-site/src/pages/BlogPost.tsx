import { useParams, Link, Navigate } from "react-router-dom";
import { blogs } from "@/data/blogs";
import { Calendar, User, ArrowLeft } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";

const BlogPost = () => {
  const { slug } = useParams();
  const blog = blogs.find((b) => b.slug === slug);

  if (!blog) {
    return <Navigate to="/blogs" replace />;
  }

  return (
    <div className="min-h-screen bg-background pt-32 pb-24">
      <SEOHead
        title={`${blog.title} | Journal`}
        description={blog.excerpt}
        canonical={`https://addisonlimos.com/blogs/${blog.slug}`}
        ogImage={blog.imageUrl}
      />
      <div className="container mx-auto px-4 max-w-4xl">
        <Link
          to="/blogs"
          className="inline-flex items-center text-white/50 hover:text-primary transition-colors mb-8 text-sm"
        >
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Journal
        </Link>

        <div className="mb-10">
          <div className="flex items-center gap-4 text-sm text-white/40 mb-6">
            <span className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4" /> {blog.date}
            </span>
            <span className="flex items-center gap-1.5">
              <User className="w-4 h-4" /> {blog.author}
            </span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-white mb-8 leading-tight">
            {blog.title}
          </h1>
        </div>

        <div className="aspect-video w-full rounded-none overflow-hidden mb-12 border border-white/10">
          <img
            src={blog.imageUrl}
            alt={blog.title}
            className="w-full h-full object-cover"
          />
        </div>

        <div
          className="prose prose-invert prose-lg max-w-none prose-headings:font-serif prose-headings:text-white prose-p:text-white/70 prose-p:font-light prose-p:leading-relaxed prose-a:text-primary hover:prose-a:text-primary/80 prose-strong:text-white prose-li:text-white/70 prose-ul:list-disc prose-ol:list-decimal prose-ul:pl-6 prose-ol:pl-6 prose-li:marker:text-primary"
          dangerouslySetInnerHTML={{ __html: blog.content }}
        />
      </div>
    </div>
  );
};

export default BlogPost;

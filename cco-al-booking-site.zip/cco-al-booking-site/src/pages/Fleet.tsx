import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Phone, Users, Check, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { vehicles } from "@/data/vehicles";
import { SEOHead } from "@/components/SEOHead";

const Fleet = () => {
  return (
    <div className="min-h-screen bg-[#0d0d0d] text-foreground font-sans selection:bg-primary/30">
      <SEOHead
        title="Our Premium Fleet"
        description="Discover our meticulously curated collection of luxury vehicles, designed to provide unparalleled comfort and sophistication for any occasion."
        canonical="https://addisonlimos.com/fleet"
      />

      {/* Header Section */}
      <section className="pt-32 pb-16 px-4 relative">
        <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none"></div>
        <div className="container mx-auto text-center relative z-10">
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6">
            Our Premium Fleet
          </h1>
          <p className="text-lg md:text-xl text-white/60 max-w-2xl mx-auto font-light">
            Discover our meticulously curated collection of luxury vehicles,
            designed to provide unparalleled comfort and sophistication for any
            occasion.
          </p>
        </div>
      </section>

      {/* Fleet Catalog */}
      <section className="pb-16 px-4">
        <div className="container mx-auto">
          <p className="text-center text-sm text-white/40 mb-3">
            Tap the vehicle to expand
          </p>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {vehicles.map((vehicle, i) => (
              <Link to={`/fleet/${vehicle.id}`} key={i} className="block group">
                <Card className="bg-zinc-900/40 border-white/5 overflow-hidden rounded-none flex flex-col hover:bg-zinc-900/60 transition-all duration-500 h-full">
                  <div className="aspect-[16/9] overflow-hidden relative group/carousel">
                    <Carousel opts={{ loop: true }} className="w-full h-full">
                      <CarouselContent className="h-full ml-0">
                        {vehicle.images.map((img, idx) => (
                          <CarouselItem
                            key={idx}
                            className="pl-0 h-full relative overflow-hidden"
                          >
                            <img
                              src={img}
                              alt={`${vehicle.title} view ${idx + 1}`}
                              className={`w-full h-full transition-transform duration-1000 opacity-90 group-hover:opacity-100 group-hover:scale-105 ${vehicle.id === "luxury-black-stretch-limo" ? (idx === 1 ? "object-cover object-bottom -translate-y-6 sm:-translate-y-8" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-12 sm:-translate-y-16" : "object-cover object-center") : vehicle.id === "mercedes-sprinter-limo" ? (idx === 1 ? "object-cover object-bottom -translate-y-24 sm:-translate-y-40" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-8 sm:-translate-y-12" : "object-cover object-center") : vehicle.id === "mercedes-sprinter-van" ? (idx === 1 ? "object-cover object-bottom -translate-y-24 sm:-translate-y-40" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-8 sm:-translate-y-12" : "object-cover object-center") : "object-cover object-center"}`}
                            />
                          </CarouselItem>
                        ))}
                      </CarouselContent>
                      <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent pointer-events-none z-10"></div>
                      <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                      <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                    </Carousel>
                    <div className="absolute bottom-4 left-4 bg-black/60 backdrop-blur-md border border-white/10 px-3 py-1.5 hidden md:flex items-center gap-2 z-20">
                      <Users className="w-4 h-4 text-primary" />
                      <span className="text-sm font-medium text-white">
                        {vehicle.capacity}
                      </span>
                    </div>
                  </div>
                  <CardContent className="px-6 pb-6 pt-1.5 md:p-8 flex flex-col flex-grow">
                    <div className="md:hidden flex items-center gap-2 bg-black/60 backdrop-blur-md border border-white/10 px-3 py-1.5 w-fit mb-0.5">
                      <Users className="w-4 h-4 text-primary" />
                      <span className="text-sm font-medium text-white">
                        {vehicle.capacity}
                      </span>
                    </div>
                    <h3 className="text-2xl font-serif font-bold text-white mb-4 group-hover:text-primary transition-colors">
                      {vehicle.id === "luxury-black-stretch-limo" ? (
                        <>
                          <span className="text-[1.35rem] sm:text-2xl">
                            Chrysler 300
                          </span>{" "}
                          <span className="text-[0.9rem] sm:text-2xl">
                            Stretch Limo
                          </span>
                        </>
                      ) : vehicle.id === "lincoln-navigator-suv" ||
                        vehicle.id === "mercedes-sprinter-van" ? (
                        <span className="text-[1.25rem] sm:text-2xl">
                          {vehicle.title}
                        </span>
                      ) : vehicle.id === "mercedes-sprinter-limo" ? (
                        <span className="text-[1.35rem] sm:text-2xl whitespace-nowrap tracking-tighter sm:tracking-normal">
                          {vehicle.title}
                        </span>
                      ) : (
                        vehicle.title
                      )}
                    </h3>
                    <p className="hidden md:block text-white/70 font-light leading-relaxed mb-6 flex-grow">
                      {vehicle.desc}
                    </p>
                    <p className="md:hidden text-white/70 font-light text-xs sm:text-sm leading-snug mb-3">
                      {(vehicle as any).mobileDesc || vehicle.desc}
                    </p>

                    <div className="mb-4 md:mb-8">
                      <h4 className="text-sm font-semibold text-white/90 uppercase tracking-wider mb-4 border-b border-white/10 pb-2">
                        <span className="md:hidden">Premium Amenities..</span>
                        <span className="hidden md:inline">
                          Premium Amenities
                        </span>
                      </h4>
                      <ul className="hidden md:grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-4">
                        {vehicle.amenities.map((amenity, j) => (
                          <li key={j} className="flex items-start gap-2">
                            <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                            <span className="text-sm text-white/60 font-light">
                              {amenity}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-auto">
                      <div className="w-full flex items-center justify-center bg-transparent border border-primary text-primary group-hover:bg-primary group-hover:text-primary-foreground rounded-none h-14 text-base transition-all duration-300 font-medium cursor-pointer">
                        View Vehicle Details
                        <ChevronRight className="w-5 h-5 ml-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Ready to Book Section */}
      <section className="pb-32 px-4 pt-4">
        <div className="container mx-auto max-w-2xl">
          <div className="bg-zinc-900/50 border border-primary/20 p-10 text-center relative overflow-hidden">
            <div className="relative z-10">
              <h4 className="text-3xl font-serif font-bold text-white mb-3">
                Ready to Book?
              </h4>
              <p className="text-white/60 mb-8 font-light text-lg">
                Secure a vehicle for your next event or transfer.
              </p>
              <div className="flex flex-col gap-4">
                <Link
                  to="/quote"
                  className="block w-full"
                  onClick={() => (window as any).gtag_report_conversion?.()}
                >
                  <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-none h-14 text-base font-medium">
                    Get Quote
                  </Button>
                </Link>
                <a
                  href="tel:9726083680"
                  className="block w-full"
                  onClick={() => (window as any).gtag_report_conversion?.()}
                >
                  <Button
                    variant="outline"
                    className="w-full border-white/20 text-white hover:bg-white/10 rounded-none h-14 text-base bg-transparent font-medium"
                  >
                    <Phone className="w-4 h-4 mr-2" />
                    Call 972-608-3680
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Fleet;

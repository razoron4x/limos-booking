import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Phone, Star, ChevronRight, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { vehicles } from "@/data/vehicles";
import { SEOHead } from "@/components/SEOHead";
import CompactServiceArea from "@/components/CompactServiceArea";
import ServiceReviewsPreview from "@/components/ServiceReviewsPreview";
import { AirportPickupProcess } from "@/components/AirportPickupProcess";
import { ChauffeurGuarantee } from "@/components/ChauffeurGuarantee";
import {
  ServiceTopSections,
  ServiceExploreSection,
} from "@/components/ServiceSections";
import { serviceConfigs } from "@/data/serviceConfigs";

const ServiceAirport = () => {
  return (
    <div className="min-h-screen bg-[#0d0d0d] text-foreground font-sans selection:bg-primary/30">
      <SEOHead
        title="Airport Transfers & Shuttle Services"
        description="Dedicated FBO staging and real-time flight tracking for DFW International, Dallas Love Field, and Addison Airport (ADS)."
        canonical="https://addisonlimos.com/service-airport"
      />
      {/* Header Section */}
      <section className="pt-32 pb-16 px-4 relative border-b border-white/5 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-b from-primary/10 to-transparent pointer-events-none"></div>
        <div className="absolute inset-0 z-0 opacity-20">
          <img
            src="https://vibe.filesafe.space/1792719026995615993/assets/71c83224-f0a0-44be-97f7-9c3d3a0dd5ba.png"
            alt="Luxury airport transfer at DFW"
            className="w-full h-full object-cover"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0d0d0d] via-[#0d0d0d]/80 to-transparent"></div>
        </div>
        <div className="container mx-auto relative z-10">
          <Link
            to="/#services"
            className="inline-flex items-center text-white/60 hover:text-primary transition-colors mb-8 group"
          >
            <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Services
          </Link>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6">
                Airport Transfers & Shuttle
              </h1>
              <p className="text-base md:text-xl text-white/70 font-light leading-relaxed">
                <span className="md:hidden">
                  Real-time flight tracking. Meet & greet at DFW, Love Field &
                  ADS.
                </span>
                <span className="hidden md:inline">
                  Dedicated FBO staging and real-time flight tracking for DFW
                  International, Dallas Love Field, and Addison Airport (ADS).
                </span>
              </p>
            </div>
            <Link to="/quote?service=Airport%20Transfer">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg rounded-none h-14 px-8 shadow-[0_0_20px_rgba(212,175,55,0.2)] whitespace-nowrap"
              >
                Book Airport Transfer
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <ServiceTopSections config={serviceConfigs.airport} />

      <AirportPickupProcess />

      {/* Recommended Fleet Section */}
      <section className="py-24 bg-zinc-950 relative border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Ideal for Airport Transfers
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
              Explore our most popular vehicles for seamless airport arrivals
              and departures.
            </p>
          </div>

          <div className="relative py-12">
            {/* Top Line */}
            <div className="absolute top-0 left-0 right-0 h-[2px] overflow-hidden rounded-full bg-gradient-to-r from-transparent via-primary/30 to-transparent">
              <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-primary to-transparent animate-glow-line"></div>
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-[2px] bg-primary blur-[4px] opacity-50"></div>
            </div>

            <p className="text-center text-sm text-white/40 mb-3 relative z-10">
              Tap the vehicle to expand
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
              {[
                vehicles.find((v) => v.id === "lincoln-navigator-suv")!,
                vehicles.find((v) => v.id === "mercedes-sprinter-executive")!,
                vehicles.find((v) => v.id === "mercedes-sprinter-van")!,
              ].map((vehicle, i) => (
                <Card
                  key={i}
                  className="bg-zinc-900/50 border-white/5 overflow-hidden group rounded-none relative"
                >
                  <div className="aspect-[16/9] overflow-hidden relative group/carousel">
                    <Carousel opts={{ loop: true }} className="w-full h-full">
                      <CarouselContent className="h-full ml-0">
                        {vehicle.images.map((img, idx) => (
                          <CarouselItem
                            key={idx}
                            className="pl-0 h-full relative"
                          >
                            <Link
                              to={`/fleet/${vehicle.id}`}
                              className="block w-full h-full cursor-pointer"
                            >
                              <img
                                src={img}
                                alt={`${vehicle.title} view ${idx + 1}`}
                                className={`w-full h-full transition-transform duration-1000 opacity-80 group-hover:opacity-100 group-hover:scale-105 ${vehicle.id === "luxury-black-stretch-limo" ? (idx === 1 ? "object-cover object-bottom -translate-y-6 sm:-translate-y-8" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-12 sm:-translate-y-16" : "object-cover object-center") : vehicle.id === "mercedes-sprinter-limo" ? (idx === 1 ? "object-cover object-bottom -translate-y-24 sm:-translate-y-40" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-8 sm:-translate-y-12" : "object-cover object-center") : vehicle.id === "mercedes-sprinter-van" ? (idx === 1 ? "object-cover object-bottom -translate-y-24 sm:-translate-y-40" : idx === 2 || idx === 3 ? "object-cover object-bottom -translate-y-8 sm:-translate-y-12" : "object-cover object-center") : "object-cover object-center"}`}
                              />
                            </Link>
                          </CarouselItem>
                        ))}
                      </CarouselContent>
                      <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/50 to-transparent pointer-events-none z-10"></div>
                      <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                      <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                    </Carousel>
                  </div>
                  <CardContent className="absolute bottom-0 left-0 p-4 pb-2 sm:p-6 w-full z-30 pointer-events-none">
                    <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-1 group-hover:text-primary transition-colors drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                      <Link
                        to={`/fleet/${vehicle.id}`}
                        className="pointer-events-auto hover:text-primary transition-colors"
                      >
                        {vehicle.shortTitle}
                      </Link>
                    </h3>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Bottom Line */}
            <div className="absolute bottom-0 left-0 right-0 h-[2px] overflow-hidden rounded-full bg-gradient-to-r from-transparent via-primary/30 to-transparent">
              <div
                className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-primary to-transparent animate-glow-line"
                style={{ animationDelay: "1.5s" }}
              ></div>
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-[2px] bg-primary blur-[4px] opacity-50"></div>
            </div>
          </div>

          <div className="mt-10 flex justify-center gap-4">
            <Link to="/fleet" className="max-w-sm">
              <Button className="h-14 px-8 bg-gradient-to-b from-zinc-800/40 to-zinc-950 border border-white/10 hover:border-primary/40 text-white text-base tracking-wide rounded-none group relative overflow-hidden transition-all duration-500 shadow-2xl hover:shadow-[0_0_30px_rgba(212,175,55,0.15)]">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
                <span className="relative z-10 flex items-center justify-center">
                  View Full Fleet
                  <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </span>
              </Button>
            </Link>
            <Link to="/quote?service=Airport%20Transfer" className="max-w-sm">
              <Button className="h-14 px-8 bg-primary text-primary-foreground hover:bg-primary/90 text-base tracking-wide rounded-none shadow-[0_0_20px_rgba(212,175,55,0.2)] whitespace-nowrap">
                Get Quote
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Commitment & Chauffeurs Section */}
      <section className="py-24 px-4 bg-[#0d0d0d] relative border-t border-white/5">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16">
            {/* Our Commitment */}
            <div className="space-y-6">
              <div className="aspect-[4/3] overflow-hidden border border-white/5 relative group rounded-xl">
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/attachments/ce851af8-a48c-407d-9e58-5646393d8747.jpg"
                  alt="Our Commitment to Excellence"
                  className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent"></div>
              </div>
              <h2 className="text-3xl font-serif font-bold text-white">
                Our Commitment
              </h2>
              <p className="text-white/60 font-light leading-relaxed text-lg">
                At Addison Limos, our commitment to excellence goes beyond
                merely driving you from point A to point B. We guarantee
                flawless execution, absolute discretion, and an unwavering
                dedication to your comfort and safety with our premier Dallas
                airport transfer and DFW airport limo service. Every luxury
                airport car service journey is meticulously planned and
                monitored to ensure your complete peace of mind, offering a
                reliable airport shuttle and private airport transportation for
                all your travel needs.
              </p>
            </div>

            {/* Our Chauffeurs */}
            <div className="space-y-6">
              <div className="aspect-[4/3] overflow-hidden border border-white/5 relative group rounded-xl">
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/assets/637887bf-9eaf-41f9-8ee3-eec3ad7c630e.png"
                  alt="Our Elite Chauffeurs"
                  className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent"></div>
              </div>
              <h2 className="text-3xl font-serif font-bold text-white">
                Our Chauffeurs
              </h2>
              <p className="text-white/60 font-light leading-relaxed text-lg">
                Our elite chauffeurs are the pinnacle of professional ground
                transportation. Hand-selected, extensively trained, and
                impeccably uniformed, our professional airport chauffeur Dallas
                team possesses an intimate knowledge of the Dallas-Fort Worth
                metroplex. Expect a polite, accommodating, and secure experience
                from your DFW airport private driver, tailored exactly to your
                preferences for Dallas Love Field car service and executive
                airport chauffeur needs.
              </p>
            </div>
          </div>

          <div className="mt-16 flex justify-center">
            <a
              href="tel:9726083680"
              onClick={() => (window as any).gtag_report_conversion?.()}
            >
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg rounded-none h-14 px-10 shadow-[0_0_20px_rgba(212,175,55,0.2)] whitespace-nowrap group"
              >
                <Phone className="w-5 h-5 mr-3 group-hover:animate-pulse" />
                Call 972-608-3680
              </Button>
            </a>
          </div>
        </div>
      </section>

      <ServiceReviewsPreview />

      <ChauffeurGuarantee />

      <ServiceExploreSection config={serviceConfigs.airport} />

      <CompactServiceArea />
    </div>
  );
};

// Trigger HMR to remove stale footer
export default ServiceAirport;

// Mock operational data for the Addison Limos staff dashboard.
// Frontend-only preview data — not backed by a live dispatch system.

export type BookingStatus =
  "Confirmed" | "En Route" | "Completed" | "Pending" | "Cancelled";

export interface Booking {
  id: string;
  client: string;
  service: string;
  vehicle: string;
  pickup: string;
  dropoff: string;
  date: string; // ISO date
  time: string;
  chauffeur: string;
  amount: number;
  status: BookingStatus;
}

export interface Invoice {
  id: string;
  client: string;
  account: string;
  issued: string;
  due: string;
  amount: number;
  status: "Paid" | "Pending" | "Overdue" | "Draft";
}

export interface Account {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  type: "Corporate" | "Private" | "VIP";
  trips: number;
  balance: number;
}

export const accountDisplayName = (
  a: Pick<Account, "firstName" | "lastName">,
) => `${a.firstName} ${a.lastName}`.trim();

export const addAccount = (
  account: Omit<Account, "id" | "trips" | "balance">,
): Account => {
  const id = `ACC-${String(accounts.length + 1).padStart(2, "0")}`;
  const created: Account = { ...account, id, trips: 0, balance: 0 };
  accounts.unshift(created);
  return created;
};

export const addBooking = (booking: Omit<Booking, "id">): Booking => {
  const id = `BK-${2049 + bookings.length}`;
  const created: Booking = { ...booking, id };
  bookings.unshift(created);
  return created;
};

export const bookings: Booking[] = [
  {
    id: "BK-2041",
    client: "Carter Whitfield",
    service: "Airport Transfer",
    vehicle: "Mercedes S-Class",
    pickup: "DFW Airport · Terminal D",
    dropoff: "The Joule, Dallas",
    date: "2026-10-23",
    time: "08:15 AM",
    chauffeur: "M. Reyes",
    amount: 185,
    status: "Confirmed",
  },
  {
    id: "BK-2042",
    client: "Halcyon Capital",
    service: "Corporate Hourly",
    vehicle: "Cadillac Escalade",
    pickup: "Rosewood Office",
    dropoff: "Multiple stops",
    date: "2026-10-23",
    time: "10:00 AM",
    chauffeur: "D. Okafor",
    amount: 420,
    status: "En Route",
  },
  {
    id: "BK-2043",
    client: "Sienna & Marcus Vale",
    service: "Wedding",
    vehicle: "Rolls-Royce Phantom",
    pickup: "The Adolphus",
    dropoff: "The Statler",
    date: "2026-10-24",
    time: "05:30 PM",
    chauffeur: "A. Bianchi",
    amount: 980,
    status: "Confirmed",
  },
  {
    id: "BK-2044",
    client: "Liang Group",
    service: "Airport Transfer",
    vehicle: "BMW 7 Series",
    pickup: "Love Field",
    dropoff: "Frisco HQ",
    date: "2026-10-24",
    time: "07:45 AM",
    chauffeur: "M. Reyes",
    amount: 165,
    status: "Pending",
  },
  {
    id: "BK-2045",
    client: "Dr. Priya Nair",
    service: "Point-to-Point",
    vehicle: "Mercedes S-Class",
    pickup: "Uptown Dallas",
    dropoff: "UT Southwestern",
    date: "2026-10-25",
    time: "09:00 AM",
    chauffeur: "D. Okafor",
    amount: 140,
    status: "Confirmed",
  },
  {
    id: "BK-2046",
    client: "Vance Industries",
    service: "Corporate Shuttle",
    vehicle: "Sprinter Van",
    pickup: "Downtown Dallas",
    dropoff: "Plano Campus",
    date: "2026-10-25",
    time: "06:30 PM",
    chauffeur: "T. Holloway",
    amount: 310,
    status: "Completed",
  },
  {
    id: "BK-2047",
    client: "Eleanor Frost",
    service: "Anniversary",
    vehicle: "Vintage Bentley",
    pickup: "Highland Park",
    dropoff: "The Mansion",
    date: "2026-10-26",
    time: "07:15 PM",
    chauffeur: "A. Bianchi",
    amount: 725,
    status: "Confirmed",
  },
  {
    id: "BK-2048",
    client: "Knox Logistics",
    service: "Airport Transfer",
    vehicle: "Cadillac Escalade",
    pickup: "DFW Airport · Terminal E",
    dropoff: "Fort Worth",
    date: "2026-10-23",
    time: "02:20 PM",
    chauffeur: "T. Holloway",
    amount: 240,
    status: "Cancelled",
  },
];

export const invoices: Invoice[] = [
  {
    id: "INV-8821",
    client: "Halcyon Capital",
    account: "Corporate",
    issued: "2026-10-18",
    due: "2026-10-25",
    amount: 4200,
    status: "Pending",
  },
  {
    id: "INV-8820",
    client: "Vance Industries",
    account: "Corporate",
    issued: "2026-10-15",
    due: "2026-10-22",
    amount: 1860,
    status: "Overdue",
  },
  {
    id: "INV-8819",
    client: "Carter Whitfield",
    account: "Private",
    issued: "2026-10-12",
    due: "2026-10-19",
    amount: 185,
    status: "Paid",
  },
  {
    id: "INV-8818",
    client: "Liang Group",
    account: "Corporate",
    issued: "2026-10-10",
    due: "2026-10-17",
    amount: 2475,
    status: "Paid",
  },
  {
    id: "INV-8817",
    client: "Eleanor Frost",
    account: "VIP",
    issued: "2026-10-22",
    due: "2026-10-29",
    amount: 725,
    status: "Draft",
  },
  {
    id: "INV-8816",
    client: "Knox Logistics",
    account: "Corporate",
    issued: "2026-10-08",
    due: "2026-10-15",
    amount: 980,
    status: "Paid",
  },
];

export const accounts: Account[] = [
  {
    id: "ACC-01",
    firstName: "Jordan",
    lastName: "Meeks",
    phone: "(214) 555-0118",
    email: "jordan@halcyoncap.com",
    type: "Corporate",
    trips: 64,
    balance: 4200,
  },
  {
    id: "ACC-02",
    firstName: "Renee",
    lastName: "Vance",
    phone: "(214) 555-0144",
    email: "renee@vanceind.com",
    type: "Corporate",
    trips: 38,
    balance: 1860,
  },
  {
    id: "ACC-03",
    firstName: "Wei",
    lastName: "Liang",
    phone: "(469) 555-0192",
    email: "wei@lianggroup.com",
    type: "Corporate",
    trips: 51,
    balance: 0,
  },
  {
    id: "ACC-04",
    firstName: "Eleanor",
    lastName: "Frost",
    phone: "(214) 555-0177",
    email: "e.frost@frostestates.com",
    type: "VIP",
    trips: 22,
    balance: 725,
  },
  {
    id: "ACC-05",
    firstName: "Carter",
    lastName: "Whitfield",
    phone: "(214) 555-0102",
    email: "cwhitfield@private.com",
    type: "Private",
    trips: 9,
    balance: 0,
  },
  {
    id: "ACC-06",
    firstName: "Dale",
    lastName: "Knox",
    phone: "(817) 555-0166",
    email: "dale@knoxlog.com",
    type: "Corporate",
    trips: 27,
    balance: 0,
  },
];

export const formatCurrency = (value: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
  }).format(value);

export const statusTone = (status: string): string => {
  switch (status) {
    case "Confirmed":
    case "Paid":
      return "text-primary border-primary/40 bg-primary/10";
    case "En Route":
      return "text-sky-300 border-sky-400/40 bg-sky-400/10";
    case "Completed":
      return "text-emerald-300 border-emerald-400/40 bg-emerald-400/10";
    case "Pending":
      return "text-amber-200 border-amber-300/40 bg-amber-300/10";
    case "Overdue":
      return "text-red-300 border-red-400/40 bg-red-400/10";
    case "Cancelled":
      return "text-muted-foreground border-border bg-muted";
    case "Draft":
      return "text-muted-foreground border-border bg-muted/60";
    default:
      return "text-muted-foreground border-border bg-muted";
  }
};

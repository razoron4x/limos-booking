export interface CityData {
  slug: string;
  name: string;
  heroTitle: string;
  heroSubtitle: string;
  heroDescription: string;
  heroImage: string;
  fourthService: {
    title: string;
    desc: string;
    link: string;
    img: string;
  };
  trust1: {
    title: string;
    text: string;
    bullets: string[];
    image: string;
  };
  trust2: {
    title: string;
    text: string;
    bullets: string[];
    image: string;
  };
  faqs: { question: string; answer: string }[];
  metaTitle: string;
  metaDescription: string;
  landmarks: string;
  driveTime: string;
}

const commonImg = {
  airport:
    "https://vibe.filesafe.space/1792719026995615993/attachments/105ccb92-8123-4ed8-84a9-4418d97c9941.webp",
  events:
    "https://vibe.filesafe.space/1792719026995615993/attachments/fba40358-8871-45b6-8d55-3e9f4c2c30b1.webp",
  group:
    "https://vibe.filesafe.space/1792719026995615993/attachments/dfd0c52f-a532-4e35-9f71-57c8857e9e9f.webp",
  cityToCity:
    "https://vibe.filesafe.space/1792719026995615993/attachments/f36247b6-7933-45f9-b1f9-756634a8a11f.webp",
  vip: "https://vibe.filesafe.space/1792719026995615993/attachments/dfd0c52f-a532-4e35-9f71-57c8857e9e9f.webp",
  chauffeur:
    "https://vibe.filesafe.space/1792719026995615993/attachments/1bfdf4a0-aa39-420c-9073-6fcbba52d19b.png",
  billing:
    "https://vibe.filesafe.space/1792719026995615993/attachments/b98fa96c-ed80-4458-82c1-abdac7ad556c.webp",
};

export const cities: CityData[] = [
  // 0. DALLAS
  {
    slug: "dallas",
    name: "Dallas",
    heroTitle: "Luxury Chauffeur Service in Dallas, TX",
    heroSubtitle:
      "Premium limousine and executive car service for downtown Dallas, Uptown, Deep Ellum, the Design District, and DFW airport transfers.",
    heroDescription:
      "From the skyscrapers of downtown Dallas to the vibrant nightlife of Deep Ellum, Addison Limos delivers white-glove chauffeur transportation across the city with 20+ years of proven reliability.",
    heroImage: commonImg.airport,
    fourthService: {
      title: "VIP & Executive Transport",
      desc: "Dallas is a global business hub. Our VIP chauffeur service provides discreet, first-class transportation for executives, celebrities, and high-profile clients across the city.",
      link: "/service-vip",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Dallas's premier executive chauffeur partner",
      text: "Dallas is the economic heart of the DFW metroplex, home to the largest concentration of Fortune 500 headquarters in Texas. From the Arts District to the Dallas World Trade Center, from American Airlines Center to the Kay Bailey Hutchison Convention Center, our chauffeurs know every district, every venue, and every corporate campus. Whether it's an executive sedan for a downtown business meeting, a luxury SUV for a night in Uptown, or a Sprinter van for a group transfer to a Mavericks or Stars game, our locally based team delivers with the precision and discretion that Dallas professionals demand.",
      bullets: [
        "Executive sedan service for downtown Dallas and Uptown corporate towers",
        "VIP transportation for American Airlines Center concerts and Mavericks games",
        "Convention transportation for the Kay Bailey Hutchison Convention Center",
        "Background-checked, NDA-compliant chauffeurs for confidential Dallas travel",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Effortless DFW and Love Field airport transfers from Dallas",
      text: "Downtown Dallas is approximately 25 minutes from Dallas Love Field and 30 minutes from DFW International Airport. Our real-time flight tracking system monitors arrivals automatically, adjusting pickup times for early landings or delays. Your chauffeur arrives 15 minutes early with meet-and-greet service inside the terminal. Whether you're a corporate executive flying out for a meeting or returning from an international trip, your Dallas airport transfer is seamless, quiet, and perfectly timed.",
      bullets: [
        "25-minute transfers to Dallas Love Field from downtown",
        "30-minute transfers to DFW International Airport",
        "Meet-and-greet service inside both DFW and Love Field terminals",
        "Executive sedans, SUVs, and Sprinter vans for Dallas airport transfers",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/2612e314-8c01-49ec-a416-db26e45e2e28.png", // Dallas
    },
    faqs: [
      {
        question: `How far in advance should I book a limo in Dallas?`,
        answer: `We recommend booking at least 24-48 hours in advance for Dallas limousine service, especially during peak corporate travel hours, convention weeks, and major event nights at American Airlines Center. However, we do accommodate same-day and last-minute requests based on fleet availability.`,
      },
      {
        question: `Do you provide corporate accounts for Dallas businesses?`,
        answer: `Yes. We offer centralized corporate accounts with simple invoicing, multi-passenger booking, and consolidated monthly reporting for Dallas-based companies. Our service is ideal for executive assistants and travel managers coordinating transportation for multiple employees across the city.`,
      },
      {
        question: `What is the drive time from downtown Dallas to DFW Airport?`,
        answer: `The drive from downtown Dallas to DFW International Airport typically takes 30-35 minutes depending on traffic. Dallas Love Field is closer, approximately 20-25 minutes from downtown. Our chauffeurs monitor real-time traffic on I-35E and the Dallas North Tollway to ensure timely arrivals.`,
      },
      {
        question: `Can I book a Sprinter van for group transportation in Dallas?`,
        answer: `Absolutely. Our Mercedes Sprinter vans and Sprinter limo buses are perfect for corporate group outings, convention shuttles, and group airport transfers from Dallas. Each vehicle accommodates up to 14 passengers with premium amenities.`,
      },
      {
        question: `Do you provide transportation to American Airlines Center events?`,
        answer: `Yes. We provide premium chauffeur service to American Airlines Center for Dallas Mavericks games, Dallas Stars games, and major concerts. Our chauffeurs know the best pickup and drop-off zones to avoid traffic congestion around the venue.`,
      },
    ],
    metaTitle:
      "Dallas Limo Service | Luxury Chauffeur & Airport Car Service Dallas TX",
    metaDescription:
      "Premium limousine and executive chauffeur service in Dallas, TX. DFW airport transfers, corporate travel, VIP transport, and special event transportation with 20+ years of 5-star service.",
    landmarks:
      "Downtown Dallas, Uptown, Deep Ellum, American Airlines Center, Kay Bailey Hutchison Convention Center, Dallas Arts District",
    driveTime: "30 minutes to DFW, 25 minutes to Love Field",
  },

  // 0b. ADDISON
  {
    slug: "addison",
    name: "Addison",
    heroTitle: "Addison Chauffeur & Limo Service",
    heroSubtitle:
      "Executive car service from Addison's restaurant district, corporate parks, and Addison Airport (ADS) to destinations across the DFW metroplex.",
    heroDescription:
      "As our home base, Addison is where Addison Limos was built. We know every street, every corporate park, and every restaurant circle with 20+ years of local expertise.",
    heroImage: commonImg.events,
    fourthService: {
      title: "Point-to-Point Transfers",
      desc: "From Addison's restaurant circle to meetings across the metroplex, our point-to-point chauffeur service gets Addison professionals where they need to be on time, every time.",
      link: "/service-point-to-point",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Addison's hometown chauffeur service for over 20 years",
      text: "Addison is our home. This vibrant town north of Dallas is known for its restaurant district along Belt Line Road, Addison Circle Park, the Addison Airport (ADS), and a thriving corporate community. Our chauffeurs know every corner of Addison, from the Quorum Drive business parks to the Vitruvian Park development. Whether it's an executive sedan for a corporate meeting at one of Addison's many business parks, a luxury SUV for a dinner at a Belt Line Road restaurant, or a Sprinter van for a group transfer to Addison Circle Park events, our locally based team delivers with unmatched local knowledge and professionalism.",
      bullets: [
        "Executive car service for Addison corporate parks and Belt Line Road businesses",
        "Addison Airport (ADS) FBO pickups and transfers",
        "Group transportation for Addison Circle Park and Vitruvian Park events",
        "20+ years as Addison's trusted hometown limousine service",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "The closest premium airport service to Addison Airport (ADS)",
      text: "Addison is uniquely positioned for airport access. Addison Airport (ADS) is right in town for private aviation, Dallas Love Field is just 15 minutes away, and DFW International Airport is 20 minutes via I-635. Our chauffeurs are DFW-permitted and provide inside-terminal meet-and-greet service, real-time flight tracking, and curbside express pickups. For private aviation clients at Addison Airport, we coordinate directly with FBO staff for seamless curbside pickup. Your Addison airport transfer is effortless from curb to curb.",
      bullets: [
        "Addison Airport (ADS) FBO coordination for private aviation clients",
        "15-minute transfers to Dallas Love Field",
        "20-minute transfers to DFW International Airport via I-635",
        "Real-time flight tracking with automatic pickup time adjustments",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/d439490e-83dc-4b63-a91c-049415a6e558.png",
    },
    faqs: [
      {
        question: `Do you provide pickups at Addison Airport (ADS)?`,
        answer: `Yes. We coordinate directly with FBO staff at Addison Airport for seamless curbside pickups of private aviation clients. Our chauffeurs monitor your arrival and are ready the moment you step out of the FBO.`,
      },
      {
        question: `How far is Addison from DFW Airport?`,
        answer: `Addison is approximately 20 minutes from DFW International Airport via I-635 and 15 minutes from Dallas Love Field. This central location makes Addison one of the most convenient DFW cities for airport transfers.`,
      },
      {
        question: `Do you offer corporate accounts for Addison businesses?`,
        answer: `Absolutely. As our hometown, we have deep relationships with Addison's corporate community. We offer centralized corporate billing, multi-passenger booking, and monthly reporting for Addison-based companies along Belt Line Road and Quorum Drive.`,
      },
      {
        question: `Can I book transportation for Addison Circle Park events?`,
        answer: `Yes. We provide luxury chauffeur service to Addison Circle Park events, including the Addison Oktoberfest, Addison Kaboom Town!, and other community festivals. Our Sprinter vans and limo buses are perfect for group event transportation.`,
      },
      {
        question: `What vehicles are available for Addison limo service?`,
        answer: `Our full fleet is available in Addison, including executive sedans, Lincoln Navigator SUVs, Chrysler 300 stretch limos, Hummer stretch limos, and Mercedes Sprinter vans and limo buses. We match the vehicle to your group size and occasion.`,
      },
    ],
    metaTitle:
      "Addison Limo Service | Luxury Chauffeur & Airport Car Service Addison TX",
    metaDescription:
      "Premium limousine and executive chauffeur service in Addison, TX. Addison Airport (ADS) transfers, corporate travel, Belt Line Road dining, and special event transportation with 20+ years of 5-star service.",
    landmarks:
      "Addison Circle Park, Addison Airport (ADS), Belt Line Road restaurant district, Vitruvian Park, Quorum Drive business parks",
    driveTime: "20 minutes to DFW, 15 minutes to Love Field",
  },

  // 1. PLANO
  {
    slug: "plano",
    name: "Plano",
    heroTitle: "Luxury Chauffeur Service in Plano, TX",
    heroSubtitle:
      "Premium limousine and executive car service for Plano's corporate headquarters, Legacy West events, and DFW airport transfers.",
    heroDescription:
      "From Legacy West boardroom pickups to DFW International arrivals, Addison Limos delivers white-glove chauffeur transportation across Plano with 20+ years of proven reliability.",
    heroImage: commonImg.airport,
    fourthService: {
      title: "Corporate Travel & Executive Transport",
      desc: "Plano is home to Fortune 500 headquarters. Our executive chauffeur service caters to corporate travel managers and C-suite executives with centralized billing and flight tracking.",
      link: "/corporate",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Plano's trusted executive chauffeur partner",
      text: "With major corporate campuses like Toyota Motor North America, JCPenney, and Dr Pepper Snapple Group headquartered in Plano, business travel demands precision. Our locally based chauffeurs know Legacy Drive, the Dallas North Tollway, and every corporate campus access point. We coordinate with travel managers and executive assistants to ensure seamless pickups at Legacy West, The Shops at Legacy, and everywhere in between.",
      bullets: [
        "Door-to-door executive sedan service for Plano corporate campuses",
        "Real-time GPS tracking for all Plano chauffeur assignments",
        "Background-checked, NDA-compliant professional drivers",
        "Centralized corporate billing for Plano-based companies",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Effortless DFW airport transfers from Plano",
      text: "Plano sits approximately 35 minutes from DFW International Airport and 25 minutes from Dallas Love Field. Our flight tracking system monitors arrivals in real time, adjusting pickup times automatically for early landings or delays. Your chauffeur arrives 15 minutes early, curbside and ready. No circling, no waiting, no stress, just a smooth, quiet ride to your terminal or back home to Plano.",
      bullets: [
        "Meet-and-greet service inside DFW and Love Field terminals",
        "Automatic flight delay adjustments with no wait fees",
        "Lincoln Navigator SUVs and executive sedans for airport runs",
        "Curbside express pickups at DFW and DAL",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/a28a7057-b449-4197-8b2c-4de908b39551.png",
    },
    faqs: [
      {
        question: `How far in advance should I book a limo in Plano?`,
        answer: `We recommend booking at least 24-48 hours in advance for Plano limousine service, especially during peak corporate travel hours and weekend event seasons around Legacy West. However, we do accommodate same-day and last-minute requests based on fleet availability.`,
      },
      {
        question: `Do you provide corporate accounts for Plano businesses?`,
        answer: `Yes. We offer centralized corporate accounts with simple invoicing, multi-passenger booking, and consolidated monthly reporting for Plano-based companies. Our service is ideal for executive assistants and travel managers coordinating transportation for multiple employees.`,
      },
      {
        question: `What is the drive time from Plano to DFW Airport?`,
        answer: `The drive from Plano to DFW International Airport typically takes 30-40 minutes depending on traffic and your specific location within Plano. Our chauffeurs monitor real-time traffic conditions and plan routes accordingly to ensure you arrive with plenty of time before your flight.`,
      },
      {
        question: `Can I book a Sprinter van for group transportation in Plano?`,
        answer: `Absolutely. Our Mercedes Sprinter vans and Sprinter limo buses are perfect for corporate group outings, team-building events, and group airport transfers from Plano. Each vehicle accommodates up to 14 passengers with premium amenities.`,
      },
      {
        question: `Do you offer one-way transfers on weekends in Plano?`,
        answer: `Yes, for sedans, SUVs, and Sprinter vehicles we offer one-way weekend transfers. For stretch limos and Hummer limos, weekend service is hourly only.`,
      },
    ],
    metaTitle: "Plano Limo Service | Luxury Chauffeur & Airport Car Service",
    metaDescription:
      "Premium limousine and executive chauffeur service in Plano, TX. DFW airport transfers, corporate travel, and special event transportation with 20+ years of 5-star service.",
    landmarks:
      "Legacy West, The Shops at Legacy, Toyota North America headquarters, JCPenney headquarters, Dr Pepper Ballpark",
    driveTime: "35 minutes to DDFW, 25 minutes to Love Field",
  },

  // 2. FRISCO
  {
    slug: "frisco",
    name: "Frisco",
    heroTitle: "Frisco Chauffeur & Limo Service",
    heroSubtitle:
      "Executive car service for Frisco's booming business district, The Star district, and premium DFW airport transfers.",
    heroDescription:
      "Whether you're heading to a Cowboys training facility at The Star or catching a flight at DFW, Addison Limos provides first-class chauffeur transportation throughout Frisco with unmatched reliability.",
    heroImage: commonImg.events,
    fourthService: {
      title: "Sporting & Concert Transportation",
      desc: "Frisco is home to The Star and Toyota Stadium. Arrive in style for Cowboys events, FC Dallas matches, and concerts with our premium chauffeur service. No parking hassles, no traffic stress.",
      link: "/service-sporting-concerts",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Frisco's premier chauffeur service for business and leisure",
      text: "Frisco is one of the fastest-growing cities in America, home to The Star (Dallas Cowboys World Headquarters), Toyota Stadium, and major corporate developments along the Dallas North Tollway. Our chauffeurs are intimately familiar with Frisco's expanding road network, from Stonebrook Parkway to the PGA of America headquarters. Whether it's a corporate pickup at The Star or a group transfer to Toyota Stadium, we deliver punctual, professional service every time.",
      bullets: [
        "Executive sedan service for Frisco corporate campuses and The Star",
        "Group transportation for FC Dallas matches and events at Toyota Stadium",
        "GPS-tracked vehicles with live arrival updates for Frisco clients",
        "NDA-compliant chauffeurs for confidential business travel",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Stress-free DFW airport transportation from Frisco",
      text: "Frisco is approximately 40 minutes from DFW International Airport and 30 minutes from Dallas Love Field. Our real-time flight tracking ensures your chauffeur is always synced with your actual arrival time. Early landings, delayed flights, last-minute gate changes; our system handles it all automatically. You step off the plane, your chauffeur is waiting with a name sign, and you're on your way home to Frisco without a single stress.",
      bullets: [
        "Inside-terminal meet-and-greet at DFW and Love Field",
        "Flight delay monitoring with automatic pickup rescheduling",
        "Executive SUVs and Sprinter vans for Frisco group airport transfers",
        "15-minute early chauffeur arrival guarantee",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/8e02d0c6-77da-4c36-829f-279f0f3c99f2.png", // Frisco
    },
    faqs: [
      {
        question: `Do you provide transportation to The Star in Frisco?`,
        answer: `Yes. We provide premium chauffeur service to The Star district for Cowboys events, corporate functions, and private gatherings. Our chauffeurs know the best pickup and drop-off zones to avoid traffic congestion around the facility.`,
      },
      {
        question: `How long is the drive from Frisco to DFW Airport?`,
        answer: `The drive from Frisco to DFW International Airport typically takes 35-45 minutes depending on traffic and your exact location. Our chauffeurs monitor traffic on the Dallas North Tollway and Sam Rayburn Tollway to choose the fastest route.`,
      },
      {
        question: `Can I book a limo for a Frisco FC Dallas game?`,
        answer: `Absolutely. We provide group transportation to Toyota Stadium for FC Dallas matches and other events. Our Sprinter vans and Sprinter limo buses are perfect for group game-day transportation with no parking hassles.`,
      },
      {
        question: `Do you offer corporate accounts for Frisco businesses?`,
        answer: `Yes. We offer centralized corporate billing, multi-passenger booking, and monthly reporting for Frisco-based companies. Our service is designed for travel managers and executive assistants who need reliable, repeatable transportation.`,
      },
      {
        question: `What vehicles are available for Frisco limo service?`,
        answer: `Our fleet includes executive sedans, Lincoln Navigator SUVs, Chrysler 300 stretch limos, Hummer stretch limos, and Mercedes Sprinter vans and limo buses. We match the vehicle to your group size and occasion.`,
      },
    ],
    metaTitle:
      "Frisco Limo Service | Chauffeur & Airport Car Service Frisco TX",
    metaDescription:
      "Luxury limousine and executive chauffeur service in Frisco, TX. DFW airport transfers, The Star events, corporate travel, and group transportation with 5-star rated service.",
    landmarks:
      "The Star, Toyota Stadium, PGA of America headquarters, Frisco Square, Stonebriar Centre",
    driveTime: "40 minutes to DFW, 30 minutes to Love Field",
  },

  // 3. IRVING
  {
    slug: "irving",
    name: "Irving",
    heroTitle: "Irving Limo & Executive Chauffeur Service",
    heroSubtitle:
      "Premium car service for Irving's Las Colinas business district, DFW Airport, and special events across the metroplex.",
    heroDescription:
      "Situated between Dallas and DFW Airport, Irving demands efficient, reliable transportation. Addison Limos delivers with 20+ years of elite chauffeur service across Las Colinas and beyond.",
    heroImage: commonImg.airport,
    fourthService: {
      title: "Wedding & Special Occasion Limo",
      desc: "From the elegant venues of Las Colinas to the Mandalay Canal, our stretch limos and luxury SUVs make your Irving wedding or special celebration unforgettable.",
      link: "/service-wedding",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Irving's go-to chauffeur service for Las Colinas and beyond",
      text: "Irving is the strategic heart of the DFW metroplex, home to the Las Colinas business district, the Mandalay Canal Walk, and the Irving Convention Center. Our chauffeurs know every route through the Las Colinas Urban Center, from the Omni Mandalay Hotel to the Toyota Music Factory. Whether you need an executive sedan for a corporate meeting at the Irving Convention Center or a luxury SUV for a night out at the Toyota Music Factory, our locally based team delivers with precision and discretion.",
      bullets: [
        "Executive car service for Las Colinas corporate centers",
        "Convention and event transportation for the Irving Convention Center",
        "Luxury SUVs and sedans for Toyota Music Factory events",
        "Real-time GPS tracking and 15-minute early arrival guarantee",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "The closest premium airport service to DFW International",
      text: "Irving is just 15 minutes from DFW International Airport, making it one of the most convenient locations for air travelers. Our chauffeurs are DFW Airport permitted and know every terminal, pickup zone, and curbside access point. With real-time flight tracking, meet-and-greet service inside the terminal, and automatic delay adjustments, your Irving airport transfer is seamless from curb to curb.",
      bullets: [
        "DFW Airport permitted with terminal meet-and-greet service",
        "Only 15 minutes from Irving to DFW International",
        "Flight tracking with automatic pickup time adjustments",
        "Executive sedans, SUVs, and Sprinter vans for Irving airport transfers",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/8cd81521-9651-4421-a946-10bee2b40bc2.png", // Irving
    },
    faqs: [
      {
        question: `How close is Irving to DFW Airport?`,
        answer: `Irving is approximately 15 minutes from DFW International Airport, making it one of the closest cities to the airport. This proximity makes Irving an ideal location for business travelers who need quick, reliable airport transportation.`,
      },
      {
        question: `Do you provide transportation to the Irving Convention Center?`,
        answer: `Yes. We provide executive chauffeur service to the Irving Convention Center for conferences, trade shows, and corporate events. We also serve the nearby Toyota Music Factory and Las Colinas Resort for events and entertainment.`,
      },
      {
        question: `Can I book a stretch limo for a wedding in Irving?`,
        answer: `Absolutely. Our Chrysler 300 stretch limos and Hummer stretch limos are perfect for Irving weddings, especially at venues along the Mandalay Canal and in Las Colinas. We coordinate with your wedding timeline for seamless arrivals and departures.`,
      },
      {
        question: `Do you offer corporate accounts for Irving businesses?`,
        answer: `Yes. We provide centralized corporate billing, multi-passenger booking, and monthly reporting for Irving-based companies in Las Colinas and the surrounding business districts. Our service is designed for executive assistants and travel managers.`,
      },
      {
        question: `What is the best vehicle for Irving airport transfers?`,
        answer: `For solo travelers, our executive sedans provide a quiet, comfortable ride. For groups or extra luggage, our Lincoln Navigator SUVs are ideal. For larger corporate groups, our Mercedes Sprinter vans accommodate up to 14 passengers.`,
      },
    ],
    metaTitle:
      "Irving Limo Service | Las Colinas Chauffeur & DFW Airport Car Service",
    metaDescription:
      "Luxury limousine and executive chauffeur service in Irving, TX. Las Colinas corporate travel, DFW airport transfers, and special event transportation with 20+ years of 5-star service.",
    landmarks:
      "Las Colinas, Irving Convention Center, Toyota Music Factory, Mandalay Canal Walk, Omni Mandalay Hotel",
    driveTime: "15 minutes to DFW, 20 minutes to Love Field",
  },

  // 4. GRAPEVINE
  {
    slug: "grapevine",
    name: "Grapevine",
    heroTitle: "Grapevine Limo & Chauffeur Service",
    heroSubtitle:
      "Executive car service for Grapevine's wineries, DFW Airport, Gaylord Texan events, and Historic Downtown transportation.",
    heroDescription:
      "From wine tours along Grapevine's Main Street to corporate events at the Gaylord Texan Resort, Addison Limos provides luxury chauffeur transportation with 20+ years of DFW expertise.",
    heroImage: commonImg.events,
    fourthService: {
      title: "Wine Tour Transportation",
      desc: "Grapevine is the wine capital of DFW. Our chauffeur-driven wine tours visit the top tasting rooms along Main Street and beyond. No designated driver needed, just pure luxury.",
      link: "/service-wine-tours",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title:
        "Grapevine's trusted chauffeur for wine country and corporate events",
      text: "Grapevine is a unique DFW destination, blending Texas wine culture with major corporate and convention infrastructure. The Gaylord Texan Resort and Convention Center, Great Wolf Lodge, and the Grapevine Convention Center draw thousands of visitors year-round. Our chauffeurs are experts in Grapevine's logistics, from navigating Historic Downtown Main Street for wine tours to coordinating large-group arrivals at the Gaylord Texan. We know the best pickup zones, the quietest routes, and the timing that keeps your schedule flawless.",
      bullets: [
        "Wine tour transportation to Grapevine's top tasting rooms and wineries",
        "Corporate and convention service for the Gaylord Texan Resort",
        "Group shuttles for Great Wolf Lodge and Grapevine Mills events",
        "Executive sedans and SUVs for DFW-area business travel",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "The nearest luxury car service to DFW International Airport",
      text: "Grapevine is literally adjacent to DFW International Airport, just 10 minutes away. This makes it the most convenient city in DFW for airport transfers. Our DFW-permitted chauffeurs provide inside-terminal meet-and-greet service, real-time flight tracking, and curbside express pickups. Whether you're a corporate guest arriving at the Gaylord Texan or a family heading out on vacation, your Grapevine airport transfer is effortless with Addison Limos.",
      bullets: [
        "Just 10 minutes from Grapevine to DFW International Airport",
        "DFW Airport permitted with terminal meet-and-greet service",
        "Real-time flight tracking with no wait fees for delays",
        "Sprinter vans for group airport transfers from Grapevine hotels",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/b4196450-d822-47f7-9071-23ea420933f8.png", // Grapevine
    },
    faqs: [
      {
        question: `Do you offer wine tour transportation in Grapevine?`,
        answer: `Yes. We provide chauffeur-driven wine tours to Grapevine's top wineries and tasting rooms along Historic Main Street. Our luxury vehicles let your group enjoy the wine without worrying about a designated driver. We can customize the itinerary based on your preferred stops.`,
      },
      {
        question: `How far is Grapevine from DFW Airport?`,
        answer: `Grapevine is just 10 minutes from DFW International Airport, making it the closest city to the airport. This proximity makes Grapevine ideal for travelers who need quick, efficient airport transfers.`,
      },
      {
        question: `Can you provide transportation to the Gaylord Texan Resort?`,
        answer: `Absolutely. We provide executive chauffeur service to the Gaylord Texan Resort and Convention Center for corporate events, conferences, and weddings. Our chauffeurs know the best pickup and drop-off zones at the resort.`,
      },
      {
        question: `Do you offer group transportation for Grapevine events?`,
        answer: `Yes. Our Mercedes Sprinter vans and Sprinter limo buses accommodate groups up to 14 passengers. We provide group transportation for Grapevine festivals, Christmas events at Gaylord Texan, and corporate conventions.`,
      },
      {
        question: `What vehicles do you recommend for Grapevine wine tours?`,
        answer: `For intimate wine tours, our Lincoln Navigator SUV or Chrysler 300 stretch limo is perfect. For larger groups, our Mercedes Sprinter limo bus offers a party atmosphere with premium amenities, accommodating up to 14 guests.`,
      },
    ],
    metaTitle:
      "Grapevine Limo Service | Wine Tours, DFW Airport & Gaylord Texan Chauffeur",
    metaDescription:
      "Luxury limousine and chauffeur service in Grapevine, TX. Wine tours, DFW airport transfers, Gaylord Texan events, and corporate transportation with 20+ years of 5-star service.",
    landmarks:
      "Gaylord Texan Resort, Historic Main Street, Grapevine Mills Mall, Great Wolf Lodge, Grapevine Lake",
    driveTime: "10 minutes to DFW, 25 minutes to Love Field",
  },

  // 5. ARLINGTON
  {
    slug: "arlington",
    name: "Arlington",
    heroTitle: "Arlington Limo & Chauffeur Service",
    heroSubtitle:
      "Premium transportation for AT&T Stadium, Globe Life Field, Six Flags, and corporate events across Arlington, TX.",
    heroDescription:
      "Home of the Dallas Cowboys and Texas Rangers, Arlington demands world-class event transportation. Addison Limos delivers with 20+ years of game-day and corporate chauffeur expertise.",
    heroImage: commonImg.group,
    fourthService: {
      title: "Sporting Events & Concerts",
      desc: "AT&T Stadium, Globe Life Field, and Texas Live! draw massive crowds. Skip the parking chaos. Our chauffeurs handle game-day traffic while you relax in luxury.",
      link: "/service-sporting-concerts",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Arlington's game-day and event transportation specialists",
      text: "Arlington is the entertainment capital of DFW, home to AT&T Stadium (Dallas Cowboys), Globe Life Field (Texas Rangers), Six Flags Over Texas, and Texas Live!. On game days and concert nights, traffic around the Entertainment District can be overwhelming. Our chauffeurs know the back routes, the best pickup and drop-off zones, and the timing that gets you in and out efficiently. From solo executive sedan service to Sprinter limo buses for tailgate groups, we handle Arlington's biggest events with precision.",
      bullets: [
        "Game-day transportation to AT&T Stadium and Globe Life Field",
        "Concert and event service for Texas Live! and Six Flags",
        "Sprinter limo buses for tailgate groups up to 14 passengers",
        "Executive sedans for Arlington corporate travel",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Reliable Arlington airport and corporate transportation",
      text: "Arlington sits between Dallas and Fort Worth, approximately 30 minutes from DFW International Airport and 25 minutes from Dallas Love Field. Our flight tracking system monitors your arrival in real time, and our chauffeurs arrive 15 minutes early at every pickup. Whether you're a corporate executive heading to a meeting at the Arlington Convention Center or a family flying out for vacation, our DFW-permitted chauffeurs ensure a smooth, stress-free ride.",
      bullets: [
        "30-minute airport transfers to DFW and Love Field",
        "DFW Airport permitted with terminal meet-and-greet",
        "Corporate transportation for Arlington Convention Center events",
        "Group shuttles for University of Texas at Arlington events",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/3a267296-c974-44eb-a0d8-0caca955673c3.png", // Arlington
    },
    faqs: [
      {
        question: `Do you provide limo service to Dallas Cowboys games at AT&T Stadium?`,
        answer: `Yes. We provide premium chauffeur and limo service to all Dallas Cowboys home games at AT&T Stadium. Our chauffeurs know the best routes and pickup zones to avoid game-day traffic. We offer everything from executive sedans to Sprinter limo buses for tailgate groups.`,
      },
      {
        question: `Can I book transportation for a concert at Texas Live!?`,
        answer: `Absolutely. We provide luxury transportation to concerts and events at Texas Live!, Globe Life Field, and AT&T Stadium. Our service eliminates parking hassles and lets you enjoy the event without worrying about driving home.`,
      },
      {
        question: `How far is Arlington from DFW Airport?`,
        answer: `Arlington is approximately 30 minutes from DFW International Airport and 25 minutes from Dallas Love Field, depending on traffic. Our chauffeurs monitor real-time traffic to choose the fastest route.`,
      },
      {
        question: `Do you offer group transportation for Six Flags Over Texas?`,
        answer: `Yes. Our Mercedes Sprinter vans and Sprinter limo buses are perfect for group trips to Six Flags Over Texas. We handle the driving and parking while your group enjoys the park.`,
      },
      {
        question: `Can I book a Hummer limo for an Arlington event?`,
        answer: `Yes. Our white Hummer stretch limo is a popular choice for Arlington events, parties, and game-day transportation. It accommodates up to 18 passengers with premium sound, lighting, and bar amenities.`,
      },
    ],
    metaTitle:
      "Arlington Limo Service | AT&T Stadium, Globe Life Field & Airport Transfers",
    metaDescription:
      "Luxury limousine and chauffeur service in Arlington, TX. Dallas Cowboys game-day transport, concert transportation, DFW airport transfers, and corporate travel with 20+ years of 5-star service.",
    landmarks:
      "AT&T Stadium, Globe Life Field, Texas Live!, Six Flags Over Texas, Arlington Convention Center, UTA",
    driveTime: "30 minutes to DFW, 25 minutes to Love Field",
  },

  // 6. RICHARDSON
  {
    slug: "richardson",
    name: "Richardson",
    heroTitle: "Richardson Chauffeur & Limo Service",
    heroSubtitle:
      "Executive car service for Richardson's Telecom Corridor, corporate campuses, and DFW airport transfers.",
    heroDescription:
      "Richardson's Telecom Corridor is a hub for technology and telecom companies. Addison Limos provides reliable executive chauffeur service with 20+ years of DFW expertise.",
    heroImage: commonImg.cityToCity,
    fourthService: {
      title: "Point-to-Point Transfers",
      desc: "Whether it's a meeting across the metroplex or a dinner in downtown Dallas, our point-to-point chauffeur service gets Richardson professionals where they need to be on time, every time.",
      link: "/service-point-to-point",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title:
        "Richardson's executive chauffeur partner for the Telecom Corridor",
      text: "Richardson's Telecom Corridor is home to major technology and telecommunications companies, including AT&T, Cisco, and Texas Instruments. Business travel here demands punctuality and professionalism. Our chauffeurs know the corporate campuses along US-75 and Campbell Road, the Galatyn Park area, and the Eisemann Center for Performing Arts. Whether it's an executive pickup at a Richardson tech campus or a group transfer to a conference, our locally based team delivers with the precision that technology professionals expect.",
      bullets: [
        "Executive sedan service for Richardson Telecom Corridor campuses",
        "Corporate event transportation for the Eisemann Center",
        "Point-to-point transfers across the DFW metroplex",
        "GPS-tracked vehicles with live arrival updates",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Efficient DFW airport transfers from Richardson",
      text: "Richardson is approximately 30 minutes from DFW International Airport and 20 minutes from Dallas Love Field via US-75. Our real-time flight tracking ensures your chauffeur is always in sync with your actual arrival time. Meet-and-greet service inside the terminal, curbside express pickups, and automatic delay adjustments mean your Richardson airport transfer is smooth from landing to doorstep.",
      bullets: [
        "20-minute transfers to Dallas Love Field via US-75",
        "30-minute transfers to DFW International Airport",
        "Flight tracking with automatic pickup time adjustments",
        "Executive sedans and SUVs for Richardson business travelers",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/d91093bf-9dd0-4b8b-9614-103941e706c1.png", // Richardson
    },
    faqs: [
      {
        question: `Do you provide corporate transportation for Richardson tech companies?`,
        answer: `Yes. We provide executive chauffeur service for Richardson's Telecom Corridor companies, including AT&T, Cisco, and Texas Instruments. We offer centralized corporate billing and multi-passenger booking for travel managers.`,
      },
      {
        question: `How far is Richardson from DFW Airport?`,
        answer: `Richardson is approximately 30 minutes from DFW International Airport and 20 minutes from Dallas Love Field. Our chauffeurs monitor traffic on US-75 and I-635 to choose the fastest route.`,
      },
      {
        question: `Can you provide transportation to the Eisemann Center?`,
        answer: `Absolutely. We provide executive chauffeur service to the Eisemann Center for Performing Arts for corporate events, galas, and performances. Our chauffeurs know the best pickup and drop-off points at the Galatyn Park complex.`,
      },
      {
        question: `Do you offer point-to-point transfers from Richardson?`,
        answer: `Yes. Our point-to-point chauffeur service is perfect for Richardson professionals who need transportation to meetings, dinners, or events across the DFW metroplex. We provide a dedicated chauffeur for each transfer.`,
      },
      {
        question: `What vehicles are available for Richardson limo service?`,
        answer: `Our fleet includes executive sedans, Lincoln Navigator SUVs, Chrysler 300 stretch limos, and Mercedes Sprinter vans. We match the vehicle to your needs, whether it's a solo airport transfer or a group corporate event.`,
      },
    ],
    metaTitle:
      "Richardson Limo Service | Telecom Corridor Chauffeur & Airport Car Service",
    metaDescription:
      "Luxury limousine and executive chauffeur service in Richardson, TX. Telecom Corridor corporate travel, DFW airport transfers, and point-to-point transportation with 20+ years of 5-star service.",
    landmarks:
      "Telecom Corridor, Eisemann Center, Galatyn Park, Cottonwood Heights, Richardson City Hall",
    driveTime: "30 minutes to DFW, 20 minutes to Love Field",
  },

  // 7. McKINNEY
  {
    slug: "mckinney",
    name: "McKinney",
    heroTitle: "McKinney Limo & Chauffeur Service",
    heroSubtitle:
      "Premium car service for McKinney's Historic Downtown, corporate campuses, and DFW airport transfers.",
    heroDescription:
      "From the charm of Historic Downtown McKinney to corporate campuses along US-75, Addison Limos delivers luxury chauffeur transportation with 20+ years of DFW reliability.",
    heroImage: commonImg.events,
    fourthService: {
      title: "Birthday & Celebration Limo",
      desc: "Make your McKinney birthday or special celebration unforgettable with our stretch limos and luxury SUVs. Red-carpet treatment for every milestone.",
      link: "/service-birthday",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "McKinney's trusted chauffeur for business and special occasions",
      text: "McKinney is one of the fastest-growing cities in DFW, blending historic charm with modern corporate development. Our chauffeurs know the route from the historic downtown square to the corporate campuses along US-75 and the Stonebridge Ranch area. Whether it's an executive pickup at a McKinney business park, a luxury ride to a wedding at the Collin County Courthouse, or a birthday celebration in a stretch limo, our locally based team delivers with professionalism and punctuality.",
      bullets: [
        "Executive car service for McKinney corporate campuses and business parks",
        "Luxury limo service for Historic Downtown McKinney events and weddings",
        "Birthday and celebration transportation with red-carpet treatment",
        "GPS-tracked vehicles with 15-minute early arrival guarantee",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Premium DFW airport transfers from McKinney",
      text: "McKinney is approximately 45 minutes from DFW International Airport and 35 minutes from Dallas Love Field. While it's farther north than some DFW cities, our chauffeurs make the drive seamless with real-time traffic monitoring and flight tracking. Your chauffeur arrives 15 minutes early, helps with luggage, and takes the fastest route to or from the terminal. No stress, no rushing, just a quiet, comfortable ride.",
      bullets: [
        "45-minute airport transfers to DFW International",
        "Flight tracking with automatic pickup time adjustments",
        "Meet-and-greet service inside DFW and Love Field terminals",
        "Executive sedans, SUVs, and Sprinter vans for McKinney travelers",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/41aa51c1-e3b4-4801-a7ea-a13c4bb2e249.png", // McKinney
    },
    faqs: [
      {
        question: `How far is McKinney from DFW Airport?`,
        answer: `McKinney is approximately 45 minutes from DFW International Airport and 35 minutes from Dallas Love Field, depending on traffic. Our chauffeurs monitor real-time traffic on US-75 and the Sam Rayburn Tollway to ensure the fastest route.`,
      },
      {
        question: `Do you provide wedding limo service in McKinney?`,
        answer: `Yes. We provide luxury stretch limo and SUV service for McKinney weddings, including venues near Historic Downtown McKinney and the Collin County Courthouse. Our Chrysler 300 stretch limo and Hummer stretch limo are popular choices for wedding parties.`,
      },
      {
        question: `Can I book a limo for a birthday party in McKinney?`,
        answer: `Absolutely. Our stretch limos and Hummer limos are perfect for birthday celebrations in McKinney. We provide red-carpet treatment, premium sound systems, and a dedicated chauffeur so you can enjoy the celebration safely.`,
      },
      {
        question: `Do you offer corporate accounts for McKinney businesses?`,
        answer: `Yes. We offer centralized corporate billing, multi-passenger booking, and monthly reporting for McKinney-based companies. Our service is ideal for executive assistants and travel managers coordinating transportation.`,
      },
      {
        question: `What is the best vehicle for a McKinney airport transfer?`,
        answer: `For solo travelers, our executive sedan provides a quiet, comfortable ride. For families or groups with extra luggage, our Lincoln Navigator SUV is ideal. For larger groups, our Mercedes Sprinter vans accommodate up to 14 passengers.`,
      },
    ],
    metaTitle:
      "McKinney Limo Service | Luxury Chauffeur & Airport Car Service McKinney TX",
    metaDescription:
      "Premium limousine and executive chauffeur service in McKinney, TX. DFW airport transfers, wedding limos, birthday celebrations, and corporate travel with 20+ years of 5-star service.",
    landmarks:
      "Historic Downtown McKinney, Collin County Courthouse, Stonebridge Ranch, McKinney National Airport",
    driveTime: "45 minutes to DFW, 35 minutes to Love Field",
  },

  // 8. SOUTHLAKE
  {
    slug: "southlake",
    name: "Southlake",
    heroTitle: "Southlake Chauffeur & Limo Service",
    heroSubtitle:
      "Executive car service for Southlake's Town Square, corporate executives, and premium DFW airport transfers.",
    heroDescription:
      "Southlake is synonymous with luxury living. Addison Limos matches that standard with white-glove chauffeur service for Southlake residents and businesses, backed by 20+ years of DFW expertise.",
    heroImage: commonImg.vip,
    fourthService: {
      title: "VIP & Executive Transport",
      desc: "Southlake's discerning clients expect the best. Our VIP chauffeur service provides discreet, first-class transportation for executives, VIPs, and special guests.",
      link: "/service-vip",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Southlake's premier luxury chauffeur service",
      text: "Southlake is one of the most affluent communities in DFW, home to Southlake Town Square, Carroll ISD, and a thriving business community along Highway 114. Our chauffeurs understand the standard of service that Southlake residents and executives expect: impeccable vehicles, discreet drivers, and absolute punctuality. From a luxury SUV for a dinner at Southlake Town Square to an executive sedan for a corporate meeting in Las Colinas, we deliver a first-class experience every time.",
      bullets: [
        "VIP chauffeur service for Southlake executives and residents",
        "Luxury SUV and sedan service for Southlake Town Square events",
        "Discreet, NDA-compliant drivers for confidential travel",
        "Premium vehicles maintained to the highest standards",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Effortless DFW airport service from Southlake",
      text: "Southlake is just 15 minutes from DFW International Airport via Highway 114, making it one of the most convenient locations for air travel in DFW. Our DFW-permitted chauffeurs provide inside-terminal meet-and-greet service, real-time flight tracking, and curbside express pickups. Whether you're flying out for business or returning from an international trip, your Southlake airport transfer is seamless, quiet, and perfectly timed.",
      bullets: [
        "Only 15 minutes from Southlake to DFW International via Highway 114",
        "DFW Airport permitted with terminal meet-and-greet",
        "Real-time flight tracking with no wait fees for delays",
        "Lincoln Navigator SUVs and executive sedans for Southlake travelers",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/257f292e-d169-4815-b9d6-7e7b5b7f8658.png", // Carrollton
    },
    faqs: [
      {
        question: `How far is Southlake from DFW Airport?`,
        answer: `Southlake is just 15 minutes from DFW International Airport via Highway 114, making it one of the closest residential communities to the airport. This proximity makes Southlake ideal for frequent business travelers.`,
      },
      {
        question: `Do you provide VIP transportation for Southlake executives?`,
        answer: `Yes. Our VIP chauffeur service is designed for Southlake's discerning executives and professionals. We provide discreet, NDA-compliant drivers, premium vehicles, and absolute punctuality for confidential business travel.`,
      },
      {
        question: `Can I book a luxury SUV for a night out at Southlake Town Square?`,
        answer: `Absolutely. Our Lincoln Navigator SUVs and executive sedans are perfect for a luxury night out at Southlake Town Square. Your chauffeur handles the driving and parking while you enjoy your evening.`,
      },
      {
        question: `Do you offer corporate accounts for Southlake businesses?`,
        answer: `Yes. We offer centralized corporate billing, multi-passenger booking, and monthly reporting for Southlake-based companies. Our service is designed for executive assistants and travel managers who need reliable, repeatable transportation.`,
      },
      {
        question: `What vehicles do you recommend for Southlake clients?`,
        answer: `For solo executive travel, our executive sedan is ideal. For families or VIP guests, the Lincoln Navigator SUV offers premium comfort and luggage capacity. For special occasions, our Chrysler 300 stretch limo adds a touch of luxury.`,
      },
    ],
    metaTitle:
      "Southlake Limo Service | Luxury Chauffeur & DFW Airport Car Service",
    metaDescription:
      "Premium limousine and VIP chauffeur service in Southlake, TX. DFW airport transfers, executive transport, Southlake Town Square events, and corporate travel with 20+ years of 5-star service.",
    landmarks:
      "Southlake Town Square, Carroll ISD, Highway 114 corridor, Bicentennial Park",
    driveTime: "15 minutes to DFW, 25 minutes to Love Field",
  },

  // 9. CARROLLTON
  {
    slug: "carrollton",
    name: "Carrollton",
    heroTitle: "Carrollton Limo & Chauffeur Service",
    heroSubtitle:
      "Executive car service for Carrollton's business parks, historic downtown, and DFW airport transfers.",
    heroDescription:
      "Carrollton's strategic location at the crossroads of I-35E and the President George Bush Turnpike makes it a DFW transportation hub. Addison Limos provides premium chauffeur service with 20+ years of expertise.",
    heroImage: commonImg.cityToCity,
    fourthService: {
      title: "Group Shuttle Service",
      desc: "Carrollton's corporate parks and cultural diversity mean group events are frequent. Our Sprinter vans and shuttle service handle corporate group transportation with ease.",
      link: "/service-shuttle",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Carrollton's reliable chauffeur for business and events",
      text: "Carrollton sits at the strategic crossroads of I-35E, I-635, and the President George Bush Turnpike, making it a key logistics and business hub in DFW. Our chauffeurs know every route through Carrollton's business parks, the Historic Downtown area, and the Crosby Road corridor. Whether it's an executive sedan for a corporate meeting at a Carrollton business park or a Sprinter van for a group shuttle to a DFW event, our locally based team delivers with the punctuality and professionalism that Carrollton businesses demand.",
      bullets: [
        "Executive car service for Carrollton business parks and corporate centers",
        "Group shuttle service for corporate events and conferences",
        "Point-to-point transfers across the DFW metroplex",
        "GPS-tracked vehicles with live arrival updates",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Convenient DFW airport transfers from Carrollton",
      text: "Carrollton is approximately 25 minutes from DFW International Airport and 20 minutes from Dallas Love Field. Its central location makes airport transfers efficient from any part of the city. Our flight tracking system monitors your arrival in real time, and our DFW-permitted chauffeurs provide inside-terminal meet-and-greet service. Your Carrollton airport transfer is smooth, quiet, and perfectly timed.",
      bullets: [
        "25-minute transfers to DFW International Airport",
        "20-minute transfers to Dallas Love Field",
        "DFW Airport permitted with terminal meet-and-greet",
        "Sprinter vans for group airport transfers from Carrollton",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/789db4d9-ee51-4ca7-b1e8-08d415025281.png", // Denton
    },
    faqs: [
      {
        question: `How far is Carrollton from DFW Airport?`,
        answer: `Carrollton is approximately 25 minutes from DFW International Airport and 20 minutes from Dallas Love Field. Its central location at the crossroads of I-35E and the President George Bush Turnpike makes airport transfers efficient.`,
      },
      {
        question: `Do you provide group shuttle service in Carrollton?`,
        answer: `Yes. Our Mercedes Sprinter vans and Sprinter limo buses are perfect for group transportation in Carrollton. We provide corporate shuttles, event transportation, and group airport transfers for up to 14 passengers.`,
      },
      {
        question: `Can I book a corporate account for my Carrollton business?`,
        answer: `Absolutely. We offer centralized corporate billing, multi-passenger booking, and monthly reporting for Carrollton-based companies. Our service is designed for travel managers and executive assistants coordinating company-wide transportation.`,
      },
      {
        question: `Do you provide transportation to Historic Downtown Carrollton?`,
        answer: `Yes. We provide luxury chauffeur service to Historic Downtown Carrollton for events, dinners, and special occasions. Our chauffeurs know the best pickup and drop-off points in the downtown area.`,
      },
      {
        question: `What vehicles are available for Carrollton limo service?`,
        answer: `Our fleet includes executive sedans, Lincoln Navigator SUVs, Chrysler 300 stretch limos, Hummer stretch limos, and Mercedes Sprinter vans and limo buses. We match the vehicle to your group size and occasion.`,
      },
    ],
    metaTitle:
      "Carrollton Limo Service | Chauffeur, Group Shuttle & Airport Car Service",
    metaDescription:
      "Luxury limousine and executive chauffeur service in Carrollton, TX. DFW airport transfers, corporate group shuttles, and special event transportation with 20+ years of 5-star service.",
    landmarks:
      "Historic Downtown Carrollton, Crosby Road corridor, Carrollton business parks, Sandy Lake Road",
    driveTime: "25 minutes to DFW, 20 minutes to Love Field",
  },

  // 10. LEWISVILLE
  {
    slug: "lewisville",
    name: "Lewisville",
    heroTitle: "Lewisville Limo & Chauffeur Service",
    heroSubtitle:
      "Premium car service for Lewisville Lake events, corporate travel, and DFW airport transfers.",
    heroDescription:
      "From lakeside events at Lewisville Lake to corporate travel along I-35E, Addison Limos delivers luxury chauffeur transportation with 20+ years of DFW expertise.",
    heroImage: commonImg.events,
    fourthService: {
      title: "Birthday & Celebration Limo",
      desc: "Celebrate at Lewisville Lake or anywhere in DFW with our stretch limos and luxury SUVs. Red-carpet service for birthdays, anniversaries, and special milestones.",
      link: "/service-birthday",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Lewisville's trusted chauffeur for lake events and business",
      text: "Lewisville is a vibrant DFW city centered around Lewisville Lake, a major destination for boating, fishing, and lakeside events. The city also has a growing corporate presence along I-35E and the Corporate Drive corridor. Our chauffeurs know the routes to the lakefront venues, the Music City Lewisville event space, and the corporate parks along I-35E. Whether it's a luxury SUV for a lakeside wedding or an executive sedan for a corporate meeting, our locally based team delivers with precision.",
      bullets: [
        "Luxury limo service for Lewisville Lake events and lakeside weddings",
        "Executive car service for Lewisville corporate parks",
        "Birthday and celebration transportation with red-carpet treatment",
        "GPS-tracked vehicles with 15-minute early arrival guarantee",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Efficient DFW airport transfers from Lewisville",
      text: "Lewisville is approximately 20 minutes from DFW International Airport via I-35E, making it one of the most convenient northern suburbs for airport travel. Our DFW-permitted chauffeurs provide inside-terminal meet-and-greet service, real-time flight tracking, and curbside express pickups. Whether you're flying out for business or returning from a trip, your Lewisville airport transfer is seamless and stress-free.",
      bullets: [
        "20-minute transfers to DFW International Airport via I-35E",
        "DFW Airport permitted with terminal meet-and-greet",
        "Real-time flight tracking with automatic delay adjustments",
        "Executive sedans, SUVs, and Sprinter vans for Lewisville travelers",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/bf10dae8-a75e-46a4-a171-ee93b8471121.png", // Lewisville
    },
    faqs: [
      {
        question: `How far is Lewisville from DFW Airport?`,
        answer: `Lewisville is approximately 20 minutes from DFW International Airport via I-35E, making it one of the closest northern suburbs to the airport. This proximity makes Lewisville ideal for frequent air travelers.`,
      },
      {
        question: `Do you provide transportation for events at Lewisville Lake?`,
        answer: `Yes. We provide luxury chauffeur service to Lewisville Lake events, lakeside weddings, and lakeside parties. Our stretch limos and luxury SUVs are perfect for making a grand entrance at any lakefront venue.`,
      },
      {
        question: `Can I book a birthday limo in Lewisville?`,
        answer: `Absolutely. Our Chrysler 300 stretch limo and Hummer stretch limo are popular choices for birthday celebrations in Lewisville. We provide red-carpet treatment, premium sound systems, and a dedicated chauffeur.`,
      },
      {
        question: `Do you offer corporate accounts for Lewisville businesses?`,
        answer: `Yes. We offer centralized corporate billing, multi-passenger booking, and monthly reporting for Lewisville-based companies. Our service is designed for travel managers and executive assistants coordinating transportation.`,
      },
      {
        question: `What is the best vehicle for a Lewisville airport transfer?`,
        answer: `For solo travelers, our executive sedan provides a quiet, comfortable ride. For families or groups, our Lincoln Navigator SUV offers premium comfort and luggage capacity. For larger groups, our Mercedes Sprinter vans accommodate up to 14 passengers.`,
      },
    ],
    metaTitle:
      "Lewisville Limo Service | Lake Events, Chauffeur & DFW Airport Car Service",
    metaDescription:
      "Luxury limousine and executive chauffeur service in Lewisville, TX. Lewisville Lake events, DFW airport transfers, birthday celebrations, and corporate travel with 20+ years of 5-star service.",
    landmarks:
      "Lewisville Lake, Music City Lewisville, I-35E corridor, Corporate Drive, Lake Park",
    driveTime: "20 minutes to DFW, 25 minutes to Love Field",
  },

  // 11. DENTON
  {
    slug: "denton",
    name: "Denton",
    heroTitle: "Denton Limo & Chauffeur Service",
    heroSubtitle:
      "Executive car service for UNT, TWU, Downtown Denton, and DFW airport transfers.",
    heroDescription:
      "Denton's unique blend of university culture and growing business makes it a distinctive DFW destination. Addison Limos provides premium chauffeur service with 20+ years of expertise.",
    heroImage: commonImg.group,
    fourthService: {
      title: "City Tours & Special Events",
      desc: "Explore Denton's vibrant Downtown Square, live music scene, and cultural events in a luxury chauffeur-driven vehicle. Perfect for visitors and locals alike.",
      link: "/service-city-tours",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Denton's go-to chauffeur for university and business travel",
      text: "Denton is home to the University of North Texas (UNT) and Texas Woman's University (TWU), giving it a vibrant, youthful energy. The Historic Downtown Square is a cultural hub with live music, restaurants, and events. Our chauffeurs know the routes to both university campuses, the Downtown Square, and the growing business corridors along I-35E. Whether it's transportation for a university event, a corporate meeting, or a night out on the Square, our locally based team delivers with professionalism and local knowledge.",
      bullets: [
        "Executive car service for UNT and TWU university events",
        "Luxury transportation for Downtown Denton Square events",
        "Corporate travel for Denton's growing business community",
        "Group shuttles for university and corporate group transportation",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Premium DFW airport transfers from Denton",
      text: "Denton is approximately 45 minutes from DFW International Airport via I-35E, making it one of the farther north DFW cities. However, our chauffeurs make the drive seamless with real-time traffic monitoring, flight tracking, and 15-minute early arrival. Your chauffeur handles the I-35E traffic while you relax, work, or make calls in a quiet, comfortable vehicle. Meet-and-greet service inside the terminal makes your arrival effortless.",
      bullets: [
        "45-minute airport transfers to DFW International via I-35E",
        "Flight tracking with automatic pickup time adjustments",
        "Meet-and-greet service inside DFW and Love Field terminals",
        "Executive sedans, SUVs, and Sprinter vans for Denton travelers",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/36ac270d-eb15-4365-8087-1acd9b1a665f.png", // Southlake
    },
    faqs: [
      {
        question: `How far is Denton from DFW Airport?`,
        answer: `Denton is approximately 45 minutes from DFW International Airport via I-35E, depending on traffic. Our chauffeurs monitor real-time traffic conditions to ensure the fastest route and timely arrival.`,
      },
      {
        question: `Do you provide transportation for UNT and TWU events?`,
        answer: `Yes. We provide luxury chauffeur service for university events at the University of North Texas and Texas Woman's University. Our Sprinter vans are perfect for group transportation for university functions, graduation ceremonies, and campus events.`,
      },
      {
        question: `Can I book a limo for a night out on the Denton Square?`,
        answer: `Absolutely. Our stretch limos and luxury SUVs are perfect for a night out on the Historic Downtown Denton Square. Your chauffeur handles the driving and parking while you enjoy the live music, restaurants, and nightlife.`,
      },
      {
        question: `Do you offer corporate accounts for Denton businesses?`,
        answer: `Yes. We offer centralized corporate billing, multi-passenger booking, and monthly reporting for Denton-based companies. Our service is designed for travel managers and executive assistants coordinating transportation.`,
      },
      {
        question: `What vehicles are available for Denton limo service?`,
        answer: `Our fleet includes executive sedans, Lincoln Navigator SUVs, Chrysler 300 stretch limos, Hummer stretch limos, and Mercedes Sprinter vans and limo buses. We match the vehicle to your group size and occasion.`,
      },
    ],
    metaTitle:
      "Denton Limo Service | UNT, TWU, Downtown Square & DFW Airport Chauffeur",
    metaDescription:
      "Luxury limousine and executive chauffeur service in Denton, TX. UNT and TWU university events, Downtown Square nightlife, DFW airport transfers, and corporate travel with 20+ years of 5-star service.",
    landmarks:
      "University of North Texas, Texas Woman's University, Historic Downtown Denton Square, Denton County Courthouse",
    driveTime: "45 minutes to DFW, 40 minutes to Love Field",
  },

  // 12. FORT WORTH
  {
    slug: "fort-worth",
    name: "Fort Worth",
    heroTitle: "Fort Worth Limo & Executive Chauffeur Service",
    heroSubtitle:
      "Premium car service for downtown Fort Worth, the Stockyards, Sundance Square, and DFW airport transfers.",
    heroDescription:
      "From the historic Stockyards to the cultural district, Fort Worth demands transportation as bold as the city itself. Addison Limos delivers with 20+ years of DFW chauffeur expertise.",
    heroImage: commonImg.events,
    fourthService: {
      title: "Wedding & Special Occasion Limo",
      desc: "Fort Worth's stunning wedding venues, from the Stockyards to the Botanic Garden, deserve first-class arrival. Our stretch limos and luxury SUVs make your day unforgettable.",
      link: "/service-wedding",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Fort Worth's premier chauffeur for the Stockyards and beyond",
      text: "Fort Worth is a city of distinct character, from the cowboy culture of the historic Stockyards to the sophistication of the Cultural District and the business energy of downtown Sundance Square. Our chauffeurs know every district: the Bass Performance Hall, the Kimbell Art Museum, the Fort Worth Convention Center, and the Stockyards Station. Whether it's an executive sedan for a downtown business meeting, a luxury SUV for a Cultural District event, or a stretch limo for a Stockyards night out, our locally based team delivers with the punctuality and professionalism that Fort Worth expects.",
      bullets: [
        "Executive car service for downtown Fort Worth and Sundance Square",
        "Luxury transportation for Stockyards events and nightlife",
        "Cultural District and Bass Performance Hall chauffeur service",
        "Corporate travel for Fort Worth Convention Center events",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Seamless DFW airport transfers from Fort Worth",
      text: "Fort Worth is approximately 35 minutes from DFW International Airport via I-820 and TX-121, and 30 minutes from Dallas Love Field. Our DFW-permitted chauffeurs provide inside-terminal meet-and-greet service, real-time flight tracking, and curbside express pickups. Whether you're a business executive flying out for a meeting or a family returning from vacation, your Fort Worth airport transfer is smooth, quiet, and perfectly timed.",
      bullets: [
        "35-minute transfers to DFW International via I-820 and TX-121",
        "DFW Airport permitted with terminal meet-and-greet service",
        "Real-time flight tracking with no wait fees for delays",
        "Sprinter vans for group airport transfers from Fort Worth",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/d56f1b89-98dc-4fe4-b006-bd9f0fef39b0.png", // Flower Mound
    },
    faqs: [
      {
        question: `Do you provide limo service to the Fort Worth Stockyards?`,
        answer: `Yes. We provide luxury chauffeur and limo service to the Fort Worth Stockyards for events, nightlife, and special occasions. Our chauffeurs know the best pickup and drop-off points in the Stockyards district.`,
      },
      {
        question: `How far is Fort Worth from DFW Airport?`,
        answer: `Fort Worth is approximately 35 minutes from DFW International Airport via I-820 and TX-121, depending on traffic. Our chauffeurs monitor real-time traffic to choose the fastest route.`,
      },
      {
        question: `Can I book a wedding limo in Fort Worth?`,
        answer: `Absolutely. We provide luxury stretch limo and SUV service for Fort Worth weddings, including venues at the Stockyards, the Botanic Garden, and downtown hotels. Our Chrysler 300 stretch limo and Hummer stretch limo are popular choices.`,
      },
      {
        question: `Do you provide transportation to Bass Performance Hall?`,
        answer: `Yes. We provide executive chauffeur service to Bass Performance Hall for performances, galas, and events. Our luxury vehicles ensure you arrive in style for any Cultural District event.`,
      },
      {
        question: `Do you offer corporate accounts for Fort Worth businesses?`,
        answer: `Yes. We offer centralized corporate billing, multi-passenger booking, and monthly reporting for Fort Worth-based companies. Our service is designed for travel managers and executive assistants coordinating company-wide transportation.`,
      },
    ],
    metaTitle:
      "Fort Worth Limo Service | Stockyards, Sundance Square & DFW Airport Chauffeur",
    metaDescription:
      "Luxury limousine and executive chauffeur service in Fort Worth, TX. Stockyards events, Sundance Square, DFW airport transfers, weddings, and corporate travel with 20+ years of 5-star service.",
    landmarks:
      "Fort Worth Stockyards, Sundance Square, Bass Performance Hall, Kimbell Art Museum, Fort Worth Convention Center, Cultural District",
    driveTime: "35 minutes to DFW, 30 minutes to Love Field",
  },

  // 13. DUNCANVILLE
  {
    slug: "duncanville",
    name: "Duncanville",
    heroTitle: "Duncanville Limo & Chauffeur Service",
    heroSubtitle:
      "Executive car service for Duncanville residents, businesses, and DFW airport transfers.",
    heroDescription:
      "Duncanville's community charm meets luxury transportation with Addison Limos. Our 20+ years of DFW expertise ensures reliable, first-class chauffeur service every time.",
    heroImage: commonImg.cityToCity,
    fourthService: {
      title: "Funeral & Dignified Transport",
      desc: "In times of need, our compassionate chauffeur service provides dignified, respectful transportation for funeral processions and family gatherings in Duncanville and across DFW.",
      link: "/service-funeral",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Duncanville's trusted chauffeur for every occasion",
      text: "Duncanville is a close-knit community in southern Dallas County, known for its family-friendly atmosphere and convenient access to downtown Dallas via I-20 and US-67. Our chauffeurs know Duncanville's residential neighborhoods, the Cedar Valley College area, and the best routes to downtown Dallas events. Whether it's an executive sedan for a business meeting in downtown Dallas, a luxury SUV for a special occasion, or dignified transportation for a funeral, our locally based team delivers with the respect and professionalism that Duncanville residents expect.",
      bullets: [
        "Executive car service for Duncanville residents and businesses",
        "Luxury transportation for special occasions and events",
        "Dignified, compassionate funeral transportation",
        "Convenient access to downtown Dallas via I-20 and US-67",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Reliable DFW airport transfers from Duncanville",
      text: "Duncanville is approximately 30 minutes from Dallas Love Field and 35 minutes from DFW International Airport via I-20. Our DFW-permitted chauffeurs provide inside-terminal meet-and-greet service, real-time flight tracking, and curbside express pickups. Whether you're flying out for business or pleasure, your Duncanville airport transfer is seamless, comfortable, and perfectly timed.",
      bullets: [
        "30-minute transfers to Dallas Love Field via I-20",
        "35-minute transfers to DFW International Airport",
        "DFW Airport permitted with terminal meet-and-greet",
        "Executive sedans and SUVs for Duncanville travelers",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/fd768035-67bd-478e-85e8-08e06969eaf2.png", // Garland
    },
    faqs: [
      {
        question: `How far is Duncanville from DFW Airport?`,
        answer: `Duncanville is approximately 35 minutes from DFW International Airport and 30 minutes from Dallas Love Field via I-20, depending on traffic. Our chauffeurs monitor real-time traffic to choose the fastest route.`,
      },
      {
        question: `Do you provide funeral transportation in Duncanville?`,
        answer: `Yes. We provide dignified, compassionate chauffeur service for funeral processions and family gatherings in Duncanville and across DFW. Our professional chauffeurs handle every detail with the utmost respect and discretion.`,
      },
      {
        question: `Can I book a limo for a special occasion in Duncanville?`,
        answer: `Absolutely. Our stretch limos and luxury SUVs are perfect for birthdays, anniversaries, and special celebrations in Duncanville. We provide red-carpet treatment and a dedicated chauffeur for your event.`,
      },
      {
        question: `Do you offer corporate accounts for Duncanville businesses?`,
        answer: `Yes. We offer centralized corporate billing, multi-passenger booking, and monthly reporting for Duncanville-based companies. Our service is designed for travel managers and executive assistants coordinating transportation.`,
      },
      {
        question: `What vehicles are available for Duncanville limo service?`,
        answer: `Our fleet includes executive sedans, Lincoln Navigator SUVs, Chrysler 300 stretch limos, Hummer stretch limos, and Mercedes Sprinter vans. We match the vehicle to your group size and occasion.`,
      },
    ],
    metaTitle:
      "Duncanville Limo Service | Luxury Chauffeur & DFW Airport Car Service",
    metaDescription:
      "Premium limousine and executive chauffeur service in Duncanville, TX. DFW airport transfers, special occasion limos, funeral transportation, and corporate travel with 20+ years of 5-star service.",
    landmarks:
      "Cedar Valley College, Duncanville City Hall, I-20 corridor, Armstrong Park",
    driveTime: "35 minutes to DFW, 30 minutes to Love Field",
  },

  // 14. CEDAR HILL
  {
    slug: "cedar-hill",
    name: "Cedar Hill",
    heroTitle: "Cedar Hill Limo & Chauffeur Service",
    heroSubtitle:
      "Premium car service for Cedar Hill's retail district, Cedar Hill State Park, and DFW airport transfers.",
    heroDescription:
      "Cedar Hill's hilltop views and growing business community deserve first-class transportation. Addison Limos delivers luxury chauffeur service with 20+ years of DFW expertise.",
    heroImage: commonImg.events,
    fourthService: {
      title: "Medical Transportation",
      desc: "Cedar Hill residents deserve comfortable, reliable medical transportation. Our professional chauffeurs provide non-emergency medical transport to appointments across DFW.",
      link: "/service-medical-transport",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Cedar Hill's trusted chauffeur for business and leisure",
      text: "Cedar Hill sits on the highest elevation in Dallas County, offering panoramic views and a growing retail and business presence along Highway 67 and Belt Line Road. The city is home to Cedar Hill State Park, the popular Uptown Village shopping center, and a growing corporate community. Our chauffeurs know the routes through Cedar Hill's residential areas, the retail district, and the best paths to downtown Dallas and DFW Airport. Whether it's an executive sedan for a business meeting or a luxury SUV for a special occasion, our locally based team delivers with professionalism.",
      bullets: [
        "Executive car service for Cedar Hill businesses and retail district",
        "Luxury transportation for Cedar Hill State Park events and outings",
        "Non-emergency medical transportation to DFW-area medical facilities",
        "GPS-tracked vehicles with 15-minute early arrival guarantee",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Convenient DFW airport transfers from Cedar Hill",
      text: "Cedar Hill is approximately 35 minutes from Dallas Love Field and 40 minutes from DFW International Airport via US-67 and I-20. Our DFW-permitted chauffeurs provide inside-terminal meet-and-greet service, real-time flight tracking, and curbside express pickups. Whether you're flying out for business or returning from a trip, your Cedar Hill airport transfer is seamless and stress-free.",
      bullets: [
        "35-minute transfers to Dallas Love Field via US-67",
        "40-minute transfers to DFW International Airport",
        "DFW Airport permitted with terminal meet-and-greet",
        "Executive sedans and SUVs for Cedar Hill travelers",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/53c429af-1423-442a-8680-f9ed6bc50cd0.png", // Addison
    },
    faqs: [
      {
        question: `How far is Cedar Hill from DFW Airport?`,
        answer: `Cedar Hill is approximately 40 minutes from DFW International Airport and 35 minutes from Dallas Love Field via US-67 and I-20, depending on traffic. Our chauffeurs monitor real-time traffic to choose the fastest route.`,
      },
      {
        question: `Do you provide medical transportation in Cedar Hill?`,
        answer: `Yes. We provide professional non-emergency medical transportation for Cedar Hill residents to medical appointments across DFW. Our chauffeurs are professional, punctual, and sensitive to the needs of patients and families.`,
      },
      {
        question: `Can I book a limo for a special occasion in Cedar Hill?`,
        answer: `Absolutely. Our stretch limos and luxury SUVs are perfect for birthdays, anniversaries, and special celebrations in Cedar Hill. We provide red-carpet treatment and a dedicated chauffeur for your event.`,
      },
      {
        question: `Do you offer corporate accounts for Cedar Hill businesses?`,
        answer: `Yes. We offer centralized corporate billing, multi-passenger booking, and monthly reporting for Cedar Hill-based companies. Our service is designed for travel managers and executive assistants coordinating transportation.`,
      },
      {
        question: `Do you provide transportation to Cedar Hill State Park?`,
        answer: `Yes. We provide luxury chauffeur service to Cedar Hill State Park for outings, events, and special occasions. Our SUVs and Sprinter vans are ideal for group trips to the park.`,
      },
    ],
    metaTitle:
      "Cedar Hill Limo Service | Luxury Chauffeur, Medical Transport & Airport",
    metaDescription:
      "Premium limousine and executive chauffeur service in Cedar Hill, TX. DFW airport transfers, medical transportation, special occasion limos, and corporate travel with 20+ years of 5-star service.",
    landmarks:
      "Cedar Hill State Park, Uptown Village, Highway 67 corridor, Cedar Hill City Hall",
    driveTime: "40 minutes to DFW, 35 minutes to Love Field",
  },

  // 15. FLOWER MOUND
  {
    slug: "flower-mound",
    name: "Flower Mound",
    heroTitle: "Flower Mound Limo & Chauffeur Service",
    heroSubtitle:
      "Executive car service for Flower Mound's corporate parks, lakeside events, and DFW airport transfers.",
    heroDescription:
      "Flower Mound's prime location between Lake Lewisville and Grapevine Lake makes it a sought-after DFW community. Addison Limos provides luxury chauffeur service with 20+ years of expertise.",
    heroImage: commonImg.cityToCity,
    fourthService: {
      title: "Holiday Lights Tours",
      desc: "Flower Mound's neighborhoods go all-out for holiday lights. Our chauffeur-driven holiday lights tours let your family enjoy the magic in luxury. No driving, no cold, just comfort.",
      link: "/service-holiday-lights",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title:
        "Flower Mound's premier chauffeur for business and lakeside events",
      text: "Flower Mound is a thriving community situated between Lake Lewisville and Grapevine Lake, with growing corporate parks along FM 2499 and I-35W. The town is known for its master-planned communities, the River Walk development, and convenient access to DFW Airport. Our chauffeurs know the routes through Flower Mound's residential areas, the corporate parks, and the best paths to both lakes. Whether it's an executive sedan for a corporate meeting or a luxury SUV for a lakeside event, our locally based team delivers with precision.",
      bullets: [
        "Executive car service for Flower Mound corporate parks and FM 2499",
        "Luxury transportation for lakeside events at Lake Lewisville and Grapevine Lake",
        "Holiday lights tours through Flower Mound's decorated neighborhoods",
        "GPS-tracked vehicles with 15-minute early arrival guarantee",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Quick DFW airport transfers from Flower Mound",
      text: "Flower Mound is approximately 20 minutes from DFW International Airport via FM 2499 and TX-121, making it one of the most convenient locations for airport travel in DFW. Our DFW-permitted chauffeurs provide inside-terminal meet-and-greet service, real-time flight tracking, and curbside express pickups. Whether you're flying out for business or pleasure, your Flower Mound airport transfer is seamless, quiet, and perfectly timed.",
      bullets: [
        "20-minute transfers to DFW International via FM 2499 and TX-121",
        "DFW Airport permitted with terminal meet-and-greet",
        "Real-time flight tracking with no wait fees for delays",
        "Executive sedans, SUVs, and Sprinter vans for Flower Mound travelers",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/ec5b187b-e866-43d4-91b5-352a0e01c011.png", // Plano
    },
    faqs: [
      {
        question: `How far is Flower Mound from DFW Airport?`,
        answer: `Flower Mound is approximately 20 minutes from DFW International Airport via FM 2499 and TX-121, making it one of the most convenient communities for airport travel in DFW.`,
      },
      {
        question: `Do you provide holiday lights tours in Flower Mound?`,
        answer: `Yes. We provide chauffeur-driven holiday lights tours through Flower Mound's beautifully decorated neighborhoods. Our luxury SUVs and Sprinter vans let your family enjoy the holiday magic in warmth and comfort.`,
      },
      {
        question: `Can I book a limo for a lakeside event at Lake Lewisville or Grapevine Lake?`,
        answer: `Absolutely. We provide luxury chauffeur service to lakeside events at both Lake Lewisville and Grapevine Lake. Our SUVs and Sprinter vans are perfect for group outings to lakeside venues.`,
      },
      {
        question: `Do you offer corporate accounts for Flower Mound businesses?`,
        answer: `Yes. We offer centralized corporate billing, multi-passenger booking, and monthly reporting for Flower Mound-based companies. Our service is designed for travel managers and executive assistants coordinating transportation.`,
      },
      {
        question: `What vehicles are available for Flower Mound limo service?`,
        answer: `Our fleet includes executive sedans, Lincoln Navigator SUVs, Chrysler 300 stretch limos, Hummer stretch limos, and Mercedes Sprinter vans and limo buses. We match the vehicle to your group size and occasion.`,
      },
    ],
    metaTitle:
      "Flower Mound Limo Service | Luxury Chauffeur & DFW Airport Car Service",
    metaDescription:
      "Premium limousine and executive chauffeur service in Flower Mound, TX. DFW airport transfers, lakeside events, holiday lights tours, and corporate travel with 20+ years of 5-star service.",
    landmarks:
      "Lake Lewisville, Grapevine Lake, River Walk development, FM 2499 corridor, Flower Mound Town Hall",
    driveTime: "20 minutes to DFW, 30 minutes to Love Field",
  },
  // 16. GARLAND
  {
    slug: "garland",
    name: "Garland",
    heroTitle: "Garland Limo & Chauffeur Service",
    heroSubtitle:
      "Executive car service for Garland's downtown district, corporate centers, and DFW airport transfers.",
    heroDescription:
      "Garland's strategic location along I-635 and US-78 makes it a key DFW transportation hub. Addison Limos provides premium chauffeur service with 20+ years of expertise.",
    heroImage: commonImg.events,
    fourthService: {
      title: "Wedding & Special Occasion Limo",
      desc: "From the elegant venues in Garland's downtown to nearby wedding chapels, our stretch limos and luxury SUVs make your special day unforgettable.",
      link: "/service-wedding",
      img: "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
    },
    trust1: {
      title: "Garland's trusted chauffeur for business and celebrations",
      text: "Garland is a vibrant city east of Dallas, known for its downtown revitalization, the Granville Arts Center, and a growing corporate community along I-635 and the Bush Turnpike. Our chauffeurs know every route through Garland's residential neighborhoods, the Firewheel Town Center area, and the best paths to downtown Dallas events. Whether it's an executive sedan for a corporate meeting or a stretch limo for a celebration at the Atrium at Garland City Hall, our locally based team delivers with professionalism.",
      bullets: [
        "Executive car service for Garland corporate centers and downtown businesses",
        "Luxury limo service for events at the Granville Arts Center",
        "Wedding and celebration transportation with red-carpet treatment",
        "GPS-tracked vehicles with 15-minute early arrival guarantee",
      ],
      image: commonImg.chauffeur,
    },
    trust2: {
      title: "Convenient DFW airport transfers from Garland",
      text: "Garland is approximately 30 minutes from DFW International Airport via I-635 and 25 minutes from Dallas Love Field. Its central location makes airport transfers efficient from any part of the city. Our flight tracking system monitors your arrival in real time, and our DFW-permitted chauffeurs provide inside-terminal meet-and-greet service. Your Garland airport transfer is smooth, quiet, and perfectly timed.",
      bullets: [
        "30-minute transfers to DFW International Airport via I-635",
        "25-minute transfers to Dallas Love Field",
        "DFW Airport permitted with terminal meet-and-greet service",
        "Sprinter vans for group airport transfers from Garland",
      ],
      image:
        "https://vibe.filesafe.space/1792719026995615993/assets/482f5643-5d07-4e69-8b14-07a56ee50580.png", // City 17 - DFW Airport area
    },
    faqs: [
      {
        question: `How far is Garland from DFW Airport?`,
        answer: `Garland is approximately 30 minutes from DFW International Airport via I-635 and 25 minutes from Dallas Love Field, depending on traffic. Its location near the Bush Turnpike makes it convenient for airport access.`,
      },
      {
        question: `Do you provide limo service for events at the Granville Arts Center?`,
        answer: `Yes. We provide executive chauffeur and limo service to the Granville Arts Center for performances, galas, and private events. Our luxury vehicles ensure you arrive in style for any downtown Garland event.`,
      },
      {
        question: `Can I book a limo for a wedding in Garland?`,
        answer: `Absolutely. We provide luxury stretch limo and SUV service for Garland weddings, including venues like The Atrium at Garland City Hall and nearby wedding chapels. Our Chrysler 300 stretch limo is a popular choice.`,
      },
      {
        question: `Do you offer corporate accounts for Garland businesses?`,
        answer: `Yes. We offer centralized corporate billing, multi-passenger booking, and monthly reporting for Garland-based companies. Our service is designed for travel managers and executive assistants coordinating transportation.`,
      },
      {
        question: `What vehicles are available for Garland limo service?`,
        answer: `Our fleet includes executive sedans, Lincoln Navigator SUVs, Chrysler 300 stretch limos, Hummer stretch limos, and Mercedes Sprinter vans. We match the vehicle to your group size and occasion.`,
      },
    ],
    metaTitle:
      "Garland Limo Service | Luxury Chauffeur & DFW Airport Car Service",
    metaDescription:
      "Luxury limousine and executive chauffeur service in Garland, TX. DFW airport transfers, wedding limos, corporate travel, and special event transportation with 20+ years of 5-star service.",
    landmarks:
      "Granville Arts Center, Downtown Garland, Firewheel Town Center, Lake Ray Hubbard, Atrium at Garland City Hall",
    driveTime: "30 minutes to DFW, 25 minutes to Love Field",
  },
];

export const getCityBySlug = (slug: string): CityData | undefined => {
  return cities.find((c) => c.slug === slug);
};

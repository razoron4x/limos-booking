export const vehicles = [
  {
    id: "h2-hummer-stretch-limo",
    title: "H2 Hummer Limo",
    shortTitle: "H2 Hummer Limo",
    capacity: "14–18 Passengers",
    amenities: [
      "Luxury Seats",
      "Strobe Lighted Ceiling",
      "Optic & LED Lighting",
      "Large Cooler Bins",
      "Full Sized Wet Bar",
      "Surround Sound",
    ],
    faqs: [
      {
        question:
          "How many passengers can the H2 Hummer limo accommodate in Dallas?",
        answer:
          "Our H2 Hummer stretch limo comfortably seats 14–18 passengers, making it one of the most spacious party limos available in the Dallas-Fort Worth area. It's ideal for bachelor parties, prom nights, birthdays, and large group celebrations.",
      },
      {
        question:
          "Does the Hummer limo come with a bar and entertainment system?",
        answer:
          "Yes. The H2 Hummer limo features a full-sized wet bar, large cooler bins, strobe lighted ceiling, optic and LED lighting, and a premium surround sound system. Everything you need for an unforgettable night out in Dallas.",
      },
      {
        question:
          "Can I rent the Hummer limo for a Dallas Cowboys game or concert?",
        answer:
          "Absolutely. The Hummer limo is a popular choice for Dallas Cowboys game days at AT&T Stadium, concerts at American Airlines Center, and other major DFW events. We recommend booking at least 2 weeks in advance during football season.",
      },
      {
        question: "Can I book a one-way Hummer limo ride on the weekend?",
        answer:
          "No. On weekends, the H2 Hummer limo is only available for hourly rentals. If you need a one-way transfer on a Saturday or Sunday, we'd be happy to recommend our Mercedes Sprinter Van or Lincoln Navigator SUV, which do offer one-way weekend service.",
      },
      {
        question: "What's included when I rent the Hummer limo?",
        answer:
          "Every Hummer limo rental includes a professional, uniformed chauffeur, ice and bottled water, and all onboard amenities. Fuel, gratuity, and any tolls are handled separately. Your booking agent will provide a transparent all-inclusive quote upfront.",
      },
    ],
    desc: "The sheer presence of our Hummer limo commands attention. Its bold and iconic design makes a statement wherever it goes. Perfect for high-energy celebrations.",
    mobileDesc: "Bold & iconic presence. Built for high-energy celebrations.",
    images: [
      "https://vibe.filesafe.space/1792719026995615993/attachments/278d259b-dfca-4ae9-9892-e0235c13b364.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/bdba5859-0876-4bc7-a581-203b8ed8c77c.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/58a625bc-1679-4264-95dd-d33c606a5c8f.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/f58de790-d5ad-4794-8cca-39fcacc242b9.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/bda54c77-aba6-4a4f-8ff8-98e5c33d1775.webp",
    ],
    video: "https://www.youtube.com/embed/8M1uXumxVE0?autoplay=1",
    videoThumbnail: "https://img.youtube.com/vi/8M1uXumxVE0/maxresdefault.jpg",
  },
  {
    id: "mercedes-sprinter-limo",
    title: "Mercedes Sprinter Limo",
    shortTitle: "Mercedes Sprinter Limo",
    capacity: "12–14 Passengers",
    amenities: [
      "Dual Diamond J Seats",
      "2 TV Monitors",
      "Steel Mirrored Ceiling",
      "RGB Lighted Floor",
      "Custom Built Bar Cooler",
      "Fiber Optic Lighting",
      "Theater Surround Sound",
    ],
    faqs: [
      {
        question:
          "How many people fit in the Mercedes Sprinter Limo in Dallas?",
        answer:
          "Our Mercedes Sprinter Limo accommodates 12–14 passengers, making it the perfect luxury group transportation option in Dallas for weddings, corporate outings, wine tours, and family celebrations.",
      },
      {
        question: "What amenities are included in the Sprinter Limo?",
        answer:
          "The Sprinter Limo features dual diamond J seats, two TV monitors, a steel mirrored ceiling, RGB lighted floor, custom built bar cooler, fiber optic lighting, and theater surround sound for a first-class group travel experience.",
      },
      {
        question:
          "Is the Mercedes Sprinter Limo good for Dallas airport group transfers?",
        answer:
          "Yes. With seating for up to 14 passengers and ample space for luggage, the Sprinter Limo is an excellent choice for group airport transfers to DFW International, Dallas Love Field, and Addison Airport.",
      },
      {
        question: "Can I book a one-way Sprinter Limo ride on the weekend?",
        answer:
          "Yes. Unlike our stretch limos, the Mercedes Sprinter Limo is available for one-way transfers on weekends. This makes it a flexible option for Saturday and Sunday airport runs, point-to-point transfers, and group drop-offs across the DFW metroplex.",
      },
      {
        question: "How do I get a quote for the Sprinter Limo?",
        answer:
          "Simply click 'Get Quote' on this page or call 972-608-3680. Our team will ask about your pickup location, drop-off, date, passenger count, and any special requests, then provide a transparent, all-inclusive price with no hidden fees.",
      },
    ],
    desc: "Experience the ultimate 12-14 passenger Mercedes Sprinter Limo in Dallas. Step into a custom-designed interior where plush leather seating and ambient lighting create an environment that transcends traditional group travel.",
    mobileDesc:
      "Plush leather seating & ambient lighting for luxury group travel.",
    images: [
      "https://vibe.filesafe.space/1792719026995615993/attachments/9ff34acc-63df-453e-b227-96dbd4a60267.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/f68e4eb6-cda5-4405-adc7-bf31dfa65f22.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/8d411452-3ffb-48b0-bd27-2ae53f24679d.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/e32b67bf-38a0-495c-8e83-58d74360f910.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/fed850b2-6f8a-4ec8-8842-a09b7dcb29b7.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/1408b09c-2f1b-4d54-87fc-31e2589bafe5.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/82a90cae-e6d8-4cd4-9e16-24d0f3a5e4f6.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/de2d9d48-4e0c-426f-adb0-45ec7da8f173.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/a88a7a57-7f70-4866-b92a-33e0cae981fd.webp",
    ],
    video: "https://www.youtube.com/embed/IAGduhALk5A?autoplay=1",
    videoThumbnail: "https://img.youtube.com/vi/IAGduhALk5A/maxresdefault.jpg",
  },
  {
    id: "luxury-black-stretch-limo",
    title: "Luxury Black Stretch Limo",
    shortTitle: "Chrysler 300 Stretch Limo",
    capacity: "8–10 Passengers",
    amenities: [
      "J-Seating Leather Seats",
      "Large Cooler Bins",
      "Strobe Lighted Ceiling",
      "Full Sized Wet Bar",
      "Optic & LED Lighting",
      "Surround Sound",
    ],
    faqs: [
      {
        question:
          "Is the Chrysler 300 stretch limo available for Dallas weddings?",
        answer:
          "Yes. The Chrysler 300 stretch limo is one of our most popular wedding limousines in Dallas-Fort Worth. Its sleek black exterior and elegant J-seating leather interior make it perfect for brides, grooms, and wedding parties.",
      },
      {
        question: "How many passengers can the Chrysler 300 stretch limo seat?",
        answer:
          "The Chrysler 300 stretch limo comfortably seats 8–10 passengers, making it ideal for intimate weddings, prom nights, anniversaries, and milestone celebrations in the DFW metroplex.",
      },
      {
        question: "Does the stretch limo include a bar and lighting features?",
        answer:
          "Yes. The Chrysler 300 limo comes equipped with a full-sized wet bar, large cooler bins, strobe lighted ceiling, optic and LED lighting, and surround sound to enhance your luxury transportation experience.",
      },
      {
        question: "Can I book a one-way stretch limo ride on the weekend?",
        answer:
          "No. On weekends, the Chrysler 300 stretch limo is only available for hourly rentals. For one-way weekend transfers, we recommend our Mercedes Sprinter Van or Lincoln Navigator SUV, both of which offer one-way service on Saturdays and Sundays.",
      },
      {
        question: "Do you provide a red carpet service for weddings?",
        answer:
          "Yes. We offer complimentary red carpet service for wedding bookings with the Chrysler 300 stretch limo. Just let your booking agent know when you reserve, and your chauffeur will have everything set up for your grand entrance.",
      },
    ],
    desc: "A seamless fusion of custom interior styling and classic sophistication. Perfect for weddings, corporate galas, and milestone events.",
    mobileDesc: "Classic sophistication for weddings, galas, and VIP events.",
    images: [
      "https://vibe.filesafe.space/1792719026995615993/attachments/e7319457-c2da-4518-8f5e-f950a8b734ce.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/dab4941e-6dce-4ba2-a571-f2de740dfce0.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/74d38f93-6631-485a-8fd2-95552893cbd7.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/0a1e3af7-ea2a-426f-8277-c3a3b19ad926.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/c298c183-62cb-4bb5-ade1-e396929b078b.webp",
    ],
  },
  {
    id: "mercedes-sprinter-executive",
    title: "Mercedes Sprinter Executive",
    shortTitle: "Mercedes Sprinter Executive",
    capacity: "8 Passengers",
    amenities: [
      "360° Swivel & Reclining Leather Seating",
      "110V & USB Power Plugs",
      "Wood Tables & Suede Hardwood Flooring",
      "LED HDTV",
      "1000 Watt Surround Sound",
      "High Performance Climate Controls",
    ],
    faqs: [
      {
        question:
          "What makes the Mercedes Sprinter Executive ideal for corporate travel in Dallas?",
        answer:
          "The Sprinter Executive is designed for business professionals who need to work on the go. With 360° swivel leather seating, wood tables, 110V and USB power outlets, and an LED HDTV, it's the ultimate mobile boardroom for Dallas corporate transportation.",
      },
      {
        question: "How many passengers can the Sprinter Executive accommodate?",
        answer:
          "The Mercedes Sprinter Executive seats up to 8 passengers in premium comfort, making it perfect for executive team transport, corporate roadshows, and VIP client transfers across the Dallas-Fort Worth metroplex.",
      },
      {
        question:
          "Does the Sprinter Executive have power outlets for laptops and devices?",
        answer:
          "Yes. The vehicle is equipped with 110V power plugs and USB charging ports at every seat, so your team can stay productive and connected throughout the journey.",
      },
      {
        question:
          "Can I book a one-way Sprinter Executive ride on the weekend?",
        answer:
          "Yes. The Mercedes Sprinter Executive is available for one-way transfers on weekends, making it a flexible choice for Saturday and Sunday executive travel, airport runs, and point-to-point transfers in Dallas-Fort Worth.",
      },
      {
        question:
          "Can the Sprinter Executive be used for multi-stop corporate roadshows?",
        answer:
          "Absolutely. The Sprinter Executive is ideal for multi-stop corporate roadshows and investor tours. Your booking agent can map out an efficient itinerary with multiple stops, and your chauffeur will handle all logistics so your team can focus on business.",
      },
    ],
    desc: "Tailored specifically for discerning corporate individuals whose journeys are centered around business excellence, comfort, and mobile productivity.",
    mobileDesc: "Mobile boardroom comfort tailored for corporate productivity.",
    images: [
      "https://vibe.filesafe.space/1792719026995615993/assets/25f03de9-1d02-47a2-92b9-29dfa0370fe6.png",
      "https://vibe.filesafe.space/1792719026995615993/attachments/46b4d1e2-f426-4b7f-b076-b229e1b10b62.jpg",
      "https://vibe.filesafe.space/1792719026995615993/attachments/b80a4cad-aa02-4b24-8620-4c8d98cd44d1.jpg",
      "https://vibe.filesafe.space/1792719026995615993/attachments/ce2411e4-b455-40a4-b3c0-c94ae338f4d6.jpg",
      "https://vibe.filesafe.space/1792719026995615993/attachments/d880831d-4ade-4d91-86ec-4f304f31da6c.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/a04a0a7f-5f58-44c8-9583-92e7c939a655.webp",
    ],
  },
  {
    id: "lincoln-navigator-suv",
    title: "Lincoln Navigator SUV",
    shortTitle: "Luxury SUVs",
    capacity: "Up to 6–8 Passengers",
    amenities: [
      "Elite Luxury Leather Seating",
      "Extra Spacious Legroom & Cargo Space",
      "Premium Climate Control",
    ],
    faqs: [
      {
        question:
          "Is the Lincoln Navigator SUV good for Dallas airport transfers?",
        answer:
          "Yes. The Lincoln Navigator SUV is our top choice for discreet DFW airport transfers. With premium climate control, extra spacious legroom, and ample cargo space, it offers significantly more comfort than a standard sedan.",
      },
      {
        question: "How many passengers can the Lincoln Navigator SUV seat?",
        answer:
          "The Lincoln Navigator SUV comfortably seats 6–8 passengers, making it ideal for VIP clients, executive travel, small group transfers, and family airport runs in the Dallas-Fort Worth area.",
      },
      {
        question: "Is the luxury SUV discreet for high-profile clients?",
        answer:
          "Absolutely. The Lincoln Navigator provides a discreet, climate-controlled environment with tinted privacy glass, making it the preferred choice for executives, celebrities, and VIP clients who value privacy and comfort.",
      },
      {
        question: "Can I book a one-way SUV ride on the weekend?",
        answer:
          "Yes. The Lincoln Navigator SUV is available for one-way transfers on weekends, making it a convenient option for Saturday and Sunday airport pickups, point-to-point travel, and executive transfers throughout the Dallas-Fort Worth area.",
      },
      {
        question: "Is the Lincoln Navigator SUV available for hourly charter?",
        answer:
          "Yes. In addition to one-way transfers, the Lincoln Navigator can be booked by the hour for as-directed service. This is ideal for clients who need a chauffeur on standby for meetings, shopping, or multi-stop itineraries in Dallas.",
      },
    ],
    desc: "Discreet, climate-controlled comfort utilizing brand-new luxury SUVs. Offers significantly more room than a standard sedan for premium airport transfers.",
    mobileDesc: "Discreet, climate-controlled comfort with extra legroom.",
    images: [
      "https://vibe.filesafe.space/1792719026995615993/attachments/fffb1544-09c3-4429-9842-290f8ea2ae8b.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/27acf329-8b3a-41c1-871e-ef4874f9a4b2.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/f1c0a7c7-ce9e-4bd2-a7e0-ab486cf6b158.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/3f10eb07-943c-45a3-ad11-3db7bf49f612.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/64082cf3-26cd-40b5-bb00-3625fa6408b3.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/f02eab3f-0234-4b86-8a74-6bc7b9245837.webp",
    ],
  },
  {
    id: "mercedes-sprinter-van",
    title: "Mercedes Sprinter Van",
    shortTitle: "Mercedes Sprinter Van",
    capacity: "Up to 14 Passengers",
    amenities: [
      "Large Separated Rear Luggage Area",
      "LED Lit Ceiling",
      "1000 Watt Surround Sound",
      "Beverage Cooler Bins",
      "High Performance Climate Controls",
    ],
    faqs: [
      {
        question: "How much luggage can the Mercedes Sprinter Van hold?",
        answer:
          "The Sprinter Van features a large separated rear luggage area, making it the #1 choice for Dallas group travel that requires extensive cargo space. It comfortably handles luggage for up to 14 passengers on airport transfers and long-distance trips.",
      },
      {
        question: "What is the passenger capacity of the Sprinter Van?",
        answer:
          "The Mercedes Sprinter Van seats up to 14 passengers, offering a spacious and comfortable ride for corporate groups, family vacations, and leisure travel throughout the Dallas-Fort Worth metroplex.",
      },
      {
        question:
          "Is the Sprinter Van good for corporate shuttle services in Dallas?",
        answer:
          "Yes. With high-performance climate controls, LED lit ceiling, surround sound, and beverage cooler bins, the Sprinter Van is perfect for corporate shuttles, team transport, and group outings in DFW.",
      },
      {
        question: "Can I book a one-way Sprinter Van ride on the weekend?",
        answer:
          "Yes. The Mercedes Sprinter Van is available for one-way transfers on weekends, making it a flexible and cost-effective option for Saturday and Sunday airport runs, group drop-offs, and point-to-point travel across the Dallas-Fort Worth metroplex.",
      },
      {
        question:
          "Can the Sprinter Van handle long-distance trips outside Dallas?",
        answer:
          "Absolutely. The Sprinter Van is well-suited for long-distance travel to destinations like Austin, Houston, San Antonio, and Waco. With its spacious interior, climate control, and large luggage area, it keeps up to 14 passengers comfortable for extended journeys.",
      },
    ],
    desc: "The #1 choice for corporate or leisure travel groups requiring extensive luggage space without sacrificing a spacious, hassle-free ride.",
    mobileDesc:
      "Spacious group transport with large separated rear luggage area.",
    images: [
      "https://vibe.filesafe.space/1792719026995615993/attachments/9ff34acc-63df-453e-b227-96dbd4a60267.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/f68e4eb6-cda5-4405-adc7-bf31dfa65f22.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/8d411452-3ffb-48b0-bd27-2ae53f24679d.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/e32b67bf-38a0-495c-8e83-58d74360f910.webp",
      "https://vibe.filesafe.space/1792719026995615993/attachments/4dbe8203-52f7-4ae4-90e9-848c7ef7ca22.webp",
    ],
  },
];

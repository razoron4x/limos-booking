export type { ServicePageConfig } from "./shared";

import { airport, events, group, sportingConcerts } from "./configsA";
import { birthday, cityTours, holidayLights, pointToPoint } from "./configsB";
import { vip, shuttle, medical, funeral } from "./configsC";
import { wedding, wineTours } from "./configsD";

export const serviceConfigs = {
  airport,
  events,
  group,
  sportingConcerts,
  birthday,
  cityTours,
  holidayLights,
  pointToPoint,
  vip,
  shuttle,
  medical,
  funeral,
  wedding,
  wineTours,
};

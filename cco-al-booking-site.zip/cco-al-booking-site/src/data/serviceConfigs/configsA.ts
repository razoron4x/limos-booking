import {
  Plane,
  Shield,
  Clock,
  Sparkles,
  Music,
  Users,
  Star,
  Ticket,
} from "lucide-react";
import type { ServicePageConfig } from "./shared";
import { img } from "./shared";

export const airport: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Airport Testimonial",
    testimonialImage: img.airport,
    testimonialAlt:
      "Luxury airport transfer at DFW International with meet and greet",
    testimonialQuote:
      "Betty met me at the airport today and what a genuinely wonderful experience. Car was immaculate and the driver was fantastic.",
    testimonialAuthor: "Betty Becker, DFW Airport Transfer",
    safetyLabel: "Flight Tracking",
    safetyTitle: "On-time, every flight.",
    safetyText:
      "Real-time flight monitoring across all DFW airports. Your chauffeur is ready when you land.",
    safetyImage: img.sprinter,
    safetyAlt: "Mercedes Sprinter staged at an FBO for private aviation",
    secondaryImage: img.airportSecondary,
    secondaryAlt:
      "Chauffeur loading luggage into a luxury SUV at the airport curb",
  },
  trustStats: [
    { value: "24/7", label: "Flight Monitoring" },
    { value: "3", label: "DFW Area Airports" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to Land in Dallas",
    subtitle:
      "Curbside pickup, luggage assist, and zero waiting. Your chauffeur is already there.",
    ctaLink: "/quote?service=Airport%20Transfer",
    ctaBadge: "Airport",
    ctaBadgeIcon: Plane,
    ctaHeading: "Meet & Greet at the Gate",
    ctaText:
      "Your chauffeur meets you at baggage claim with a customized sign, assists with luggage, and handles curbside pickup at every DFW terminal.",
    ctaImage: img.airport,
    ctaImageAlt: "Luxury airport transfer meet and greet at DFW",
    box2: {
      icon: Clock,
      title: "Real-Time Flight Tracking",
      text: "We monitor every flight and adjust for delays or early arrivals so your chauffeur is always on time.",
    },
    box3: {
      icon: Shield,
      title: "Private Aviation (FBO) Staging",
      text: "Exclusive tarmac access and discreet staging for private jet arrivals and departures.",
    },
  },
  explore: {
    card1: {
      link: "/service-private-car",
      image: img.events,
      alt: "Private car service for executive travel in Dallas",
      badge: "Most Booked",
      title: "Private Car Service",
    },
    card2: {
      link: "/corporate",
      image: img.vip,
      alt: "Corporate executive transportation in Dallas",
      badge: "For Business",
      title: "Corporate Accounts",
    },
    card3: {
      link: "/service-point-to-point",
      image: img.p2p,
      alt: "Point to point luxury transfer in Dallas",
      badge: "Direct Transfers",
      title: "Point to Point",
    },
  },
};

export const events: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Events Testimonial",
    testimonialImage: img.events,
    testimonialAlt: "Luxury limousine arriving for a special event in Dallas",
    testimonialQuote:
      "The customer service was amazing, from the first phone call to the final drop-off, you were treated like your reservation was the most important thing.",
    testimonialAuthor: "Alli Enzo, Special Event",
    safetyLabel: "Event Coordination",
    safetyTitle: "Flawless event logistics.",
    safetyText:
      "We handle timing, routes, and multiple stops so you celebrate stress-free from start to finish.",
    safetyImage: img.commitment,
    safetyAlt: "Elegant event limousine service coordination",
    secondaryImage: img.eventsSecondary,
    secondaryAlt: "Guests arriving on the red carpet at a nighttime gala",
  },
  trustStats: [
    { value: "100%", label: "Vetted Chauffeurs" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "18", label: "Passengers Per Vehicle" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to Make an Entrance",
    subtitle: "Red-carpet treatment for every celebration, start to finish.",
    ctaLink: "/quote?service=Special%20Events",
    ctaBadge: "Special Events",
    ctaBadgeIcon: Sparkles,
    ctaHeading: "Red Carpet Treatment",
    ctaText:
      "VIP treatment from start to finish with immaculate vehicles, attentive uniformed chauffeurs, and a grand entrance at every venue.",
    ctaImage: img.events,
    ctaImageAlt: "Luxury limousine red carpet arrival at a special event",
    box2: {
      icon: Music,
      title: "Premium Entertainment",
      text: "State-of-the-art surround sound, dynamic LED lighting, and customized interiors keep the party moving.",
    },
    box3: {
      icon: Shield,
      title: "Luxury Amenities",
      text: "Built-in wet bars, cooler bins, and plush leather seating designed for group comfort and celebration.",
    },
  },
  explore: {
    card1: {
      link: "/service-wedding",
      image: img.wedding,
      alt: "Wedding limousine service in Dallas",
      badge: "Most Booked",
      title: "Wedding Chauffeur",
    },
    card2: {
      link: "/service-birthday",
      image: img.birthday,
      alt: "Birthday party limo celebration",
      badge: "For Celebrations",
      title: "Birthday Parties",
    },
    card3: {
      link: "/service-sporting-concerts",
      image: img.concert,
      alt: "Concert and sporting event limo transportation",
      badge: "For Fans",
      title: "Concerts & Sporting Events",
    },
  },
};

export const group: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Group Testimonial",
    testimonialImage: img.group,
    testimonialAlt: "Group of friends arriving in a stretch limo in Dallas",
    testimonialQuote:
      "I have used Addison Limos twice to transport customers to and from business dinners. The Mercedes Sprinters were spotless and perfect for our groups.",
    testimonialAuthor: "Amy O'Malley, Group Outing",
    safetyLabel: "Group Logistics",
    safetyTitle: "Everyone arrives together.",
    safetyText:
      "We coordinate multiple pickups and routes seamlessly for groups of any size.",
    safetyImage: img.sprinter,
    safetyAlt: "Mercedes Sprinter van for large group transportation",
    secondaryImage: img.groupSecondary,
    secondaryAlt: "Group of friends boarding a luxury Sprinter van",
  },
  trustStats: [
    { value: "18", label: "Passengers Per Vehicle" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "100%", label: "Vetted Chauffeurs" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to Travel Together",
    subtitle:
      "Spacious, comfortable vehicles that keep your whole group together in luxury.",
    ctaLink: "/quote?service=Group%20Transportation",
    ctaBadge: "Group Travel",
    ctaBadgeIcon: Users,
    ctaHeading: "Spacious Accommodations",
    ctaText:
      "Ample seating and luggage space for groups of any size without compromising on luxury. Everyone rides together, every time.",
    ctaImage: img.group,
    ctaImageAlt: "Group transportation in a luxury stretch limo",
    box2: {
      icon: Star,
      title: "Premium Amenities",
      text: "Climate control, premium sound systems, and comfortable seating throughout your entire journey.",
    },
    box3: {
      icon: Shield,
      title: "Coordinated Logistics",
      text: "We manage the timing, routes, and multiple pick-up and drop-off locations seamlessly so you relax.",
    },
  },
  explore: {
    card1: {
      link: "/service-football",
      image: img.football,
      alt: "Football game day group transportation",
      badge: "Most Booked",
      title: "Football Game Day",
    },
    card2: {
      link: "/service-shuttle",
      image: img.shuttle,
      alt: "Shuttle service for groups and events",
      badge: "Recurring",
      title: "Shuttle Service",
    },
    card3: {
      link: "/service-sporting-concerts",
      image: img.concert,
      alt: "Concert and sporting event group transportation",
      badge: "For Fans",
      title: "Concerts & Sporting Events",
    },
  },
};

export const sportingConcerts: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Event Testimonial",
    testimonialImage: img.concert,
    testimonialAlt: "Friends heading to a concert in a Mercedes Sprinter limo",
    testimonialQuote:
      "Great experience! Driver was on time and sprinter limo was great! Clean and just as promised. Driver was very friendly and accommodating.",
    testimonialAuthor: "Chris Randall, Concert Night",
    safetyLabel: "Event Safety",
    safetyTitle: "Skip the parking, arrive VIP.",
    safetyText:
      "Direct venue drop-off and a guaranteed safe ride home after every show.",
    safetyImage: img.sprinter,
    safetyAlt: "Mercedes Sprinter limo for concert transportation",
    secondaryImage: img.concertSecondary,
    secondaryAlt:
      "Fans in jerseys exiting a stretch limo outside a stadium at night",
  },
  trustStats: [
    { value: "24/7", label: "Event Availability" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "18", label: "Passengers Per Vehicle" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to Arrive at the Show",
    subtitle: "VIP drop-off, no parking fees, no post-event gridlock.",
    ctaLink: "/quote?service=Sporting%20Events%20%26%20Concerts",
    ctaBadge: "Game & Show Day",
    ctaBadgeIcon: Ticket,
    ctaHeading: "VIP Venue Drop-Off",
    ctaText:
      "Direct access to the closest entrances. No long walks, no parking fees, no post-event gridlock. Just step out and enjoy.",
    ctaImage: img.concert,
    ctaImageAlt: "VIP concert and sporting event limo drop-off",
    box2: {
      icon: Music,
      title: "Party Onboard",
      text: "Surround sound, LED lighting, wet bars, and cooler bins keep the energy going before you even reach the gate.",
    },
    box3: {
      icon: Shield,
      title: "Safe Ride Home",
      text: "Celebrate responsibly with a guaranteed safe ride home. No surge pricing, no rideshare lines, no stress.",
    },
  },
  explore: {
    card1: {
      link: "/service-football",
      image: img.football,
      alt: "Football game day transportation",
      badge: "Most Booked",
      title: "Football Game Day",
    },
    card2: {
      link: "/service-group",
      image: img.group,
      alt: "Group nights out transportation",
      badge: "For Groups",
      title: "Group Nights Out",
    },
    card3: {
      link: "/service-birthday",
      image: img.birthday,
      alt: "Birthday party limo celebration",
      badge: "For Celebrations",
      title: "Birthday Parties",
    },
  },
};

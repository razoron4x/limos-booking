import { Heart, Wine, Camera, Clock, Shield } from "lucide-react";
import type { ServicePageConfig } from "./shared";
import { img } from "./shared";

export const wedding: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Wedding Testimonial",
    testimonialImage: img.wedding,
    testimonialAlt: "Wedding chauffeur luxury limo in Dallas",
    testimonialQuote:
      "We have used this company for many years and they will continue to be our go to car service. Kind, helpful and aim to please.",
    testimonialAuthor: "Kelli Watkins, Wedding Day",
    safetyLabel: "Wedding Coordination",
    safetyTitle: "Flawless timing for your perfect day.",
    safetyText:
      "Elegant limousines and seamless coordination for your Dallas wedding, start to finish.",
    safetyImage: img.commitment,
    safetyAlt: "Elegant wedding limousine service coordination",
    secondaryImage: img.weddingSecondary,
    secondaryAlt: "Bride and groom walking toward a white luxury limousine",
  },
  trustStats: [
    { value: "100%", label: "Vetted Chauffeurs" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "18", label: "Passengers Per Vehicle" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to Arrive on Your Wedding Day",
    subtitle:
      "Elegant limousines, professional chauffeurs, and flawless coordination for your Dallas wedding.",
    ctaLink: "/quote?service=Wedding%20Chauffeur",
    ctaBadge: "Wedding Day",
    ctaBadgeIcon: Heart,
    ctaHeading: "Elegant Wedding Transportation",
    ctaText:
      "Make your special day unforgettable with luxury wedding transportation. Elegant limousines, professional chauffeurs, and flawless coordination from ceremony to reception.",
    ctaImage: img.wedding,
    ctaImageAlt: "Wedding chauffeur luxury limo in Dallas",
    box2: {
      icon: Camera,
      title: "Photo Stops Built In",
      text: "Coordinate scenic photo stops for the wedding party. Your chauffeur knows the most romantic DFW backdrops.",
    },
    box3: {
      icon: Clock,
      title: "Flawless Timing",
      text: "Ceremony, photos, reception, send-off. We coordinate every leg so your timeline stays perfectly on track.",
    },
  },
  explore: {
    card1: {
      link: "/service-events",
      image: img.events,
      alt: "Special events and celebrations transportation",
      badge: "Most Booked",
      title: "Special Events",
    },
    card2: {
      link: "/service-birthday",
      image: img.birthday,
      alt: "Birthday party limo celebration",
      badge: "For Celebrations",
      title: "Birthday Parties",
    },
    card3: {
      link: "/service-wine-tours",
      image: img.wine,
      alt: "Wine tour transportation for couples",
      badge: "For Couples",
      title: "Wine Tours",
    },
  },
};

export const wineTours: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Wine Tour Testimonial",
    testimonialImage: img.wine,
    testimonialAlt: "Wine tour luxury transportation in Texas",
    testimonialQuote:
      "Great experience! Driver was on time and sprinter limo was great! Clean and just as promised. Driver was very friendly and accommodating.",
    testimonialAuthor: "Chris Randall, Wine Tour",
    safetyLabel: "Safe Sipping",
    safetyTitle: "Sip, savor. No driving required.",
    safetyText:
      "Private vineyard tours to Texas Hill Country wineries. Safe, stylish, round-trip from DFW.",
    safetyImage: img.sprinter,
    safetyAlt: "Mercedes Sprinter for wine tour transportation",
    secondaryImage: img.wineSecondary,
    secondaryAlt: "Luxury SUV parked at a scenic Texas hill country vineyard",
  },
  trustStats: [
    { value: "100%", label: "Private Chauffeur" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "18", label: "Passengers Per Vehicle" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to Tour Wine Country",
    subtitle:
      "Private chauffeur-driven vineyard tours with safe, stylish round-trip transportation from DFW.",
    ctaLink: "/quote?service=Wine%20Tours",
    ctaBadge: "Wine Tours",
    ctaBadgeIcon: Wine,
    ctaHeading: "Sip, Savor, Explore",
    ctaText:
      "Sip, savor, and explore Texas wine country in luxury. Private chauffeur-driven vineyard tours with safe, stylish round-trip transportation from Dallas-Fort Worth.",
    ctaImage: img.wine,
    ctaImageAlt: "Wine tour luxury transportation in Texas",
    box2: {
      icon: Shield,
      title: "Safe Round-Trip",
      text: "Enjoy every tasting without a designated driver. We handle the roads so you can enjoy the wine, safely.",
    },
    box3: {
      icon: Camera,
      title: "Custom Itineraries",
      text: "Texas Hill Country wineries, your choice. We build the route around your favorite vineyards and tasting rooms.",
    },
  },
  explore: {
    card1: {
      link: "/service-city-tours",
      image: img.cityTours,
      alt: "Dallas city tour luxury transportation",
      badge: "Most Booked",
      title: "City Tours",
    },
    card2: {
      link: "/service-group",
      image: img.group,
      alt: "Group transportation for wine tours",
      badge: "For Groups",
      title: "Group Tours",
    },
    card3: {
      link: "/service-events",
      image: img.events,
      alt: "Special events transportation",
      badge: "For Celebrations",
      title: "Special Events",
    },
  },
};

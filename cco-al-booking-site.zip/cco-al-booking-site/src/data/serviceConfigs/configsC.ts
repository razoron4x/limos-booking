import {
  Crown,
  Bus,
  HeartPulse,
  Heart,
  Shield,
  Clock,
  Users,
} from "lucide-react";
import type { ServicePageConfig } from "./shared";
import { img } from "./shared";

export const vip: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "VIP Testimonial",
    testimonialImage: img.vip,
    testimonialAlt: "VIP executive transportation in Dallas",
    testimonialQuote:
      "I have used Addison Limos twice now to transport customers to and from business dinners. Both times the experience could not have been better.",
    testimonialAuthor: "Amy O'Malley, Executive Client",
    safetyLabel: "Executive Security",
    safetyTitle: "Discreet, high-security transport.",
    safetyText:
      "Privacy partitions and executive protection chauffeurs for absolute discretion.",
    safetyImage: img.chauffeur,
    safetyAlt: "Executive protection chauffeur for VIP transport",
    secondaryImage: img.vipSecondary,
    secondaryAlt:
      "Executive stepping out of a luxury SUV outside an office tower",
  },
  trustStats: [
    { value: "100%", label: "Discreet Service" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "24/7", label: "Availability" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to Travel in Confidence",
    subtitle:
      "Discreet, high-security transportation for executives, celebrities, and dignitaries.",
    ctaLink: "/quote?service=VIP%20Service",
    ctaBadge: "VIP & Executive",
    ctaBadgeIcon: Crown,
    ctaHeading: "Absolute Discretion",
    ctaText:
      "Privacy partitions, specially trained executive protection chauffeurs, and absolute discretion for every journey. Your privacy is our priority.",
    ctaImage: img.vip,
    ctaImageAlt: "VIP executive transportation with privacy",
    box2: {
      icon: Shield,
      title: "Trained Protection Chauffeurs",
      text: "Specially trained executive protection drivers who prioritize your security, privacy, and comfort above all.",
    },
    box3: {
      icon: Clock,
      title: "On-Call, Anytime",
      text: "24/7 availability for last-minute changes, extended waits, and multi-leg itineraries. We adapt to your schedule.",
    },
  },
  explore: {
    card1: {
      link: "/corporate",
      image: img.events,
      alt: "Corporate executive transportation",
      badge: "Most Booked",
      title: "Corporate Accounts",
    },
    card2: {
      link: "/service-airport",
      image: img.airport,
      alt: "Airport transfer service for executives",
      badge: "For Travel",
      title: "Airport Transfers",
    },
    card3: {
      link: "/service-point-to-point",
      image: img.p2p,
      alt: "Point to point executive transfer",
      badge: "Direct Transfers",
      title: "Point to Point",
    },
  },
};

export const shuttle: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Shuttle Testimonial",
    testimonialImage: img.shuttle,
    testimonialAlt: "Shuttle service transportation for groups",
    testimonialQuote:
      "The Mercedes Sprinters were spotless and perfect for our groups. Both times the experience could not have been better!",
    testimonialAuthor: "Amy O'Malley, Corporate Shuttle",
    safetyLabel: "Reliable Scheduling",
    safetyTitle: "Dependable group transit, every time.",
    safetyText:
      "Recurring or one-time shuttle solutions for employees, guests, and attendees.",
    safetyImage: img.sprinter,
    safetyAlt: "Mercedes Sprinter shuttle for employee transport",
    secondaryImage: img.shuttleSecondary,
    secondaryAlt:
      "Employees boarding a luxury Sprinter shuttle van outside an office",
  },
  trustStats: [
    { value: "100%", label: "On-Time Record" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "18", label: "Passengers Per Vehicle" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to Move Your People",
    subtitle:
      "Reliable, recurring or one-time shuttle solutions for employees, guests, and attendees.",
    ctaLink: "/quote?service=Shuttle",
    ctaBadge: "Shuttle Service",
    ctaBadgeIcon: Bus,
    ctaHeading: "Dependable Group Transit",
    ctaText:
      "Reliable shuttle solutions for employee commutes, hotel guests, convention attendees, or campus transportation. We run on your schedule.",
    ctaImage: img.shuttle,
    ctaImageAlt: "Shuttle service transportation for groups",
    box2: {
      icon: Clock,
      title: "Recurring Schedules",
      text: "Daily, weekly, or event-based routes. We manage the schedule so your people always have a ride.",
    },
    box3: {
      icon: Shield,
      title: "Coordinated Logistics",
      text: "Multiple stops, multiple vehicles, multiple shifts. We handle the routing so you don't have to.",
    },
  },
  explore: {
    card1: {
      link: "/corporate",
      image: img.events,
      alt: "Corporate transportation accounts",
      badge: "Most Booked",
      title: "Corporate Accounts",
    },
    card2: {
      link: "/service-group",
      image: img.group,
      alt: "Group transportation services",
      badge: "For Groups",
      title: "Group Transportation",
    },
    card3: {
      link: "/service-airport",
      image: img.airport,
      alt: "Airport shuttle service",
      badge: "For Travel",
      title: "Airport Transfers",
    },
  },
};

export const medical: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Medical Testimonial",
    testimonialImage: img.medical,
    testimonialAlt: "Medical transport service in Dallas",
    testimonialQuote:
      "Denis was very professional and a great driver. The vehicle was very clean and roomy. They are very easy to work with.",
    testimonialAuthor: "Judy Viegas, Medical Transport",
    safetyLabel: "Time-Critical Care",
    safetyTitle: "Discreet, reliable, on time.",
    safetyText:
      "Time-critical transportation for patients and medical professionals handled with care.",
    safetyImage:
      "https://vibe.filesafe.space/1792719026995615993/assets/52920900-aaff-43aa-bce9-12d2e736a0f9.png",
    safetyAlt: "Luxury sedan at hospital patient drop-off entrance",
    secondaryImage: img.medicalSecondary,
    secondaryAlt: "Private luxury car parked at a hospital entrance",
  },
  trustStats: [
    { value: "24/7", label: "On-Call Availability" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "100%", label: "Discreet Service" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to Transport With Care",
    subtitle:
      "Discreet, time-critical, and comfortable transportation for patients and medical professionals.",
    ctaLink: "/quote?service=Medical%20Transport",
    ctaBadge: "Medical Transport",
    ctaBadgeIcon: HeartPulse,
    ctaHeading: "Critical Care in Motion",
    ctaText:
      "Discreet, time-critical, and comfortable transportation for patients, medical professionals, and organ donor transfers. Every detail handled with care.",
    ctaImage: img.medical,
    ctaImageAlt: "Medical transport service in Dallas",
    box2: {
      icon: Clock,
      title: "Time-Critical Reliability",
      text: "When minutes matter, we deliver. On-time, every time, with real-time coordination for critical transfers.",
    },
    box3: {
      icon: Shield,
      title: "Comfort & Dignity",
      text: "Clean, comfortable vehicles and compassionate chauffeurs who treat every patient with respect and care.",
    },
  },
  explore: {
    card1: {
      link: "/service-airport",
      image: img.airport,
      alt: "Airport transfer service",
      badge: "Most Booked",
      title: "Airport Transfers",
    },
    card2: {
      link: "/service-point-to-point",
      image: img.p2p,
      alt: "Point to point transfer service",
      badge: "Direct Transfers",
      title: "Point to Point",
    },
    card3: {
      link: "/service-shuttle",
      image: img.shuttle,
      alt: "Shuttle service for recurring transport",
      badge: "Recurring",
      title: "Shuttle Service",
    },
  },
};

export const funeral: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Family Testimonial",
    testimonialImage: img.funeral,
    testimonialAlt: "Dignified funeral transportation service",
    testimonialQuote:
      "The communication is wonderful, pricing is competitive, car was immaculate and the drivers are fantastic. What a genuinely wonderful experience.",
    testimonialAuthor: "Betty Becker, Family Service",
    safetyLabel: "Dignified Service",
    safetyTitle: "Respectful transit when it matters most.",
    safetyText:
      "Elegant stretch limousine and family transport offering peace of mind during difficult times.",
    safetyImage:
      "https://vibe.filesafe.space/1792719026995615993/assets/a70ef63e-019c-4734-9a6d-7b4eae2d8528.png",
    safetyAlt:
      "Dignified black stretch limousine parked outside a quiet chapel",
    secondaryImage: img.funeralSecondary,
    secondaryAlt: "Dignified stretch limousine parked outside a quiet chapel",
  },
  trustStats: [
    { value: "100%", label: "Compassionate Care" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "24/7", label: "Availability" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to Honor the Moment",
    subtitle:
      "Respectful, elegant, and reliable transportation for funerals and family services.",
    ctaLink: "/quote?service=Funeral",
    ctaBadge: "Funeral Service",
    ctaBadgeIcon: Heart,
    ctaHeading: "Dignified & Respectful Transit",
    ctaText:
      "Respectful, elegant, and reliable transportation services for funerals, including stretch limousine and family transport. We offer peace of mind during difficult times.",
    ctaImage: img.funeral,
    ctaImageAlt: "Dignified funeral transportation service",
    box2: {
      icon: Shield,
      title: "Compassionate Chauffeurs",
      text: "Discreet, professional chauffeurs who understand the sensitivity of the occasion and handle every detail with care.",
    },
    box3: {
      icon: Users,
      title: "Family Coordination",
      text: "Coordinated family transport so everyone arrives together, on time, with one less thing to worry about.",
    },
  },
  explore: {
    card1: {
      link: "/service-group",
      image: img.group,
      alt: "Group family transportation",
      badge: "For Families",
      title: "Group Transportation",
    },
    card2: {
      link: "/service-point-to-point",
      image: img.p2p,
      alt: "Point to point transfer service",
      badge: "Direct Transfers",
      title: "Point to Point",
    },
    card3: {
      link: "/service-shuttle",
      image: img.shuttle,
      alt: "Shuttle service for family transport",
      badge: "For Groups",
      title: "Shuttle Service",
    },
  },
};

import {
  Gift,
  Music,
  Shield,
  Map,
  Camera,
  Lightbulb,
  MapPin,
  Clock,
  Star,
} from "lucide-react";
import type { ServicePageConfig } from "./shared";
import { img } from "./shared";

export const birthday: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Birthday Testimonial",
    testimonialImage: img.birthday,
    testimonialAlt: "Friends celebrating a birthday inside a luxury limo",
    testimonialQuote:
      "We have used this company for many years and they will continue to be our go to car service. Mr. Sunny and the staff are kind, helpful and aim to please.",
    testimonialAuthor: "Kelli Watkins, Birthday Night Out",
    safetyLabel: "Celebration Safety",
    safetyTitle: "Make an unforgettable entrance.",
    safetyText:
      "Your celebration starts the moment you board, with a safe ride home guaranteed.",
    safetyImage: img.interior,
    safetyAlt: "Luxury limo interior for birthday celebrations",
    secondaryImage: img.birthdaySecondary,
    secondaryAlt:
      "Friends celebrating a birthday inside a limousine with string lights",
  },
  trustStats: [
    { value: "100%", label: "Vetted Chauffeurs" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "18", label: "Passengers Per Vehicle" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to Celebrate Your Day",
    subtitle: "Turn the journey into the celebration with a party on wheels.",
    ctaLink: "/quote?service=Birthday",
    ctaBadge: "Birthday",
    ctaBadgeIcon: Gift,
    ctaHeading: "Red Carpet Treatment",
    ctaText:
      "Feel like a VIP with professional chauffeurs and pristine luxury vehicles. Your birthday is the one day that's all about you.",
    ctaImage: img.birthday,
    ctaImageAlt: "Birthday limousine celebration with friends",
    box2: {
      icon: Music,
      title: "Party On The Move",
      text: "Keep the celebration going between stops with premium sound systems and mood lighting.",
    },
    box3: {
      icon: Shield,
      title: "Safe Celebrations",
      text: "Enjoy your night to the fullest knowing you have a guaranteed safe ride home, no surge pricing.",
    },
  },
  explore: {
    card1: {
      link: "/service-group",
      image: img.group,
      alt: "Group nights out transportation",
      badge: "Most Booked",
      title: "Group Nights Out",
    },
    card2: {
      link: "/service-events",
      image: img.events,
      alt: "Special events and celebrations transportation",
      badge: "For Celebrations",
      title: "Special Events",
    },
    card3: {
      link: "/service-sporting-concerts",
      image: img.concert,
      alt: "Concert and sporting event transportation",
      badge: "For Fans",
      title: "Concerts & Sporting Events",
    },
  },
};

export const cityTours: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Tour Testimonial",
    testimonialImage: img.cityTours,
    testimonialAlt: "Dallas city tour in a luxury vehicle",
    testimonialQuote:
      "Denis was very professional and a great driver. The vehicle was very clean and roomy. We will definitely use Addison Limo Service again.",
    testimonialAuthor: "Judy Viegas, Dallas City Tour",
    safetyLabel: "Custom Itineraries",
    safetyTitle: "See DFW your way, in comfort.",
    safetyText:
      "Customized routes covering landmarks, culture, and dining with a local expert chauffeur.",
    safetyImage: img.sprinter,
    safetyAlt: "Luxury vehicle for Dallas sightseeing tours",
    secondaryImage: img.cityToursSecondary,
    secondaryAlt:
      "Luxury SUV parked in front of the Dallas downtown skyline at dusk",
  },
  trustStats: [
    { value: "100%", label: "Custom Itineraries" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "18", label: "Passengers Per Vehicle" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to See Dallas-Fort Worth",
    subtitle:
      "Customized itineraries covering landmarks, culture, and dining from the comfort of a luxury vehicle.",
    ctaLink: "/quote?service=City%20Tours",
    ctaBadge: "City Tours",
    ctaBadgeIcon: Map,
    ctaHeading: "Explore DFW in Luxury",
    ctaText:
      "Discover the best of Dallas-Fort Worth from the comfort of a luxury vehicle. Your chauffeur doubles as your local guide.",
    ctaImage: img.cityTours,
    ctaImageAlt: "Dallas city tour luxury transportation",
    box2: {
      icon: Camera,
      title: "Photo Stops Built In",
      text: "Coordinate scenic stops at landmarks and cultural districts. Your chauffeur knows the best backdrops.",
    },
    box3: {
      icon: Shield,
      title: "Door-to-Door Comfort",
      text: "No parking, no navigation, no stress. Just sit back and enjoy the sights in climate-controlled comfort.",
    },
  },
  explore: {
    card1: {
      link: "/service-wine-tours",
      image: img.wine,
      alt: "Wine tour transportation in Texas",
      badge: "Most Booked",
      title: "Wine Tours",
    },
    card2: {
      link: "/service-holiday-lights",
      image: img.holiday,
      alt: "Holiday light tour limo",
      badge: "Seasonal",
      title: "Holiday Light Tours",
    },
    card3: {
      link: "/service-group",
      image: img.group,
      alt: "Group transportation for tours",
      badge: "For Groups",
      title: "Group Tours",
    },
  },
};

export const holidayLights: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Holiday Testimonial",
    testimonialImage: img.holiday,
    testimonialAlt: "Holiday light tour limo in Dallas",
    testimonialQuote:
      "Once again I cannot say enough good things about Addison car and Limo service. The communication is wonderful, pricing is competitive, car was immaculate.",
    testimonialAuthor: "Betty Becker, Holiday Light Tour",
    safetyLabel: "Family Comfort",
    safetyTitle: "Holiday magic from a warm luxury ride.",
    safetyText:
      "Private, chauffeur-driven tours of DFW's most spectacular festive light displays.",
    safetyImage: img.interior,
    safetyAlt: "Warm luxury interior for holiday light tours",
    secondaryImage: img.holidaySecondary,
    secondaryAlt:
      "Luxury SUV touring a neighborhood decorated with holiday lights",
  },
  trustStats: [
    { value: "100%", label: "Private Tours" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "18", label: "Passengers Per Vehicle" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to See the Lights",
    subtitle:
      "Private, chauffeur-driven tours of DFW's most spectacular festive displays.",
    ctaLink: "/quote?service=Holiday%20Light%20Tours",
    ctaBadge: "Holiday Season",
    ctaBadgeIcon: Lightbulb,
    ctaHeading: "A Magical Winter Experience",
    ctaText:
      "Experience the magic of the holiday season with private, chauffeur-driven tours of the most spectacular festive light displays across DFW.",
    ctaImage: img.holiday,
    ctaImageAlt: "Holiday light tour luxury limo in Dallas",
    box2: {
      icon: Camera,
      title: "Best Displays, Planned",
      text: "Your chauffeur knows the most spectacular neighborhoods and park displays across the metroplex.",
    },
    box3: {
      icon: Shield,
      title: "Warm & Cozy",
      text: "Skip the cold and the parking. Enjoy the lights from a climate-controlled luxury vehicle with the whole family.",
    },
  },
  explore: {
    card1: {
      link: "/service-city-tours",
      image: img.cityTours,
      alt: "Dallas city tour luxury transportation",
      badge: "Most Booked",
      title: "City Tours",
    },
    card2: {
      link: "/service-wine-tours",
      image: img.wine,
      alt: "Wine tour transportation in Texas",
      badge: "For Groups",
      title: "Wine Tours",
    },
    card3: {
      link: "/service-group",
      image: img.group,
      alt: "Group transportation for outings",
      badge: "For Families",
      title: "Group Outings",
    },
  },
};

export const pointToPoint: ServicePageConfig = {
  mosaic: {
    testimonialLabel: "Transfer Testimonial",
    testimonialImage: img.p2p,
    testimonialAlt: "Point to point luxury transfer in Dallas",
    testimonialQuote:
      "The customer service was amazing, from the first phone call to the final drop-off, you were treated like your reservation was the most important thing.",
    testimonialAuthor: "Alli Enzo, Point to Point Transfer",
    safetyLabel: "Guaranteed Punctuality",
    safetyTitle: "A to B. Flat rates. No detours.",
    safetyText:
      "Direct luxury travel with transparent flat rates and guaranteed punctuality.",
    safetyImage:
      "https://vibe.filesafe.space/1792719026995615993/assets/8f911e19-5a5c-4409-ad0a-35448d0b973e.png",
    safetyAlt:
      "Black luxury sedan arriving at a downtown Dallas building at dusk",
    secondaryImage: img.p2pSecondary,
    secondaryAlt:
      "Luxury sedan driving on the highway at dusk for a direct transfer",
  },
  trustStats: [
    { value: "100%", label: "Flat-Rate Pricing" },
    { value: "20+", label: "Years Serving DFW" },
    { value: "24/7", label: "Availability" },
    { value: "4.8★", label: "Average Rating" },
  ],
  whyChoose: {
    title: "The Only Way to Get From A to B",
    subtitle:
      "Direct, uninterrupted luxury travel with transparent flat-rate pricing.",
    ctaLink: "/quote?service=Point%20to%20Point",
    ctaBadge: "Point to Point",
    ctaBadgeIcon: MapPin,
    ctaHeading: "Direct Luxury Travel",
    ctaText:
      "Direct, uninterrupted luxury travel from your exact location to your destination. No detours, no surprises, pure efficiency.",
    ctaImage: img.p2p,
    ctaImageAlt: "Point to point luxury transfer in Dallas",
    box2: {
      icon: Star,
      title: "Transparent Flat Rates",
      text: "Know your price upfront. No surge pricing, no hidden fees, no meter running. Just a fair flat rate.",
    },
    box3: {
      icon: Clock,
      title: "Guaranteed Punctuality",
      text: "On-time, every time, for any distance. Your chauffeur is tracked and ready the moment you need to leave.",
    },
  },
  explore: {
    card1: {
      link: "/service-airport",
      image: img.airport,
      alt: "Airport transfer service in Dallas",
      badge: "Most Booked",
      title: "Airport Transfers",
    },
    card2: {
      link: "/service-private-car",
      image: img.events,
      alt: "Private car service in Dallas",
      badge: "For Executives",
      title: "Private Car Service",
    },
    card3: {
      link: "/corporate",
      image: img.vip,
      alt: "Corporate executive transportation",
      badge: "For Business",
      title: "Corporate Accounts",
    },
  },
};

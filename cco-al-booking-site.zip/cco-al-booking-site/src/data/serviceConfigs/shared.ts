import type { ServiceMosaicProps } from "@/components/ServiceMosaic";
import type { TrustStat } from "@/components/ServiceTrustStrip";
import type { ServiceWhyChooseProps } from "@/components/ServiceWhyChoose";
import type { ExploreCard } from "@/components/ServiceExploreOptions";

export interface ServicePageConfig {
  mosaic: ServiceMosaicProps;
  trustStats: TrustStat[];
  whyChoose: ServiceWhyChooseProps;
  explore: { card1: ExploreCard; card2: ExploreCard; card3: ExploreCard };
}

const P = "https://vibe.filesafe.space/1792719026995615993";

export const img = {
  group: `${P}/assets/2c5fd576-f767-4941-90ee-4d240434dad2.png`,
  birthday: `${P}/assets/3c5cbb3d-d8df-445f-a0c0-7713c3c213a0.png`,
  football: `${P}/attachments/da8cb189-97a1-4aab-a770-94af37245fd4.jpg`,
  concert: `${P}/assets/ad4c6814-5776-4ceb-81b1-2d9016753c77.png`,
  wedding: `${P}/assets/3d2d2678-57a0-4ca9-a16e-9a934615619f.png`,
  wine: `${P}/assets/8929dfff-0003-4745-8528-a0800c6d65d7.png`,
  cityTours: `${P}/attachments/4ad39678-8683-44f7-9ab5-66a7067e230d.jpg`,
  holiday: `${P}/attachments/98e642a1-d7bd-4b94-9cd9-4fd684dd040c.jpg`,
  events: `${P}/attachments/b08434c1-1042-4d37-a5de-c0a5e538af94.jpg`,
  airport: `${P}/assets/71c83224-f0a0-44be-97f7-9c3d3a0dd5ba.png`,
  vip: `${P}/attachments/0059a0db-3b29-42b5-800e-dc241b882d8e.jpg`,
  shuttle: `${P}/attachments/699b6859-adc5-49d6-83af-860a6b8a3333.jpg`,
  medical: `${P}/assets/65ab1833-b672-4ed9-9ed1-a968c600d229.png`,
  funeral: `${P}/assets/1930cba6-cb5e-440c-b124-fb749abc9d9b.png`,
  p2p: `${P}/attachments/a4dd5e40-e791-4c5c-af1e-58f32ed3ed91.jpg`,
  sprinter: `${P}/assets/5ae05287-68b0-4384-80b3-b522851542b5.png`,
  interior: `${P}/assets/27d2059c-9841-474b-8b65-d227811da8c5.png`,
  commitment: `${P}/attachments/796901b1-cefb-4324-a7d8-8f27d47a89c8.jpg`,
  chauffeur: `${P}/assets/637887bf-9eaf-41f9-8ee3-eec3ad7c630e.png`,
  airportSecondary: `${P}/assets/6752e089-7f9b-40e6-87a0-5add4a4fa689.png`,
  eventsSecondary: `${P}/assets/a871912d-bf39-470c-8633-cf38f8e6e6fd.png`,
  groupSecondary: `${P}/assets/c821474c-3470-4a92-8fe5-b75e275dfb7e.png`,
  concertSecondary: `${P}/assets/49f950b6-cf4e-4d1c-a6a1-7c401e0a3b18.png`,
  birthdaySecondary: `${P}/assets/db7e3bd8-6b24-4e60-8776-6e926aedee44.png`,
  cityToursSecondary: `${P}/assets/0e1a19e2-09bc-4119-8081-e945bacdfa73.png`,
  holidaySecondary: `${P}/assets/d1bfeda1-53fd-4af5-8249-b6274d5a3601.png`,
  p2pSecondary: `${P}/assets/27c511d8-2263-470c-af75-b24bae36acb8.png`,
  vipSecondary: `${P}/assets/272c1182-a1bd-4086-85b9-22504ae60431.png`,
  shuttleSecondary: `${P}/assets/4be34df2-658b-4b70-bfeb-03bd1d43c53a.png`,
  medicalSecondary: `${P}/assets/4adf1023-0d0c-4fea-af51-48c19f296b38.png`,
  funeralSecondary: `${P}/assets/36636a38-3757-46ab-b795-c7f98f09b3b2.png`,
  weddingSecondary: `${P}/assets/6492ade4-0d1a-4733-bff8-b22ba0c00f64.png`,
  wineSecondary: `${P}/assets/152730ab-feef-4574-981e-394870e7f10f.png`,
};

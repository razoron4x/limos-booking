import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  ArrowRight,
  MapPin,
  Phone,
  Shield,
  Clock,
  CreditCard,
} from "lucide-react";

interface PrivateCarFaqAndCtaProps {
  faqs: Array<{ question: string; answer: string }>;
}

export const PrivateCarFaqAndCta = ({ faqs }: PrivateCarFaqAndCtaProps) => {
  return (
    <>
      {/* HOW IT WORKS */}
      <section className="py-24 bg-white border-y border-zinc-200">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-zinc-900 mb-6">
              How It Works
            </h2>
            <p className="text-zinc-600 max-w-2xl mx-auto text-lg font-light">
              Three simple steps to your private driver.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              {
                step: "01",
                title: "Book Online or Call",
                desc: "Get an instant quote in seconds. Book through our form, call us directly, or set up a recurring schedule.",
              },
              {
                step: "02",
                title: "Driver Arrives Early",
                desc: "Your professional chauffeur arrives 15 minutes early at your location, ready with a pristine vehicle.",
              },
              {
                step: "03",
                title: "Relax & Arrive Refreshed",
                desc: "Sit back, work, rest, or enjoy the ride. We handle everything including traffic, parking, and luggage.",
              },
            ].map((item, i) => (
              <div key={i} className="text-center relative">
                <div className="text-6xl font-serif font-bold text-primary/60 mb-4">
                  {item.step}
                </div>
                <h3 className="text-xl font-serif font-bold text-zinc-900 mb-3">
                  {item.title}
                </h3>
                <p className="text-zinc-600 text-sm leading-relaxed font-medium">
                  {item.desc}
                </p>
                {i < 2 && (
                  <div className="hidden md:block absolute top-12 -right-4 text-primary/70">
                    <ArrowRight className="w-6 h-6" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 bg-white border-y border-zinc-200">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-zinc-900 mb-6">
              Frequently Asked Questions
            </h2>
            <p className="text-zinc-600 max-w-2xl mx-auto text-lg font-light">
              Everything you need to know about our private car service.
            </p>
          </div>
          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <details
                key={i}
                className="group bg-zinc-50 border border-zinc-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md hover:border-primary/30 transition-all duration-300"
              >
                <summary className="flex items-center justify-between cursor-pointer px-6 py-5 list-none">
                  <div className="flex items-start gap-4">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2.5 shrink-0 group-open:bg-yellow-500 transition-colors"></span>
                    <h3 className="text-base md:text-lg font-semibold text-zinc-900 pr-8 leading-snug group-hover:text-primary transition-colors">
                      {faq.question}
                    </h3>
                  </div>
                  <svg
                    className="w-5 h-5 text-zinc-400 shrink-0 transform transition-transform duration-300 group-open:rotate-180"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </summary>
                <div className="px-6 pb-5 pl-11">
                  <p className="text-zinc-600 leading-relaxed font-medium text-sm md:text-base pt-1 border-t border-zinc-200/60 mt-1">
                    {faq.answer}
                  </p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* SERVING ALL DALLAS METROPLEX */}
      <section className="py-20 bg-zinc-100 border-y border-zinc-200">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                Service Areas
              </span>
            </div>
            <h2 className="text-2xl md:text-4xl font-serif font-bold text-zinc-900 mb-4">
              Serving All the{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-600 via-yellow-500 to-yellow-700">
                Dallas-Fort Worth
              </span>{" "}
              Metroplex
            </h2>
            <p className="text-zinc-800 font-medium leading-relaxed mb-8 max-w-2xl mx-auto">
              Addison Limos provides private car service across the entire DFW
              area. With 20+ years of experience, our professional chauffeurs
              know every route and neighborhood.
            </p>
            <div className="bg-zinc-800 border border-zinc-600 shadow-lg p-6 md:p-10 rounded-[2.5rem] mb-8 max-w-3xl mx-auto">
              <div className="flex flex-wrap justify-center gap-2">
                {[
                  "Dallas",
                  "Fort Worth",
                  "Addison",
                  "Plano",
                  "Frisco",
                  "Irving",
                  "Grapevine",
                  "Arlington",
                  "Richardson",
                  "Garland",
                  "McKinney",
                  "Carrollton",
                  "Denton",
                  "Lewisville",
                  "Southlake",
                  "Allen",
                  "Mesquite",
                  "Grand Prairie",
                  "The Colony",
                  "Flower Mound",
                ].map((city, i) => {
                  const link = city.toLowerCase().replace(/\s+/g, "-");
                  const hasLink = [
                    "dallas",
                    "fort-worth",
                    "addison",
                    "plano",
                    "frisco",
                    "irving",
                    "grapevine",
                    "arlington",
                    "richardson",
                    "garland",
                    "mckinney",
                    "carrollton",
                    "denton",
                    "lewisville",
                    "southlake",
                    "flower-mound",
                  ].includes(link);
                  return hasLink ? (
                    <Link
                      key={i}
                      to={`/limo-service/${link}`}
                      className="px-4 py-2 text-sm text-white border border-zinc-500 bg-zinc-700 hover:border-primary hover:text-primary transition-all duration-200 rounded-full font-semibold shadow-sm hover:shadow-md"
                    >
                      {city}
                    </Link>
                  ) : (
                    <span
                      key={i}
                      className="px-4 py-2 text-sm text-white/80 border border-zinc-500 bg-zinc-700 rounded-full font-semibold shadow-sm"
                    >
                      {city}
                    </span>
                  );
                })}
                <span className="px-4 py-2 text-sm text-primary border border-primary/40 bg-primary/15 rounded-full font-semibold shadow-sm">
                  & 50+ more
                </span>
              </div>
            </div>
            <p className="text-zinc-800 text-sm font-semibold mb-6">
              Don't see your city? We serve the entire DFW metroplex and
              surrounding regions.
            </p>
            <a
              href="tel:9726083680"
              className="inline-block"
              onClick={() => (window as any).gtag_report_conversion?.()}
            >
              <Button className="bg-gradient-to-b from-yellow-600 via-yellow-500 to-yellow-700 text-black hover:from-yellow-500 hover:via-yellow-400 hover:to-yellow-600 rounded-none px-8 h-12 font-semibold shadow-[0_0_15px_rgba(212,175,55,0.25)] border border-yellow-400/30 transition-all duration-300">
                <Phone className="w-4 h-4 mr-2" />
                Call 972-608-3680
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-24 bg-zinc-900 border-t border-zinc-800">
        <div className="container mx-auto px-4">
          <div className="bg-zinc-900 border border-primary/30 p-12 md:p-20 text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent"></div>
            <div className="relative z-10">
              <h2 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6">
                Ready to Ride in Privacy?
              </h2>
              <p className="text-xl text-white/70 mb-10 max-w-2xl mx-auto font-medium">
                Book your private driver today. Flat rates, no surges,
                guaranteed punctuality.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center px-2 sm:px-0">
                <Link
                  to="/quote?service=Private%20Car%20Service"
                  onClick={() => (window as any).gtag_report_conversion?.()}
                >
                  <Button
                    size="lg"
                    className="w-full sm:w-auto bg-primary text-primary-foreground hover:bg-primary/90 text-sm sm:text-lg rounded-none h-14 sm:h-16 px-4 sm:px-12 shadow-[0_0_20px_rgba(212,175,55,0.2)] text-center whitespace-normal"
                  >
                    Book Your Private Driver Now
                    <ArrowRight className="w-5 h-5 ml-2 shrink-0" />
                  </Button>
                </Link>
                <a
                  href="tel:9726083680"
                  onClick={() => (window as any).gtag_report_conversion?.()}
                >
                  <Button
                    size="lg"
                    variant="outline"
                    className="w-full sm:w-auto border-white/20 text-white hover:bg-white/10 text-base sm:text-lg rounded-none h-14 sm:h-16 px-6 sm:px-12 bg-transparent backdrop-blur-sm transition-all text-center whitespace-nowrap"
                  >
                    <Phone className="w-5 h-5 mr-2 shrink-0" />
                    Call 972-608-3680
                  </Button>
                </a>
              </div>

              <div className="mt-12 pt-8 border-t border-white/10 flex flex-wrap justify-center gap-6">
                <div className="inline-flex items-center gap-2 text-white/50 text-xs font-light">
                  <Shield className="w-4 h-4 text-primary/70" />
                  <span>TxDOT Licensed</span>
                </div>
                <div className="inline-flex items-center gap-2 text-white/50 text-xs font-light">
                  <Clock className="w-4 h-4 text-primary/70" />
                  <span>24/7 Dispatch</span>
                </div>
                <div className="inline-flex items-center gap-2 text-white/50 text-xs font-light">
                  <CreditCard className="w-4 h-4 text-primary/70" />
                  <span>Flat-Rate Pricing</span>
                </div>
                <div className="inline-flex items-center gap-2 text-white/50 text-xs font-light">
                  <MapPin className="w-4 h-4 text-primary/70" />
                  <span>DFW Metroplex</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

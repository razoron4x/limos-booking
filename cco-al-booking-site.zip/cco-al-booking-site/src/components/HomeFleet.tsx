import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

export const HomeFleetSection = () => {
  const fleetVehicles = [
    {
      id: "luxury-black-stretch-limo",
      title: "Chrysler 300 Stretch Limo",
      desc: "The pinnacle of classic sophistication for weddings and galas.",
      images: [
        "https://vibe.filesafe.space/1792719026995615993/attachments/e7319457-c2da-4518-8f5e-f950a8b734ce.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/dab4941e-6dce-4ba2-a571-f2de740dfce0.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/74d38f93-6631-485a-8fd2-95552893cbd7.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/0a1e3af7-ea2a-426f-8277-c3a3b19ad926.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/c298c183-62cb-4bb5-ade1-e396929b078b.webp",
      ],
    },
    {
      id: "h2-hummer-stretch-limo",
      title: "H2 Hummer Limo",
      desc: "Bold, spacious luxury for large groups and high-energy celebrations.",
      images: [
        "https://vibe.filesafe.space/1792719026995615993/attachments/278d259b-dfca-4ae9-9892-e0235c13b364.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/bdba5859-0876-4bc7-a581-203b8ed8c77c.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/58a625bc-1679-4264-95dd-d33c606a5c8f.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/f58de790-d5ad-4794-8cca-39fcacc242b9.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/bda54c77-aba6-4a4f-8ff8-98e5c33d1775.webp",
      ],
    },
    {
      id: "fleet",
      title: "Mercedes Sprinter Limos, Executive & Vans",
      desc: "Premium group transport with executive interiors and custom lighting.",
      images: [
        "https://vibe.filesafe.space/1792719026995615993/attachments/9ff34acc-63df-453e-b227-96dbd4a60267.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/1c7af2eb-7c2e-4d82-9372-c3763f0858d6.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/f68e4eb6-cda5-4405-adc7-bf31dfa65f22.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/8d411452-3ffb-48b0-bd27-2ae53f24679d.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/e32b67bf-38a0-495c-8e83-58d74360f910.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/fed850b2-6f8a-4ec8-8842-a09b7dcb29b7.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/1408b09c-2f1b-4d54-87fc-31e2589bafe5.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/82a90cae-e6d8-4cd4-9e16-24d0f3a5e4f6.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/de2d9d48-4e0c-426f-adb0-45ec7da8f173.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/a88a7a57-7f70-4866-b92a-33e0cae981fd.webp",
      ],
    },
    {
      id: "lincoln-navigator-suv",
      title: "Luxury SUVs",
      desc: "Discreet, climate-controlled comfort perfect for corporate travel and VIP clients.",
      images: [
        "https://vibe.filesafe.space/1792719026995615993/attachments/fffb1544-09c3-4429-9842-290f8ea2ae8b.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/27acf329-8b3a-41c1-871e-ef4874f9a4b2.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/f1c0a7c7-ce9e-4bd2-a7e0-ab486cf6b158.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/3f10eb07-943c-45a3-ad11-3db7bf49f612.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/64082cf3-26cd-40b5-bb00-3625fa6408b3.webp",
        "https://vibe.filesafe.space/1792719026995615993/attachments/f02eab3f-0234-4b86-8a74-6bc7b9245837.webp",
      ],
    },
  ];

  const imgClass = (vehicleId: string, idx: number) => {
    if (vehicleId === "luxury-black-stretch-limo") {
      if (idx === 1)
        return "object-cover object-bottom -translate-y-6 sm:-translate-y-8";
      if (idx === 2 || idx === 3)
        return "object-cover object-bottom -translate-y-12 sm:-translate-y-16";
      return "object-cover object-center";
    }
    if (vehicleId === "mercedes-sprinter-limo") {
      if (idx === 1)
        return "object-cover object-bottom -translate-y-24 sm:-translate-y-40";
      if (idx === 2 || idx === 3)
        return "object-cover object-bottom -translate-y-8 sm:-translate-y-12";
      return "object-cover object-center";
    }
    if (vehicleId === "mercedes-sprinter-van") {
      if (idx === 1)
        return "object-cover object-bottom -translate-y-24 sm:-translate-y-40";
      if (idx === 2 || idx === 3)
        return "object-cover object-bottom -translate-y-8 sm:-translate-y-12";
      return "object-cover object-center";
    }
    if (vehicleId === "fleet") {
      if (idx === 2)
        return "object-cover object-bottom -translate-y-36 sm:-translate-y-48";
      if (idx === 3 || idx === 4)
        return "object-cover object-bottom -translate-y-16 sm:-translate-y-24";
      return "object-cover object-center";
    }
    return "object-cover object-center";
  };

  return (
    <section id="fleet" className="py-24 bg-zinc-950 relative">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
      <div className="container mx-auto px-4">
        <div className="text-center mb-6">
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
            Luxury Fleet
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto text-lg font-light">
            Experience the pinnacle of automotive excellence with our
            meticulously maintained collection of premium vehicles.
          </p>
        </div>
        <div className="relative py-2">
          <p className="text-center text-sm text-white/40 mb-1.5 relative z-10">
            Tap the vehicle to expand
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
            {fleetVehicles.map((vehicle, i) => (
              <Card
                key={i}
                className="bg-zinc-900/50 border-white/5 overflow-hidden group rounded-none relative"
              >
                <div className="aspect-[16/9] overflow-hidden relative group/carousel">
                  <Carousel opts={{ loop: true }} className="w-full h-full">
                    <CarouselContent className="h-full ml-0">
                      {vehicle.images.map((img, idx) => (
                        <CarouselItem
                          key={idx}
                          className="pl-0 h-full relative overflow-hidden"
                        >
                          <Link
                            to={
                              vehicle.id === "fleet"
                                ? "/fleet"
                                : `/fleet/${vehicle.id}`
                            }
                            className="block w-full h-full cursor-pointer overflow-hidden"
                          >
                            <img
                              src={img}
                              alt={`${vehicle.title} view ${idx + 1}`}
                              loading="lazy"
                              className={`w-full h-full transition-transform duration-1000 opacity-80 group-hover:opacity-100 group-hover:scale-105 ${imgClass(vehicle.id, idx)}`}
                            />
                          </Link>
                        </CarouselItem>
                      ))}
                    </CarouselContent>
                    <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                    <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-black/50 border-white/10 text-white hover:bg-primary hover:text-black z-20" />
                  </Carousel>
                </div>
                <CardContent className="absolute bottom-0 left-0 p-4 pb-2 sm:p-8 w-full z-30 pointer-events-none">
                  <h3 className="text-2xl font-serif font-bold text-white mb-1 sm:mb-2 group-hover:text-primary transition-colors drop-shadow-md">
                    <Link
                      to={
                        vehicle.id === "fleet"
                          ? "/fleet"
                          : `/fleet/${vehicle.id}`
                      }
                      className="pointer-events-auto hover:text-primary transition-colors"
                    >
                      {vehicle.title}
                    </Link>
                  </h3>
                  <p className="hidden sm:block text-base text-white/90 font-light drop-shadow-md">
                    {vehicle.desc}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        <div className="mt-10 flex justify-center">
          <Link to="/fleet" className="w-full max-w-sm">
            <Button className="w-full h-14 bg-gradient-to-b from-zinc-800/40 to-zinc-950 border border-white/10 hover:border-primary/40 text-white text-base tracking-wide rounded-none group relative overflow-hidden transition-all duration-500 shadow-2xl">
              <span className="relative z-10 flex items-center justify-center">
                See Full Fleet
                <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </span>
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";
import { Link } from "react-router-dom";

const reviews = [
  {
    name: "Kelli Watkins",
    text: "We have used this company for many years and they will continue to be our go to car service in Dallas. Mr. Sunny and the staff are kind, helpful and aim to please. Thank you Addison Limos and Mr. Sunny, we appreciate you!",
  },
  {
    name: "Chris Randall",
    text: "Great experience! Driver was on time and sprinter limo was great! Clean and just as promised Driver was very friendly and accommodating...",
  },
  {
    name: "Judy Viegas",
    text: "Denis was very professional and a great driver. The vehicle was very clean and roomy. We will definitely use Addison Limo Service again. They are very easy to work with.",
  },
];

const HalloweenReviews = () => {
  return (
    <section className="py-24 bg-background relative border-t border-white/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary via-white to-white">
            5-Star Rated Award Winning Service
          </h2>
        </div>

        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-primary/20 backdrop-blur-sm">
            <Star className="w-4 h-4 text-primary fill-primary" />
            <span className="text-xs sm:text-sm font-semibold tracking-widest uppercase text-white/90 text-center">
              Winner of Addison Magazine's Readers Choice Award
            </span>
          </div>
        </div>

        <div className="flex flex-row items-center justify-center gap-4 sm:gap-16 bg-zinc-900/50 border border-white/10 p-4 sm:p-8 rounded-none max-w-3xl mx-auto backdrop-blur-sm mb-12 sm:mb-16">
          <div className="text-center flex-1">
            <div className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-white mb-1 sm:mb-2">
              4.8
            </div>
            <div className="flex items-center justify-center gap-1 mb-1 sm:mb-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className="w-3 h-3 sm:w-5 sm:h-5 text-primary fill-primary"
                />
              ))}
            </div>
            <div className="text-[10px] sm:text-sm text-white/60 uppercase tracking-widest">
              Average Rating
            </div>
          </div>
          <div className="w-px h-16 sm:h-20 bg-white/10 shrink-0"></div>
          <div className="text-center flex-1">
            <div className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-white mb-1 sm:mb-2">
              160+
            </div>
            <div className="flex items-center justify-center gap-1 mb-1 sm:mb-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-3 h-3 sm:w-5 sm:h-5 text-primary"
              >
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
            </div>
            <div className="text-[10px] sm:text-sm text-white/60 uppercase tracking-widest">
              Verified Reviews
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-8 mb-12 -mx-2 sm:mx-0">
          {reviews.map((review, i) => (
            <Card
              key={i}
              className="bg-zinc-900/40 border-white/5 rounded-none hover:bg-zinc-900/60 transition-all duration-300 group"
            >
              <CardContent className="p-3 sm:p-8 flex flex-col h-full">
                <div className="flex items-center gap-0.5 mb-2 sm:mb-6">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className="w-3 h-3 sm:w-4 sm:h-4 text-primary fill-primary"
                    />
                  ))}
                </div>
                <p className="text-sm sm:text-base text-white/80 font-light leading-relaxed mb-3 sm:mb-8 italic flex-grow">
                  "{review.text}"
                </p>
                <div className="flex items-center gap-2 sm:gap-4 mt-auto pt-3 sm:pt-4 border-t border-white/5">
                  <div className="w-8 h-8 sm:w-12 sm:h-12 bg-primary/10 rounded-full flex items-center justify-center border border-primary/20 shrink-0">
                    <span className="text-primary font-serif font-bold text-sm sm:text-lg">
                      {review.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <div className="text-white font-medium text-sm sm:text-base">
                      {review.name}
                    </div>
                    <div className="text-[10px] sm:text-xs text-white/50">
                      Google Review
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Link to="/reviews">
            <Button
              size="lg"
              className="bg-transparent border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground text-base tracking-wide rounded-none h-14 px-10 transition-all duration-300"
            >
              See All Reviews
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default HalloweenReviews;

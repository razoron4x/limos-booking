import { Plane, Star, Trophy } from "lucide-react";

export const CorporateAirportMosaic = () => {
  return (
    <section className="py-20 bg-white border-y border-zinc-200">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 lg:gap-6">
          {/* Row 1: IMAGE left (8 cols) | AWARD right (4 cols) */}
          <div className="md:col-span-8 relative overflow-hidden rounded-xl shadow-lg group h-[240px] md:h-[380px] lg:h-[340px]">
            <img
              src="https://vibe.filesafe.space/1792719026995615993/assets/036600e4-efeb-494c-bd8c-5a189e8271ad.png"
              alt="Luxury black SUV interior at night with corporate client testimonial overlay"
              loading="lazy"
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-black/70 via-black/30 to-black/60"></div>

            {/* Label - Top Left */}
            <div className="absolute top-0 left-0 p-6 lg:p-8">
              <p className="text-xs font-bold uppercase tracking-wider text-primary mb-2">
                Corporate Client Testimonial
              </p>
            </div>

            {/* Quote & Author - Bottom Left */}
            <div className="absolute bottom-0 left-0 p-5 lg:p-8 max-w-2xl lg:max-w-3xl">
              <blockquote className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-white leading-[1.15] mb-2 sm:mb-3 drop-shadow-lg">
                "Reliable, easy to book, and always on time for business trips.
                Every ride was flawless."
              </blockquote>
              <p className="text-sm sm:text-base text-white/90 font-medium">
                JC, Google Review
              </p>
            </div>
          </div>

          <div className="md:col-span-4 bg-gradient-to-br from-yellow-600 via-yellow-500 to-yellow-700 rounded-xl p-3 md:p-5 lg:p-7 flex flex-col items-center justify-center text-center shadow-lg h-[240px] md:h-[340px] lg:h-[340px] relative overflow-hidden">
            {/* Subtle pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-white"></div>
              <div className="absolute -bottom-10 -left-10 w-32 h-32 rounded-full bg-black"></div>
            </div>

            <div className="relative z-10 flex flex-col items-center justify-center">
              <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-black/90 border-2 border-yellow-300 flex items-center justify-center mb-1.5 md:mb-3 shadow-lg">
                <Trophy className="w-6 h-6 md:w-8 md:h-8 text-yellow-400" />
              </div>
              <p className="text-[8px] md:text-[9px] font-bold uppercase tracking-[0.2em] text-black/70 mb-0.5 md:mb-1">
                Addison Magazine's
              </p>
              <p className="text-sm md:text-base lg:text-lg font-serif font-bold text-black leading-tight mb-1.5 md:mb-3">
                Readers Choice Award Winner
              </p>

              <div className="w-full border-t border-black/20 pt-1.5 md:pt-3">
                <div className="flex items-center justify-center gap-0.5 md:gap-1 mb-1 md:mb-1.5">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-3 h-3 md:w-4 md:h-4 text-black fill-black"
                    />
                  ))}
                </div>
                <div className="text-2xl md:text-3xl lg:text-4xl font-serif font-bold text-black leading-none mb-0.5 md:mb-1">
                  4.8
                </div>
                <p className="text-[8px] md:text-[9px] font-bold uppercase tracking-wider text-black/70 mb-1.5 md:mb-3">
                  Average Rating
                </p>

                <div className="inline-flex items-center gap-1.5 bg-black/90 px-2.5 py-1 md:px-3 md:py-1.5 rounded-full">
                  <span className="text-base md:text-lg lg:text-xl font-serif font-bold text-yellow-400 leading-none">
                    160+
                  </span>
                  <span className="text-[7px] md:text-[8px] font-bold uppercase tracking-wider text-white whitespace-nowrap">
                    Verified Reviews
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Row 2: AIRPORT SAFETY left (4 cols) | IMAGE right (8 cols) */}
          <div className="md:col-span-4 bg-zinc-900 border border-zinc-800 rounded-xl p-5 sm:p-7 lg:p-9 flex flex-col justify-between shadow-lg h-auto md:h-[370px] lg:h-[320px]">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-primary mb-3">
                Airport Safety Protocol
              </p>
              <h3 className="text-base lg:text-lg font-serif font-bold text-white leading-snug mb-2">
                Corporate-grade security for every transfer.
              </h3>
              <p className="text-white/70 text-sm font-medium leading-relaxed">
                Licensed, insured chauffeurs with real-time GPS monitoring and
                $1.5M+ commercial coverage.
              </p>
            </div>

            <div className="mt-3 sm:mt-6 aspect-[36/9] sm:aspect-[16/9] overflow-hidden rounded-lg border border-white/10">
              <img
                src="https://vibe.filesafe.space/1792719026995615993/assets/f363bfea-960a-4e61-ae98-b3d6e7b23870.png"
                alt="Professional chauffeur in uniform"
                loading="lazy"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="md:col-span-8 relative overflow-hidden rounded-xl shadow-lg group h-[220px] md:h-[370px] lg:h-[320px]">
            <img
              src="https://vibe.filesafe.space/1792719026995615993/assets/0fd8b99e-2de8-402b-bb4b-3ff09b9eab11.png"
              alt="Luxury Mercedes Sprinter limo parked curbside at DFW Airport terminal at dusk"
              loading="lazy"
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent"></div>
            <div className="absolute bottom-4 right-4 z-10 bg-zinc-900/90 border border-primary/30 px-4 py-2 backdrop-blur-sm">
              <div className="flex items-center gap-2">
                <Plane className="w-4 h-4 text-primary" />
                <span className="text-white text-sm font-semibold">
                  DFW & DAL Specialists
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

import { useState, useMemo, useRef, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Calendar, CheckCircle2, Mail, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  parsePhoneNumberFromString,
  type CountryCode,
} from "libphonenumber-js";
import { postTrackingEvent, CRM_CONFIG, getGclid } from "@/lib/formTracking";
import {
  VEHICLE_OPTIONS,
  SERVICE_TYPE_OPTIONS,
  CHILD_SEAT_OPTIONS,
  getTrackingSessionId,
} from "./quote-form/quoteFormConstants";
import { CountrySelector } from "./quote-form/CountrySelector";
import { RoundTripSection } from "./quote-form/RoundTripSection";

export const CustomQuoteForm = () => {
  const [searchParams] = useSearchParams();

  // Basic Info
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phoneRaw, setPhoneRaw] = useState("");
  const [country, setCountry] = useState<CountryCode>("US");
  const [email, setEmail] = useState("");

  // Trip details
  const [passengers, setPassengers] = useState("");
  const [childSeats, setChildSeats] = useState("");
  const [vehicleRequested, setVehicleRequested] = useState("");
  const [serviceType, setServiceType] = useState("");
  const [dateOfPickup, setDateOfPickup] = useState("");
  const [timeOfPickup, setTimeOfPickup] = useState("");
  const [pickupAddress, setPickupAddress] = useState("");
  const [dropoffAddress, setDropoffAddress] = useState("");

  // Round trip specific
  const [sameReturnLocations, setSameReturnLocations] = useState(true);
  const [returnTime, setReturnTime] = useState("");
  const [returnDate, setReturnDate] = useState("");
  const [returnPickupAddress, setReturnPickupAddress] = useState("");
  const [returnDropoffAddress, setReturnDropoffAddress] = useState("");

  // Consent
  const [consent, setConsent] = useState(true);

  // Status
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const dateInputRef = useRef<HTMLInputElement>(null);
  const returnDateRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const vParam = searchParams.get("vehicle");
    if (vParam) {
      const match = VEHICLE_OPTIONS.find(
        (v) => v.toLowerCase() === vParam.toLowerCase(),
      );
      if (match) setVehicleRequested(match);
    }
  }, [searchParams]);

  const parsedPhone = useMemo(() => {
    return parsePhoneNumberFromString(phoneRaw, country);
  }, [phoneRaw, country]);

  const isRoundTrip =
    serviceType === "Round Trip - Different Day" ||
    serviceType === "Round Trip - Same Day";
  const isDifferentDay = serviceType === "Round Trip - Different Day";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");

    if (!firstName.trim()) {
      setErrorMessage("Please enter your first name.");
      return;
    }
    if (!lastName.trim()) {
      setErrorMessage("Please enter your last name.");
      return;
    }
    if (!phoneRaw.trim()) {
      setErrorMessage("Please enter your phone number.");
      return;
    }
    if (!email.trim() || !email.includes("@")) {
      setErrorMessage("Please enter a valid email address.");
      return;
    }
    if (!passengers.trim()) {
      setErrorMessage("Please enter the number of passengers.");
      return;
    }
    if (!serviceType) {
      setErrorMessage("Please select a service type.");
      return;
    }
    if (!dateOfPickup) {
      setErrorMessage("Please select a date of pickup.");
      return;
    }
    if (!timeOfPickup.trim()) {
      setErrorMessage("Please enter your pickup time.");
      return;
    }
    if (!pickupAddress.trim()) {
      setErrorMessage("Please enter your pickup address.");
      return;
    }

    if (isRoundTrip) {
      if (!returnTime.trim()) {
        setErrorMessage("Please enter your return pickup time.");
        return;
      }
      if (isDifferentDay && !returnDate) {
        setErrorMessage("Please select your return pickup date.");
        return;
      }
      if (!sameReturnLocations) {
        if (!returnPickupAddress.trim()) {
          setErrorMessage("Please enter your return pickup address.");
          return;
        }
        if (!returnDropoffAddress.trim()) {
          setErrorMessage("Please enter your return drop-off address.");
          return;
        }
      }
    }

    if (!consent) {
      setErrorMessage("Please agree to the terms & conditions to continue.");
      return;
    }

    setIsSubmitting(true);

    const e164Phone = parsedPhone?.format("E.164") || phoneRaw;
    const finalReturnDate = isRoundTrip
      ? isDifferentDay
        ? returnDate
        : dateOfPickup
      : undefined;

    const finalReturnPickup = isRoundTrip
      ? sameReturnLocations
        ? dropoffAddress || pickupAddress
        : returnPickupAddress
      : undefined;

    const finalReturnDropoff = isRoundTrip
      ? sameReturnLocations
        ? pickupAddress
        : returnDropoffAddress
      : undefined;

    const trackingPayload = {
      type: "external_form_submission",
      timestamp: Date.now(),
      formId: CRM_CONFIG.formId,
      formData: {
        first_name: firstName.trim(),
        last_name: lastName.trim(),
        email: email.trim(),
        phone: e164Phone,
      },
      formLabels: {
        first_name: "First Name",
        last_name: "Last Name",
        email: "Email",
        phone: "Phone",
      },
      url: window.location.href,
      title: document.title,
      path: window.location.pathname,
      userAgent: navigator.userAgent,
      trackingId: CRM_CONFIG.trackingId,
      locationId: CRM_CONFIG.locationId,
      projectId: CRM_CONFIG.projectId,
      sessionId: getTrackingSessionId(),
      properties: {
        deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent)
          ? "mobile"
          : "desktop",
        source: "ai_studio",
        projectId: CRM_CONFIG.projectId,
        formName: "Addison Limos Website Form - Copy",
      },
    };

    try {
      await postTrackingEvent(trackingPayload, {
        customFields: {
          mGdJADvY89TGko5eCKy7: {
            value: "Quote",
            label: "Quote or Reservation",
          },
          L3hnJfT44Qg3EYZL7j1v: {
            value: parseInt(passengers, 10) || passengers,
            label: "How Many Passengers",
          },
          jN6xyqaLZbibc0ZuLD3K: {
            value: childSeats || undefined,
            label: "Need Child Car Seats",
          },
          GjBpPhDrMPUk2KOYCzuf: {
            value: vehicleRequested || undefined,
            label: "Vehicle Requested",
          },
          mL0dRw8WiUILXYINqTje: {
            value: serviceType,
            label: "Trip Type",
          },
          RLseVtL867s9RRWzmZAl: {
            value: dateOfPickup,
            label: "Date of Pickup",
          },
          GAcplVGT6Y5CzLdh5sgD: {
            value: timeOfPickup,
            label: "Time of Pickup",
          },
          tGgdaZWV1LMrV8efnse9: {
            value: pickupAddress,
            label: "Initial Pickup Address",
          },
          NrpBGSUrEPwUnkPvdt9T: {
            value: dropoffAddress || undefined,
            label: "Initial Drop Off Address",
          },
          cHetRbT2poaIfiiyJk0O: {
            value: dropoffAddress || undefined,
            label: "Dropoff Address",
          },
          PurScZXDytFHvdqoj9Yn: {
            value: isRoundTrip
              ? sameReturnLocations
                ? "Yes"
                : "No"
              : undefined,
            label: "Same Return Pickup and Dropoff Locations",
          },
          RjRvUbmVvhOLRcybr0ef: {
            value: finalReturnDate,
            label: "Return Date of Pickup",
          },
          Dbs1liDJNus890c3ZqLJ: {
            value: isRoundTrip ? returnTime : undefined,
            label: "Return Time of Pickup",
          },
          mnwPfv8kzcJpHhfRE3Na: {
            value: finalReturnPickup,
            label: "Return Pickup Address",
          },
          ERMDPmChU9wDouonlNvZ: {
            value: finalReturnDropoff,
            label: "Return Dropoff Address",
          },
          contact_gclid: {
            value: getGclid(),
            label: "GCLID",
          },
        },
      });

      if (typeof (window as any).gtag_report_conversion === "function") {
        (window as any).gtag_report_conversion();
      }

      setIsSubmitted(true);
    } catch (err) {
      console.error("Form submit error:", err);
      if (typeof (window as any).gtag_report_conversion === "function") {
        (window as any).gtag_report_conversion();
      }
      setIsSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  const inputClass =
    "w-full rounded-md bg-[#544f4e] border border-amber-500/50 px-3.5 py-2.5 text-sm text-white placeholder-white/40 focus:outline-none focus:border-amber-400 transition-colors";
  const labelClass =
    "block text-sm font-serif text-white/95 mb-1.5 font-medium";

  return (
    <div className="w-full bg-[#1b1919] border border-amber-500/20 rounded-2xl p-5 sm:p-8 lg:p-10 shadow-2xl">
      {isSubmitted ? (
        <div className="flex flex-col items-center justify-center py-12 px-4 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center text-primary shadow-[0_0_25px_rgba(212,175,55,0.35)]">
            <CheckCircle2 className="w-9 h-9" />
          </div>
          <h3 className="text-2xl sm:text-3xl font-bold text-white font-serif">
            Quote Request Received!
          </h3>
          <p className="text-zinc-300 text-sm sm:text-base max-w-md leading-relaxed">
            Thank you, {firstName}! Our dispatch concierge team has received
            your reservation inquiry and will reach out with your exact quote
            shortly.
          </p>
          <p className="text-xs sm:text-sm text-zinc-400 pt-2">
            Need immediate confirmation? Call{" "}
            <a
              href="tel:9726083680"
              className="text-primary underline font-bold"
            >
              972-608-3680
            </a>
          </p>
          <Button
            onClick={() => {
              setIsSubmitted(false);
              setPhoneRaw("");
              setPickupAddress("");
              setDropoffAddress("");
              setReturnPickupAddress("");
              setReturnDropoffAddress("");
            }}
            variant="outline"
            className="mt-6 border-zinc-700 text-white hover:bg-zinc-800"
          >
            Submit Another Quote
          </Button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-5">
          {errorMessage && (
            <div className="p-3 rounded-lg bg-red-500/15 border border-red-500/30 text-red-200 text-xs sm:text-sm font-medium">
              {errorMessage}
            </div>
          )}

          {/* Row 1: First Name & Last Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5">
            <div>
              <label className={labelClass}>
                First Name <span className="text-amber-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="First Name"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                className={inputClass}
              />
            </div>
            <div>
              <label className={labelClass}>
                Last Name <span className="text-amber-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="Last Name"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                className={inputClass}
              />
            </div>
          </div>

          {/* Row 2: Phone & Email */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5">
            <div>
              <label className={labelClass}>
                Phone <span className="text-amber-400">*</span>
              </label>
              <div className="relative flex rounded-md bg-[#544f4e] border border-amber-500/50 shadow-inner overflow-visible">
                <CountrySelector country={country} onSelect={setCountry} />
                <input
                  type="tel"
                  name="phone"
                  required
                  placeholder="Phone"
                  value={phoneRaw}
                  onChange={(e) => setPhoneRaw(e.target.value)}
                  className="w-full bg-transparent px-3 py-2 text-sm text-white placeholder-white/40 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className={labelClass}>
                Email <span className="text-amber-400">*</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-white/50 pointer-events-none" />
                <input
                  type="email"
                  required
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`${inputClass} pl-10`}
                />
              </div>
            </div>
          </div>

          {/* Row 3: How Many Passengers & Need Child Car Seats? */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5">
            <div>
              <label className={labelClass}>
                How Many Passengers <span className="text-amber-400">*</span>
              </label>
              <input
                type="number"
                min="1"
                max="56"
                required
                placeholder="Number of passengers"
                value={passengers}
                onChange={(e) => setPassengers(e.target.value)}
                className={inputClass}
              />
            </div>
            <div>
              <label className={labelClass}>Need Child Car Seats?</label>
              <div className="relative">
                <select
                  value={childSeats}
                  onChange={(e) => setChildSeats(e.target.value)}
                  className={`${inputClass} appearance-none pr-9 cursor-pointer`}
                >
                  <option value="" className="bg-[#262322] text-white/60">
                    Select car seat option (optional)
                  </option>
                  {CHILD_SEAT_OPTIONS.map((opt) => (
                    <option
                      key={opt}
                      value={opt}
                      className="bg-[#262322] text-white"
                    >
                      {opt}
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/60" />
              </div>
            </div>
          </div>

          {/* Row 4: Vehicle Requested & Service Type Requested */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5">
            <div>
              <label className={labelClass}>Vehicle Requested</label>
              <div className="relative">
                <select
                  value={vehicleRequested}
                  onChange={(e) => setVehicleRequested(e.target.value)}
                  className={`${inputClass} appearance-none pr-9 cursor-pointer`}
                >
                  <option value="" className="bg-[#262322] text-white/60">
                    Select a vehicle (optional)
                  </option>
                  {VEHICLE_OPTIONS.map((opt) => (
                    <option
                      key={opt}
                      value={opt}
                      className="bg-[#262322] text-white"
                    >
                      {opt}
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/60" />
              </div>
            </div>
            <div>
              <label className={labelClass}>
                Service Type Requested <span className="text-amber-400">*</span>
              </label>
              <div className="relative">
                <select
                  required
                  value={serviceType}
                  onChange={(e) => setServiceType(e.target.value)}
                  className={`${inputClass} appearance-none pr-9 cursor-pointer`}
                >
                  <option value="" className="bg-[#262322] text-white/60">
                    Select service type
                  </option>
                  {SERVICE_TYPE_OPTIONS.map((opt) => (
                    <option
                      key={opt}
                      value={opt}
                      className="bg-[#262322] text-white"
                    >
                      {opt}
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/60" />
              </div>
            </div>
          </div>

          {/* Row 5: Date of Pickup & Time of Pickup */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5">
            <div>
              <label className={labelClass}>
                Date of Pickup <span className="text-amber-400">*</span>
              </label>
              <div
                className="relative rounded-md bg-[#544f4e] border border-amber-500/50 flex items-center cursor-pointer"
                onClick={() => {
                  const input = dateInputRef.current;
                  if (!input) return;
                  try {
                    input.focus();
                    input.showPicker();
                  } catch (e) {
                    console.error("Date picker error:", e);
                  }
                }}
              >
                <Calendar className="w-4 h-4 ml-3 text-white/60 shrink-0 pointer-events-none" />
                <input
                  ref={dateInputRef}
                  type="date"
                  required
                  value={dateOfPickup}
                  onChange={(e) => setDateOfPickup(e.target.value)}
                  className="w-full bg-transparent px-3 py-2.5 text-sm text-white placeholder-white/40 focus:outline-none cursor-pointer"
                  style={{ colorScheme: "dark" }}
                />
              </div>
            </div>
            <div>
              <label className={labelClass}>
                Time of Pickup <span className="text-amber-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. 7:00 PM"
                value={timeOfPickup}
                onChange={(e) => setTimeOfPickup(e.target.value)}
                className={inputClass}
              />
            </div>
          </div>

          {/* Row 6: Pickup Address */}
          <div>
            <label className={labelClass}>
              Pickup Address <span className="text-amber-400">*</span>
            </label>
            <textarea
              required
              rows={3}
              placeholder="Pickup Address"
              value={pickupAddress}
              onChange={(e) => setPickupAddress(e.target.value)}
              className={`${inputClass} resize-y`}
            />
          </div>

          {/* Row 7: Dropoff Address */}
          <div>
            <label className={labelClass}>Dropoff Address</label>
            <textarea
              rows={2}
              placeholder="Dropoff Address"
              value={dropoffAddress}
              onChange={(e) => setDropoffAddress(e.target.value)}
              className={`${inputClass} resize-y`}
            />
          </div>

          {/* Progressive Round Trip Section */}
          {isRoundTrip && (
            <RoundTripSection
              isDifferentDay={isDifferentDay}
              sameReturnLocations={sameReturnLocations}
              onToggleSameLocations={() =>
                setSameReturnLocations((prev) => !prev)
              }
              returnTime={returnTime}
              onReturnTimeChange={setReturnTime}
              returnDate={returnDate}
              onReturnDateChange={setReturnDate}
              returnDateRef={returnDateRef}
              returnPickupAddress={returnPickupAddress}
              onReturnPickupChange={setReturnPickupAddress}
              returnDropoffAddress={returnDropoffAddress}
              onReturnDropoffChange={setReturnDropoffAddress}
              inputClass={inputClass}
              labelClass={labelClass}
            />
          )}

          {/* Consent Checkbox */}
          <div className="pt-2">
            <label className="flex items-start gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                required
                checked={consent}
                onChange={(e) => setConsent(e.target.checked)}
                className="mt-1 w-4 h-4 rounded border-amber-500/50 bg-[#544f4e] text-amber-500 focus:ring-amber-400 accent-amber-500 cursor-pointer shrink-0"
              />
              <span className="text-xs sm:text-sm text-white/85 leading-relaxed font-serif">
                I agree to{" "}
                <a
                  href="/privacy-policy"
                  target="_blank"
                  rel="noreferrer"
                  className="text-amber-400 hover:text-amber-300 underline underline-offset-2"
                >
                  terms &amp; conditions
                </a>{" "}
                provided by the company. By providing my phone number, I agree
                to receive text messages from the business.
              </span>
            </label>
          </div>

          {/* Submit Button */}
          <div className="pt-3">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full h-12 bg-amber-500 hover:bg-amber-400 text-black font-semibold text-base rounded-lg transition-colors shadow-lg hover:shadow-amber-500/20"
            >
              {isSubmitting ? "Submitting Request..." : "Request a Quote"}
            </Button>
          </div>

          <p className="text-[11px] text-white/40 text-center font-light pt-1">
            Need immediate service? Call dispatch directly at{" "}
            <a
              href="tel:9726083680"
              className="text-amber-400 hover:text-amber-300 underline underline-offset-2 font-medium"
            >
              972-608-3680
            </a>
          </p>
        </form>
      )}
    </div>
  );
};

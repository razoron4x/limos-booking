import { Briefcase, ArrowRight, Phone } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export const CorporateServicesOccasions = () => {
  return (
    <section className="py-24 bg-white border-y border-zinc-200">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Briefcase className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold tracking-widest uppercase text-primary">
              Corporate Services
            </span>
          </div>
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-zinc-900 mb-6">
            Corporate chauffeur services for{" "}
            <span className="bg-gradient-to-b from-[#f5e28a] via-[#d4af37] to-[#9c7a1e] bg-clip-text text-transparent">
              every
            </span>{" "}
            occasion
          </h2>
          <p className="text-zinc-600 max-w-2xl mx-auto text-xl font-medium italic tracking-wide">
            Built for business. Engineered for reliability. Addison Limos makes
            corporate travel effortless.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {[
            {
              title: "Executive Airport Transfers",
              desc: "Real-time flight tracking, meet-and-greet service at DFW & Love Field, and guaranteed punctual arrivals for every executive trip.",
              link: "/service-airport",
              img: "https://vibe.filesafe.space/1792719026995615993/attachments/105ccb92-8123-4ed8-84a9-4418d97c9941.webp",
            },
            {
              title: "Business Meetings & Events",
              desc: "Ensure punctual arrivals, seamless departures, and foster strong professional relationships at every meeting or conference.",
              link: "/service-events",
              img: "https://vibe.filesafe.space/1792719026995615993/attachments/fba40358-8871-45b6-8d55-3e9f4c2c30b1.webp",
            },
            {
              title: "City-to-City Travel",
              desc: "Effortlessly work while traveling between Dallas, Fort Worth, Plano, Frisco, and across the DFW metroplex.",
              link: "/service-point-to-point",
              img: "https://vibe.filesafe.space/1792719026995615993/attachments/f36247b6-7933-45f9-b1f9-756634a8a11f.webp",
            },
            {
              title: "Client & Partner Transport",
              desc: "Impress clients and partners with exceptional chauffeur service, elevating their travel experience from pickup to drop-off.",
              link: "/service-vip",
              img: "https://vibe.filesafe.space/1792719026995615993/attachments/dfd0c52f-a532-4e35-9f71-57c8857e9e9f.webp",
            },
          ].map((service, i) => (
            <Link key={i} to={service.link} className="group block">
              <div className="relative aspect-[2/1] overflow-hidden border border-zinc-200 rounded-xl mb-4">
                <img
                  src={service.img}
                  alt={service.title}
                  loading="lazy"
                  className={`w-full h-full object-cover transition-all duration-700 ease-out group-hover:blur-sm group-hover:scale-110 rounded-xl ${
                    i === 2 ? "object-[center_60%]" : ""
                  }`}
                />
                {/* Overlay + Button */}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-all duration-500 flex items-center justify-center rounded-xl">
                  <span className="opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-500 delay-100 inline-flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2 text-xs font-semibold tracking-wide uppercase rounded shadow-[0_0_20px_rgba(212,175,55,0.4)]">
                    View Now
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
                {/* Subtle top gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none rounded-xl"></div>
              </div>
              <h3 className="text-lg font-serif font-bold text-zinc-900 mb-1.5 group-hover:text-primary transition-colors duration-300">
                {service.title}
              </h3>
              <p className="text-zinc-600 font-normal text-base leading-relaxed">
                {service.desc}
              </p>
            </Link>
          ))}
        </div>

        {/* CTA Buttons */}
        <div className="mt-12 flex flex-col sm:flex-row gap-4 justify-center max-w-xl mx-auto">
          <Link
            to="/quote"
            onClick={() => (window as any).gtag_report_conversion?.()}
            className="w-full sm:w-auto"
          >
            <Button
              size="lg"
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 text-base rounded-none h-14 px-8 shadow-[0_0_20px_rgba(212,175,55,0.3)] transition-all hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] whitespace-nowrap"
            >
              Try Our Award-Winning Service
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
          <a
            href="tel:9726083680"
            onClick={() => (window as any).gtag_report_conversion?.()}
            className="w-full sm:w-auto"
          >
            <Button
              size="lg"
              variant="outline"
              className="w-full border-zinc-300 text-zinc-900 hover:bg-zinc-100 text-base rounded-none h-14 px-8 bg-transparent backdrop-blur-sm transition-all whitespace-nowrap"
            >
              <Phone className="w-5 h-5 mr-2" />
              Call 972-608-3680
            </Button>
          </a>
        </div>
      </div>
    </section>
  );
};

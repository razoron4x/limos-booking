import { Clock, MapPin, Luggage, Plane } from "lucide-react";

const steps = [
  {
    icon: Clock,
    step: "01",
    title: "Pre-Arrival Fleet Staging",
    desc: "Your chauffeur arrives at the airport 15 minutes prior to touchdown, staging at the terminal staging area or private FBO ramp so your ride is waiting the instant you step outside.",
  },
  {
    icon: MapPin,
    step: "02",
    title: "Terminal Meet & Greet",
    desc: "Your chauffeur greets you inside baggage claim at DFW & Love Field with a personalized sign, or curbside at Addison Airport (ADS) — your choice, every time.",
  },
  {
    icon: Luggage,
    step: "03",
    title: "Luggage Assistance",
    desc: "Door-to-door service with full luggage handling. Your chauffeur loads, transports, and unloads every bag so you can step out and walk straight into your destination.",
  },
];

export const AirportPickupProcess = () => {
  return (
    <section className="py-20 px-4 bg-zinc-950 relative border-t border-white/5">
      <div className="container mx-auto">
        <div className="text-center mb-14 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-5">
            <Plane className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold tracking-widest uppercase text-primary">
              How DFW & Love Field Pickups Work
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-4">
            A Stress-Free Arrival, Every Single Time
          </h2>
          <p className="text-white/60 font-light leading-relaxed text-lg">
            From the moment your flight touches down, our chauffeurs handle
            every detail so you can skip the chaos and travel like a VIP.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto relative">
          {/* Connector line */}
          <div className="hidden md:block absolute top-12 left-[16%] right-[16%] h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />

          {steps.map((s, i) => (
            <div
              key={i}
              className="relative bg-zinc-900/40 border border-white/10 p-8 rounded-xl group hover:border-primary/40 transition-colors duration-500"
            >
              <div className="flex items-center gap-4 mb-5">
                <div className="w-12 h-12 bg-primary/10 border border-primary/30 flex items-center justify-center rounded-lg shrink-0 group-hover:bg-primary/20 transition-colors">
                  <s.icon className="w-6 h-6 text-primary" />
                </div>
                <span className="text-4xl font-serif font-bold text-white/10 group-hover:text-primary/30 transition-colors">
                  {s.step}
                </span>
              </div>
              <h3 className="text-xl font-serif font-bold text-white mb-3">
                {s.title}
              </h3>
              <p className="text-white/60 font-light leading-relaxed text-sm">
                {s.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

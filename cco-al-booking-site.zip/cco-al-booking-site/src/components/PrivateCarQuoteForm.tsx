import { useState, useMemo, useRef } from "react";
import {
  Calendar,
  Clock,
  CheckCircle2,
  MapPin,
  Users,
  Phone as PhoneIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import {
  parsePhoneNumberFromString,
  getCountries,
  getCountryCallingCode,
  type CountryCode,
} from "libphonenumber-js";
import { postTrackingEvent, CRM_CONFIG, getGclid } from "@/lib/formTracking";

type TripType = "One Way" | "Round Trip" | "Hourly";

type PrivateCarQuoteFormProps = {
  /** stable slug used in the tracking formId */
  formIdPrefix: string;
  /** human-readable label shown in CRM workflows */
  formNamePrefix: string;
  defaultTripType?: TripType;
  /** when true, only shows the Hourly option (no tabs) */
  hourlyOnly?: boolean;
  /** optional heading/subheading shown above the tabs */
  heading?: string;
  subheading?: string;
};

const getTrackingSessionId = () => {
  try {
    const sid = document.cookie.match(
      /(?:^|;\s*)__vibe_sid=([0-9a-f-]{36})(?:;|$)/,
    )?.[1];
    if (sid) return sid;
  } catch {}
  return crypto.randomUUID();
};

export const PrivateCarQuoteForm = ({
  formIdPrefix,
  formNamePrefix,
  defaultTripType = "One Way",
  hourlyOnly = false,
  heading,
  subheading,
}: PrivateCarQuoteFormProps) => {
  const [tripType, setTripType] = useState<TripType>(
    hourlyOnly ? "Hourly" : defaultTripType,
  );

  const [phoneRaw, setPhoneRaw] = useState("");
  const [country, setCountry] = useState<CountryCode>("US");
  const [countryOpen, setCountryOpen] = useState(false);
  const [countrySearch, setCountrySearch] = useState("");

  const [pickupAddress, setPickupAddress] = useState("");
  const [dropoffAddress, setDropoffAddress] = useState("");
  const [dateOfPickup, setDateOfPickup] = useState("");
  const [timeOfPickup, setTimeOfPickup] = useState("");
  const [returnDate, setReturnDate] = useState("");
  const [returnTime, setReturnTime] = useState("");
  const [returnPickupAddress, setReturnPickupAddress] = useState("");
  const [returnDropoffAddress, setReturnDropoffAddress] = useState("");
  const [passengers, setPassengers] = useState("");
  const dateInputRef = useRef<HTMLInputElement>(null);
  const returnDateRef = useRef<HTMLInputElement>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const countries = useMemo(
    () =>
      getCountries()
        .map((c: CountryCode) => {
          let name: string = c;
          try {
            name = new Intl.DisplayNames(["en"], { type: "region" }).of(c) || c;
          } catch {}
          return {
            c,
            name,
            dial: `+${getCountryCallingCode(c)}`,
          };
        })
        .sort((a, b) => a.name.localeCompare(b.name)),
    [],
  );

  const parsedPhone = useMemo(
    () => parsePhoneNumberFromString(phoneRaw, country),
    [phoneRaw, country],
  );

  const validate = () => {
    if (!phoneRaw.trim()) {
      setErrorMessage("Please enter your phone number.");
      return false;
    }
    if (!dateOfPickup) {
      setErrorMessage("Please select a date of pickup.");
      return false;
    }
    if (!timeOfPickup.trim()) {
      setErrorMessage("Please enter a pickup time.");
      return false;
    }
    if (!passengers.trim()) {
      setErrorMessage("Please enter the number of passengers.");
      return false;
    }
    if (tripType !== "Hourly" && !pickupAddress.trim()) {
      setErrorMessage("Please enter a pickup address.");
      return false;
    }
    if (tripType === "One Way" && !dropoffAddress.trim()) {
      setErrorMessage("Please enter a drop-off address.");
      return false;
    }
    if (tripType === "Round Trip") {
      if (!returnDate) {
        setErrorMessage("Please select a return date.");
        return false;
      }
      if (!returnTime.trim()) {
        setErrorMessage("Please enter a return time.");
        return false;
      }
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    if (!validate()) return;

    setIsSubmitting(true);

    const e164Phone = parsedPhone?.format("E.164") || phoneRaw;
    const formSlug = hourlyOnly
      ? formIdPrefix
      : `${formIdPrefix}-${tripType.toLowerCase().replace(" ", "-")}`;
    const formName = hourlyOnly
      ? `${formNamePrefix} Hourly`
      : `${formNamePrefix} ${tripType}`;

    const trackingPayload = {
      type: "external_form_submission" as const,
      timestamp: Date.now(),
      formId: formSlug,
      formData: {
        first_name: "",
        last_name: "",
        email: "",
        phone: e164Phone,
      },
      formLabels: {
        first_name: "First Name",
        last_name: "Last Name",
        email: "Email",
        phone: "Phone",
      },
      url: window.location.href,
      title: document.title,
      path: window.location.pathname,
      userAgent: navigator.userAgent,
      trackingId: CRM_CONFIG.trackingId,
      locationId: CRM_CONFIG.locationId,
      projectId: CRM_CONFIG.projectId,
      sessionId: getTrackingSessionId(),
      properties: {
        deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent)
          ? "mobile"
          : "desktop",
        source: "ai_studio",
        projectId: CRM_CONFIG.projectId,
        formName,
      },
    };

    try {
      await postTrackingEvent(trackingPayload, {
        customFields: {
          mL0dRw8WiUILXYINqTje: { value: tripType, label: "Trip Type" },
          tGgdaZWV1LMrV8efnse9: {
            value: pickupAddress || undefined,
            label: "Initial Pickup Address",
          },
          NrpBGSUrEPwUnkPvdt9T: {
            value:
              tripType === "Hourly" ? undefined : dropoffAddress || undefined,
            label: "Initial Drop Off Address",
          },
          RLseVtL867s9RRWzmZAl: {
            value: dateOfPickup,
            label: "Date of Pickup",
          },
          GAcplVGT6Y5CzLdh5sgD: {
            value: timeOfPickup,
            label: "Time of Pickup",
          },
          RjRvUbmVvhOLRcybr0ef: {
            value: tripType === "Round Trip" ? returnDate : undefined,
            label: "Return Date of Pickup",
          },
          Dbs1liDJNus890c3ZqLJ: {
            value: tripType === "Round Trip" ? returnTime : undefined,
            label: "Return Time of Pickup",
          },
          mnwPfv8kzcJpHhfRE3Na: {
            value:
              tripType === "Round Trip"
                ? returnPickupAddress || undefined
                : undefined,
            label: "Return Pickup Address",
          },
          ERMDPmChU9wDouonlNvZ: {
            value:
              tripType === "Round Trip"
                ? returnDropoffAddress || undefined
                : undefined,
            label: "Return Dropoff Address",
          },
          L3hnJfT44Qg3EYZL7j1v: {
            value: passengers
              ? parseInt(passengers, 10) || passengers
              : undefined,
            label: "How Many Passengers",
          },
          contact_gclid: {
            value: getGclid(),
            label: "GCLID",
          },
        },
      });

      if (typeof (window as any).gtag_report_conversion === "function") {
        (window as any).gtag_report_conversion();
      }

      setIsSubmitted(true);
    } catch (err) {
      console.error("Form submit error:", err);
      if (typeof (window as any).gtag_report_conversion === "function") {
        (window as any).gtag_report_conversion();
      }
      setIsSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  const inputClass =
    "w-full rounded-md bg-[#544f4e] border border-amber-500/50 px-3 py-2 text-sm text-white placeholder-white/40 focus:outline-none focus:border-amber-400";
  const labelClass =
    "block text-[11px] font-serif text-white/90 mb-1 font-medium";

  const DateField = ({
    label,
    value,
    onChange,
    inputRef,
  }: {
    label: string;
    value: string;
    onChange: (v: string) => void;
    inputRef: React.RefObject<HTMLInputElement>;
  }) => (
    <div>
      <label className={labelClass}>
        {label} <span className="text-primary">*</span>
      </label>
      <div
        className="relative rounded-md bg-[#544f4e] border border-amber-500/50 flex items-center cursor-pointer"
        onClick={() => {
          const input = inputRef.current;
          if (!input) return;
          try {
            input.focus();
            input.showPicker();
          } catch (e) {
            console.error("Date picker error:", e);
          }
        }}
      >
        <Calendar className="w-4 h-4 ml-3 text-white/60 shrink-0 pointer-events-none" />
        <input
          ref={inputRef}
          type="date"
          required
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-transparent px-3 py-2 text-sm text-white placeholder-white/40 focus:outline-none cursor-pointer"
          style={{ colorScheme: "dark" }}
        />
      </div>
    </div>
  );

  return (
    <div className="w-full">
      {(heading || subheading) && (
        <div className="text-center mb-3">
          {heading && (
            <h4 className="text-lg lg:text-xl font-serif font-bold text-white mb-0.5">
              {heading}
            </h4>
          )}
          {subheading && (
            <p className="text-white/60 font-light text-center text-xs lg:text-sm">
              {subheading}
            </p>
          )}
        </div>
      )}

      {/* Trip Type Tabs */}
      {!hourlyOnly && (
        <div className="flex gap-2 mb-4">
          {(["One Way", "Round Trip", "Hourly"] as TripType[]).map((type) => (
            <button
              key={type}
              type="button"
              onClick={() => setTripType(type)}
              className={`flex-1 py-2 px-3 text-xs font-semibold tracking-wide uppercase transition-all duration-300 rounded-none ${
                tripType === type
                  ? "bg-primary text-black border border-primary"
                  : "bg-transparent text-white/50 border border-white/20 hover:border-white/40 hover:text-white"
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      )}

      {isSubmitted ? (
        <div className="flex flex-col items-center justify-center py-10 px-4 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center text-primary shadow-[0_0_20px_rgba(212,175,55,0.3)]">
            <CheckCircle2 className="w-9 h-9" />
          </div>
          <h4 className="text-xl font-bold text-white font-serif">
            Quote Request Received!
          </h4>
          <p className="text-zinc-300 text-sm max-w-sm leading-relaxed">
            Thank you! Our dispatch team is reviewing your{" "}
            {tripType.toLowerCase()} request and will reach out with your exact
            quote shortly.
          </p>
          <p className="text-xs text-zinc-400">
            Need instant confirmation? Call{" "}
            <a
              href="tel:9726083680"
              className="text-primary underline font-bold"
            >
              972-608-3680
            </a>
          </p>
          <Button
            onClick={() => {
              setIsSubmitted(false);
              setPhoneRaw("");
              setPickupAddress("");
              setDropoffAddress("");
              setReturnPickupAddress("");
              setReturnDropoffAddress("");
            }}
            variant="outline"
            className="mt-4 border-zinc-700 text-white hover:bg-zinc-800"
          >
            Submit Another Quote
          </Button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {errorMessage && (
            <div className="p-2.5 rounded-lg bg-red-500/15 border border-red-500/30 text-red-300 text-xs font-medium">
              {errorMessage}
            </div>
          )}

          {/* Phone */}
          <div>
            <label className={labelClass}>
              Phone <span className="text-primary">*</span>
            </label>
            <div className="relative flex rounded-md bg-[#544f4e] border border-amber-500/50 shadow-inner overflow-visible">
              <button
                type="button"
                aria-haspopup="listbox"
                aria-expanded={countryOpen}
                onClick={() => setCountryOpen((o) => !o)}
                className="flex items-center gap-1.5 px-2.5 py-2 text-xs text-white/90 hover:bg-white/5 border-r border-white/10 shrink-0"
              >
                <span className="text-sm">
                  {country === "US"
                    ? "🇺🇸"
                    : country === "CA"
                      ? "🇨🇦"
                      : country === "MX"
                        ? "🇲🇽"
                        : country === "GB"
                          ? "🇬🇧"
                          : "🌐"}
                </span>
                <span className="text-[11px] font-mono text-white/80">
                  +{getCountryCallingCode(country)}
                </span>
                <span className="text-[9px] text-white/40">▼</span>
              </button>

              {countryOpen && (
                <div
                  role="listbox"
                  className="absolute left-0 top-full mt-1 z-50 w-64 max-h-56 overflow-y-auto rounded-md border border-zinc-700 bg-zinc-900 shadow-2xl p-1"
                >
                  <input
                    autoFocus
                    placeholder="Search country..."
                    value={countrySearch}
                    onChange={(e) => setCountrySearch(e.target.value)}
                    className="w-full px-2.5 py-1.5 mb-1 text-xs rounded bg-zinc-800 border border-zinc-700 text-white placeholder-zinc-500 focus:outline-none focus:border-primary"
                  />
                  {countries
                    .filter(
                      (x) =>
                        x.name
                          .toLowerCase()
                          .includes(countrySearch.toLowerCase()) ||
                        x.dial.includes(countrySearch),
                    )
                    .map((x) => (
                      <div
                        key={x.c}
                        role="option"
                        aria-selected={x.c === country}
                        onClick={() => {
                          setCountry(x.c);
                          setCountryOpen(false);
                          setCountrySearch("");
                        }}
                        className={`px-2 py-1.5 text-xs rounded cursor-pointer flex items-center justify-between hover:bg-zinc-800 ${
                          x.c === country
                            ? "bg-primary/20 text-primary font-bold"
                            : "text-zinc-200"
                        }`}
                      >
                        <span className="truncate">{x.name}</span>
                        <span className="text-zinc-400 font-mono ml-2 shrink-0">
                          {x.dial}
                        </span>
                      </div>
                    ))}
                </div>
              )}

              <input
                type="tel"
                name="phone"
                required
                placeholder="Phone"
                value={phoneRaw}
                onChange={(e) => setPhoneRaw(e.target.value)}
                className="w-full bg-transparent px-3 py-2 text-sm text-white placeholder-white/40 focus:outline-none"
              />
            </div>
          </div>

          {/* Pickup Address */}
          <div>
            <label className={labelClass}>
              {tripType === "Hourly" ? "Pickup Address" : "Pickup Address"}{" "}
              {tripType !== "Hourly" && <span className="text-primary">*</span>}
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none" />
              <input
                type="text"
                placeholder="Pickup address"
                value={pickupAddress}
                onChange={(e) => setPickupAddress(e.target.value)}
                className={`${inputClass} pl-9`}
              />
            </div>
          </div>

          {/* Dropoff Address (not for Hourly) */}
          {tripType !== "Hourly" && (
            <div>
              <label className={labelClass}>
                Drop-off Address <span className="text-primary">*</span>
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none" />
                <input
                  type="text"
                  placeholder="Drop-off address"
                  value={dropoffAddress}
                  onChange={(e) => setDropoffAddress(e.target.value)}
                  className={`${inputClass} pl-9`}
                />
              </div>
            </div>
          )}

          {/* Date & Time row */}
          <div className="grid grid-cols-2 gap-3">
            <DateField
              label="Date"
              value={dateOfPickup}
              onChange={setDateOfPickup}
              inputRef={dateInputRef}
            />
            <div>
              <label className={labelClass}>
                Time <span className="text-primary">*</span>
              </label>
              <div className="relative">
                <Clock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none" />
                <input
                  type="text"
                  required
                  placeholder="e.g. 7:00 PM"
                  value={timeOfPickup}
                  onChange={(e) => setTimeOfPickup(e.target.value)}
                  className={`${inputClass} pl-9`}
                />
              </div>
            </div>
          </div>

          {/* Round Trip return fields */}
          {tripType === "Round Trip" && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <DateField
                  label="Return Date"
                  value={returnDate}
                  onChange={setReturnDate}
                  inputRef={returnDateRef}
                />
                <div>
                  <label className={labelClass}>
                    Return Time <span className="text-primary">*</span>
                  </label>
                  <div className="relative">
                    <Clock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none" />
                    <input
                      type="text"
                      placeholder="e.g. 10:00 PM"
                      value={returnTime}
                      onChange={(e) => setReturnTime(e.target.value)}
                      className={`${inputClass} pl-9`}
                    />
                  </div>
                </div>
              </div>
              <div>
                <label className={labelClass}>Return Pickup Address</label>
                <div className="relative">
                  <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="Return pickup (optional)"
                    value={returnPickupAddress}
                    onChange={(e) => setReturnPickupAddress(e.target.value)}
                    className={`${inputClass} pl-9`}
                  />
                </div>
              </div>
              <div>
                <label className={labelClass}>Return Drop-off Address</label>
                <div className="relative">
                  <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="Return drop-off (optional)"
                    value={returnDropoffAddress}
                    onChange={(e) => setReturnDropoffAddress(e.target.value)}
                    className={`${inputClass} pl-9`}
                  />
                </div>
              </div>
            </>
          )}

          {/* Passengers */}
          <div>
            <label className={labelClass}>
              Passengers <span className="text-primary">*</span>
            </label>
            <div className="relative">
              <Users className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none" />
              <input
                type="number"
                min="1"
                max="40"
                required
                placeholder="Number of passengers"
                value={passengers}
                onChange={(e) => setPassengers(e.target.value)}
                className={`${inputClass} pl-9`}
              />
            </div>
          </div>

          {/* Submit */}
          <div className="pt-1">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full h-11 bg-amber-500 hover:bg-amber-400 text-black font-semibold text-base rounded-lg transition-colors shadow-lg"
            >
              {isSubmitting ? "Submitting..." : "Get a Quote"}
            </Button>
          </div>
        </form>
      )}

      <p className="text-[10px] text-white/40 text-center font-light mt-3">
        Booking for your company?{" "}
        <Link
          to="/corporate"
          className="text-primary hover:text-primary/80 underline underline-offset-2"
        >
          Set up a business account
        </Link>
      </p>
    </div>
  );
};

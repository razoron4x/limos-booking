import { useState, useMemo, useRef } from "react";
import {
  Phone as PhoneIcon,
  Clock,
  Calendar,
  CheckCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import {
  parsePhoneNumberFromString,
  getCountries,
  getCountryCallingCode,
  type CountryCode,
} from "libphonenumber-js";
import { postTrackingEvent, CRM_CONFIG, getGclid } from "@/lib/formTracking";

const LIMO_OPTIONS = [
  "Hummer Limo",
  "Sprinter Limo",
  "Stretch Limo",
  "Executive SUV",
];

const getTrackingSessionId = () => {
  try {
    const sid = document.cookie.match(
      /(?:^|;\s*)__vibe_sid=([0-9a-f-]{36})(?:;|$)/,
    )?.[1];
    if (sid) return sid;
  } catch {}
  return crypto.randomUUID();
};

export const HalloweenQuoteForm = () => {
  const [phoneRaw, setPhoneRaw] = useState("");
  const [country, setCountry] = useState<CountryCode>("US");
  const [countryOpen, setCountryOpen] = useState(false);
  const [countrySearch, setCountrySearch] = useState("");

  const [limoChoice, setLimoChoice] = useState("");
  const [dateOfPickup, setDateOfPickup] = useState("");
  const [timeOfPickup, setTimeOfPickup] = useState("");
  const [passengers, setPassengers] = useState("");
  const [whereTo, setWhereTo] = useState("");
  const dateInputRef = useRef<HTMLInputElement>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const countries = useMemo(
    () =>
      getCountries()
        .map((c: CountryCode) => {
          let name: string = c;
          try {
            name = new Intl.DisplayNames(["en"], { type: "region" }).of(c) || c;
          } catch {}
          return {
            c,
            name,
            dial: `+${getCountryCallingCode(c)}`,
          };
        })
        .sort((a, b) => a.name.localeCompare(b.name)),
    [],
  );

  const parsedPhone = useMemo(() => {
    return parsePhoneNumberFromString(phoneRaw, country);
  }, [phoneRaw, country]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");

    if (!phoneRaw.trim()) {
      setErrorMessage("Please enter your phone number.");
      return;
    }
    if (!dateOfPickup) {
      setErrorMessage("Please select a date of pickup.");
      return;
    }
    if (!timeOfPickup.trim()) {
      setErrorMessage("Please enter your pickup time.");
      return;
    }
    if (!passengers.trim()) {
      setErrorMessage("Please enter the number of passengers.");
      return;
    }

    setIsSubmitting(true);

    const e164Phone = parsedPhone?.format("E.164") || phoneRaw;

    const trackingPayload = {
      type: "external_form_submission",
      timestamp: Date.now(),
      formId: "halloween-quote-form",
      formData: {
        first_name: "",
        last_name: "",
        email: "",
        phone: e164Phone,
      },
      formLabels: {
        first_name: "First Name",
        last_name: "Last Name",
        email: "Email",
        phone: "Phone",
      },
      url: window.location.href,
      title: document.title,
      path: window.location.pathname,
      userAgent: navigator.userAgent,
      trackingId: CRM_CONFIG.trackingId,
      locationId: CRM_CONFIG.locationId,
      projectId: CRM_CONFIG.projectId,
      sessionId: getTrackingSessionId(),
      properties: {
        deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent)
          ? "mobile"
          : "desktop",
        source: "ai_studio",
        projectId: CRM_CONFIG.projectId,
        formName: "Halloween Hourly",
      },
    };

    try {
      await postTrackingEvent(trackingPayload, {
        customFields: {
          WBeTXKwHHjrTePkzdnJ7: {
            value: limoChoice || undefined,
            label: "Limo Choice",
          },
          RLseVtL867s9RRWzmZAl: {
            value: dateOfPickup,
            label: "Date of Pickup",
          },
          GAcplVGT6Y5CzLdh5sgD: {
            value: timeOfPickup,
            label: "Time of Pickup",
          },
          gvJbN7Eh9CFBXqznJfzu: {
            value: passengers
              ? parseInt(passengers, 10) || passengers
              : undefined,
            label: "Passengers",
          },
          XdA98kgnh1JrcuU6PV7R: {
            value: whereTo || undefined,
            label: "Where To",
          },
          contact_gclid: {
            value: getGclid(),
            label: "GCLID",
          },
        },
      });

      if (typeof (window as any).gtag_report_conversion === "function") {
        (window as any).gtag_report_conversion();
      }

      setIsSubmitted(true);
    } catch (err) {
      console.error("Form submit error:", err);
      if (typeof (window as any).gtag_report_conversion === "function") {
        (window as any).gtag_report_conversion();
      }
      setIsSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-12 lg:py-16 px-4 bg-[#0d0d0d] border-b border-white/5">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 lg:gap-12 items-stretch">
          {/* Left - Headline + CTA with bg image (exact original height restored) */}
          <div className="relative lg:h-full">
            <div className="relative rounded-t-2xl rounded-b-none lg:rounded-xl overflow-hidden h-[150px] sm:h-[180px] lg:h-full lg:min-h-[575px] lg:absolute lg:inset-x-0 lg:top-0 lg:bottom-[0px] border border-primary/20 border-b-0 lg:border-none">
              {/* Background Image */}
              <div className="absolute inset-0 z-0">
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/assets/96db13e2-7587-4911-9810-85beb13814e9.png"
                  alt="White H2 Hummer stretch limo at a three-quarter angle outside a Dallas Halloween night gala entrance with orange uplighting and jack-o'-lanterns"
                  className="w-full h-full object-cover object-bottom opacity-90"
                  loading="lazy"
                />
                <div
                  className="absolute inset-0"
                  style={{
                    background:
                      "radial-gradient(circle at 50% 100%, rgba(24,24,27,0.05) 0%, rgba(24,24,27,0.35) 50%, rgba(24,24,27,0.8) 80%, #18181b 100%)",
                  }}
                ></div>
                <div className="absolute inset-0 bg-gradient-to-b from-zinc-900/70 via-zinc-900/35 to-transparent"></div>
              </div>

              {/* Content */}
              <div className="relative z-10 flex flex-col justify-start h-full p-4 sm:p-5 lg:p-8 pt-6 lg:pt-7 space-y-2 lg:space-y-5">
                <div className="hidden lg:inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/15 border border-primary/30 backdrop-blur-sm self-start">
                  <span className="text-xs font-bold tracking-widest uppercase text-primary">
                    Reserve Your Ride
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl md:text-4xl lg:text-5xl font-serif font-bold text-white leading-[1.15] drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]">
                  Halloween Night
                  <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-yellow-400 to-primary">
                    Quote in Seconds
                  </span>
                </h2>
                <p className="hidden lg:block text-white font-semibold leading-relaxed text-lg max-w-md drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]">
                  Instant hourly pricing for costume galas, haunted nights out,
                  and every DFW Halloween event.
                </p>
                <div className="hidden lg:flex flex-col sm:flex-row gap-2.5 lg:gap-4 sm:max-w-md">
                  <Link
                    to="/quote?service=Halloween%20Limo%20Service"
                    className="w-full sm:flex-1"
                  >
                    <Button className="w-full h-14 bg-gradient-to-b from-yellow-500 via-primary to-yellow-600 text-black hover:from-yellow-400 hover:via-yellow-500 hover:to-yellow-500 text-base font-bold rounded-none shadow-[0_0_25px_rgba(212,175,55,0.3)] border border-yellow-400/40">
                      Book Your Ride
                    </Button>
                  </Link>
                  <a
                    href="tel:9726083680"
                    onClick={() => (window as any).gtag_report_conversion?.()}
                    className="w-full sm:flex-1"
                  >
                    <Button
                      variant="outline"
                      className="w-full h-14 border-white/30 text-white hover:bg-white/10 text-base rounded-none bg-white/10 backdrop-blur-sm relative overflow-hidden group/call font-bold"
                    >
                      <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent translate-x-[-150%] group-hover/call:translate-x-[150%] transition-transform duration-700 ease-out"></span>
                      <span className="relative z-10 flex items-center justify-center">
                        <PhoneIcon className="w-5 h-5 mr-2" />
                        972-608-3680
                      </span>
                    </Button>
                  </a>
                </div>
                <div className="hidden lg:flex flex-wrap gap-x-6 gap-y-2 pt-2 text-sm text-white font-bold drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]">
                  <span>4-hr minimum</span>
                  <span className="text-primary/70">|</span>
                  <span>Flat-rate pricing</span>
                  <span className="text-primary/70">|</span>
                  <span>Groups up to 18</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right - Custom Form (matches exact 525px height of football/homecoming) */}
          <div className="relative bg-zinc-800 border border-zinc-700 rounded-b-2xl rounded-t-none lg:rounded-2xl overflow-hidden w-full shadow-2xl">
            {/* Gold accent stripe */}
            <div className="h-1.5 w-full bg-gradient-to-r from-yellow-600 via-primary to-yellow-600"></div>

            {/* Headline Area */}
            <div className="flex items-center justify-center gap-2 pt-5 pb-2.5 px-4">
              <Clock className="w-4 h-4 text-primary shrink-0" />
              <div className="text-center">
                <h3 className="text-sm sm:text-base font-bold tracking-widest uppercase text-white leading-tight">
                  Hourly Booking
                </h3>
                <p className="text-[11px] sm:text-xs text-white/40 font-light">
                  Flat-rate group pricing &middot; 4-hr minimum
                </p>
              </div>
            </div>
            <div className="h-px w-full bg-white/5"></div>

            <div className="px-4 pb-5 pt-2 sm:px-5 sm:pb-6 sm:pt-2.5">
              <div className="w-full space-y-4">
                {isSubmitted ? (
                  <div className="flex flex-col items-center justify-center py-12 px-4 text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center text-primary shadow-[0_0_20px_rgba(212,175,55,0.3)]">
                      <CheckCircle2 className="w-9 h-9" />
                    </div>
                    <h4 className="text-xl font-bold text-white font-serif">
                      Quote Request Received!
                    </h4>
                    <p className="text-zinc-300 text-sm max-w-sm leading-relaxed">
                      Thank you! Our dispatch team is reviewing your Halloween
                      hourly request and will reach out with your exact quote
                      shortly.
                    </p>
                    <p className="text-xs text-zinc-400">
                      Need instant confirmation? Call{" "}
                      <a
                        href="tel:9726083680"
                        className="text-primary underline font-bold"
                      >
                        972-608-3680
                      </a>
                    </p>
                    <Button
                      onClick={() => {
                        setIsSubmitted(false);
                        setPhoneRaw("");
                        setWhereTo("");
                      }}
                      variant="outline"
                      className="mt-4 border-zinc-700 text-white hover:bg-zinc-800"
                    >
                      Submit Another Quote
                    </Button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4 pb-2">
                    {errorMessage && (
                      <div className="p-2.5 rounded-lg bg-red-500/15 border border-red-500/30 text-red-300 text-xs font-medium">
                        {errorMessage}
                      </div>
                    )}

                    {/* Phone */}
                    <div>
                      <label className="block text-[11px] font-serif text-white/90 mb-1 font-medium">
                        Phone <span className="text-primary">*</span>
                      </label>
                      <div className="relative flex rounded-md bg-[#544f4e] border border-amber-500/50 shadow-inner overflow-visible">
                        <button
                          type="button"
                          aria-haspopup="listbox"
                          aria-expanded={countryOpen}
                          onClick={() => setCountryOpen((o) => !o)}
                          className="flex items-center gap-1.5 px-2.5 py-2 text-xs text-white/90 hover:bg-white/5 border-r border-white/10 shrink-0"
                        >
                          <span className="text-sm">
                            {country === "US"
                              ? "🇺🇸"
                              : country === "CA"
                                ? "🇨🇦"
                                : country === "MX"
                                  ? "🇲🇽"
                                  : country === "GB"
                                    ? "🇬🇧"
                                    : "🌐"}
                          </span>
                          <span className="text-[11px] font-mono text-white/80">
                            +{getCountryCallingCode(country)}
                          </span>
                          <span className="text-[9px] text-white/40">▼</span>
                        </button>

                        {countryOpen && (
                          <div
                            role="listbox"
                            className="absolute left-0 top-full mt-1 z-50 w-64 max-h-56 overflow-y-auto rounded-md border border-zinc-700 bg-zinc-900 shadow-2xl p-1"
                          >
                            <input
                              autoFocus
                              placeholder="Search country..."
                              value={countrySearch}
                              onChange={(e) => setCountrySearch(e.target.value)}
                              className="w-full px-2.5 py-1.5 mb-1 text-xs rounded bg-zinc-800 border border-zinc-700 text-white placeholder-zinc-500 focus:outline-none focus:border-primary"
                            />
                            {countries
                              .filter(
                                (x) =>
                                  x.name
                                    .toLowerCase()
                                    .includes(countrySearch.toLowerCase()) ||
                                  x.dial.includes(countrySearch),
                              )
                              .map((x) => (
                                <div
                                  key={x.c}
                                  role="option"
                                  aria-selected={x.c === country}
                                  onClick={() => {
                                    setCountry(x.c);
                                    setCountryOpen(false);
                                    setCountrySearch("");
                                  }}
                                  className={`px-2 py-1.5 text-xs rounded cursor-pointer flex items-center justify-between hover:bg-zinc-800 ${
                                    x.c === country
                                      ? "bg-primary/20 text-primary font-bold"
                                      : "text-zinc-200"
                                  }`}
                                >
                                  <span className="truncate">{x.name}</span>
                                  <span className="text-zinc-400 font-mono ml-2 shrink-0">
                                    {x.dial}
                                  </span>
                                </div>
                              ))}
                          </div>
                        )}

                        <input
                          type="tel"
                          name="phone"
                          required
                          placeholder="Phone"
                          value={phoneRaw}
                          onChange={(e) => setPhoneRaw(e.target.value)}
                          className="w-full bg-transparent px-3 py-2 text-sm text-white placeholder-white/40 focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Limo Choice */}
                    <div>
                      <label className="block text-[11px] font-serif text-white/90 mb-1 font-medium">
                        Limo Choice
                      </label>
                      <div className="relative">
                        <select
                          value={limoChoice}
                          onChange={(e) => setLimoChoice(e.target.value)}
                          className="w-full rounded-md bg-[#544f4e] border border-amber-500/50 px-3 py-2 text-sm text-white appearance-none focus:outline-none focus:border-amber-400"
                        >
                          <option
                            value=""
                            className="bg-zinc-800 text-white/60"
                          >
                            Select a limo (optional)
                          </option>
                          {LIMO_OPTIONS.map((opt) => (
                            <option
                              key={opt}
                              value={opt}
                              className="bg-zinc-800 text-white"
                            >
                              {opt}
                            </option>
                          ))}
                        </select>
                        <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-white/60">
                          ▼
                        </span>
                      </div>
                    </div>

                    {/* Date of Pickup */}
                    <div>
                      <label className="block text-[11px] font-serif text-white/90 mb-1 font-medium">
                        Date of Pickup <span className="text-primary">*</span>
                      </label>
                      <div
                        className="relative rounded-md bg-[#544f4e] border border-amber-500/50 flex items-center cursor-pointer"
                        onClick={() => {
                          const input = dateInputRef.current;
                          if (!input) return;
                          try {
                            input.focus();
                            input.showPicker();
                          } catch (e) {
                            console.error("Date picker error:", e);
                          }
                        }}
                      >
                        <Calendar className="w-4 h-4 ml-3 text-white/60 shrink-0 pointer-events-none" />
                        <input
                          ref={dateInputRef}
                          type="date"
                          required
                          value={dateOfPickup}
                          onChange={(e) => setDateOfPickup(e.target.value)}
                          className="w-full bg-transparent px-3 py-2 text-sm text-white placeholder-white/40 focus:outline-none cursor-pointer"
                          style={{ colorScheme: "dark" }}
                        />
                      </div>
                    </div>

                    {/* Time of Pickup */}
                    <div>
                      <label className="block text-[11px] font-serif text-white/90 mb-1 font-medium">
                        Time of Pickup <span className="text-primary">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 7:00 PM"
                        value={timeOfPickup}
                        onChange={(e) => setTimeOfPickup(e.target.value)}
                        className="w-full rounded-md bg-[#544f4e] border border-amber-500/50 px-3 py-2 text-sm text-white placeholder-white/40 focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    {/* Passengers */}
                    <div>
                      <label className="block text-[11px] font-serif text-white/90 mb-1 font-medium">
                        Passengers <span className="text-primary">*</span>
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="40"
                        required
                        placeholder="Number of guests"
                        value={passengers}
                        onChange={(e) => setPassengers(e.target.value)}
                        className="w-full rounded-md bg-[#544f4e] border border-amber-500/50 px-3 py-2 text-sm text-white placeholder-white/40 focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    {/* Where To */}
                    <div>
                      <label className="block text-[11px] font-serif text-white/90 mb-1 font-medium">
                        Where To
                      </label>
                      <input
                        type="text"
                        placeholder="Pickup Address"
                        value={whereTo}
                        onChange={(e) => setWhereTo(e.target.value)}
                        className="w-full rounded-md bg-[#544f4e] border border-amber-500/50 px-3 py-2 text-sm text-white placeholder-white/40 focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    {/* Submit Button */}
                    <div className="pt-3">
                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full h-11 bg-amber-500 hover:bg-amber-400 text-black font-semibold text-base rounded-lg transition-colors shadow-lg"
                      >
                        {isSubmitting ? "Submitting..." : "Get a Quote"}
                      </Button>
                    </div>
                  </form>
                )}
              </div>

              <p className="text-[10px] text-white/40 text-center font-light mt-3">
                Booking for your company?{" "}
                <Link
                  to="/corporate"
                  className="text-primary hover:text-primary/80 underline underline-offset-2"
                >
                  Set up a business account
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

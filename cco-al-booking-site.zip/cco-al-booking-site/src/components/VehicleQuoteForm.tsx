import { useEffect, useRef, useState } from "react";

type VehicleQuoteFormProps = {
  formId: string;
  formName: string;
  dataHeight: number;
  title: string;
  containerHeight?: string;
  heading?: string;
  subheading?: string;
};

export const VehicleQuoteForm = ({
  formId,
  formName,
  dataHeight,
  title,
  containerHeight = "560px",
  heading = "Get an Hourly Quote",
  subheading = "Reserve this vehicle by the hour for your next event or transfer.",
}: VehicleQuoteFormProps) => {
  const scriptRef = useRef<HTMLScriptElement | null>(null);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(max-width: 1023px)");
    const update = () => setIsMobile(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);

  useEffect(() => {
    if (
      document.querySelector(
        'script[src="https://link.dreamsapi.com/js/form_embed.js"]',
      )
    ) {
      return;
    }
    const s = document.createElement("script");
    s.src = "https://link.dreamsapi.com/js/form_embed.js";
    s.async = true;
    document.body.appendChild(s);
    scriptRef.current = s;
  }, []);

  const iframeId = `inline-${formId}-vehicle`;

  return (
    <div className="bg-zinc-800 border border-zinc-700 p-4 lg:p-5 rounded-2xl overflow-hidden pb-[36px] lg:pb-5">
      <h4 className="text-lg lg:text-xl font-serif font-bold text-white mb-0.5 text-center">
        {heading}
      </h4>
      <p className="text-white/60 mb-3 lg:mb-5 font-light text-center text-xs lg:text-sm">
        {subheading}
      </p>
      <div
        className="w-full rounded-lg overflow-hidden"
        style={{ height: isMobile ? "660px" : containerHeight }}
      >
        <iframe
          src={`https://link.dreamsapi.com/widget/form/${formId}`}
          style={{
            width: "100%",
            height: "100%",
            border: "none",
            borderRadius: "4px",
            display: "block",
          }}
          id={iframeId}
          data-layout="{'id':'INLINE'}"
          data-trigger-type="alwaysShow"
          data-trigger-value=""
          data-activation-type="alwaysActivated"
          data-activation-value=""
          data-deactivation-type="neverDeactivate"
          data-deactivation-value=""
          data-form-name={formName}
          data-height={String(dataHeight)}
          data-layout-iframe-id={iframeId}
          data-form-id={formId}
          data-cookie-consent="true"
          data-cookie-consent-provider="auto"
          title={title}
        />
      </div>
    </div>
  );
};

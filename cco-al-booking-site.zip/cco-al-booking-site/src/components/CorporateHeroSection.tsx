import { Button } from "@/components/ui/button";
import { Clock, Shield, FileText, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export const CorporateHeroSection = () => {
  return (
    <section className="relative min-h-[85vh] flex items-center pt-32 pb-16 overflow-hidden bg-zinc-950">
      {/* Dark executive hero background image with subtle overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://vibe.filesafe.space/1792719026995615993/attachments/105ccb92-8123-4ed8-84a9-4418d97c9941.webp"
          alt="Corporate executive chauffeur service in Dallas-Fort Worth"
          className="w-full h-full object-cover opacity-40 scale-105"
          fetchPriority="high"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/85 to-zinc-950/40"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-zinc-950/70"></div>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,rgba(212,175,55,0.12),transparent_50%)]"></div>
      </div>

      <div className="container relative z-10 mx-auto px-4">
        <div className="max-w-3xl">
          {/* Trust Badges */}
          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 mb-8">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-zinc-900/90 border border-primary/40 backdrop-blur-md rounded-md shadow-md">
              <Clock className="w-3.5 h-3.5 text-primary" />
              <span className="text-[11px] font-semibold tracking-wide text-zinc-200 uppercase">
                15-Min Early Arrival
              </span>
            </div>
            <span className="text-zinc-700 hidden sm:inline">|</span>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-zinc-900/90 border border-primary/40 backdrop-blur-md rounded-md shadow-md">
              <Shield className="w-3.5 h-3.5 text-primary" />
              <span className="text-[11px] font-semibold tracking-wide text-zinc-200 uppercase">
                $1.5M+ Commercial Coverage
              </span>
            </div>
            <span className="text-zinc-700 hidden sm:inline">|</span>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-zinc-900/90 border border-primary/40 backdrop-blur-md rounded-md shadow-md">
              <FileText className="w-3.5 h-3.5 text-primary" />
              <span className="text-[11px] font-semibold tracking-wide text-zinc-200 uppercase">
                Multi Account Billing
              </span>
            </div>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif font-bold text-white leading-[1.1] mb-6 tracking-tight drop-shadow-lg">
            Executive Chauffeur <br />
            <span
              className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-500"
              style={{ WebkitBackgroundClip: "text", backgroundClip: "text" }}
            >
              Built for Business.
            </span>
          </h1>
          <p className="text-lg sm:text-xl md:text-2xl text-zinc-300 mb-10 max-w-2xl leading-relaxed font-normal drop-shadow">
            No missed flights. No last-minute scrambles. Just seamless,
            high-touch corporate travel, handled by Addison Limos.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              to="/quote?service=Corporate%20Account"
              className="w-full sm:w-auto"
              onClick={() => (window as any).gtag_report_conversion?.()}
            >
              <Button
                size="lg"
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 text-sm sm:text-lg rounded-none h-14 px-6 sm:px-8 shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all hover:shadow-[0_0_30px_rgba(212,175,55,0.6)] whitespace-nowrap"
              >
                <span className="sm:hidden">Get Quote Now</span>
                <span className="hidden sm:inline">
                  Open a Corporate Account
                </span>
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Link
              to="/quote?service=Executive%20Transport"
              className="w-full sm:w-auto"
              onClick={() => (window as any).gtag_report_conversion?.()}
            >
              <Button
                size="lg"
                variant="outline"
                className="w-full border-zinc-600 text-white hover:bg-white/10 text-base sm:text-lg rounded-none h-14 px-8 bg-zinc-900/80 backdrop-blur-md transition-all whitespace-nowrap"
              >
                Book Executive Transport
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const HalloweenExploreOptions = () => {
  return (
    <section className="py-20 lg:py-28 bg-[#0d0d0d] border-t border-white/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 lg:mb-16">
          <p className="text-xs sm:text-sm font-bold uppercase tracking-[0.2em] text-primary/80 mb-3">
            More Ways to Ride With Addison Limos.
          </p>
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4 lg:mb-6">
            Explore Other Options
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 lg:gap-5 max-w-7xl mx-auto">
          {/* Card 1: Group Nights Out */}
          <Link
            to="/service-group"
            className="md:col-span-7 relative overflow-hidden rounded-xl shadow-lg group min-h-[320px] md:min-h-[520px] lg:min-h-[540px] block"
          >
            <img
              src="https://vibe.filesafe.space/1792719026995615993/assets/2c5fd576-f767-4941-90ee-4d240434dad2.png"
              alt="Group of friends arriving in a stretch limo for a night out in downtown Dallas"
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

            <div className="absolute top-5 left-5 lg:top-8 lg:left-8">
              <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.15em] text-white/80 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                Most Booked
              </span>
            </div>

            <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-9">
              <h3 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-white mb-2 lg:mb-3 leading-tight">
                Group Nights Out
              </h3>
              <span className="inline-flex items-center gap-2 text-sm sm:text-base font-semibold text-white/90 hover:text-primary transition-colors group-hover:gap-3 duration-300">
                Explore
                <ArrowRight className="w-4 h-4" />
              </span>
            </div>
          </Link>

          {/* Right Column - Stacked */}
          <div className="md:col-span-5 flex flex-col gap-4 lg:gap-5">
            <Link
              to="/service-homecoming"
              className="relative overflow-hidden rounded-xl shadow-lg group min-h-[240px] md:min-h-[250px] lg:min-h-[270px] block"
            >
              <img
                src="https://vibe.filesafe.space/1792719026995615993/assets/ceaa1fe6-0551-4fd3-bb2c-aa6665bd3a0a.png"
                alt="Luxury stretch limo arriving for a homecoming dance drop-off at dusk"
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

              <div className="absolute top-5 left-5 lg:top-6 lg:left-6">
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.15em] text-white/80 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                  For Celebrations
                </span>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-5 lg:p-6">
                <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-2 leading-tight">
                  Homecoming Dances
                </h3>
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-white/90 hover:text-primary transition-colors group-hover:gap-3 duration-300">
                  Explore
                  <ArrowRight className="w-4 h-4" />
                </span>
              </div>
            </Link>

            <Link
              to="/service-football"
              className="relative overflow-hidden rounded-xl shadow-lg group min-h-[240px] md:min-h-[250px] lg:min-h-[270px] block"
            >
              <img
                src="https://vibe.filesafe.space/1792719026995615993/attachments/da8cb189-97a1-4aab-a770-94af37245fd4.jpg"
                alt="White H2 Hummer limo parked at AT&T Stadium for game day drop-off"
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

              <div className="absolute top-5 left-5 lg:top-6 lg:left-6">
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.15em] text-white/80 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                  For Fans
                </span>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-5 lg:p-6">
                <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-2 leading-tight">
                  Football Game Day
                </h3>
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-white/90 hover:text-primary transition-colors group-hover:gap-3 duration-300">
                  Explore
                  <ArrowRight className="w-4 h-4" />
                </span>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HalloweenExploreOptions;

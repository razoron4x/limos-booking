import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { CheckCircle2, Shield, CreditCard, Star, Phone } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

const pillars = [
  {
    icon: CheckCircle2,
    title: "Flawless Private Transport",
    desc: "No detail is too small; we manage complex logistics seamlessly 24/7, no matter the party size or event.",
  },
  {
    icon: Shield,
    title: "Highly Trained Staff",
    desc: "Experienced, punctual, and fully uniformed professional chauffeurs committed to your absolute safety.",
  },
  {
    icon: CreditCard,
    title: "Elite Online Booking",
    desc: "Effortless, transparent instant quoting with completely secure online payment channels. Professional agents are always ready to be at service.",
  },
  {
    icon: Star,
    title: "Top-Tier Vehicle Standards",
    desc: "Custom-built configurations boasting plush leather interiors, advanced climate controls, and pristine maintenance.",
  },
];

const homeReviews = [
  {
    name: "Maliha Asalati",
    text: "I have used Addison Limos twice now to transport customers to and from business dinners in the Grapevine / Coppell area. Both times the experience could not have been better! The Mercedes Sprinters were spotless and perfect.",
    rating: 5,
  },
  {
    name: "Amy O'Malley",
    text: "I have used Addison Limos twice to transport customers to and from business dinners. Both times the experience could not have been better. The Mercedes Sprinters were spotless and perfect for our groups.",
    rating: 5,
  },
  {
    name: "Andrea Woodworth",
    text: "Once again, I cannot say enough good things about Addison car and Limo service. The communication is wonderful, pricing is competitive, car was immaculate and the drivers are fantastic. Dale met me at the airport today.",
    rating: 5,
  },
];

const faqs = [
  {
    question: "What areas does Addison Limos serve?",
    answer:
      "We proudly serve the entire Dallas-Fort Worth metroplex including Dallas, Fort Worth, Addison, Plano, Frisco, Irving, Grapevine, and surrounding areas. We also provide airport transfers to DFW International, Dallas Love Field, and Addison Airport (ADS).",
  },
  {
    question: "How far in advance should I book my reservation?",
    answer:
      "We recommend booking at least 2 weeks in advance to ensure availability, especially on busy days like weekends, holidays, and major events. However, we do accommodate last-minute requests whenever our fleet allows. Call 972-608-3680 for same-day availability.",
  },
  {
    question: "What types of vehicles are available in your fleet?",
    answer:
      "Our luxury fleet includes the Chrysler 300 Stretch Limo, H2 Hummer Limo, Mercedes Sprinter Limos (12-14 passengers), Mercedes Sprinter Vans, Mercedes Sprinter Executive vehicles, and Lincoln Navigator SUVs. All vehicles are meticulously maintained with premium interiors.",
  },
  {
    question: "Do you provide airport transfers with flight tracking?",
    answer:
      "Yes. We offer dedicated airport transportation with real-time flight tracking for DFW International, Dallas Love Field, and Addison Airport. Our chauffeurs monitor your flight and adjust pickup times automatically for early arrivals or delays.",
  },
  {
    question: "Can I book transportation for large groups?",
    answer:
      "Absolutely. Our Mercedes Sprinter Limos and Vans accommodate 12-14 passengers, and our H2 Hummer Limo handles large parties with ease. We also offer coordinated multi-vehicle logistics for weddings, corporate events, and group outings.",
  },
  {
    question: "How are your chauffeurs trained?",
    answer:
      "All Addison Limos chauffeurs are experienced, fully vetted, professionally uniformed, and trained in defensive driving and customer service. They are punctual, discreet, and committed to providing a safe, comfortable experience.",
  },
];

export const HomeDistinctionPillars = () => {
  return (
    <section className="py-24 bg-background relative border-t border-white/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4">
            Distinction Pillars
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto text-base sm:text-lg font-light">
            Why world travelers and corporate executives consistently choose
            Addison Limos.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
          {pillars.map((p, i) => (
            <div key={i} className="space-y-3 p-2">
              <p.icon className="w-8 h-8 text-primary mb-2" />
              <h3 className="text-xl font-serif font-bold text-white leading-snug">
                {p.title}
              </h3>
              <p className="text-white/60 font-light text-sm leading-relaxed">
                {p.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export const HomeAwardReviews = () => {
  return (
    <section className="py-24 bg-zinc-950 relative border-t border-white/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-6">
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
            5-Star Rated Award Winning Service
          </h2>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-primary/20 backdrop-blur-sm">
            <Star className="w-4 h-4 text-primary fill-primary" />
            <span className="text-xs sm:text-sm font-semibold tracking-widest uppercase text-white/90">
              WINNER OF ADDISON MAGAZINE'S READERS CHOICE AWARD
            </span>
          </div>
        </div>

        <div className="flex flex-row items-center justify-center gap-8 sm:gap-16 bg-zinc-900/50 border border-white/10 p-6 sm:p-8 max-w-2xl mx-auto backdrop-blur-sm mb-16">
          <div className="text-center flex-1">
            <div className="text-4xl sm:text-5xl font-serif font-bold text-white mb-2">
              4.8
            </div>
            <div className="flex items-center justify-center gap-1 mb-2">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star key={s} className="w-4 h-4 text-primary fill-primary" />
              ))}
            </div>
            <div className="text-xs text-white/50 uppercase tracking-widest">
              AVERAGE RATING
            </div>
          </div>
          <div className="h-16 w-px bg-white/10"></div>
          <div className="text-center flex-1">
            <div className="text-4xl sm:text-5xl font-serif font-bold text-white mb-2">
              160+
            </div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-5 h-5 text-primary mx-auto mb-2"
            >
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
            </svg>
            <div className="text-xs text-white/50 uppercase tracking-widest">
              VERIFIED REVIEWS
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto mb-10">
          {homeReviews.map((rev, i) => (
            <Card
              key={i}
              className="bg-zinc-900/40 border-white/5 p-6 flex flex-col justify-between rounded-none"
            >
              <div>
                <div className="flex gap-1 mb-4">
                  {[...Array(rev.rating)].map((_, idx) => (
                    <Star
                      key={idx}
                      className="w-4 h-4 text-primary fill-primary"
                    />
                  ))}
                </div>
                <p className="text-white/80 font-light text-sm italic leading-relaxed mb-6">
                  "{rev.text}"
                </p>
              </div>
              <p className="text-white font-serif font-bold text-sm">
                {rev.name}
              </p>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Link to="/reviews">
            <Button
              variant="outline"
              className="border-primary/40 text-primary hover:bg-primary hover:text-black rounded-none px-8 h-12 text-sm font-semibold tracking-wide"
            >
              View All Reviews
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export const HomeFaq = () => {
  return (
    <section className="py-24 bg-background relative border-t border-white/5">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-white/60 text-base sm:text-lg font-light">
            Everything you need to know about booking luxury transportation with
            Addison Limos.
          </p>
        </div>

        <Accordion type="single" collapsible className="space-y-4">
          {faqs.map((f, i) => (
            <AccordionItem
              key={i}
              value={`faq-${i}`}
              className="border border-white/10 bg-zinc-900/30 px-6 py-2 rounded-none"
            >
              <AccordionTrigger className="text-left text-white font-serif font-bold text-lg hover:text-primary transition-colors py-4">
                {f.question}
              </AccordionTrigger>
              <AccordionContent className="text-white/70 font-light leading-relaxed text-sm pb-4">
                {f.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="mt-12 text-center">
          <p className="text-white/50 text-sm mb-4">Still have questions?</p>
          <a
            href="tel:9726083680"
            onClick={() => (window as any).gtag_report_conversion?.()}
          >
            <Button className="bg-gradient-to-r from-yellow-600 via-primary to-yellow-500 text-black font-bold hover:brightness-110 rounded-none px-8 h-12">
              <Phone className="w-4 h-4 mr-2" />
              Call 972-608-3680
            </Button>
          </a>
        </div>
      </div>
    </section>
  );
};

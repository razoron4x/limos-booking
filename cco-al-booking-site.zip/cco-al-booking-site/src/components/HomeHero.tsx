import React from "react";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

export const HomeHeroSection = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center pt-32 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img
          src="https://vibe.filesafe.space/1792719026995615993/attachments/af133c99-d0b1-4918-a338-94a0cefc553b.webp"
          alt="Addison Limos luxury fleet"
          className="w-full h-full object-cover opacity-50"
          fetchPriority="high"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      <div className="container relative z-10 mx-auto px-4">
        <div className="max-w-3xl">
          <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-serif font-bold text-white leading-[1.08] mb-6">
            Addison
            <br />
            Limos
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/60">
              {" "}
              Booking.
            </span>
          </h1>
          <p className="text-lg md:text-xl text-white/70 mb-10 max-w-2xl leading-relaxed font-light">
            Dallas-Fort Worth's premier 5-star private ground transportation.
            From executive airport transfers to unforgettable milestone
            celebrations, our elite fleet ensures flawless travel. Proudly
            Serving 20+ Years!
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link to="/login" className="w-full sm:w-auto">
              <Button
                size="lg"
                className="w-full sm:w-auto bg-primary text-primary-foreground hover:bg-primary/90 text-lg sm:text-xl font-medium rounded-none h-16 px-10 shadow-[0_0_25px_rgba(212,175,55,0.35)] transition-all hover:shadow-[0_0_35px_rgba(212,175,55,0.6)]"
              >
                Staff Sign In
                <ChevronRight className="w-6 h-6 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

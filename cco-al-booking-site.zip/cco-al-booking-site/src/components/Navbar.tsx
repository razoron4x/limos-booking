import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Lock } from "lucide-react";
import { useEffect, useState } from "react";

export const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const onLogin = location.pathname === "/login";

  return (
    <nav
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? "bg-background/95 backdrop-blur-md border-b border-border py-2" : "bg-transparent py-4"}`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link
          to="/"
          className="text-xl sm:text-2xl font-serif font-bold tracking-wider text-foreground"
        >
          ADDISON <span className="text-primary">LIMOS</span>
        </Link>
        <div className="flex items-center gap-3">
          <span className="hidden sm:inline-flex items-center gap-1.5 text-xs uppercase tracking-[0.2em] text-muted-foreground">
            <Lock className="w-3.5 h-3.5 text-primary" /> Staff Portal
          </span>
          <Link to="/login">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-none px-5 shadow-[0_0_12px_rgba(212,175,55,0.2)]">
              {onLogin ? "Sign In" : "Staff Login"}
            </Button>
          </Link>
        </div>
      </div>
    </nav>
  );
};

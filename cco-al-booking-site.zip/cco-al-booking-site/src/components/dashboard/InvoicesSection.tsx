import { Download, FileText } from "lucide-react";
import { invoices, formatCurrency, statusTone } from "@/data/dashboard";

const totals = {
  paid: invoices
    .filter((i) => i.status === "Paid")
    .reduce((s, i) => s + i.amount, 0),
  pending: invoices
    .filter((i) => i.status === "Pending")
    .reduce((s, i) => s + i.amount, 0),
  overdue: invoices
    .filter((i) => i.status === "Overdue")
    .reduce((s, i) => s + i.amount, 0),
};

export const InvoicesSection = () => {
  return (
    <div className="space-y-8">
      <div>
        <span className="text-xs font-medium uppercase tracking-[0.25em] text-primary">
          Billing
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-foreground mt-2">
          Invoices
        </h1>
        <p className="text-muted-foreground font-light mt-1">
          Track billing across corporate and private accounts.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        {[
          { label: "Paid", value: totals.paid, tone: "text-emerald-300" },
          { label: "Pending", value: totals.pending, tone: "text-amber-200" },
          { label: "Overdue", value: totals.overdue, tone: "text-red-300" },
        ].map((t) => (
          <div key={t.label} className="border border-border bg-card p-6">
            <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
              {t.label}
            </p>
            <p
              className={`text-2xl sm:text-3xl font-serif font-bold mt-2 ${t.tone}`}
            >
              {formatCurrency(t.value)}
            </p>
          </div>
        ))}
      </div>

      <div className="border border-border bg-card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left">
              {[
                "Invoice",
                "Client",
                "Account",
                "Issued",
                "Due",
                "Amount",
                "Status",
                "",
              ].map((h) => (
                <th
                  key={h}
                  className="px-5 py-3 text-[11px] uppercase tracking-wider text-muted-foreground font-medium whitespace-nowrap"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {invoices.map((inv) => (
              <tr key={inv.id} className="hover:bg-muted/30 transition-colors">
                <td className="px-5 py-4 font-mono text-xs text-primary">
                  {inv.id}
                </td>
                <td className="px-5 py-4 font-medium text-foreground whitespace-nowrap">
                  {inv.client}
                </td>
                <td className="px-5 py-4 text-muted-foreground whitespace-nowrap">
                  {inv.account}
                </td>
                <td className="px-5 py-4 text-muted-foreground whitespace-nowrap">
                  {new Date(inv.issued).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                  })}
                </td>
                <td className="px-5 py-4 text-muted-foreground whitespace-nowrap">
                  {new Date(inv.due).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                  })}
                </td>
                <td className="px-5 py-4 font-serif font-bold text-foreground whitespace-nowrap">
                  {formatCurrency(inv.amount)}
                </td>
                <td className="px-5 py-4">
                  <span
                    className={`text-[10px] uppercase tracking-wider px-2.5 py-1 border whitespace-nowrap ${statusTone(
                      inv.status,
                    )}`}
                  >
                    {inv.status}
                  </span>
                </td>
                <td className="px-5 py-4">
                  <button
                    className="text-muted-foreground hover:text-primary transition-colors"
                    aria-label={`Download ${inv.id}`}
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center gap-3 text-xs text-muted-foreground border border-border bg-card px-5 py-4">
        <FileText className="w-4 h-4 text-primary/60" />
        Invoices are generated from completed trips and corporate contracts.
        Download statements from each account record.
      </div>
    </div>
  );
};

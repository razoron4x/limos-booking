import { useState } from "react";
import { User, Mail, Phone, Search, Plus, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  accounts,
  addAccount,
  accountDisplayName,
  formatCurrency,
  type Account,
} from "@/data/dashboard";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export const AccountsSection = () => {
  const [query, setQuery] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [detail, setDetail] = useState<Account | null>(null);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const filtered = query.trim()
    ? accounts.filter((a) => {
        const q = query.toLowerCase();
        return (
          accountDisplayName(a).toLowerCase().includes(q) ||
          a.email.toLowerCase().includes(q) ||
          a.phone.toLowerCase().includes(q)
        );
      })
    : accounts;

  const resetCreate = () => {
    setCreateOpen(false);
    setFirstName("");
    setLastName("");
    setPhone("");
    setEmail("");
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName || !lastName || !phone || !email) {
      toast.error("Please complete all account fields.");
      return;
    }
    setSubmitting(true);
    try {
      const created = addAccount({
        firstName,
        lastName,
        phone,
        email,
        type: "Private",
      });
      toast.success(`Account created for ${accountDisplayName(created)}.`);
      resetCreate();
      setDetail(created);
    } catch {
      toast.error("Could not create account.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <span className="text-xs font-medium uppercase tracking-[0.25em] text-primary">
          Client Directory
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-foreground mt-2">
          Accounts
        </h1>
        <p className="text-muted-foreground font-light mt-1">
          Corporate, VIP, and private client accounts and balances.
        </p>
      </div>

      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Lookup by name, email, or phone…"
            className="rounded-none bg-transparent border-border pl-9"
          />
        </div>
        <Button
          onClick={() => setCreateOpen(true)}
          className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-none h-11 px-6"
        >
          <Plus className="w-4 h-4" /> Create Account
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filtered.map((a) => {
          return (
            <button
              key={a.id}
              onClick={() => setDetail(a)}
              className="text-left border border-border bg-card p-6 transition-colors hover:border-primary/30"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-11 h-11 flex items-center justify-center border border-primary/30 bg-primary/10 shrink-0">
                    <User className="w-5 h-5 text-primary" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-lg font-serif font-bold text-foreground truncate">
                      {accountDisplayName(a)}
                    </h3>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs text-muted-foreground">Balance</p>
                  <p
                    className={`font-serif font-bold ${a.balance > 0 ? "text-primary" : "text-muted-foreground"}`}
                  >
                    {formatCurrency(a.balance)}
                  </p>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-border space-y-2 text-sm">
                <div className="flex flex-col sm:flex-row gap-2 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1.5 truncate">
                    <Mail className="w-3.5 h-3.5 text-primary/60" /> {a.email}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-primary/60" /> {a.phone}
                  </span>
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">
                  {a.trips} completed trips
                </span>
                <span className="text-primary">View details →</span>
              </div>
            </button>
          );
        })}
        {filtered.length === 0 && (
          <p className="text-sm text-muted-foreground md:col-span-2">
            No accounts match “{query}”.
          </p>
        )}
      </div>

      {createOpen && (
        <div
          className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={resetCreate}
        >
          <div
            className="w-full max-w-lg border border-border bg-card"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-border px-6 py-4">
              <h2 className="text-xl font-serif font-bold text-foreground">
                Create Account
              </h2>
              <button
                onClick={resetCreate}
                className="text-muted-foreground hover:text-foreground"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreate} className="p-6 space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-foreground text-xs uppercase tracking-wider">
                    First Name
                  </Label>
                  <Input
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="James"
                    className="rounded-none bg-transparent border-border"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-foreground text-xs uppercase tracking-wider">
                    Last Name
                  </Label>
                  <Input
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="Carter"
                    className="rounded-none bg-transparent border-border"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-foreground text-xs uppercase tracking-wider">
                  Email
                </Label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@email.com"
                  className="rounded-none bg-transparent border-border"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-foreground text-xs uppercase tracking-wider">
                  Phone
                </Label>
                <Input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="(214) 555-0100"
                  className="rounded-none bg-transparent border-border"
                />
              </div>
              <div className="flex justify-end gap-3 pt-2 border-t border-border">
                <Button
                  type="button"
                  variant="outline"
                  onClick={resetCreate}
                  className="rounded-none"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={submitting}
                  className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-none h-11 px-8"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Creating…
                    </>
                  ) : (
                    "Create Account"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {detail && (
        <div
          className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setDetail(null)}
        >
          <div
            className="w-full max-w-lg border border-border bg-card"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-border px-6 py-4">
              <h2 className="text-xl font-serif font-bold text-foreground">
                Account Details
              </h2>
              <button
                onClick={() => setDetail(null)}
                className="text-muted-foreground hover:text-foreground"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 flex items-center justify-center border border-primary/30 bg-primary/10 shrink-0">
                  <User className="w-6 h-6 text-primary" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-2xl font-serif font-bold text-foreground truncate">
                    {accountDisplayName(detail)}
                  </h3>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    First Name
                  </p>
                  <p className="text-sm text-foreground mt-1">
                    {detail.firstName}
                  </p>
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    Last Name
                  </p>
                  <p className="text-sm text-foreground mt-1">
                    {detail.lastName}
                  </p>
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    Email
                  </p>
                  <p className="text-sm text-foreground mt-1 truncate">
                    {detail.email}
                  </p>
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    Phone
                  </p>
                  <p className="text-sm text-foreground mt-1">{detail.phone}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    Completed Trips
                  </p>
                  <p className="text-lg font-serif font-bold text-foreground mt-1">
                    {detail.trips}
                  </p>
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    Balance
                  </p>
                  <p
                    className={`text-lg font-serif font-bold mt-1 ${detail.balance > 0 ? "text-primary" : "text-muted-foreground"}`}
                  >
                    {formatCurrency(detail.balance)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

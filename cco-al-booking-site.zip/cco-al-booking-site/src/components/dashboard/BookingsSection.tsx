import { useState } from "react";
import { Plus, MapPin, User } from "lucide-react";
import {
  bookings,
  formatCurrency,
  statusTone,
  type Booking,
} from "@/data/dashboard";
import { BookingDispatchModal } from "./dispatch/BookingDispatchModal";
import { Button } from "@/components/ui/button";

export const BookingsSection = () => {
  const [showForm, setShowForm] = useState(false);
  const [, setRefreshKey] = useState(0);

  return (
    <div className="space-y-8">
      <div className="flex items-end justify-between flex-wrap gap-4">
        <div>
          <span className="text-xs font-medium uppercase tracking-[0.25em] text-primary">
            Reservations
          </span>
          <h1 className="text-3xl sm:text-4xl font-serif font-bold text-foreground mt-2">
            Bookings
          </h1>
          <p className="text-muted-foreground font-light mt-1">
            Create, track, and dispatch client reservations.
          </p>
        </div>
        <Button
          onClick={() => setShowForm(true)}
          className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-none h-11 px-6"
        >
          <Plus className="w-4 h-4" /> New Booking
        </Button>
      </div>

      <div className="border border-border bg-card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left">
              {[
                "Ref",
                "Client",
                "Service",
                "Route",
                "Schedule",
                "Chauffeur",
                "Amount",
                "Status",
              ].map((h) => (
                <th
                  key={h}
                  className="px-5 py-3 text-[11px] uppercase tracking-wider text-muted-foreground font-medium whitespace-nowrap"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {bookings.map((b: Booking) => (
              <tr key={b.id} className="hover:bg-muted/30 transition-colors">
                <td className="px-5 py-4 font-mono text-xs text-primary">
                  {b.id}
                </td>
                <td className="px-5 py-4 font-medium text-foreground whitespace-nowrap">
                  {b.client}
                </td>
                <td className="px-5 py-4 text-muted-foreground whitespace-nowrap">
                  {b.service}
                </td>
                <td className="px-5 py-4 text-muted-foreground">
                  <span className="flex items-start gap-1.5">
                    <MapPin className="w-3.5 h-3.5 mt-0.5 text-primary/60 shrink-0" />
                    <span className="min-w-0">
                      <span className="block text-foreground/90 truncate max-w-[180px]">
                        {b.pickup}
                      </span>
                      <span className="block text-xs truncate max-w-[180px]">
                        → {b.dropoff}
                      </span>
                    </span>
                  </span>
                </td>
                <td className="px-5 py-4 text-muted-foreground whitespace-nowrap">
                  <div className="text-foreground/90">
                    {new Date(b.date).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                    })}
                  </div>
                  <div className="text-xs">{b.time}</div>
                </td>
                <td className="px-5 py-4 text-muted-foreground whitespace-nowrap">
                  <span className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-primary/60" />{" "}
                    {b.chauffeur}
                  </span>
                </td>
                <td className="px-5 py-4 font-serif font-bold text-foreground whitespace-nowrap">
                  {formatCurrency(b.amount)}
                </td>
                <td className="px-5 py-4">
                  <span
                    className={`text-[10px] uppercase tracking-wider px-2.5 py-1 border whitespace-nowrap ${statusTone(
                      b.status,
                    )}`}
                  >
                    {b.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && (
        <BookingDispatchModal
          onClose={() => setShowForm(false)}
          onSuccess={() => {
            setShowForm(false);
            setRefreshKey((k) => k + 1);
          }}
        />
      )}
    </div>
  );
};

import { useState } from "react";
import { Search, UserPlus, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  accounts,
  addAccount,
  accountDisplayName,
  type Account,
} from "@/data/dashboard";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

const accountTypes: Account["type"][] = ["Corporate", "Private", "VIP"];

interface AccountLookupProps {
  selected: Account | null;
  onSelect: (account: Account) => void;
  onClear: () => void;
  forceCreating?: boolean;
  onRequestCloseCreating?: () => void;
}

export const AccountLookup = ({
  selected,
  onSelect,
  onClear,
  forceCreating,
  onRequestCloseCreating,
}: AccountLookupProps) => {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [internalCreating, setInternalCreating] = useState(false);
  const creating = forceCreating || internalCreating;
  const [submitting, setSubmitting] = useState(false);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [type, setType] = useState<Account["type"]>("Private");

  const results = query.trim()
    ? accounts.filter((a) => {
        const q = query.toLowerCase();
        return (
          accountDisplayName(a).toLowerCase().includes(q) ||
          a.email.toLowerCase().includes(q) ||
          a.phone.toLowerCase().includes(q)
        );
      })
    : accounts;

  const resetCreate = () => {
    setInternalCreating(false);
    onRequestCloseCreating?.();
    setFirstName("");
    setLastName("");
    setPhone("");
    setEmail("");
    setType("Private");
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName || !lastName || !phone || !email) {
      toast.error("Please complete all account fields.");
      return;
    }
    setSubmitting(true);
    try {
      const created = addAccount({ firstName, lastName, phone, email, type });
      toast.success(`Account created for ${accountDisplayName(created)}.`);
      onSelect(created);
      resetCreate();
      setQuery("");
      setOpen(false);
    } catch {
      toast.error("Could not create account.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-1.5">
      <Label className="text-foreground text-xs uppercase tracking-wider">
        Account
      </Label>

      {selected ? (
        <div className="flex items-center justify-between gap-3 border border-primary/40 bg-primary/10 px-4 py-3">
          <div className="min-w-0">
            <p className="text-sm font-medium text-foreground truncate">
              {accountDisplayName(selected)}
            </p>
            <p className="text-xs text-muted-foreground truncate">
              {selected.email} · {selected.phone}
            </p>
          </div>
          <button
            type="button"
            onClick={onClear}
            className="text-xs text-primary hover:underline shrink-0"
          >
            Change
          </button>
        </div>
      ) : creating ? (
        <div className="border border-border bg-muted/20 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider text-foreground">
              New Account
            </span>
            <button
              type="button"
              onClick={resetCreate}
              className="text-muted-foreground hover:text-foreground"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Input
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              placeholder="First name"
              className="rounded-none bg-transparent border-border"
            />
            <Input
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              placeholder="Last name"
              className="rounded-none bg-transparent border-border"
            />
          </div>
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="name@email.com"
            className="rounded-none bg-transparent border-border"
          />
          <Input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="(214) 555-0100"
            className="rounded-none bg-transparent border-border"
          />
          <select
            value={type}
            onChange={(e) => setType(e.target.value as Account["type"])}
            className="w-full h-10 rounded-none bg-transparent border border-border px-3 text-sm text-foreground"
          >
            {accountTypes.map((t) => (
              <option key={t} value={t} className="bg-card">
                {t}
              </option>
            ))}
          </select>
          <div className="flex justify-end gap-2 pt-1">
            <Button
              type="button"
              variant="outline"
              onClick={resetCreate}
              className="rounded-none"
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={handleCreate}
              disabled={submitting}
              className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-none h-11 px-6"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Creating…
                </>
              ) : (
                "Create account"
              )}
            </Button>
          </div>
        </div>
      ) : (
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <Input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setOpen(true);
            }}
            onFocus={() => setOpen(true)}
            placeholder="Search by name, email, or phone…"
            className="rounded-none bg-transparent border-border pl-9"
          />
          {open && (
            <>
              <div
                className="fixed inset-0 z-10"
                onClick={() => setOpen(false)}
              />
              <div className="absolute z-20 mt-1 w-full max-h-64 overflow-y-auto custom-scroll border border-border bg-card shadow-lg">
                {results.slice(0, 8).map((a) => (
                  <button
                    key={a.id}
                    type="button"
                    onClick={() => {
                      onSelect(a);
                      setOpen(false);
                      setQuery("");
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-muted/40 transition-colors border-b border-border last:border-0"
                  >
                    <p className="text-sm font-medium text-foreground">
                      {accountDisplayName(a)}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {a.email} · {a.phone}
                    </p>
                  </button>
                ))}
                {results.length === 0 && (
                  <p className="px-4 py-3 text-sm text-muted-foreground">
                    No accounts match “{query}”.
                  </p>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setInternalCreating(true);
                    setOpen(false);
                  }}
                  className="w-full flex items-center gap-2 px-4 py-3 text-sm text-primary hover:bg-primary/10 transition-colors"
                >
                  <UserPlus className="w-4 h-4" /> Create new account
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
};

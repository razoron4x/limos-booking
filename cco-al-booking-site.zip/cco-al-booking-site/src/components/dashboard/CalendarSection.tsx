import { useState, useMemo } from "react";
import { ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { bookings, statusTone } from "@/data/dashboard";
import { CALENDAR_ID, fetchCalendarFreeSlots } from "@/lib/calendarApi";

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export const CalendarSection = () => {
  const today = new Date(2026, 9, 23);
  const [view, setView] = useState(new Date(2026, 9, 1));
  const [loading, setLoading] = useState(false);
  const [freeDays, setFreeDays] = useState<Set<string>>(new Set());

  const year = view.getFullYear();
  const month = view.getMonth();

  const firstDay = new Date(year, month, 1);
  const startWeekday = firstDay.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const bookingsByDate = useMemo(() => {
    const map: Record<string, typeof bookings> = {};
    bookings.forEach((b) => {
      if (!map[b.date]) map[b.date] = [];
      map[b.date].push(b);
    });
    return map;
  }, []);

  const loadMonthSlots = async (target: Date) => {
    const start = new Date(target.getFullYear(), target.getMonth(), 1);
    const end = new Date(target.getFullYear(), target.getMonth() + 1, 0);
    setLoading(true);
    setFreeDays(new Set());
    try {
      const data = await fetchCalendarFreeSlots(
        CALENDAR_ID,
        start.getTime(),
        end.getTime() + 1,
      );
      setFreeDays(new Set(Object.keys(data)));
    } catch {
      /* keep calendar usable even if availability fails */
    } finally {
      setLoading(false);
    }
  };

  // Load availability whenever the visible month changes.
  useMemo(() => {
    loadMonthSlots(view);
  }, [view]);

  const cells: (Date | null)[] = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));

  const fmtKey = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

  const isToday = (d: Date) => d.toDateString() === today.toDateString();

  return (
    <div className="space-y-8">
      <div className="flex items-end justify-between flex-wrap gap-4">
        <div>
          <span className="text-xs font-medium uppercase tracking-[0.25em] text-primary">
            Dispatch Schedule
          </span>
          <h1 className="text-3xl sm:text-4xl font-serif font-bold text-foreground mt-2">
            Calendar
          </h1>
          <p className="text-muted-foreground font-light mt-1">
            Scheduled trips and booking availability at a glance.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {loading && (
            <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
          )}
          <button
            onClick={() => setView(new Date(year, month - 1, 1))}
            className="w-9 h-9 flex items-center justify-center border border-border text-muted-foreground hover:text-primary hover:border-primary/40 transition-colors"
            aria-label="Previous month"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-sm font-serif font-bold text-foreground w-32 text-center">
            {view.toLocaleDateString("en-US", {
              month: "long",
              year: "numeric",
            })}
          </span>
          <button
            onClick={() => setView(new Date(year, month + 1, 1))}
            className="w-9 h-9 flex items-center justify-center border border-border text-muted-foreground hover:text-primary hover:border-primary/40 transition-colors"
            aria-label="Next month"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="border border-border bg-card overflow-hidden">
        <div className="grid grid-cols-7 border-b border-border">
          {WEEKDAYS.map((d) => (
            <div
              key={d}
              className="px-2 py-3 text-[11px] uppercase tracking-wider text-muted-foreground text-center font-medium"
            >
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {cells.map((d, i) => {
            if (!d)
              return (
                <div
                  key={i}
                  className="min-h-[110px] border-b border-r border-border bg-muted/20"
                />
              );
            const key = fmtKey(d);
            const dayBookings = bookingsByDate[key] || [];
            const hasSlots = freeDays.has(key);
            return (
              <div
                key={i}
                className={`min-h-[110px] border-b border-r border-border p-2 flex flex-col gap-1 ${
                  isToday(d) ? "bg-primary/5" : ""
                }`}
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`text-xs font-medium ${
                      isToday(d)
                        ? "w-6 h-6 flex items-center justify-center bg-primary text-primary-foreground"
                        : "text-muted-foreground"
                    }`}
                  >
                    {d.getDate()}
                  </span>
                  {hasSlots && (
                    <span
                      className="w-1.5 h-1.5 rounded-full bg-emerald-400/70"
                      title="Slots available"
                    />
                  )}
                </div>
                <div className="space-y-1 overflow-hidden">
                  {dayBookings.slice(0, 2).map((b) => (
                    <div
                      key={b.id}
                      className={`text-[10px] px-1.5 py-0.5 border truncate ${statusTone(
                        b.status,
                      )}`}
                      title={`${b.time} · ${b.client}`}
                    >
                      {b.time} {b.client}
                    </div>
                  ))}
                  {dayBookings.length > 2 && (
                    <p className="text-[10px] text-muted-foreground px-1">
                      +{dayBookings.length - 2} more
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-5 text-xs text-muted-foreground">
        <span className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400/70" /> Booking
          availability
        </span>
        <span className="flex items-center gap-2">
          <span className="w-3 h-3 border border-primary bg-primary/10" />{" "}
          Confirmed
        </span>
        <span className="flex items-center gap-2">
          <span className="w-3 h-3 border border-sky-400/40 bg-sky-400/10" /> En
          route
        </span>
        <span className="flex items-center gap-2">
          <span className="w-3 h-3 border border-amber-300/40 bg-amber-300/10" />{" "}
          Pending
        </span>
      </div>
    </div>
  );
};

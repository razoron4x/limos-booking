import {
  CalendarCheck,
  DollarSign,
  Car,
  FileWarning,
  ArrowUpRight,
  Clock,
} from "lucide-react";
import {
  bookings,
  invoices,
  accounts,
  accountDisplayName,
  formatCurrency,
  statusTone,
} from "@/data/dashboard";

const stats = [
  {
    label: "Active Bookings",
    value: bookings.filter(
      (b) => b.status === "Confirmed" || b.status === "En Route",
    ).length,
    sub: `${bookings.filter((b) => b.status === "Pending").length} pending review`,
    icon: CalendarCheck,
  },
  {
    label: "Today's Revenue",
    value: formatCurrency(
      bookings
        .filter((b) => b.date === "2026-10-23" && b.status !== "Cancelled")
        .reduce((sum, b) => sum + b.amount, 0),
    ),
    sub: "Confirmed & en route",
    icon: DollarSign,
  },
  {
    label: "Fleet in Service",
    value: new Set(
      bookings
        .filter((b) => b.status === "Confirmed" || b.status === "En Route")
        .map((b) => b.vehicle),
    ).size,
    sub: "Vehicles deployed",
    icon: Car,
  },
  {
    label: "Outstanding Invoices",
    value: formatCurrency(
      invoices
        .filter((i) => i.status === "Pending" || i.status === "Overdue")
        .reduce((sum, i) => sum + i.amount, 0),
    ),
    sub: `${invoices.filter((i) => i.status === "Overdue").length} overdue`,
    icon: FileWarning,
  },
];

export const OverviewSection = () => {
  const upcoming = bookings
    .filter((b) => b.status !== "Cancelled" && b.status !== "Completed")
    .slice(0, 5);

  return (
    <div className="space-y-10">
      <div>
        <span className="text-xs font-medium uppercase tracking-[0.25em] text-primary">
          Operations Overview
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-foreground mt-2">
          Good evening, Morgan
        </h1>
        <p className="text-muted-foreground font-light mt-1">
          Here is the fleet and booking activity for Friday, October 23.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
        {stats.map(({ label, value, sub, icon: Icon }) => (
          <div
            key={label}
            className="border border-border bg-card p-6 transition-colors hover:border-primary/30"
          >
            <div className="flex items-start justify-between">
              <div className="w-10 h-10 flex items-center justify-center border border-primary/30 bg-primary/10">
                <Icon className="w-5 h-5 text-primary" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-muted-foreground/50" />
            </div>
            <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground mt-5">
              {label}
            </p>
            <p className="text-2xl sm:text-3xl font-serif font-bold text-foreground mt-1">
              {value}
            </p>
            <p className="text-xs text-muted-foreground mt-1 font-light">
              {sub}
            </p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-6 py-4">
            <h2 className="text-lg font-serif font-bold text-foreground">
              Upcoming Trips
            </h2>
            <span className="text-xs text-muted-foreground">
              {upcoming.length} scheduled
            </span>
          </div>
          <div className="divide-y divide-border">
            {upcoming.map((b) => (
              <div
                key={b.id}
                className="flex items-center gap-4 px-6 py-4 hover:bg-muted/30 transition-colors"
              >
                <div className="flex flex-col items-center justify-center w-14 h-14 border border-border shrink-0">
                  <span className="text-[10px] uppercase text-muted-foreground">
                    {new Date(b.date).toLocaleDateString("en-US", {
                      month: "short",
                    })}
                  </span>
                  <span className="text-lg font-serif font-bold text-foreground">
                    {new Date(b.date).getDate()}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground truncate">
                    {b.client}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    {b.service} · {b.pickup}
                  </p>
                </div>
                <div className="hidden sm:block text-right shrink-0">
                  <p className="text-sm font-medium text-foreground">
                    {b.time}
                  </p>
                  <p className="text-xs text-muted-foreground">{b.vehicle}</p>
                </div>
                <span
                  className={`text-[10px] uppercase tracking-wider px-2.5 py-1 border ${statusTone(
                    b.status,
                  )}`}
                >
                  {b.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="border border-border bg-card">
          <div className="border-b border-border px-6 py-4">
            <h2 className="text-lg font-serif font-bold text-foreground">
              Account Balances
            </h2>
          </div>
          <div className="divide-y divide-border">
            {accounts
              .filter((a) => a.balance > 0)
              .map((a) => (
                <div
                  key={a.id}
                  className="flex items-center justify-between px-6 py-4"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">
                      {accountDisplayName(a)}
                    </p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {a.trips} trips
                    </p>
                  </div>
                  <p className="text-sm font-serif font-bold text-primary">
                    {formatCurrency(a.balance)}
                  </p>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};

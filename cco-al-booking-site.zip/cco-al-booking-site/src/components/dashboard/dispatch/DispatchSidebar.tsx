import { Plus, Loader2, RefreshCw, DollarSign, Ban, Edit3 } from "lucide-react";
import { toast } from "sonner";
import {
  DispatchFormData,
  chauffeurs,
  calculateCharges,
} from "./dispatchTypes";

interface SidebarProps {
  data: DispatchFormData;
  submitting: boolean;
  onChange: <K extends keyof DispatchFormData>(
    key: K,
    val: DispatchFormData[K],
  ) => void;
  onOpenEditCharges: () => void;
  onClose: () => void;
}

export const DispatchSidebar = ({
  data,
  submitting,
  onChange,
  onOpenEditCharges,
  onClose,
}: SidebarProps) => {
  const calc = calculateCharges(data.charges);
  const chargeNum = calc.total;

  return (
    <div className="space-y-2.5">
      <div className="space-y-1.5">
        <button
          type="submit"
          disabled={submitting}
          className="w-full bg-gradient-to-b from-amber-300 via-amber-400 to-amber-600 text-black font-bold uppercase tracking-wider py-2.5 px-3 border border-amber-200 shadow-md hover:brightness-110 flex items-center justify-center gap-2 text-xs"
        >
          {submitting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-black" /> SAVING…
            </>
          ) : (
            <>
              <Plus className="w-4 h-4" /> SAVE BOOKING
            </>
          )}
        </button>

        <div className="grid grid-cols-1 gap-1.5">
          <button
            type="button"
            onClick={onOpenEditCharges}
            className="w-full bg-gradient-to-b from-emerald-600 to-emerald-800 hover:from-emerald-500 hover:to-emerald-700 text-white font-bold uppercase tracking-wider py-2 px-3 border border-emerald-400 shadow-md flex items-center justify-center gap-2 text-xs"
          >
            <Edit3 className="w-3.5 h-3.5" /> EDIT CHARGES
          </button>
        </div>

        <button
          type="button"
          onClick={() => toast.info("Repeat trip copied to dispatch queue.")}
          className="w-full bg-gradient-to-b from-amber-300/80 via-amber-400/80 to-amber-600/80 text-black font-bold uppercase tracking-wide py-2 px-3 border border-amber-300/50 hover:brightness-110 flex items-center justify-center gap-1.5 text-xs"
        >
          <RefreshCw className="w-3.5 h-3.5" /> REPEAT / RETURN
        </button>

        <button
          type="button"
          onClick={() => toast.success("Order queued for affiliate farm-out.")}
          className="w-full bg-gradient-to-b from-amber-300/80 via-amber-400/80 to-amber-600/80 text-black font-bold uppercase tracking-wide py-2 px-3 border border-amber-300/50 hover:brightness-110 flex items-center justify-center gap-1.5 text-xs"
        >
          FARM-OUT ORDER
        </button>

        <button
          type="button"
          onClick={onClose}
          className="w-full bg-gradient-to-b from-red-500 via-red-600 to-red-800 text-white font-bold uppercase tracking-wide py-2 px-3 border border-red-400 hover:brightness-110 flex items-center justify-center gap-1.5 text-xs"
        >
          <Ban className="w-3.5 h-3.5" /> CANCEL / EXIT
        </button>
      </div>

      {/* Rates box */}
      <div className="border border-amber-500/40 bg-gradient-to-b from-neutral-900 to-neutral-950 p-2.5 space-y-1.5">
        <div className="flex items-center justify-between border-b border-neutral-800 pb-1">
          <div className="flex items-center gap-1.5 text-amber-400 font-serif font-bold text-xs uppercase">
            <DollarSign className="w-4 h-4" /> Rates & Summary
          </div>
          <button
            type="button"
            onClick={onOpenEditCharges}
            className="text-[10px] text-emerald-400 hover:underline uppercase font-mono font-bold"
          >
            Edit
          </button>
        </div>
        <div className="space-y-1 text-xs">
          <div className="flex justify-between">
            <span className="text-neutral-400">Current Charge:</span>
            <span className="font-mono font-bold text-emerald-400">
              ${chargeNum.toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between text-[11px]">
            <span className="text-neutral-400">Base Ride:</span>
            <span className="font-mono text-neutral-300">
              ${calc.baseRide.toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between text-[11px]">
            <span className="text-neutral-400">Stops / Tolls / Other:</span>
            <span className="font-mono text-neutral-300">
              ${(calc.stops + calc.tolls + calc.other).toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between text-[11px]">
            <span className="text-neutral-400">
              Service Fee ({data.charges.serviceFeePercent}%):
            </span>
            <span className="font-mono text-neutral-300">
              ${calc.serviceFee.toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between text-[11px]">
            <span className="text-neutral-400">Gratuity (Base+Extra):</span>
            <span className="font-mono text-neutral-300">
              ${(calc.baseGratuity + calc.extraGrat).toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between text-[11px] pt-1 border-t border-neutral-800">
            <span className="text-neutral-400">Payments Applied:</span>
            <span className="font-mono text-neutral-400">
              ${(parseFloat(data.charges.paymentsApplied) || 0).toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between text-[11px] font-bold">
            <span className="text-neutral-300">Balance Due:</span>
            <span className="font-mono text-emerald-300">
              ${calc.balanceDue.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Internal Notes */}
      <div className="space-y-1">
        <label className="text-[10px] uppercase font-bold text-neutral-300 block">
          Internal Notes:
        </label>
        <textarea
          rows={4}
          value={data.internalNotes}
          onChange={(e) => onChange("internalNotes", e.target.value)}
          placeholder="Gate codes, flight alerts, special instructions..."
          className="w-full bg-neutral-950 border border-neutral-700 text-white p-2 text-xs focus:border-amber-400 outline-none resize-none font-mono"
        />
      </div>
    </div>
  );
};

export interface ChargesBreakdown {
  durationHours: string;
  hourlyRate: string;
  useFlatRate: boolean;
  flatRate: string;
  stopsFee: string;
  otherFee: string;
  tollsFee: string;
  serviceFeePercent: string;
  extraGratuity: string;
  baseGratuityPercent: string;
  currency: string;
  paymentsApplied: string;
  farmOutRate: string;

  // Driver pay section
  commissionFlatRate: string;
  commissionPercent: string;
  driverHourlyRate: string;
  driverDurationHours: string;
  driverAdditionalPay: string;
  miscReimbursement: string;
}

export const defaultCharges: ChargesBreakdown = {
  durationHours: "1.00",
  hourlyRate: "0.00",
  useFlatRate: true,
  flatRate: "185.00",
  stopsFee: "25.00",
  otherFee: "5.00",
  tollsFee: "6.00",
  serviceFeePercent: "20.00",
  extraGratuity: "0.00",
  baseGratuityPercent: "0",
  currency: "USD $",
  paymentsApplied: "0.00",
  farmOutRate: "0.00",

  commissionFlatRate: "0.00",
  commissionPercent: "30",
  driverHourlyRate: "0.00",
  driverDurationHours: "1.00",
  driverAdditionalPay: "0.00",
  miscReimbursement: "0.00",
};

export const calculateCharges = (c: ChargesBreakdown) => {
  const dur = parseFloat(c.durationHours) || 0;
  const hrRate = parseFloat(c.hourlyRate) || 0;
  const flat = parseFloat(c.flatRate) || 0;

  const baseRide = c.useFlatRate && flat > 0 ? flat : dur * hrRate;
  const stops = parseFloat(c.stopsFee) || 0;
  const other = parseFloat(c.otherFee) || 0;
  const tolls = parseFloat(c.tollsFee) || 0;

  const subtotalBeforeFees = baseRide + stops + other + tolls;
  const svcPercent = parseFloat(c.serviceFeePercent) || 0;
  const serviceFee = (subtotalBeforeFees * svcPercent) / 100;

  const baseGratPercent = parseFloat(c.baseGratuityPercent) || 0;
  const baseGratuity = (baseRide * baseGratPercent) / 100;
  const extraGrat = parseFloat(c.extraGratuity) || 0;

  const total = subtotalBeforeFees + serviceFee + baseGratuity + extraGrat;
  const applied = parseFloat(c.paymentsApplied) || 0;
  const balanceDue = Math.max(0, total - applied);

  // Driver pay calculation
  const commPercent = parseFloat(c.commissionPercent) || 0;
  const commFlat = parseFloat(c.commissionFlatRate) || 0;
  let driverCommission = 0;
  if (commPercent > 0) {
    driverCommission = (baseRide * commPercent) / 100;
  } else {
    driverCommission = commFlat;
  }

  const dHourly = parseFloat(c.driverHourlyRate) || 0;
  const dDur = parseFloat(c.driverDurationHours) || 0;
  const driverBasePay = dHourly > 0 ? dHourly * dDur : driverCommission;
  const addPay = parseFloat(c.driverAdditionalPay) || 0;
  const misc = parseFloat(c.miscReimbursement) || 0;
  const driverTotal = driverBasePay + addPay + misc + baseGratuity + extraGrat;

  return {
    baseRide,
    stops,
    other,
    tolls,
    serviceFee,
    baseGratuity,
    extraGrat,
    total,
    balanceDue,
    driverBasePay,
    driverTotal,
  };
};

export interface DispatchFormData {
  orderedBy: string;
  passengerName: string;
  passPhone: string;
  passEmail: string;
  hidePricing: boolean;
  sendReminders: boolean;
  doNotSendPolicies: boolean;

  travelDate: string;
  pickupTimeHour: string;
  pickupTimeMinute: string;
  pickupAmPm: "am" | "pm";
  numPassengers: string;
  numLuggage: string;
  vehicleType: string;

  indComments: string;
  corpComments: string;
  specialRequests: string;

  pickupAirport: string;
  pickupAirline: string;
  pickupFlight: string;
  pickupAddress: string;
  pickupBldg: string;
  pickupCity: string;
  pickupState: string;
  pickupZip: string;

  dropoffAirport: string;
  dropoffAirline: string;
  dropoffFlight: string;
  dropoffAddress: string;
  dropoffBldg: string;
  dropoffCity: string;
  dropoffState: string;
  dropoffZip: string;

  stops: string[];
  chauffeur: string;
  rateAmount: string;
  charges: ChargesBreakdown;
  internalNotes: string;
}

export const initialDispatchFormData: DispatchFormData = {
  orderedBy: "",
  passengerName: "",
  passPhone: "",
  passEmail: "",
  hidePricing: false,
  sendReminders: true,
  doNotSendPolicies: false,

  travelDate: "",
  pickupTimeHour: "08",
  pickupTimeMinute: "15",
  pickupAmPm: "am",
  numPassengers: "1",
  numLuggage: "1",
  vehicleType: "Hummer Limo",

  indComments: "",
  corpComments: "",
  specialRequests: "",

  pickupAirport: "",
  pickupAirline: "",
  pickupFlight: "",
  pickupAddress: "",
  pickupBldg: "",
  pickupCity: "Dallas",
  pickupState: "TX - Texas",
  pickupZip: "",

  dropoffAirport: "",
  dropoffAirline: "",
  dropoffFlight: "",
  dropoffAddress: "",
  dropoffBldg: "",
  dropoffCity: "Dallas",
  dropoffState: "TX - Texas",
  dropoffZip: "",

  stops: [],
  chauffeur: "M. Reyes",
  rateAmount: "253.20",
  charges: defaultCharges,
  internalNotes: "",
};

export const vehicleTypes = [
  "Hummer Limo",
  "Stretch Limo",
  "Mercedes Sprinter",
  "Sprinter Limo",
  "Executive Sprinter",
  "SUV",
];

export const airports = [
  "DFW - Dallas/Fort Worth Intl",
  "DAL - Dallas Love Field",
  "AFW - Fort Worth Alliance",
  "ADS - Addison Airport",
];
export const airlines = [
  "American Airlines",
  "Delta Air Lines",
  "United Airlines",
  "Southwest Airlines",
  "Private Jet / Charter",
  "Other",
];
export const chauffeurs = [
  "M. Reyes",
  "D. Okafor",
  "A. Bianchi",
  "T. Holloway",
];

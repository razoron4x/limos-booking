import { useState, useEffect, useRef } from "react";
import { Search, MapPin, Building, Loader2 } from "lucide-react";
import { DispatchFormData, airports, airlines } from "./dispatchTypes";

interface LocationPanelProps {
  type: "pickup" | "dropoff";
  data: DispatchFormData;
  onChange: <K extends keyof DispatchFormData>(
    key: K,
    val: DispatchFormData[K],
  ) => void;
  onUseMainAddress: () => void;
  onUsePickupAddress?: () => void;
}

interface AddressSuggestion {
  address: string;
  city: string;
  state: string;
  zip: string;
  full: string;
}

// Curated DFW & regional premium limo destinations for instant fallback
const COMMON_DFW_LOCATIONS: AddressSuggestion[] = [
  {
    address: "2400 Aviation Dr",
    city: "DFW Airport",
    state: "TX - Texas",
    zip: "75261",
    full: "Dallas/Fort Worth International Airport (DFW), Terminal D",
  },
  {
    address: "8008 Herb Kelleher Way",
    city: "Dallas",
    state: "TX - Texas",
    zip: "75235",
    full: "Dallas Love Field Airport (DAL), Dallas, TX",
  },
  {
    address: "4505 Claire Chennault St",
    city: "Addison",
    state: "TX - Texas",
    zip: "75001",
    full: "Addison Airport (ADS) Private Aviation, Addison, TX",
  },
  {
    address: "2121 N Pearl St",
    city: "Dallas",
    state: "TX - Texas",
    zip: "75201",
    full: "The Ritz-Carlton, Dallas, 2121 N Pearl St, Dallas, TX 75201",
  },
  {
    address: "2821 Turtle Creek Blvd",
    city: "Dallas",
    state: "TX - Texas",
    zip: "75219",
    full: "Rosewood Mansion on Turtle Creek, Dallas, TX 75219",
  },
  {
    address: "2500 Victory Ave",
    city: "Dallas",
    state: "TX - Texas",
    zip: "75219",
    full: "American Airlines Center (AAC), Victory Park, Dallas, TX",
  },
  {
    address: "1 AT&T Way",
    city: "Arlington",
    state: "TX - Texas",
    zip: "76011",
    full: "AT&T Stadium (Cowboys Stadium), Arlington, TX 76011",
  },
  {
    address: "7342 Preston Rd",
    city: "Dallas",
    state: "TX - Texas",
    zip: "75205",
    full: "Highland Park Village, Preston Rd, Dallas, TX 75205",
  },
  {
    address: "5959 W Northwest Hwy",
    city: "Dallas",
    state: "TX - Texas",
    zip: "75225",
    full: "Preston Hollow Village, Dallas, TX 75225",
  },
  {
    address: "4900 Addison Circle",
    city: "Addison",
    state: "TX - Texas",
    zip: "75001",
    full: "Addison Circle Park / Corporate Center, Addison, TX 75001",
  },
  {
    address: "Legacy West Blvd",
    city: "Plano",
    state: "TX - Texas",
    zip: "75024",
    full: "Legacy West Executive District, Plano, TX 75024",
  },
  {
    address: "The Star in Frisco, 9 Cowboys Way",
    city: "Frisco",
    state: "TX - Texas",
    zip: "75034",
    full: "The Star in Frisco (Dallas Cowboys World HQ), Frisco, TX 75034",
  },
];

export const DispatchLocationPanel = ({
  type,
  data,
  onChange,
  onUseMainAddress,
  onUsePickupAddress,
}: LocationPanelProps) => {
  const isPickup = type === "pickup";
  const airportKey = isPickup ? "pickupAirport" : "dropoffAirport";
  const airlineKey = isPickup ? "pickupAirline" : "dropoffAirline";
  const flightKey = isPickup ? "pickupFlight" : "dropoffFlight";
  const addrKey = isPickup ? "pickupAddress" : "dropoffAddress";
  const bldgKey = isPickup ? "pickupBldg" : "dropoffBldg";
  const cityKey = isPickup ? "pickupCity" : "dropoffCity";
  const stateKey = isPickup ? "pickupState" : "dropoffState";
  const zipKey = isPickup ? "pickupZip" : "dropoffZip";

  const airportVal = data[airportKey];
  const airlineVal = data[airlineKey];
  const flightVal = data[flightKey];
  const addrVal = data[addrKey];
  const bldgVal = data[bldgKey];
  const cityVal = data[cityKey];
  const stateVal = data[stateKey];
  const zipVal = data[zipKey];

  const [searchQuery, setSearchQuery] = useState("");
  const [suggestions, setSuggestions] = useState<AddressSuggestion[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        wrapperRef.current &&
        !wrapperRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Search logic with live OpenStreetMap Nominatim debounce + curated presets
  useEffect(() => {
    if (!searchQuery.trim() || searchQuery.length < 2) {
      setSuggestions([]);
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      const queryLower = searchQuery.toLowerCase();

      // Check curated first
      const curated = COMMON_DFW_LOCATIONS.filter(
        (loc) =>
          loc.full.toLowerCase().includes(queryLower) ||
          loc.address.toLowerCase().includes(queryLower) ||
          loc.city.toLowerCase().includes(queryLower),
      );

      try {
        // Query OpenStreetMap Nominatim
        const resp = await fetch(
          `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(
            searchQuery,
          )}&format=json&addressdetails=1&limit=5&countrycodes=us`,
          { headers: { "Accept-Language": "en" } },
        );
        if (resp.ok) {
          const raw = await resp.json();
          const parsed: AddressSuggestion[] = raw.map(
            (item: {
              display_name: string;
              address?: {
                house_number?: string;
                road?: string;
                city?: string;
                town?: string;
                village?: string;
                state?: string;
                postcode?: string;
              };
            }) => {
              const a = item.address || {};
              const streetNum = a.house_number || "";
              const street = a.road || "";
              const streetAddr = [streetNum, street].filter(Boolean).join(" ");
              const city = a.city || a.town || a.village || "Dallas";
              const state = a.state ? `${a.state}` : "TX - Texas";
              const zip = a.postcode || "";
              return {
                address: streetAddr || item.display_name.split(",")[0],
                city,
                state: state.includes("Texas") ? "TX - Texas" : state,
                zip,
                full: item.display_name,
              };
            },
          );

          // Deduplicate
          const combined = [...curated, ...parsed];
          const unique = combined.filter(
            (v, idx, arr) =>
              arr.findIndex(
                (x) => x.address.toLowerCase() === v.address.toLowerCase(),
              ) === idx,
          );
          setSuggestions(unique.slice(0, 6));
        } else {
          setSuggestions(curated.slice(0, 6));
        }
      } catch {
        setSuggestions(curated.slice(0, 6));
      } finally {
        setLoading(false);
      }
    }, 280);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const selectSuggestion = (sug: AddressSuggestion) => {
    onChange(addrKey, sug.address);
    onChange(bldgKey, sug.address);
    onChange(cityKey, sug.city);
    onChange(stateKey, sug.state);
    if (sug.zip) onChange(zipKey, sug.zip);
    setSearchQuery("");
    setIsOpen(false);
  };

  return (
    <div className="border border-blue-900/60 bg-neutral-950 p-2.5 sm:p-3 space-y-2">
      <div className="bg-blue-900 text-white font-bold text-xs uppercase px-2 py-1 flex items-center justify-between">
        <span>{isPickup ? "Pickup Info:" : "Dropoff Info:"}</span>
        <div className="flex items-center gap-2 text-[10px] font-normal">
          <button
            type="button"
            onClick={onUseMainAddress}
            className="text-blue-200 underline hover:text-white"
          >
            Use Main Address
          </button>
          {!isPickup && onUsePickupAddress && (
            <>
              <span>·</span>
              <button
                type="button"
                onClick={onUsePickupAddress}
                className="text-blue-200 underline hover:text-white"
              >
                Use Pickup Address
              </button>
            </>
          )}
        </div>
      </div>

      <div className="space-y-1 bg-neutral-900/60 p-2 border border-neutral-800">
        <span className="text-[10px] font-semibold text-blue-300 uppercase block">
          Airport / Airline Information
        </span>
        <div className="grid grid-cols-2 gap-2">
          <select
            value={airportVal}
            onChange={(e) => onChange(airportKey, e.target.value)}
            className="w-full h-7 bg-neutral-900 border border-neutral-700 text-white px-1 text-xs"
          >
            <option value="">Airport: Choose</option>
            {airports.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>
          <select
            value={airlineVal}
            onChange={(e) => onChange(airlineKey, e.target.value)}
            className="w-full h-7 bg-neutral-900 border border-neutral-700 text-white px-1 text-xs"
          >
            <option value="">Airline: Choose</option>
            {airlines.map((al) => (
              <option key={al} value={al}>
                {al}
              </option>
            ))}
          </select>
        </div>
        <input
          type="text"
          value={flightVal}
          onChange={(e) => onChange(flightKey, e.target.value)}
          placeholder={
            isPickup ? "Arrival Flight / Tail #" : "Departure Flight / Tail #"
          }
          className="w-full h-7 bg-neutral-900 border border-neutral-700 text-white px-2 text-xs"
        />
      </div>

      {/* Address Auto-Fill Search Bar */}
      <div className="space-y-1.5" ref={wrapperRef}>
        <div className="relative">
          <div className="relative flex items-center">
            <Search className="w-3.5 h-3.5 text-blue-400 absolute left-2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setIsOpen(true);
              }}
              onFocus={() => {
                if (searchQuery.trim().length >= 2 || suggestions.length > 0) {
                  setIsOpen(true);
                }
              }}
              placeholder={`🔍 ADDRESS AUTO-FILL: Search & click to populate fields below`}
              className="w-full h-8 pl-7 pr-7 bg-neutral-900 border border-blue-500/70 text-white placeholder-blue-300/70 text-xs focus:border-blue-400 focus:bg-neutral-850 outline-none"
            />
            {loading && (
              <Loader2 className="w-3.5 h-3.5 text-blue-400 animate-spin absolute right-2" />
            )}
          </div>

          {/* Suggestions Dropdown */}
          {isOpen && (suggestions.length > 0 || searchQuery.length >= 2) && (
            <div className="absolute left-0 right-0 top-9 z-40 bg-neutral-900 border-2 border-blue-500 shadow-2xl max-h-56 overflow-y-auto">
              <div className="bg-blue-950 text-blue-200 text-[10px] font-bold px-2 py-1 uppercase flex justify-between items-center border-b border-blue-800">
                <span>Select to Auto-Fill Address Fields:</span>
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="text-neutral-400 hover:text-white"
                >
                  ✕
                </button>
              </div>
              {suggestions.length === 0 ? (
                <div className="p-2 text-[11px] text-neutral-400 italic">
                  {loading
                    ? "Searching addresses..."
                    : "No matches found. Fill fields below manually."}
                </div>
              ) : (
                suggestions.map((sug, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => selectSuggestion(sug)}
                    className="w-full text-left p-2 hover:bg-blue-900/40 border-b border-neutral-800 flex items-start gap-2 transition-colors cursor-pointer"
                  >
                    <MapPin className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-white truncate">
                        {sug.address}
                      </p>
                      <p className="text-[10px] text-neutral-400 truncate">
                        {sug.city}, {sug.state} {sug.zip}
                      </p>
                      <p className="text-[9px] text-blue-300/70 truncate">
                        {sug.full}
                      </p>
                    </div>
                  </button>
                ))
              )}
            </div>
          )}
        </div>

        {/* Detailed Address Fill-Out Fields */}
        <div className="space-y-1.5 pt-1 border-t border-neutral-800/80">
          <div className="flex items-center gap-1">
            <Building className="w-3 h-3 text-neutral-400" />
            <span className="text-[10px] text-neutral-400 uppercase font-semibold">
              Address Line / Location
            </span>
          </div>
          <input
            type="text"
            value={addrVal}
            onChange={(e) => onChange(addrKey, e.target.value)}
            placeholder={`Street address or building (e.g. 5000 Addison Circle)`}
            className="w-full h-7 bg-neutral-900 border border-neutral-700 text-white px-2 text-xs focus:border-amber-400 outline-none"
          />
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-[9px] text-neutral-400 block">
                Bldg/Apt/Gate
              </label>
              <input
                type="text"
                value={bldgVal}
                onChange={(e) => onChange(bldgKey, e.target.value)}
                placeholder="Suite / Gate"
                className="w-full h-7 bg-neutral-900 border border-neutral-800 text-white px-2 text-xs"
              />
            </div>
            <div>
              <label className="text-[9px] text-neutral-400 block">City</label>
              <input
                type="text"
                value={cityVal}
                onChange={(e) => onChange(cityKey, e.target.value)}
                placeholder="City"
                className="w-full h-7 bg-neutral-900 border border-neutral-800 text-white px-2 text-xs"
              />
            </div>
            <div>
              <label className="text-[9px] text-neutral-400 block">
                Zip Code
              </label>
              <input
                type="text"
                value={zipVal}
                onChange={(e) => onChange(zipKey, e.target.value)}
                placeholder="Zip"
                className="w-full h-7 bg-neutral-900 border border-neutral-800 text-white px-2 text-xs"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import { useState } from "react";
import { UserPlus } from "lucide-react";
import { AccountLookup } from "@/components/dashboard/AccountLookup";
import { type Account } from "@/data/dashboard";
import { DispatchFormData, vehicleTypes } from "./dispatchTypes";

interface DispatchHeaderProps {
  data: DispatchFormData;
  selectedAccount: Account | null;
  onSelectAccount: (acc: Account) => void;
  onClearAccount: () => void;
  onChange: <K extends keyof DispatchFormData>(
    key: K,
    val: DispatchFormData[K],
  ) => void;
  onDateChange: (date: string) => void;
}

export const DispatchHeader = ({
  data,
  selectedAccount,
  onSelectAccount,
  onClearAccount,
  onChange,
  onDateChange,
}: DispatchHeaderProps) => {
  const [isCreatingAccount, setIsCreatingAccount] = useState(false);

  return (
    <div className="border border-neutral-700 bg-neutral-950/90 p-2.5 space-y-2">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-start">
        <div className="md:col-span-6">
          <AccountLookup
            selected={selectedAccount}
            onSelect={(acc) => {
              onSelectAccount(acc);
              setIsCreatingAccount(false);
            }}
            onClear={onClearAccount}
            forceCreating={isCreatingAccount}
            onRequestCloseCreating={() => setIsCreatingAccount(false)}
          />
        </div>

        <div className="md:col-span-6 grid grid-cols-2 gap-2">
          <div>
            <label className="text-[11px] text-amber-400 font-semibold uppercase tracking-wide block mb-1">
              Travel Date *
            </label>
            <input
              type="date"
              value={data.travelDate}
              onChange={(e) => {
                onChange("travelDate", e.target.value);
                onDateChange(e.target.value);
              }}
              className="w-full h-8 bg-neutral-900 border border-neutral-700 text-white px-2 text-xs focus:border-amber-400 outline-none"
              required
            />
          </div>
          <div>
            <label className="text-[11px] text-amber-400 font-semibold uppercase tracking-wide block mb-1">
              Pickup Time (local) *
            </label>
            <div className="flex items-center gap-1">
              <select
                value={data.pickupTimeHour}
                onChange={(e) => onChange("pickupTimeHour", e.target.value)}
                className="h-8 bg-neutral-900 border border-neutral-700 text-white px-1 text-xs focus:border-amber-400 outline-none"
              >
                {Array.from({ length: 12 }, (_, i) =>
                  String(i + 1).padStart(2, "0"),
                ).map((h) => (
                  <option key={h} value={h}>
                    {h}
                  </option>
                ))}
              </select>
              <span>:</span>
              <select
                value={data.pickupTimeMinute}
                onChange={(e) => onChange("pickupTimeMinute", e.target.value)}
                className="h-8 bg-neutral-900 border border-neutral-700 text-white px-1 text-xs focus:border-amber-400 outline-none"
              >
                {[
                  "00",
                  "05",
                  "10",
                  "15",
                  "20",
                  "25",
                  "30",
                  "35",
                  "40",
                  "45",
                  "50",
                  "55",
                ].map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
              <div className="flex items-center gap-2 ml-2 text-xs">
                <label className="flex items-center gap-1 cursor-pointer">
                  <input
                    type="radio"
                    name="modalPickupAmPm"
                    checked={data.pickupAmPm === "am"}
                    onChange={() => onChange("pickupAmPm", "am")}
                  />
                  a.m.
                </label>
                <label className="flex items-center gap-1 cursor-pointer">
                  <input
                    type="radio"
                    name="modalPickupAmPm"
                    checked={data.pickupAmPm === "pm"}
                    onChange={() => onChange("pickupAmPm", "pm")}
                  />
                  p.m.
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-2 pt-2 border-t border-neutral-800 items-end">
        <div className="md:col-span-4">
          <label className="text-[10px] text-amber-400 font-semibold uppercase tracking-wide block mb-0.5">
            Vehicle Type *
          </label>
          <select
            value={data.vehicleType}
            onChange={(e) => onChange("vehicleType", e.target.value)}
            className="w-full h-8 bg-neutral-900 border border-neutral-700 text-white px-2 text-xs focus:border-amber-400 outline-none"
          >
            {vehicleTypes.map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </select>
        </div>

        <div className="md:col-span-2">
          <button
            type="button"
            onClick={() => setIsCreatingAccount(true)}
            className="w-full h-8 bg-neutral-900 hover:bg-neutral-800 border border-amber-500/50 hover:border-amber-400 text-amber-300 font-semibold text-[11px] uppercase tracking-wide px-2 flex items-center justify-center gap-1.5 transition-colors"
            title="Create a new client account"
          >
            <UserPlus className="w-3.5 h-3.5 text-amber-400" />
            <span>Create Account</span>
          </button>
        </div>

        <div className="md:col-span-3">
          <label className="text-[10px] text-amber-400 font-semibold uppercase tracking-wide block mb-0.5">
            # Passengers *
          </label>
          <input
            type="number"
            min="1"
            max="50"
            value={data.numPassengers}
            onChange={(e) => onChange("numPassengers", e.target.value)}
            className="w-full h-8 bg-neutral-900 border border-neutral-700 text-white px-2 text-xs focus:border-amber-400 outline-none"
          />
        </div>
        <div className="md:col-span-3">
          <label className="text-[10px] text-neutral-300 font-semibold uppercase tracking-wide block mb-0.5">
            # Luggage
          </label>
          <input
            type="number"
            min="0"
            max="30"
            value={data.numLuggage}
            onChange={(e) => onChange("numLuggage", e.target.value)}
            className="w-full h-8 bg-neutral-900 border border-neutral-700 text-white px-2 text-xs focus:border-amber-400 outline-none"
          />
        </div>
      </div>
    </div>
  );
};

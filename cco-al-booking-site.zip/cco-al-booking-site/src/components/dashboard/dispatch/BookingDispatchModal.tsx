import { useState } from "react";
import { Plus, X, Loader2, Calendar as CalendarIcon } from "lucide-react";
import { toast } from "sonner";
import { addBooking, accountDisplayName, type Account } from "@/data/dashboard";
import {
  CALENDAR_ID,
  LOCATION_ID,
  fetchCalendarFreeSlots,
  submitCalendarBooking,
} from "@/lib/calendarApi";
import { DispatchFormData, initialDispatchFormData } from "./dispatchTypes";
import { DispatchHeader } from "./DispatchHeader";
import { DispatchPassengerFields } from "./DispatchPassengerFields";
import { DispatchLocationPanel } from "./DispatchLocationPanel";
import { DispatchSidebar } from "./DispatchSidebar";
import { EditChargesModal } from "./EditChargesModal";

interface BookingDispatchModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

export const BookingDispatchModal = ({
  onClose,
  onSuccess,
}: BookingDispatchModalProps) => {
  const [data, setData] = useState<DispatchFormData>(initialDispatchFormData);
  const [selectedAccount, setSelectedAccount] = useState<Account | null>(null);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [slots, setSlots] = useState<string[]>([]);
  const [selectedSlot, setSelectedSlot] = useState("");
  const [isEditChargesOpen, setIsEditChargesOpen] = useState(false);

  const updateField = <K extends keyof DispatchFormData>(
    key: K,
    val: DispatchFormData[K],
  ) => {
    setData((prev) => ({ ...prev, [key]: val }));
  };

  const loadSlots = async (isoDate: string) => {
    if (!isoDate) return;
    const start = new Date(isoDate + "T00:00:00");
    const end = new Date(start);
    end.setDate(end.getDate() + 1);
    setLoadingSlots(true);
    setSlots([]);
    setSelectedSlot("");
    try {
      const resp = await fetchCalendarFreeSlots(
        CALENDAR_ID,
        start.getTime(),
        end.getTime(),
      );
      const dayKey = Object.keys(resp)[0];
      setSlots(dayKey ? resp[dayKey].slots : []);
    } catch {
      toast.error("Could not load calendar availability.");
    } finally {
      setLoadingSlots(false);
    }
  };

  const handleAccountSelect = (acc: Account) => {
    setSelectedAccount(acc);
    const fullName = accountDisplayName(acc);
    setData((prev) => ({
      ...prev,
      passengerName: fullName,
      orderedBy: fullName,
      passEmail: acc.email,
      passPhone: acc.phone,
      mobileNum: acc.phone,
      contactNum: acc.phone,
    }));
  };

  const handleUseCustomerMainAddress = (type: "pickup" | "dropoff") => {
    const defaultAddr = "Highland Park, Dallas, TX";
    if (type === "pickup") {
      updateField("pickupAddress", defaultAddr);
      updateField("pickupCity", "Dallas");
      updateField("pickupState", "TX - Texas");
    } else {
      updateField("dropoffAddress", defaultAddr);
      updateField("dropoffCity", "Dallas");
      updateField("dropoffState", "TX - Texas");
    }
  };

  const handleUsePickupAddressForDropoff = () => {
    updateField("dropoffAddress", data.pickupAddress);
    updateField("dropoffCity", data.pickupCity);
    updateField("dropoffState", data.pickupState);
    updateField("dropoffZip", data.pickupZip);
    updateField("dropoffBldg", data.pickupBldg);
  };

  const handleAddStop = () => {
    if (data.stops.length < 5) {
      updateField("stops", [...data.stops, ""]);
    }
  };

  const handleUpdateStop = (index: number, val: string) => {
    const updated = [...data.stops];
    updated[index] = val;
    updateField("stops", updated);
  };

  const handleRemoveStop = (index: number) => {
    updateField(
      "stops",
      data.stops.filter((_, i) => i !== index),
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const nameParts = data.passengerName.trim().split(" ");
    const fn = nameParts[0] || "Guest";
    const ln = nameParts.slice(1).join(" ") || "Client";

    if (!data.passengerName || !data.passPhone || !data.travelDate) {
      toast.error(
        "Please fill in required fields (Passenger Name, Phone, Travel Date).",
      );
      return;
    }

    setSubmitting(true);
    try {
      const activeSlot =
        selectedSlot ||
        `${data.travelDate}T${data.pickupAmPm === "pm" ? (parseInt(data.pickupTimeHour, 10) % 12) + 12 : data.pickupTimeHour}:${data.pickupTimeMinute}:00-05:00`;

      await submitCalendarBooking({
        locationId: LOCATION_ID,
        calendarId: CALENDAR_ID,
        firstName: fn,
        lastName: ln,
        email: data.passEmail || "dispatch@addisonlimos.com",
        phone: data.passPhone,
        selectedSlot: activeSlot,
        notes: data.internalNotes || data.specialRequests,
        customFields: [
          {
            id: "GasDISnUNvpkpWO9u49Y",
            field_value: "Private Chauffeur Service",
          },
          { id: "YB9N7VzmrToABleixYHA", field_value: data.vehicleType },
          {
            id: "hdD7PaHMD4GPn1mx29br",
            field_value:
              data.pickupAddress || data.pickupAirport || "Addison / DFW",
          },
          {
            id: "BUPz9lRPx1jh5khbXLJT",
            field_value:
              data.dropoffAddress || data.dropoffAirport || "Dallas TX",
          },
          { id: "WZmYcWAgJEcy1auyXKqR", field_value: data.chauffeur },
        ],
      });

      addBooking({
        client: data.passengerName,
        service: data.vehicleType,
        vehicle: data.vehicleType,
        pickup: data.pickupAddress || data.pickupAirport || "Addison, TX",
        dropoff: data.dropoffAddress || data.dropoffAirport || "Dallas, TX",
        date: data.travelDate,
        time: `${data.pickupTimeHour}:${data.pickupTimeMinute} ${data.pickupAmPm.toUpperCase()}`,
        chauffeur: data.chauffeur,
        amount: parseFloat(data.rateAmount) || 185,
        status: "Confirmed",
      });

      toast.success(`Booking saved for ${data.passengerName}.`);
      onSuccess();
    } catch {
      toast.error("Booking saved locally; dispatch server error.");
      addBooking({
        client: data.passengerName,
        service: data.vehicleType,
        vehicle: data.vehicleType,
        pickup: data.pickupAddress || data.pickupAirport || "Addison, TX",
        dropoff: data.dropoffAddress || data.dropoffAirport || "Dallas, TX",
        date: data.travelDate,
        time: `${data.pickupTimeHour}:${data.pickupTimeMinute} ${data.pickupAmPm.toUpperCase()}`,
        chauffeur: data.chauffeur,
        amount: parseFloat(data.rateAmount) || 185,
        status: "Confirmed",
      });
      onSuccess();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="w-full max-w-6xl max-h-[94vh] overflow-y-auto custom-scroll border border-neutral-700 bg-neutral-900 text-neutral-100 rounded-none shadow-2xl my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-neutral-700 bg-neutral-950 px-4 py-3 sticky top-0 z-20">
          <div className="flex items-center gap-2">
            <span className="bg-primary/20 text-primary text-[11px] font-mono px-2 py-0.5 border border-primary/40 uppercase">
              Dispatch Order Entry
            </span>
            <h2 className="text-sm sm:text-base font-bold uppercase tracking-wider text-foreground">
              Addison Limos Reservation Form
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form
          onSubmit={handleSubmit}
          className="p-3 sm:p-4 space-y-3 text-xs font-sans"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
            {/* Left 9 cols */}
            <div className="lg:col-span-9 space-y-2.5">
              <DispatchHeader
                data={data}
                selectedAccount={selectedAccount}
                onSelectAccount={handleAccountSelect}
                onClearAccount={() => setSelectedAccount(null)}
                onChange={updateField}
                onDateChange={loadSlots}
              />

              <DispatchPassengerFields data={data} onChange={updateField} />

              {/* Comments & Special Requests */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                <div>
                  <label className="text-[10px] text-neutral-300 font-semibold uppercase block mb-1">
                    Individual Comments:
                  </label>
                  <textarea
                    rows={2}
                    value={data.indComments}
                    onChange={(e) => updateField("indComments", e.target.value)}
                    placeholder="Passenger preferences..."
                    className="w-full bg-neutral-950 border border-neutral-700 text-white p-2 text-xs focus:border-amber-400 outline-none resize-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-neutral-300 font-semibold uppercase block mb-1">
                    Corporate Comments:
                  </label>
                  <textarea
                    rows={2}
                    value={data.corpComments}
                    onChange={(e) =>
                      updateField("corpComments", e.target.value)
                    }
                    placeholder="Cost center / billing notes..."
                    className="w-full bg-neutral-950 border border-neutral-700 text-white p-2 text-xs focus:border-amber-400 outline-none resize-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-neutral-300 font-semibold uppercase block mb-1">
                    Special Requests:
                  </label>
                  <textarea
                    rows={2}
                    value={data.specialRequests}
                    onChange={(e) =>
                      updateField("specialRequests", e.target.value)
                    }
                    placeholder="Refreshments, booster seat..."
                    className="w-full bg-neutral-950 border border-neutral-700 text-white p-2 text-xs focus:border-amber-400 outline-none resize-none"
                  />
                </div>
              </div>

              {/* Pickup & Dropoff side-by-side */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                <DispatchLocationPanel
                  type="pickup"
                  data={data}
                  onChange={updateField}
                  onUseMainAddress={() =>
                    handleUseCustomerMainAddress("pickup")
                  }
                />
                <DispatchLocationPanel
                  type="dropoff"
                  data={data}
                  onChange={updateField}
                  onUseMainAddress={() =>
                    handleUseCustomerMainAddress("dropoff")
                  }
                  onUsePickupAddress={handleUsePickupAddressForDropoff}
                />
              </div>

              {/* Intermediate stops */}
              <div className="border border-neutral-800 bg-neutral-950 p-2.5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-400 uppercase tracking-wider text-[11px]">
                    Stops (Max 5)
                  </span>
                  {data.stops.length < 5 && (
                    <button
                      type="button"
                      onClick={handleAddStop}
                      className="text-[11px] text-amber-400 hover:underline flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" /> Add Stop
                    </button>
                  )}
                </div>
                {data.stops.length === 0 ? (
                  <p className="text-neutral-500 italic text-[11px]">
                    No intermediate stops configured.
                  </p>
                ) : (
                  <div className="space-y-1.5">
                    {data.stops.map((stop, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <span className="text-amber-400 font-bold shrink-0 w-14">
                          Stop {i + 1}:
                        </span>
                        <input
                          type="text"
                          value={stop}
                          onChange={(e) => handleUpdateStop(i, e.target.value)}
                          placeholder={`Enter address or landmark for stop ${i + 1}`}
                          className="flex-1 h-7 bg-neutral-900 border border-neutral-700 text-white px-2 text-xs"
                        />
                        <button
                          type="button"
                          onClick={() => handleRemoveStop(i)}
                          className="text-red-400 hover:text-red-300 p-1"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Free Slots */}
              <div className="border border-neutral-800 bg-neutral-950 p-2.5 space-y-1.5">
                <span className="text-[11px] font-bold text-primary uppercase tracking-wider flex items-center gap-1.5">
                  <CalendarIcon className="w-3.5 h-3.5" /> Synchronized Calendar
                  Free Slots
                </span>
                {loadingSlots ? (
                  <div className="flex items-center gap-2 text-neutral-400 text-xs py-2">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" /> Fetching
                    available calendar time slots…
                  </div>
                ) : slots.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {slots.map((s) => {
                      const slotLabel = new Date(s).toLocaleTimeString(
                        "en-US",
                        {
                          hour: "numeric",
                          minute: "2-digit",
                        },
                      );
                      return (
                        <button
                          key={s}
                          type="button"
                          onClick={() => setSelectedSlot(s)}
                          className={`px-2.5 py-1 text-xs border transition-colors ${
                            selectedSlot === s
                              ? "border-amber-400 bg-amber-400/20 text-amber-300 font-bold"
                              : "border-neutral-700 bg-neutral-900 text-neutral-300 hover:border-amber-400/50"
                          }`}
                        >
                          {slotLabel}
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-[11px] text-neutral-400 py-1">
                    {data.travelDate
                      ? "No slots returned for this date. Default local pickup time will be used."
                      : "Select a Travel Date above to query calendar availability."}
                  </p>
                )}
              </div>
            </div>

            {/* Right 3 cols */}
            <div className="lg:col-span-3">
              <DispatchSidebar
                data={data}
                submitting={submitting}
                onChange={updateField}
                onOpenEditCharges={() => setIsEditChargesOpen(true)}
                onClose={onClose}
              />
            </div>
          </div>
        </form>

        {isEditChargesOpen && (
          <EditChargesModal
            charges={data.charges}
            onSave={(updatedCharges, newTotal) => {
              updateField("charges", updatedCharges);
              updateField("rateAmount", newTotal);
              toast.success(`Charges updated: $${newTotal}`);
            }}
            onClose={() => setIsEditChargesOpen(false)}
          />
        )}
      </div>
    </div>
  );
};

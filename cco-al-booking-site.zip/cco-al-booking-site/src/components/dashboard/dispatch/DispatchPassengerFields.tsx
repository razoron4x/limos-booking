import { DispatchFormData } from "./dispatchTypes";

interface PassengerFieldsProps {
  data: DispatchFormData;
  onChange: <K extends keyof DispatchFormData>(
    key: K,
    val: DispatchFormData[K],
  ) => void;
}

export const DispatchPassengerFields = ({
  data,
  onChange,
}: PassengerFieldsProps) => {
  return (
    <div className="border border-neutral-700 bg-neutral-950/90 p-2.5 space-y-2">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
        <div>
          <label className="text-[10px] text-amber-400 font-semibold uppercase tracking-wide block mb-0.5">
            Ordered By *
          </label>
          <input
            type="text"
            value={data.orderedBy}
            onChange={(e) => onChange("orderedBy", e.target.value)}
            placeholder="Name / Booker"
            className="w-full h-8 bg-neutral-900 border border-neutral-700 text-white px-2 text-xs focus:border-amber-400 outline-none"
          />
        </div>
        <div>
          <label className="text-[10px] text-amber-400 font-semibold uppercase tracking-wide block mb-0.5">
            Passenger Name *
          </label>
          <input
            type="text"
            value={data.passengerName}
            onChange={(e) => onChange("passengerName", e.target.value)}
            placeholder="Passenger Full Name"
            className="w-full h-8 bg-neutral-900 border border-neutral-700 text-white px-2 text-xs focus:border-amber-400 outline-none"
            required
          />
        </div>
        <div>
          <label className="text-[10px] text-amber-400 font-semibold uppercase tracking-wide block mb-0.5">
            Pass. Contact Phone *
          </label>
          <input
            type="tel"
            value={data.passPhone}
            onChange={(e) => onChange("passPhone", e.target.value)}
            placeholder="(214) 555-0100"
            className="w-full h-8 bg-neutral-900 border border-neutral-700 text-white px-2 text-xs focus:border-amber-400 outline-none"
            required
          />
        </div>
        <div>
          <label className="text-[10px] text-neutral-300 font-semibold uppercase tracking-wide block mb-0.5">
            Pass. Email
          </label>
          <input
            type="email"
            value={data.passEmail}
            onChange={(e) => onChange("passEmail", e.target.value)}
            placeholder="client@email.com"
            className="w-full h-8 bg-neutral-900 border border-neutral-700 text-white px-2 text-xs focus:border-amber-400 outline-none"
          />
        </div>
      </div>

      <div className="flex items-center gap-4 text-[10px] text-neutral-300 pt-1 border-t border-neutral-800">
        <label className="flex items-center gap-1.5 cursor-pointer">
          <input
            type="checkbox"
            checked={data.hidePricing}
            onChange={(e) => onChange("hidePricing", e.target.checked)}
            className="rounded-none border-neutral-700 bg-neutral-900"
          />
          Hide Pricing
        </label>
        <label className="flex items-center gap-1.5 cursor-pointer">
          <input
            type="checkbox"
            checked={data.sendReminders}
            onChange={(e) => onChange("sendReminders", e.target.checked)}
            className="rounded-none border-neutral-700 bg-neutral-900"
          />
          Send reminders
        </label>
        <label className="flex items-center gap-1.5 cursor-pointer">
          <input
            type="checkbox"
            checked={data.doNotSendPolicies}
            onChange={(e) => onChange("doNotSendPolicies", e.target.checked)}
            className="rounded-none border-neutral-700 bg-neutral-900"
          />
          Do not send policies
        </label>
      </div>
    </div>
  );
};

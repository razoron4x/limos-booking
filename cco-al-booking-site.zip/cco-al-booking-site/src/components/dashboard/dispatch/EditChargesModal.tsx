import { useState } from "react";
import { X, Save, Calculator, CreditCard, Check } from "lucide-react";
import { ChargesBreakdown, calculateCharges } from "./dispatchTypes";

interface EditChargesModalProps {
  charges: ChargesBreakdown;
  onSave: (charges: ChargesBreakdown, newTotal: string) => void;
  onClose: () => void;
}

export const EditChargesModal = ({
  charges: initialCharges,
  onSave,
  onClose,
}: EditChargesModalProps) => {
  const [form, setForm] = useState<ChargesBreakdown>({ ...initialCharges });

  const update = <K extends keyof ChargesBreakdown>(
    key: K,
    val: ChargesBreakdown[K],
  ) => {
    setForm((prev) => ({ ...prev, [key]: val }));
  };

  const totals = calculateCharges(form);

  const handleSaveOnly = () => {
    onSave(form, totals.total.toFixed(2));
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-[#d5f0c9] text-black border-2 border-[#5c8a4d] shadow-2xl font-sans text-xs select-none"
        onClick={(e) => e.stopPropagation()}
        style={{
          backgroundColor: "#d8f3cb",
          borderColor: "#4a7a3b",
        }}
      >
        {/* Retro Header Strip */}
        <div className="bg-gradient-to-r from-[#2e5d1e] to-[#45802e] text-white px-3 py-1.5 flex items-center justify-between font-bold text-xs uppercase tracking-wide border-b border-[#234716]">
          <span className="flex items-center gap-1.5">
            <Calculator className="w-3.5 h-3.5" /> Rate & Charges Calculator
          </span>
          <button
            type="button"
            onClick={onClose}
            className="text-white hover:text-red-200 p-0.5"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Buttons Top Right (matching original image) */}
        <div className="p-3">
          <div className="flex justify-end gap-2 mb-2">
            <button
              type="button"
              onClick={handleSaveOnly}
              className="bg-[#246b1f] hover:bg-[#1d5718] text-white font-bold text-[11px] uppercase px-3 py-1.5 rounded-xs border border-[#164413] shadow-sm flex items-center gap-1.5"
            >
              <CreditCard className="w-3.5 h-3.5" /> PRE-AUTH FUNDS
            </button>
            <button
              type="button"
              onClick={handleSaveOnly}
              className="bg-[#246b1f] hover:bg-[#1d5718] text-white font-bold text-[11px] uppercase px-3 py-1.5 rounded-xs border border-[#164413] shadow-sm flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" /> SAVE CHARGES
            </button>
            <button
              type="button"
              onClick={handleSaveOnly}
              className="bg-[#246b1f] hover:bg-[#1d5718] text-white font-bold text-[11px] uppercase px-3 py-1.5 rounded-xs border border-[#164413] shadow-sm flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" /> SAVE CHARGES & BOOKING
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            {/* Left Box: Trip Calculation (7 cols) */}
            <div className="md:col-span-7 border-2 border-[#5c8a4d] bg-[#dcf8cf]/70 p-2.5 space-y-2">
              {/* Duration x Hourly Rate */}
              <div className="flex items-center gap-1.5 text-[11px]">
                <label className="font-bold text-gray-900 w-28">
                  Trip Duration (hrs)
                </label>
                <span className="font-bold">x</span>
                <label className="font-bold text-gray-900 w-20 text-center">
                  Hourly Rate
                </label>
              </div>

              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  step="0.25"
                  value={form.durationHours}
                  onChange={(e) => update("durationHours", e.target.value)}
                  className="w-16 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                />
                <span>x</span>
                <input
                  type="number"
                  step="0.01"
                  value={form.hourlyRate}
                  onChange={(e) => {
                    update("hourlyRate", e.target.value);
                    if (parseFloat(e.target.value) > 0) {
                      update("useFlatRate", false);
                    }
                  }}
                  className="w-24 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                />
                <span>=</span>
                <input
                  type="text"
                  readOnly
                  value={(
                    (parseFloat(form.durationHours) || 0) *
                    (parseFloat(form.hourlyRate) || 0)
                  ).toFixed(2)}
                  className="w-24 h-6 bg-[#bdbdbd] border border-gray-600 px-1 text-black font-mono text-right font-bold"
                />
                <select
                  value={form.currency}
                  onChange={(e) => update("currency", e.target.value)}
                  className="h-6 bg-white border border-[#7f9db9] px-1 text-[11px]"
                >
                  <option value="USD $">USD $</option>
                  <option value="CAD $">CAD $</option>
                  <option value="EUR €">EUR €</option>
                </select>
              </div>

              {/* OR Flat Rate */}
              <div className="flex items-center gap-1.5 pt-1">
                <span className="font-bold text-gray-900 w-8">OR</span>
                <label className="font-bold text-gray-900 w-16">
                  Flat Rate
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={form.flatRate}
                  onChange={(e) => {
                    update("flatRate", e.target.value);
                    update("useFlatRate", true);
                  }}
                  className="w-24 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                />
                <span>=</span>
                <input
                  type="text"
                  readOnly
                  value={(parseFloat(form.flatRate) || 0).toFixed(2)}
                  className="w-24 h-6 bg-[#bdbdbd] border border-gray-600 px-1 text-black font-mono text-right font-bold"
                />
                <span className="text-[10px] text-gray-700 italic">
                  Add to Driver Pay
                </span>
              </div>

              {/* Stops, Other, Tolls */}
              <div className="space-y-1 pt-1 border-t border-[#a3cca0]">
                <div className="flex items-center justify-end gap-1.5">
                  <span className="font-bold text-gray-900">Stops =</span>
                  <input
                    type="number"
                    step="0.01"
                    value={form.stopsFee}
                    onChange={(e) => update("stopsFee", e.target.value)}
                    className="w-24 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                  />
                </div>
                <div className="flex items-center justify-end gap-1.5">
                  <span className="font-bold text-gray-900">Other =</span>
                  <input
                    type="number"
                    step="0.01"
                    value={form.otherFee}
                    onChange={(e) => update("otherFee", e.target.value)}
                    className="w-24 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                  />
                </div>
                <div className="flex items-center justify-end gap-1.5">
                  <span className="font-bold text-gray-900">Tolls =</span>
                  <input
                    type="number"
                    step="0.01"
                    value={form.tollsFee}
                    onChange={(e) => update("tollsFee", e.target.value)}
                    className="w-24 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                  />
                </div>
              </div>

              {/* Service Fee */}
              <div className="flex items-center justify-end gap-1.5 pt-1">
                <span className="font-bold text-gray-900">Service Fee @</span>
                <input
                  type="number"
                  step="0.5"
                  value={form.serviceFeePercent}
                  onChange={(e) => update("serviceFeePercent", e.target.value)}
                  className="w-16 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                />
                <span>% =</span>
                <input
                  type="text"
                  readOnly
                  value={totals.serviceFee.toFixed(2)}
                  className="w-24 h-6 bg-[#bdbdbd] border border-gray-600 px-1 text-black font-mono text-right font-bold"
                />
              </div>

              {/* Extra Gratuity */}
              <div className="flex items-center justify-end gap-1.5">
                <span className="font-bold text-gray-900">
                  Extra Gratuity =
                </span>
                <input
                  type="number"
                  step="0.01"
                  value={form.extraGratuity}
                  onChange={(e) => update("extraGratuity", e.target.value)}
                  className="w-24 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                />
              </div>

              {/* Base Gratuity */}
              <div className="flex items-center justify-end gap-1.5">
                <span className="font-bold text-gray-900">Base Gratuity @</span>
                <input
                  type="number"
                  step="1"
                  value={form.baseGratuityPercent}
                  onChange={(e) =>
                    update("baseGratuityPercent", e.target.value)
                  }
                  className="w-16 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                />
                <span>% =</span>
                <input
                  type="text"
                  readOnly
                  value={totals.baseGratuity.toFixed(2)}
                  className="w-24 h-6 bg-[#bdbdbd] border border-gray-600 px-1 text-black font-mono text-right font-bold"
                />
              </div>

              {/* Total Amount & Calculate */}
              <div className="flex items-center justify-end gap-1.5 pt-2 border-t border-black/40">
                <span className="font-bold text-gray-900 text-[12px]">
                  Total Amount =
                </span>
                <input
                  type="text"
                  readOnly
                  value={totals.total.toFixed(2)}
                  className="w-28 h-7 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right font-extrabold text-[13px]"
                />
                <button
                  type="button"
                  onClick={() => {}}
                  className="h-7 px-3 bg-white hover:bg-gray-100 border border-black text-black font-semibold shadow-xs"
                >
                  Calculate
                </button>
              </div>

              {/* Payments Applied & FarmOut */}
              <div className="space-y-1 pt-1 text-[11px]">
                <div className="flex items-center justify-end gap-1.5">
                  <span className="font-semibold text-gray-800">
                    Payments Applied =
                  </span>
                  <input
                    type="number"
                    step="0.01"
                    value={form.paymentsApplied}
                    onChange={(e) => update("paymentsApplied", e.target.value)}
                    className="w-24 h-6 bg-[#bdbdbd] border border-gray-600 px-1 text-black font-mono text-right font-bold"
                  />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-gray-800">
                    FarmOut Rate:
                  </span>
                  <input
                    type="number"
                    step="0.01"
                    value={form.farmOutRate}
                    onChange={(e) => update("farmOutRate", e.target.value)}
                    className="w-20 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                  />
                </div>
              </div>
            </div>

            {/* Right Box: Driver Pay & Commission (5 cols) */}
            <div className="md:col-span-5 space-y-2.5">
              <div>
                <p className="font-bold text-gray-900 text-xs">
                  Add to Driver Pay:
                </p>
                <div className="mt-1 space-y-1 border border-[#7bb56c] bg-[#e3fad6]/70 p-2">
                  <span className="font-bold text-gray-900 block">
                    Commission:
                  </span>
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-gray-800">Flat Rate:</span>
                    <input
                      type="number"
                      step="0.01"
                      value={form.commissionFlatRate}
                      onChange={(e) =>
                        update("commissionFlatRate", e.target.value)
                      }
                      className="w-20 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                    />
                  </div>
                  <div className="text-center font-bold text-[10px] text-gray-700">
                    OR
                  </div>
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-gray-800">Percentage:</span>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        step="1"
                        value={form.commissionPercent}
                        onChange={(e) =>
                          update("commissionPercent", e.target.value)
                        }
                        className="w-16 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                      />
                      <span>%</span>
                    </div>
                  </div>
                  <p className="text-[10px] text-red-700 italic pt-0.5">
                    Percentage overrides Flat Rate.
                  </p>
                </div>
              </div>

              {/* Hourly Pay */}
              <div className="space-y-1 border border-[#7bb56c] bg-[#e3fad6]/70 p-2">
                <span className="font-bold text-gray-900 block">
                  Hourly Pay:
                </span>
                <div className="grid grid-cols-2 gap-2 text-[10px] font-bold text-gray-800">
                  <span>HR Rate:</span>
                  <span>Dur (HRS):</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    step="0.01"
                    value={form.driverHourlyRate}
                    onChange={(e) => update("driverHourlyRate", e.target.value)}
                    className="w-20 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                  />
                  <span className="text-[10px]">/hr x</span>
                  <input
                    type="number"
                    step="0.25"
                    value={form.driverDurationHours}
                    onChange={(e) =>
                      update("driverDurationHours", e.target.value)
                    }
                    className="w-16 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                  />
                </div>

                <div className="space-y-1 pt-1.5 border-t border-[#9fcb94]">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-gray-800">
                      Base Pay:
                    </span>
                    <input
                      type="text"
                      readOnly
                      value={totals.driverBasePay.toFixed(2)}
                      className="w-24 h-6 bg-[#bdbdbd] border border-gray-600 px-1 text-black font-mono text-right font-bold"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-gray-800">
                      Additional Pay:
                    </span>
                    <input
                      type="number"
                      step="0.01"
                      value={form.driverAdditionalPay}
                      onChange={(e) =>
                        update("driverAdditionalPay", e.target.value)
                      }
                      className="w-24 h-6 bg-[#bdbdbd] border border-gray-600 px-1 text-black font-mono text-right"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-gray-900">Total:</span>
                    <input
                      type="text"
                      readOnly
                      value={totals.driverTotal.toFixed(2)}
                      className="w-24 h-6 bg-[#bdbdbd] border border-gray-600 px-1 text-black font-mono text-right font-bold text-emerald-900"
                    />
                  </div>
                </div>
              </div>

              {/* Misc Reimbursement */}
              <div className="flex items-center justify-between gap-1 text-[11px] pt-1">
                <span className="font-semibold text-gray-800">
                  Miscellaneous Reimbursement:
                </span>
                <input
                  type="number"
                  step="0.01"
                  value={form.miscReimbursement}
                  onChange={(e) => update("miscReimbursement", e.target.value)}
                  className="w-16 h-6 bg-white border border-[#7f9db9] px-1 text-black font-mono text-right"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#c2e4b4] px-3 py-2 border-t border-[#7bb56c] flex items-center justify-between">
          <span className="text-[11px] text-gray-700">
            Current Balance Due:{" "}
            <strong className="text-black font-mono font-bold">
              ${totals.balanceDue.toFixed(2)}
            </strong>
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1 bg-white hover:bg-gray-100 border border-gray-500 text-black font-semibold text-xs"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveOnly}
              className="px-4 py-1 bg-[#246b1f] hover:bg-[#1d5718] text-white font-bold text-xs uppercase shadow-sm"
            >
              Apply to Reservation
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React from "react";
import { Link } from "react-router-dom";
import {
  Phone,
  Star,
  Shield,
  Clock,
  CreditCard,
  Trophy,
  ChevronRight,
} from "lucide-react";

export const PrivateCarSections = () => {
  return (
    <>
      {/* STATS BAR - Compact */}
      <section className="bg-zinc-900 border-y border-zinc-800 py-5">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { value: "24/7", label: "Availability" },
              { value: "$0", label: "Surge Pricing" },
              { value: "15min", label: "Early Arrival" },
              { value: "100%", label: "Private Rides" },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-2xl md:text-2xl font-serif font-bold text-primary leading-none mb-0.5">
                  {stat.value}
                </div>
                <div className="text-[10px] text-white/70 uppercase tracking-wider font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* COLORFUL MOSAIC - LUXY alternating layout */}
      <section className="py-20 bg-white border-y border-zinc-200">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 lg:gap-6">
            {/* Row 1: IMAGE left (8 cols) | TEXT right (4 cols) */}
            <div className="md:col-span-8 relative overflow-hidden rounded-xl shadow-lg group h-[240px] md:h-[380px] lg:h-[340px]">
              <img
                src="https://vibe.filesafe.space/1792719026995615993/assets/036600e4-efeb-494c-bd8c-5a189e8271ad.png"
                alt="Luxury black SUV interior at night with customer testimonial overlay"
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-br from-black/70 via-black/30 to-black/60"></div>

              {/* Label - Top Left */}
              <div className="absolute top-0 left-0 p-4 sm:p-6 lg:p-8">
                <p className="text-[10px] sm:text-xs font-bold uppercase tracking-wider text-primary mb-1">
                  Customer Testimonial
                </p>
              </div>

              {/* Quote & Author - Bottom Left */}
              <div className="absolute bottom-0 left-0 p-4 sm:p-6 lg:p-8 max-w-xl">
                <blockquote className="text-2xl sm:text-3xl lg:text-3xl font-serif font-bold text-white leading-tight mb-1.5 sm:mb-3 drop-shadow-lg">
                  "I have used Addison Limos twice now for business dinners.
                  Both times the experience could not have been better!"
                </blockquote>
                <p className="text-xs sm:text-base text-white/90 font-medium">
                  Amy O'Malley, Business Client
                </p>
              </div>
            </div>

            <div className="md:col-span-4 bg-gradient-to-br from-yellow-600 via-yellow-500 to-yellow-700 rounded-xl p-3 md:p-5 lg:p-7 flex flex-col items-center justify-center text-center shadow-lg h-[240px] md:h-[340px] lg:h-[340px] relative overflow-hidden">
              {/* Subtle pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-white"></div>
                <div className="absolute -bottom-10 -left-10 w-32 h-32 rounded-full bg-black"></div>
              </div>

              <div className="relative z-10 flex flex-col items-center justify-center">
                <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-black/90 border-2 border-yellow-300 flex items-center justify-center mb-1.5 md:mb-3 shadow-lg">
                  <Trophy className="w-6 h-6 md:w-8 md:h-8 text-yellow-400" />
                </div>
                <p className="text-[8px] md:text-[9px] font-bold uppercase tracking-[0.2em] text-black/70 mb-0.5 md:mb-1">
                  Addison Magazine's
                </p>
                <p className="text-sm md:text-base lg:text-lg font-serif font-bold text-black leading-tight mb-1.5 md:mb-3">
                  Readers Choice Award Winner
                </p>

                <div className="w-full border-t border-black/20 pt-1.5 md:pt-3">
                  <div className="flex items-center justify-center gap-0.5 md:gap-1 mb-1 md:mb-1.5">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className="w-3 h-3 md:w-4 md:h-4 text-black fill-black"
                      />
                    ))}
                  </div>
                  <div className="text-2xl md:text-3xl lg:text-4xl font-serif font-bold text-black leading-none mb-0.5 md:mb-1">
                    4.8
                  </div>
                  <p className="text-[8px] md:text-[9px] font-bold uppercase tracking-wider text-black/70 mb-1.5 md:mb-3">
                    Average Rating
                  </p>

                  <div className="inline-flex items-center gap-1.5 bg-black/90 px-2.5 py-1 md:px-3 md:py-1.5 rounded-full">
                    <span className="text-base md:text-lg lg:text-xl font-serif font-bold text-yellow-400 leading-none">
                      160+
                    </span>
                    <span className="text-[7px] md:text-[8px] font-bold uppercase tracking-wider text-white whitespace-nowrap">
                      Verified Reviews
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Row 2: TEXT left (4 cols) | IMAGE right (8 cols) */}
            <div className="md:col-span-4 bg-zinc-900 border border-zinc-800 rounded-xl p-7 lg:p-9 flex flex-col justify-between shadow-lg h-auto md:h-[320px] lg:h-[280px]">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-primary mb-3">
                  Passenger Safety
                </p>
                <h3 className="text-base lg:text-lg font-serif font-bold text-white leading-snug mb-3">
                  Addison Limos makes rides safer.
                </h3>
                <p className="text-white/70 text-sm font-medium leading-relaxed">
                  Fully licensed, insured, and vetted chauffeurs with real-time
                  GPS monitoring.
                </p>
              </div>

              <div className="mt-3 sm:mt-6 aspect-[28/9] sm:aspect-[16/9] overflow-hidden rounded-lg border border-white/10">
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/assets/f363bfea-960a-4e61-ae98-b3d6e7b23870.png"
                  alt="Professional chauffeur in uniform"
                  loading="lazy"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div className="md:col-span-8 relative overflow-hidden rounded-xl shadow-lg group h-[220px] md:h-[320px] lg:h-[280px]">
              <img
                src="https://vibe.filesafe.space/1792719026995615993/assets/4e9f98f2-a0b1-4359-8168-62dd08f0545a.png"
                alt="Black Lincoln Navigator SUV parked curbside at an elegant hotel at night"
                loading="lazy"
                className="w-full h-full object-cover object-[65%_center] md:object-[65%_60%] transition-transform duration-1000 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent"></div>
            </div>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE - Asymmetric Bento Grid */}
      <section className="py-20 lg:py-24 bg-white border-y border-zinc-200">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-zinc-900 mb-4 lg:mb-6">
              Why Choose Private Car Service?
            </h2>
            <p className="text-zinc-600 max-w-2xl mx-auto text-base lg:text-lg font-light leading-relaxed">
              When reliability, privacy, and professionalism matter most.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 lg:gap-5 max-w-7xl mx-auto">
            {/* Box 1: Large SUV Image Card */}
            <div className="md:col-span-7 md:row-span-2 relative overflow-hidden rounded-xl shadow-lg group min-h-[300px] md:min-h-[480px] bg-zinc-900">
              <img
                src="https://vibe.filesafe.space/1792719026995615993/assets/089aa3e1-3749-42f6-9c54-d8b1eec70385.png"
                alt="Professional chauffeur in a black suit standing beside an open door of a black Lincoln Navigator SUV at an upscale office plaza"
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-65 transition-opacity duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/50 to-black/70"></div>

              <div className="relative z-10 h-full flex flex-col justify-between p-6 lg:p-9">
                <div>
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/15 border border-primary/30 rounded-lg mb-4 lg:mb-5 backdrop-blur-sm w-fit">
                    <Shield className="w-4 h-4 text-primary" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-primary">
                      Featured
                    </span>
                  </div>
                  <h3 className="text-xl lg:text-3xl font-serif font-bold text-white mb-2 lg:mb-3 leading-tight">
                    Dedicated Vehicle & Chauffeur
                  </h3>
                </div>
                <p className="text-sm lg:text-lg text-white/80 font-medium leading-relaxed max-w-md">
                  Your own private driver in a luxury vehicle. No sharing, no
                  stops, no detours. Direct from A to B in complete comfort.
                </p>
              </div>
            </div>

            {/* Box 2: Flight Tracking */}
            <div className="md:col-span-5 bg-zinc-800 border border-zinc-700 rounded-xl p-5 lg:p-8 shadow-lg hover:border-primary/40 transition-all duration-300 group flex flex-col justify-center min-h-[160px] md:min-h-[232px]">
              <div className="w-11 h-11 lg:w-12 lg:h-12 bg-primary/10 border border-primary/20 rounded-xl flex items-center justify-center mb-3 lg:mb-4 group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300 shrink-0">
                <Clock className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
              </div>
              <h3 className="text-base lg:text-lg font-serif font-bold text-white mb-1.5 lg:mb-2 group-hover:text-primary transition-colors">
                Real-Time Flight Tracking
              </h3>
              <p className="text-white/70 text-xs lg:text-sm leading-relaxed font-medium mb-2.5 lg:mb-3">
                We monitor your flight automatically. Early or delayed, your
                pickup adjusts in real-time and we'll always arrive 15 minutes
                early.
              </p>
              <div className="flex items-center gap-1.5 mt-auto">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></div>
                <span className="text-[10px] lg:text-xs text-white/50 font-medium uppercase tracking-wider">
                  Live Tracking Active
                </span>
              </div>
            </div>

            {/* Box 3: Flat Rate */}
            <div className="md:col-span-5 bg-zinc-800 border border-zinc-700 rounded-xl p-5 lg:p-8 shadow-lg hover:border-primary/40 transition-all duration-300 group flex flex-col justify-center min-h-[160px] md:min-h-[232px]">
              <div className="w-11 h-11 lg:w-12 lg:h-12 bg-primary/10 border border-primary/20 rounded-xl flex items-center justify-center mb-3 lg:mb-4 group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300 shrink-0">
                <CreditCard className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
              </div>
              <h3 className="text-base lg:text-lg font-serif font-bold text-white mb-1.5 lg:mb-2 group-hover:text-primary transition-colors">
                Flat-Rate Pricing
              </h3>
              <p className="text-white/70 text-xs lg:text-sm leading-relaxed font-medium">
                Know your fare upfront. No surge pricing, no hidden fees, no
                meter running.
              </p>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="max-w-7xl mx-auto mt-8 lg:mt-10 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
            <Link to="/quote" className="w-full sm:w-auto">
              <button className="w-full sm:w-auto group inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-gradient-to-r from-primary via-yellow-500 to-primary bg-[length:200%_100%] hover:bg-[position:100%_0] text-black font-bold text-sm uppercase tracking-wider rounded-full shadow-lg shadow-primary/20 transition-all duration-500">
                Get a Quote
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </Link>
            <a href="tel:9726083680" className="w-full sm:w-auto">
              <button className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-white border-2 border-zinc-900 text-zinc-900 font-bold text-sm uppercase tracking-wider rounded-full hover:bg-zinc-900 hover:text-white transition-all duration-300">
                <Phone className="w-4 h-4" />
                (972) 608-3680
              </button>
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

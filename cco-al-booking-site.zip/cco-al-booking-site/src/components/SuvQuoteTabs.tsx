import { PrivateCarQuoteForm } from "@/components/PrivateCarQuoteForm";

export const SuvQuoteTabs = () => {
  return (
    <div className="bg-zinc-800 border border-zinc-700 p-4 lg:p-6 rounded-2xl overflow-hidden pb-[36px] lg:pb-6">
      <PrivateCarQuoteForm
        formIdPrefix="private-car"
        formNamePrefix="Private Car"
        heading="Reserve the Lincoln Navigator"
        subheading="One way, round trip, or hourly — get an instant quote."
      />
    </div>
  );
};

import React from "react";
import { Phone, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { PrivateCarQuoteForm } from "@/components/PrivateCarQuoteForm";

export const PrivateCarHero = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center pt-20 pb-12 lg:pt-32 lg:pb-16 overflow-hidden bg-zinc-50">
      <div className="absolute inset-0 z-0">
        <img
          src="https://vibe.filesafe.space/1792719026995615993/attachments/fffb1544-09c3-4429-9842-290f8ea2ae8b.webp"
          alt="Luxury black SUV interior - premium private car service"
          className="w-full h-full object-cover opacity-10"
          fetchPriority="high"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white via-white/95 to-white/70"></div>
      </div>

      <div className="container relative z-10 mx-auto px-4 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-[1.05fr_1fr] gap-6 lg:gap-2.5 items-start">
          {/* Left Content */}
          <div className="relative lg:static">
            {/* Mobile-only hero image frame behind title */}
            <div className="relative lg:hidden h-[320px] sm:h-[380px] rounded-2xl overflow-hidden border border-zinc-700/60 shadow-xl">
              <img
                src="https://vibe.filesafe.space/1792719026995615993/assets/973e4837-cbd3-4c65-8fce-6245bf002c5d.png"
                alt="Chauffeur assisting passenger into luxury SUV private car service"
                className="w-full h-full object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/45 to-black/70"></div>
              <div className="absolute inset-0 flex items-end px-6 pb-4">
                <h1 className="text-3xl font-serif font-bold text-white leading-[1.1] drop-shadow-lg">
                  Premium car service.
                  <br />
                  <span
                    className="text-transparent bg-clip-text bg-gradient-to-b from-yellow-600 via-yellow-500 to-yellow-700"
                    style={{
                      WebkitBackgroundClip: "text",
                      backgroundClip: "text",
                    }}
                  >
                    Booked in seconds.
                  </span>
                </h1>
              </div>
            </div>

            {/* Desktop title/copy */}
            <h1 className="hidden lg:block text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-zinc-900 leading-[1.1] mb-4">
              Premium car service.
              <br />
              <span
                className="text-transparent bg-clip-text bg-gradient-to-b from-yellow-600 via-yellow-500 to-yellow-700"
                style={{
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                }}
              >
                Booked in seconds.
              </span>
            </h1>
            <p className="hidden lg:block text-base md:text-lg text-zinc-600 mb-8 max-w-md leading-relaxed font-light">
              Professional drivers, fixed pricing, guaranteed reliability. For
              the journeys that matter.
            </p>

            {/* Custom Tracked Form */}
            <div className="bg-zinc-800 backdrop-blur-md border border-zinc-600 shadow-xl p-5 lg:p-6 rounded-2xl overflow-hidden w-full max-w-[640px]">
              <PrivateCarQuoteForm
                formIdPrefix="private-car"
                formNamePrefix="Private Car"
                heading="Reserve the Lincoln Navigator"
                subheading="One way, round trip, or hourly — get an instant quote."
              />
            </div>
          </div>

          {/* Right Side - Image + Trust */}
          <div className="hidden lg:flex flex-col gap-6">
            <div className="aspect-[3/4] relative overflow-hidden border border-zinc-700 rounded-xl group shadow-lg max-h-[620px]">
              <img
                src="https://vibe.filesafe.space/1792719026995615993/assets/e4a1c7c2-8ab4-4350-bffe-f42933619ca8.png"
                alt="Sleek black Lincoln Navigator luxury SUV - premium private car service"
                loading="eager"
                className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
              <div className="absolute bottom-5 left-5 right-5 bg-zinc-900/95 border border-primary/30 p-5 backdrop-blur-sm shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-baseline gap-3">
                    <div>
                      <p className="text-xs text-primary font-bold uppercase tracking-wider mb-1">
                        Starting From
                      </p>
                      <p className="text-3xl font-serif font-bold text-white">
                        $95
                        <span className="text-lg text-white/50 font-normal">
                          /hr
                        </span>
                      </p>
                    </div>
                    <span className="text-xs text-white/40 font-medium self-end mb-1">
                      (2 hr minimum)
                    </span>
                  </div>
                  <a
                    href="tel:9726083680"
                    onClick={() => (window as any).gtag_report_conversion?.()}
                  >
                    <Button className="bg-gradient-to-b from-yellow-600 via-yellow-500 to-yellow-700 text-black hover:from-yellow-500 hover:via-yellow-400 hover:to-yellow-600 rounded-none h-12 px-6 text-sm font-semibold shadow-[0_0_15px_rgba(212,175,55,0.25)] border border-yellow-400/30 transition-all duration-300">
                      <Phone className="w-4 h-4 mr-2" />
                      Call Now
                    </Button>
                  </a>
                </div>
              </div>
            </div>

            {/* Testimonial Card */}
            <div className="bg-zinc-800 border border-zinc-700 shadow-lg p-6 rounded-none">
              <div className="flex items-center gap-1 mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-primary fill-primary" />
                ))}
              </div>
              <p className="text-sm text-white/90 italic leading-relaxed mb-4 font-medium">
                "Best Dallas limo service! We used Addison limos to bring us to
                Cowboys stadium for a football game they were absolutely the
                best. Affordable rates, clean limo, and first class service.
                Highly recommended!"
              </p>
              <div className="flex items-center gap-3 pt-3 border-t border-white/10">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center border border-primary/20">
                  <span className="text-primary font-serif font-bold text-sm">
                    T
                  </span>
                </div>
                <div>
                  <p className="text-white font-semibold text-sm">
                    Theseus Smith
                  </p>
                  <p className="text-white/50 text-xs font-medium">
                    Google Review
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

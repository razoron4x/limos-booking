import { Calendar } from "lucide-react";

type RoundTripSectionProps = {
  isDifferentDay: boolean;
  sameReturnLocations: boolean;
  onToggleSameLocations: () => void;
  returnTime: string;
  onReturnTimeChange: (v: string) => void;
  returnDate: string;
  onReturnDateChange: (v: string) => void;
  returnDateRef: React.RefObject<HTMLInputElement>;
  returnPickupAddress: string;
  onReturnPickupChange: (v: string) => void;
  returnDropoffAddress: string;
  onReturnDropoffChange: (v: string) => void;
  inputClass: string;
  labelClass: string;
};

export const RoundTripSection = ({
  isDifferentDay,
  sameReturnLocations,
  onToggleSameLocations,
  returnTime,
  onReturnTimeChange,
  returnDate,
  onReturnDateChange,
  returnDateRef,
  returnPickupAddress,
  onReturnPickupChange,
  returnDropoffAddress,
  onReturnDropoffChange,
  inputClass,
  labelClass,
}: RoundTripSectionProps) => {
  const showReturnAddressFields = !sameReturnLocations;

  return (
    <div className="pt-2 pb-2 space-y-5 border-t border-amber-500/20">
      {/* Same Return Pickup and Dropoff Locations? */}
      <div>
        <label className={labelClass}>
          Same Return Pickup and Dropoff Locations?
        </label>
        <label className="inline-flex items-center gap-2 cursor-pointer select-none text-sm text-white/90">
          <input
            type="checkbox"
            checked={!sameReturnLocations}
            onChange={onToggleSameLocations}
            className="w-4 h-4 rounded border-amber-500/50 bg-[#544f4e] text-amber-500 focus:ring-amber-400 accent-amber-500 cursor-pointer"
          />
          <span>No</span>
        </label>
      </div>

      {/* Return Time & (optional) Return Date */}
      <div
        className={`grid grid-cols-1 ${
          isDifferentDay ? "sm:grid-cols-2" : ""
        } gap-4 sm:gap-5`}
      >
        <div>
          <label className={labelClass}>
            RETURN Time of Pickup <span className="text-amber-400">*</span>
          </label>
          <input
            type="text"
            required
            placeholder="e.g. 10:30 PM"
            value={returnTime}
            onChange={(e) => onReturnTimeChange(e.target.value)}
            className={inputClass}
          />
        </div>

        {/* Only ask for return date if Different Day */}
        {isDifferentDay && (
          <div>
            <label className={labelClass}>
              RETURN Date of Pickup <span className="text-amber-400">*</span>
            </label>
            <div
              className="relative rounded-md bg-[#544f4e] border border-amber-500/50 flex items-center cursor-pointer"
              onClick={() => {
                const input = returnDateRef.current;
                if (!input) return;
                try {
                  input.focus();
                  input.showPicker();
                } catch (e) {
                  console.error("Date picker error:", e);
                }
              }}
            >
              <Calendar className="w-4 h-4 ml-3 text-white/60 shrink-0 pointer-events-none" />
              <input
                ref={returnDateRef}
                type="date"
                required
                value={returnDate}
                onChange={(e) => onReturnDateChange(e.target.value)}
                className="w-full bg-transparent px-3 py-2.5 text-sm text-white placeholder-white/40 focus:outline-none cursor-pointer"
                style={{ colorScheme: "dark" }}
              />
            </div>
          </div>
        )}
      </div>

      {/* If user checked No on same return locations, show Return Pickup and Dropoff fields */}
      {showReturnAddressFields && (
        <div className="space-y-4">
          <div>
            <label className={labelClass}>
              RETURN Pickup Address <span className="text-amber-400">*</span>
            </label>
            <textarea
              required
              rows={3}
              placeholder="Return Pickup Address"
              value={returnPickupAddress}
              onChange={(e) => onReturnPickupChange(e.target.value)}
              className={`${inputClass} resize-y`}
            />
          </div>

          <div>
            <label className={labelClass}>
              RETURN Dropoff Address <span className="text-amber-400">*</span>
            </label>
            <textarea
              required
              rows={3}
              placeholder="Return Dropoff Address"
              value={returnDropoffAddress}
              onChange={(e) => onReturnDropoffChange(e.target.value)}
              className={`${inputClass} resize-y`}
            />
          </div>
        </div>
      )}
    </div>
  );
};

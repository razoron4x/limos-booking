import { useState, useMemo } from "react";
import {
  getCountries,
  getCountryCallingCode,
  type CountryCode,
} from "libphonenumber-js";

type CountrySelectorProps = {
  country: CountryCode;
  onSelect: (c: CountryCode) => void;
};

export const CountrySelector = ({
  country,
  onSelect,
}: CountrySelectorProps) => {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  const countries = useMemo(
    () =>
      getCountries()
        .map((c: CountryCode) => {
          let name: string = c;
          try {
            name = new Intl.DisplayNames(["en"], { type: "region" }).of(c) || c;
          } catch {}
          return {
            c,
            name,
            dial: `+${getCountryCallingCode(c)}`,
          };
        })
        .sort((a, b) => a.name.localeCompare(b.name)),
    [],
  );

  return (
    <>
      <button
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-1.5 px-2.5 py-2.5 text-xs text-white/90 hover:bg-white/5 border-r border-white/10 shrink-0"
      >
        <span className="text-sm">
          {country === "US"
            ? "🇺🇸"
            : country === "CA"
              ? "🇨🇦"
              : country === "MX"
                ? "🇲🇽"
                : country === "GB"
                  ? "🇬🇧"
                  : "🌐"}
        </span>
        <span className="text-xs font-mono text-white/80">
          +{getCountryCallingCode(country)}
        </span>
        <span className="text-[9px] text-white/40">▼</span>
      </button>

      {open && (
        <div
          role="listbox"
          className="absolute left-0 top-full mt-1 z-50 w-64 max-h-56 overflow-y-auto rounded-md border border-zinc-700 bg-zinc-900 shadow-2xl p-1"
        >
          <input
            autoFocus
            placeholder="Search country..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-2.5 py-1.5 mb-1 text-xs rounded bg-zinc-800 border border-zinc-700 text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400"
          />
          {countries
            .filter(
              (x) =>
                x.name.toLowerCase().includes(search.toLowerCase()) ||
                x.dial.includes(search),
            )
            .map((x) => (
              <div
                key={x.c}
                role="option"
                aria-selected={x.c === country}
                onClick={() => {
                  onSelect(x.c);
                  setOpen(false);
                  setSearch("");
                }}
                className={`px-2 py-1.5 text-xs rounded cursor-pointer flex items-center justify-between hover:bg-zinc-800 ${
                  x.c === country
                    ? "bg-amber-500/20 text-amber-400 font-bold"
                    : "text-zinc-200"
                }`}
              >
                <span className="truncate">{x.name}</span>
                <span className="text-zinc-400 font-mono ml-2 shrink-0">
                  {x.dial}
                </span>
              </div>
            ))}
        </div>
      )}
    </>
  );
};

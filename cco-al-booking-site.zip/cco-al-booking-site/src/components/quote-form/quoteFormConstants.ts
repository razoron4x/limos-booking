export const VEHICLE_OPTIONS = [
  "H2 Hummer Limo",
  "Mercedes Sprinter Limo",
  "Luxury Black Stretch Limo",
  "Mercedes Sprinter Executive",
  "Lincoln Navigator SUV",
  "Mercedes Sprinter Van",
];

export const SERVICE_TYPE_OPTIONS = [
  "One Way",
  "Round Trip - Different Day",
  "Round Trip - Same Day",
  "Hourly Chauffeur Service",
  "Don't Know Yet",
];

export const CHILD_SEAT_OPTIONS = [
  "No Child Car Seats Needed",
  "1 Toddler Front Facing Carseat",
  "2 Toddler Front Facing Carseats",
  "1 Infant Rear Facing Carseat",
  "2 Infant Rear Facing Carseats",
  "1 Booster Seat",
  "2 Booster Seats",
  "Multiple Different Carseats",
];

export const getTrackingSessionId = () => {
  try {
    const sid = document.cookie.match(
      /(?:^|;\s*)__vibe_sid=([0-9a-f-]{36})(?:;|$)/,
    )?.[1];
    if (sid) return sid;
  } catch {}
  return crypto.randomUUID();
};

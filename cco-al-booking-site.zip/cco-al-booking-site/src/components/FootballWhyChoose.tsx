import { Link } from "react-router-dom";
import { Phone, Shield, PartyPopper, Trophy, ChevronRight } from "lucide-react";

const FootballWhyChoose = () => {
  return (
    <section className="py-20 lg:py-24 bg-[#0d0d0d] border-y border-white/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4 lg:mb-6">
            The Only Way to Arrive on Game Day
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto text-base lg:text-lg font-light leading-relaxed">
            The tailgate starts the moment you step onboard.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 lg:gap-5 max-w-7xl mx-auto">
          {/* Box 1: Large VIP Drop-Off Image Card */}
          <div className="md:col-span-7 md:row-span-2 relative overflow-hidden rounded-xl shadow-lg group min-h-[260px] md:min-h-[420px] bg-zinc-900">
            <img
              src="https://vibe.filesafe.space/1792719026995615993/attachments/7d0467f9-29d0-4e80-83a5-6db862861ddd.jpg"
              alt="White H2 Hummer limo parked at AT&T Stadium for VIP game day drop-off"
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover object-top translate-y-8 opacity-50 group-hover:opacity-65 transition-opacity duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/50 to-black/70"></div>

            <div className="relative z-10 h-full flex flex-col justify-between p-6 lg:p-9">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/15 border border-primary/30 rounded-lg mb-4 lg:mb-5 backdrop-blur-sm w-fit">
                  <Trophy className="w-4 h-4 text-primary" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-primary">
                    Game Day
                  </span>
                </div>
                <h3 className="text-xl lg:text-3xl font-serif font-bold text-white mb-2 lg:mb-3 leading-tight">
                  VIP Stadium Drop-Off
                </h3>
              </div>
              <p className="text-sm lg:text-lg text-white/80 font-medium leading-relaxed max-w-md">
                Direct access to the closest stadium entrances. No long walks,
                no parking fees, no post-game gridlock.
              </p>
            </div>
          </div>

          {/* Box 2: Tailgate Onboard */}
          <div className="md:col-span-5 bg-zinc-800 border border-zinc-700 rounded-xl p-5 lg:p-8 shadow-lg hover:border-primary/40 transition-all duration-300 group flex flex-col justify-center min-h-[160px] md:min-h-[206px]">
            <div className="w-11 h-11 lg:w-12 lg:h-12 bg-primary/10 border border-primary/20 rounded-xl flex items-center justify-center mb-3 lg:mb-4 group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300 shrink-0">
              <PartyPopper className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
            </div>
            <h3 className="text-base lg:text-lg font-serif font-bold text-white mb-1.5 lg:mb-2 group-hover:text-primary transition-colors">
              Tailgate Onboard
            </h3>
            <p className="text-white/70 text-xs lg:text-sm leading-relaxed font-medium">
              Surround sound, LED lighting, wet bars, and cooler bins keep the
              team spirit going before you even reach the gate.
            </p>
          </div>

          {/* Box 3: Safe Return Home */}
          <div className="md:col-span-5 bg-zinc-800 border border-zinc-700 rounded-xl p-5 lg:p-8 shadow-lg hover:border-primary/40 transition-all duration-300 group flex flex-col justify-center min-h-[160px] md:min-h-[206px]">
            <div className="w-11 h-11 lg:w-12 lg:h-12 bg-primary/10 border border-primary/20 rounded-xl flex items-center justify-center mb-3 lg:mb-4 group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300 shrink-0">
              <Shield className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
            </div>
            <h3 className="text-base lg:text-lg font-serif font-bold text-white mb-1.5 lg:mb-2 group-hover:text-primary transition-colors">
              Safe Return Home
            </h3>
            <p className="text-white/70 text-xs lg:text-sm leading-relaxed font-medium">
              Celebrate responsibly with a guaranteed safe ride home. No surge
              pricing, no rideshare lines, no stress.
            </p>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="max-w-7xl mx-auto mt-8 lg:mt-10 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
          <Link
            to="/quote?service=Football%20Group%20Transportation"
            className="w-full sm:w-auto"
          >
            <button className="w-full sm:w-auto group inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-gradient-to-r from-primary via-yellow-500 to-primary bg-[length:200%_100%] hover:bg-[position:100%_0] text-black font-bold text-sm uppercase tracking-wider rounded-full shadow-lg shadow-primary/20 transition-all duration-500">
              Get a Quote
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </Link>
          <a
            href="tel:9726083680"
            className="w-full sm:w-auto"
            onClick={() => (window as any).gtag_report_conversion?.()}
          >
            <button className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-white border-2 border-zinc-900 text-zinc-900 font-bold text-sm uppercase tracking-wider rounded-full hover:bg-zinc-900 hover:text-white hover:border-white transition-all duration-300">
              <Phone className="w-4 h-4" />
              (972) 608-3680
            </button>
          </a>
        </div>
      </div>
    </section>
  );
};

export default FootballWhyChoose;

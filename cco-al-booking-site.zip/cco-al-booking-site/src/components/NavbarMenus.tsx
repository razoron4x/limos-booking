import { Link, useLocation } from "react-router-dom";
import { ChevronDown, Plus, Minus, Ghost } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const itemClass =
  "focus:bg-primary/20 focus:text-primary cursor-pointer rounded-none py-2 px-4 transition-colors";

export const DesktopServicesDropdown = ({
  darkText,
}: {
  darkText: boolean;
}) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        className={`text-sm font-medium transition-colors flex items-center gap-1 outline-none ${darkText ? "text-zinc-700 hover:text-zinc-900" : "text-white/80 hover:text-white"}`}
      >
        Services <ChevronDown className="w-4 h-4" />
      </DropdownMenuTrigger>
      <DropdownMenuContent className="bg-zinc-950 border-white/10 rounded-none shadow-2xl mt-2 p-2 min-w-[200px] max-h-[70vh] overflow-y-auto">
        <DropdownMenuItem
          asChild
          className={`${itemClass} border-b border-white/10 mb-1 font-bold`}
        >
          <Link to="/services" className="w-full text-white hover:text-primary">
            All Services
          </Link>
        </DropdownMenuItem>

        <DropdownMenuItem
          asChild
          className={`${itemClass} border-b border-primary/20 mb-1`}
        >
          <Link
            to="/service-halloween"
            className="w-full text-primary hover:text-primary font-bold flex items-center gap-2"
          >
            <Ghost className="w-4 h-4" />
            Halloween Transportation
          </Link>
        </DropdownMenuItem>

        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-private-car"
            className="w-full text-white hover:text-primary"
          >
            Private Car
          </Link>
        </DropdownMenuItem>

        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-airport"
            className="w-full text-white hover:text-primary"
          >
            Airport Transfers
          </Link>
        </DropdownMenuItem>

        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-events"
            className="w-full text-white hover:text-primary"
          >
            Special Events
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-football"
            className="w-full text-white hover:text-primary"
          >
            Football Transportation
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-homecoming"
            className="w-full text-white hover:text-primary"
          >
            Homecoming
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-group"
            className="w-full text-white hover:text-primary"
          >
            Group Transportation
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-wedding"
            className="w-full text-white hover:text-primary"
          >
            Wedding Chauffeur
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-sporting-concerts"
            className="w-full text-white hover:text-primary"
          >
            Sporting Events & Concerts
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-birthday"
            className="w-full text-white hover:text-primary"
          >
            Birthday Services
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-city-tours"
            className="w-full text-white hover:text-primary"
          >
            City Tours
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-wine-tours"
            className="w-full text-white hover:text-primary"
          >
            Wine Tours
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-holiday-lights"
            className="w-full text-white hover:text-primary"
          >
            Holiday Light Tours
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-point-to-point"
            className="w-full text-white hover:text-primary"
          >
            Point to Point
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-vip"
            className="w-full text-white hover:text-primary"
          >
            VIP Service
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-shuttle"
            className="w-full text-white hover:text-primary"
          >
            Shuttle Service
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-medical-transport"
            className="w-full text-white hover:text-primary"
          >
            Medical Transport
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className={itemClass}>
          <Link
            to="/service-funeral"
            className="w-full text-white hover:text-primary"
          >
            Funeral Services
          </Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

interface MobileServicesListProps {
  servicesOpen: boolean;
  setServicesOpen: (open: boolean) => void;
  lightPage: boolean;
}

export const MobileServicesList = ({
  servicesOpen,
  setServicesOpen,
  lightPage,
}: MobileServicesListProps) => {
  const location = useLocation();

  const baseLink = (path: string) =>
    `text-sm font-medium transition-colors ${location.pathname === path ? "text-primary" : lightPage ? "text-zinc-600 hover:text-primary" : "text-white/60 hover:text-primary"}`;

  return (
    <div className="flex flex-col gap-2 p-2">
      <button
        className={`flex items-center justify-between text-sm font-medium w-full ${lightPage ? "text-zinc-700" : "text-white/80"}`}
        onClick={() => setServicesOpen(!servicesOpen)}
      >
        Services
        {servicesOpen ? (
          <Minus className="w-4 h-4" />
        ) : (
          <Plus className="w-4 h-4" />
        )}
      </button>
      {servicesOpen && (
        <div
          className={`flex flex-col pl-4 gap-3 mt-1 border-l max-h-[40vh] overflow-y-auto ${lightPage ? "border-zinc-200" : "border-white/10"}`}
        >
          <Link
            to="/service-halloween"
            className={`text-sm font-bold transition-colors mb-1 flex items-center gap-2 ${location.pathname === "/service-halloween" ? "text-primary" : "text-primary hover:text-primary/80"}`}
          >
            <Ghost className="w-4 h-4" />
            Halloween Transportation
          </Link>
          <Link
            to="/services"
            className={`text-sm font-bold transition-colors mb-1 ${location.pathname === "/services" ? "text-primary" : lightPage ? "text-zinc-600 hover:text-primary" : "text-white/60 hover:text-primary"}`}
          >
            All Services
          </Link>
          <Link
            to="/service-private-car"
            className={baseLink("/service-private-car")}
          >
            Private Car
          </Link>
          <Link to="/service-airport" className={baseLink("/service-airport")}>
            Airport Transfers
          </Link>
          <Link to="/service-events" className={baseLink("/service-events")}>
            Special Events
          </Link>
          <Link
            to="/service-football"
            className={baseLink("/service-football")}
          >
            Football Transportation
          </Link>
          <Link
            to="/service-homecoming"
            className={baseLink("/service-homecoming")}
          >
            Homecoming
          </Link>
          <Link to="/service-wedding" className={baseLink("/service-wedding")}>
            Wedding Chauffeur
          </Link>
          <Link to="/service-group" className={baseLink("/service-group")}>
            Group Transportation
          </Link>
          <Link
            to="/service-sporting-concerts"
            className={baseLink("/service-sporting-concerts")}
          >
            Sporting Events & Concerts
          </Link>
          <Link
            to="/service-birthday"
            className={baseLink("/service-birthday")}
          >
            Birthday Services
          </Link>
          <Link
            to="/service-city-tours"
            className={baseLink("/service-city-tours")}
          >
            City Tours
          </Link>
          <Link
            to="/service-wine-tours"
            className={baseLink("/service-wine-tours")}
          >
            Wine Tours
          </Link>
          <Link
            to="/service-holiday-lights"
            className={baseLink("/service-holiday-lights")}
          >
            Holiday Light Tours
          </Link>
          <Link
            to="/service-point-to-point"
            className={baseLink("/service-point-to-point")}
          >
            Point to Point
          </Link>
          <Link to="/service-vip" className={baseLink("/service-vip")}>
            VIP Service
          </Link>
          <Link to="/service-shuttle" className={baseLink("/service-shuttle")}>
            Shuttle Service
          </Link>
          <Link
            to="/service-medical-transport"
            className={baseLink("/service-medical-transport")}
          >
            Medical Transport
          </Link>
          <Link to="/service-funeral" className={baseLink("/service-funeral")}>
            Funeral Services
          </Link>
        </div>
      )}
    </div>
  );
};

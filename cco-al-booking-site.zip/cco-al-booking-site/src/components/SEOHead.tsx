import { Helmet } from "react-helmet-async";

interface SEOHeadProps {
  title: string;
  description: string;
  canonical?: string;
  ogImage?: string;
  noIndex?: boolean;
  schemaJson?: Record<string, any>;
}

export function SEOHead({
  title,
  description,
  canonical,
  ogImage,
  noIndex,
  schemaJson,
}: SEOHeadProps) {
  const fullTitle = title.includes("Addison Limos")
    ? title
    : `${title} | Addison Limos Staff Portal`;
  const finalOgImage =
    ogImage ||
    "https://vibe.filesafe.space/1792719026995615993/attachments/51e6ee25-b03c-4a29-9660-4da2bb28ed9e.webp";

  return (
    <Helmet>
      <title>{fullTitle}</title>
      <meta name="description" content={description} />

      {/* Open Graph / Facebook */}
      <meta property="og:type" content="website" />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={finalOgImage} />
      {canonical && <meta property="og:url" content={canonical} />}

      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={finalOgImage} />

      {/* Canonical Link */}
      {canonical && <link rel="canonical" href={canonical} />}

      {/* Robots — internal portal, keep out of search engines */}
      <meta name="robots" content="noindex, nofollow" />

      {/* Structured Data */}
      {schemaJson && (
        <script type="application/ld+json">{JSON.stringify(schemaJson)}</script>
      )}
    </Helmet>
  );
}

import { useState } from "react";
import { Link } from "react-router-dom";
import { MapPin, ChevronRight } from "lucide-react";

const popularCities = [
  { name: "Dallas", popular: true, link: "dallas" },
  { name: "Fort Worth", popular: true, link: "fort-worth" },
  { name: "Addison", popular: true, link: "addison" },
  { name: "Plano", popular: true, link: "plano" },
  { name: "Frisco", popular: true, link: "frisco" },
  { name: "Irving", popular: true, link: "irving" },
  { name: "Grapevine", popular: true, link: "grapevine" },
  { name: "Arlington", popular: true, link: "arlington" },
  { name: "Richardson", popular: true, link: "richardson" },
  { name: "Garland", popular: true, link: "garland" },
  { name: "McKinney", popular: true, link: "mckinney" },
  { name: "Allen", popular: false, link: null },
  { name: "Carrollton", popular: false, link: "carrollton" },
  { name: "Denton", popular: false, link: "denton" },
  { name: "Lewisville", popular: false, link: "lewisville" },
  { name: "Flower Mound", popular: false, link: "flower-mound" },
  { name: "Coppell", popular: false, link: null },
  { name: "Southlake", popular: false, link: "southlake" },
  { name: "Colleyville", popular: false, link: null },
  { name: "Keller", popular: false, link: null },
];

const extraCityNames = [
  "Euless",
  "Bedford",
  "Hurst",
  "North Richland Hills",
  "Watauga",
  "Haltom City",
  "Farmers Branch",
  "University Park",
  "Highland Park",
  "Rockwall",
  "Rowlett",
  "Sachse",
  "Wylie",
  "Murphy",
  "Prosper",
  "Celina",
  "Little Elm",
  "Corinth",
  "Lake Dallas",
  "Justin",
  "Argyle",
  "Trophy Club",
  "Roanoke",
  "Haslet",
  "Saginaw",
  "Burleson",
  "Mansfield",
  "Kennedale",
  "Forest Hill",
  "Everman",
  "Crowley",
  "Midlothian",
  "Waxahachie",
  "Red Oak",
  "DeSoto",
  "Lancaster",
  "Balch Springs",
  "Sunnyvale",
  "Wilmer",
  "Hutchins",
  "Seagoville",
  "Terrell",
  "Duncanville",
  "Cedar Hill",
  "Mesquite",
  "Grand Prairie",
  "The Colony",
  "Weatherford",
  "Azle",
  "Springtown",
  "Aledo",
  "Krum",
  "Sanger",
];

const extraCities = extraCityNames.map((name) => ({
  name,
  popular: false as boolean,
  link:
    name === "Duncanville"
      ? "duncanville"
      : name === "Cedar Hill"
        ? "cedar-hill"
        : null,
}));

const airports = [
  { name: "DFW International Airport (DFW)", link: "/service-airport" },
  { name: "Dallas Love Field (DAL)", link: "/service-airport" },
  { name: "Addison Airport (ADS)", link: "/service-airport" },
  { name: "Fort Worth Meacham Airport", link: "/service-airport" },
];

export const HomeMetroplex = () => {
  const [activeTab, setActiveTab] = useState<"cities" | "airports">("cities");
  const [showAll, setShowAll] = useState(false);

  const allCities = [...popularCities, ...extraCities];
  const totalCities = allCities.length;
  const visibleCities = showAll ? allCities : popularCities;

  return (
    <section className="py-24 bg-zinc-950 relative border-t border-white/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4">
            Proudly Serving the{" "}
            <span className="text-primary">Dallas-Fort Worth Metroplex</span>
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto text-base sm:text-lg font-light leading-relaxed">
            From downtown Dallas to Fort Worth and everywhere in between,
            Addison Limos provides luxury chauffeur transportation across the
            DFW area. With 20+ years of experience, our professional chauffeurs
            know every route, neighborhood, and shortcut.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start max-w-6xl mx-auto">
          {/* Map Side */}
          <div className="lg:col-span-5 relative overflow-hidden border border-white/10 rounded-xl aspect-[4/3] lg:aspect-auto lg:h-full min-h-[320px]">
            <iframe
              title="Addison Limos DFW Service Area Map"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d428983.8427773229!2d-97.10000000000001!3d32.7767!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x864e99222687d002%3A0x6b24508493...!2sDallas-Fort+Worth%20Metroplex!5e0!3m2!1sen!2sus!4v1700000000000"
              width="100%"
              height="100%"
              style={{
                border: 0,
                filter: "invert(90%) hue-rotate(180deg) contrast(120%)",
              }}
              allowFullScreen={false}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="w-full h-full min-h-[320px] object-cover"
            ></iframe>
            <a
              href="https://maps.google.com/?q=Dallas-Fort+Worth+Metroplex"
              target="_blank"
              rel="noopener noreferrer"
              className="absolute top-3 left-3 bg-black/80 text-white text-xs font-semibold px-3 py-1.5 rounded border border-white/20 hover:border-primary/50 transition-colors backdrop-blur-sm"
            >
              Open in Maps ↗
            </a>
          </div>

          {/* Cities / Airports Tabbed Side */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex gap-2 border border-white/10 rounded-lg p-1 bg-zinc-900/50 max-w-xs">
              <button
                onClick={() => setActiveTab("cities")}
                className={`flex-1 py-2 rounded-md text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                  activeTab === "cities"
                    ? "bg-primary text-black shadow-[0_0_15px_rgba(212,175,55,0.3)]"
                    : "text-white/60 hover:text-white"
                }`}
              >
                <MapPin className="w-3.5 h-3.5" /> CITIES
              </button>
              <button
                onClick={() => setActiveTab("airports")}
                className={`flex-1 py-2 rounded-md text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                  activeTab === "airports"
                    ? "bg-primary text-black shadow-[0_0_15px_rgba(212,175,55,0.3)]"
                    : "text-white/60 hover:text-white"
                }`}
              >
                ✈ AIRPORTS
              </button>
            </div>

            {activeTab === "cities" ? (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {visibleCities.map((city, i) => {
                    const inner = (
                      <>
                        <div className="flex items-center gap-2 min-w-0">
                          <MapPin className="w-4 h-4 text-primary shrink-0" />
                          <span className="text-white text-sm font-bold truncate group-hover:text-primary transition-colors">
                            {city.name}
                          </span>
                        </div>
                        {city.popular && (
                          <span className="text-[9px] uppercase font-bold text-primary/80 bg-primary/10 px-1.5 py-0.5 rounded shrink-0 ml-1">
                            POPULAR
                          </span>
                        )}
                      </>
                    );
                    const cls = `p-3 rounded-md bg-zinc-900/50 border flex items-center justify-between group transition-colors ${
                      city.popular
                        ? "border-primary/40 hover:border-primary/70"
                        : "border-white/10 hover:border-primary/40"
                    }`;
                    return city.link ? (
                      <Link
                        key={i}
                        to={`/limo-service/${city.link}`}
                        className={cls}
                      >
                        {inner}
                      </Link>
                    ) : (
                      <div key={i} className={cls}>
                        {inner}
                      </div>
                    );
                  })}
                </div>

                <button
                  onClick={() => setShowAll((prev) => !prev)}
                  className="w-full py-3 border border-white/10 rounded-md text-white/80 text-xs font-bold uppercase tracking-wider hover:border-primary/40 hover:text-primary transition-all flex items-center justify-center gap-2"
                >
                  {showAll
                    ? "Show Fewer Cities"
                    : `Show All ${totalCities} Service Areas`}
                  <ChevronRight
                    className={`w-4 h-4 transition-transform ${showAll ? "rotate-90" : ""}`}
                  />
                </button>

                <p className="text-white/40 text-xs font-light text-center pt-2 border-t border-white/5">
                  Don't see your city listed? We serve the entire DFW metroplex
                  and surrounding regions.
                </p>
              </>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {airports.map((ap, i) => (
                  <Link
                    key={i}
                    to={ap.link}
                    className="p-4 rounded-md bg-zinc-900/50 border border-white/10 flex items-center gap-3 group hover:border-primary/40 transition-colors"
                  >
                    <div className="w-8 h-8 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                      <span className="text-primary font-bold text-sm">✈</span>
                    </div>
                    <span className="text-white text-sm font-bold group-hover:text-primary transition-colors">
                      {ap.name}
                    </span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

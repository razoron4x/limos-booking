import { Link } from "react-router-dom";
import { ArrowRight, PartyPopper, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export type ServiceCard = {
  to: string;
  label: string;
  tag: string;
  icon: React.ComponentType<{ className?: string }>;
  image: string;
};

const serviceImageMap: Record<string, string> = {
  "/service-airport":
    "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/4d3f47f5-2f76-49d9-8a37-a21cd0292ef7-generated-image-1785811775410-0.png",
  "/corporate":
    "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/bceddc76-1a3e-4adc-a1d7-7a07cc8c0340/standalone/26dc1fa8-aa1e-4371-86ae-e099795a0bd0-generated-image-1785811276626-0.png",
  "/service-events":
    "https://vibe.filesafe.space/1792719026995615993/assets/4447daa8-5b29-4357-bd94-d7dbd9ecfc08.png",
  "/service-vip":
    "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
  "/service-wine-tours":
    "https://vibe.filesafe.space/1792719026995615993/attachments/e7319457-c2da-4518-8f5e-f950a8b734ce.webp",
  "/service-city-tours":
    "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/313ca68d-5acc-4b95-be9b-cbdcc67b7512-generated-image-1785812179616-0.png",
  "/service-birthday":
    "https://vibe.filesafe.space/1792719026995615993/assets/5104762e-f215-457b-9a2f-7826dd899c2e.png",
  "/service-sporting-concerts":
    "https://vibe.filesafe.space/1792719026995615993/assets/d72f646b-2b2c-4ee6-bc73-d35abb34b15f.png",
  "/service-wedding":
    "https://vibe.filesafe.space/1792719026995615993/assets/08af7f69-c47e-47f7-ae12-782b7db0f8aa.png",
  "/service-group":
    "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/bceddc76-1a3e-4adc-a1d7-7a07cc8c0340/standalone/26dc1fa8-aa1e-4371-86ae-e099795a0bd0-generated-image-1785811276626-0.png",
  "/service-shuttle":
    "https://vibe.filesafe.space/1792719026995615993/assets/b7c5167e-d41d-4015-b609-7d7206092505.png",
  "/service-point-to-point":
    "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
  "/service-medical-transport":
    "https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/c45ee9ca-835f-466b-a2d7-9962c977287b-generated-image-1785812759704-0.png",
  "/service-funeral":
    "https://vibe.filesafe.space/1792719026995615993/attachments/e7319457-c2da-4518-8f5e-f950a8b734ce.webp",
};

const serviceDefs: Record<
  string,
  {
    to: string;
    label: string;
    tag: string;
    icon: React.ComponentType<{ className?: string }>;
  }
> = {
  airport: {
    to: "/service-airport",
    label: "Airport Transfers",
    tag: "Most Booked",
    icon: PartyPopper,
  },
  corporate: {
    to: "/corporate",
    label: "Corporate Travel",
    tag: "For Business",
    icon: PartyPopper,
  },
  events: {
    to: "/service-events",
    label: "Special Events",
    tag: "For Occasions",
    icon: PartyPopper,
  },
  vip: {
    to: "/service-vip",
    label: "VIP Service",
    tag: "For VIPs",
    icon: PartyPopper,
  },
  wine: {
    to: "/service-wine-tours",
    label: "Wine Tours",
    tag: "For Tours",
    icon: PartyPopper,
  },
  city: {
    to: "/service-city-tours",
    label: "City Tours",
    tag: "For Tours",
    icon: PartyPopper,
  },
  birthday: {
    to: "/service-birthday",
    label: "Birthday Parties",
    tag: "For Parties",
    icon: PartyPopper,
  },
  sporting: {
    to: "/service-sporting-concerts",
    label: "Concerts & Games",
    tag: "For Events",
    icon: PartyPopper,
  },
  wedding: {
    to: "/service-wedding",
    label: "Weddings",
    tag: "For Couples",
    icon: PartyPopper,
  },
  group: {
    to: "/service-group",
    label: "Group Transport",
    tag: "For Groups",
    icon: PartyPopper,
  },
  shuttle: {
    to: "/service-shuttle",
    label: "Shuttle Services",
    tag: "For Teams",
    icon: PartyPopper,
  },
  point: {
    to: "/service-point-to-point",
    label: "Point to Point",
    tag: "For Travel",
    icon: PartyPopper,
  },
  medical: {
    to: "/service-medical-transport",
    label: "Medical Transport",
    tag: "For Care",
    icon: PartyPopper,
  },
  funeral: {
    to: "/service-funeral",
    label: "Funeral Transportation",
    tag: "For Families",
    icon: PartyPopper,
  },
};

// Top 3 most accustomed services per vehicle (ordered by relevance)
const vehicleServiceKeys: Record<string, string[]> = {
  "h2-hummer-stretch-limo": ["birthday", "sporting", "events"],
  "mercedes-sprinter-limo": ["group", "wine", "sporting"],
  "luxury-black-stretch-limo": ["wedding", "events", "birthday"],
  "mercedes-sprinter-executive": ["corporate", "airport", "vip"],
  "lincoln-navigator-suv": ["airport", "vip", "corporate"],
  "mercedes-sprinter-van": ["group", "shuttle", "airport"],
};

// Vehicle-specific image overrides so the same service card can show a
// photo of the actual vehicle being viewed (keyed by `${vehicleId}:${serviceKey}`)
const vehicleImageOverrides: Record<string, string> = {
  "mercedes-sprinter-limo:sporting":
    "https://vibe.filesafe.space/1792719026995615993/assets/6ff278cd-d4ae-4502-b7ca-852da248cfb7.png",
  "luxury-black-stretch-limo:wedding":
    "https://vibe.filesafe.space/1792719026995615993/assets/95789354-9aa0-45fd-bf4a-481596456c44.png",
  "luxury-black-stretch-limo:events":
    "https://vibe.filesafe.space/1792719026995615993/assets/4447daa8-5b29-4357-bd94-d7dbd9ecfc08.png",
  "luxury-black-stretch-limo:birthday":
    "https://vibe.filesafe.space/1792719026995615993/assets/c232f87e-29ff-4ab9-913b-1dec1e5b41f0.png",
  "mercedes-sprinter-van:shuttle":
    "https://vibe.filesafe.space/1792719026995615993/assets/efb2bb08-722a-4d40-8f68-d470489c2454.png",
};

const getVehicleServices = (vehicleId: string): ServiceCard[] => {
  const keys = vehicleServiceKeys[vehicleId] || [
    "airport",
    "corporate",
    "events",
  ];
  return keys.map((k) => {
    const def = serviceDefs[k];
    return {
      to: def.to,
      label: def.label,
      tag: def.tag,
      icon: def.icon,
      image:
        vehicleImageOverrides[`${vehicleId}:${k}`] ||
        serviceImageMap[def.to] ||
        serviceImageMap["/service-events"],
    };
  });
};

interface VehiclePopularEventsProps {
  vehicle: {
    id: string;
    shortTitle: string;
  };
}

export const VehiclePopularEvents = ({
  vehicle,
}: VehiclePopularEventsProps) => {
  const services = getVehicleServices(vehicle.id);
  const [featured, second, third] = services;

  return (
    <section className="py-20 px-4 border-t border-white/5">
      <div className="container mx-auto">
        <div className="text-center mb-12 lg:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <PartyPopper className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold tracking-widest uppercase text-primary">
              Popular Events
            </span>
          </div>
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4 leading-tight">
            Perfect For Every Occasion
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto text-lg font-light leading-relaxed">
            The most-requested experiences booked with our {vehicle.shortTitle}{" "}
            across the Dallas-Fort Worth metroplex.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 lg:gap-5 max-w-7xl mx-auto">
          {/* Featured (large) card */}
          {featured && (
            <Link
              to={featured.to}
              className="md:col-span-7 relative overflow-hidden rounded-xl shadow-lg group min-h-[320px] md:min-h-[520px] lg:min-h-[540px] block"
            >
              <img
                src={featured.image}
                alt={featured.label}
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

              <div className="absolute top-5 left-5 lg:top-8 lg:left-8">
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.15em] text-white/80 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                  {featured.tag}
                </span>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-9">
                <h3 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-white mb-2 lg:mb-3 leading-tight">
                  {featured.label}
                </h3>
                <span className="inline-flex items-center gap-2 text-sm sm:text-base font-semibold text-white/90 hover:text-primary transition-colors group-hover:gap-3 duration-300">
                  Explore
                  <ArrowRight className="w-4 h-4" />
                </span>
              </div>
            </Link>
          )}

          {/* Right column - two stacked cards */}
          <div className="md:col-span-5 flex flex-col gap-4 lg:gap-5">
            {second && (
              <Link
                to={second.to}
                className="relative overflow-hidden rounded-xl shadow-lg group min-h-[240px] md:min-h-[250px] lg:min-h-[270px] block"
              >
                <img
                  src={second.image}
                  alt={second.label}
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

                <div className="absolute top-5 left-5 lg:top-6 lg:left-6">
                  <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.15em] text-white/80 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                    {second.tag}
                  </span>
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-5 lg:p-6">
                  <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-2 leading-tight">
                    {second.label}
                  </h3>
                  <span className="inline-flex items-center gap-2 text-sm font-semibold text-white/90 hover:text-primary transition-colors group-hover:gap-3 duration-300">
                    Explore
                    <ArrowRight className="w-4 h-4" />
                  </span>
                </div>
              </Link>
            )}

            {third && (
              <Link
                to={third.to}
                className="relative overflow-hidden rounded-xl shadow-lg group min-h-[240px] md:min-h-[250px] lg:min-h-[270px] block"
              >
                <img
                  src={third.image}
                  alt={third.label}
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

                <div className="absolute top-5 left-5 lg:top-6 lg:left-6">
                  <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.15em] text-white/80 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                    {third.tag}
                  </span>
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-5 lg:p-6">
                  <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-2 leading-tight">
                    {third.label}
                  </h3>
                  <span className="inline-flex items-center gap-2 text-sm font-semibold text-white/90 hover:text-primary transition-colors group-hover:gap-3 duration-300">
                    Explore
                    <ArrowRight className="w-4 h-4" />
                  </span>
                </div>
              </Link>
            )}
          </div>
        </div>

        <div className="text-center mt-12">
          <Link to="/services">
            <Button
              variant="outline"
              className="border-white/20 text-white hover:bg-white/10 rounded-none px-6"
            >
              View All Services
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

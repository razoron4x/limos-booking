import { MapPin } from "lucide-react";

const venues = [
  {
    name: "Costume Galas & Balls",
    detail: "Red-carpet arrivals at downtown Dallas hotel galas",
  },
  {
    name: "Haunted Attractions",
    detail: "Group rides to DFW's top haunted houses & trails",
  },
  {
    name: "Nightclub Halloween Nights",
    detail: "VIP drop-off at Deep Ellum & Uptown nightlife venues",
  },
  {
    name: "Private Mansion Parties",
    detail: "Discreet, elegant arrivals at private estate events",
  },
  {
    name: "Bar Crawls & Pub Crawls",
    detail: "Safe, stylish rides between every stop on the crawl",
  },
  {
    name: "Custom Pickups",
    detail: "Group homes, restaurants & private venues",
  },
];

const HalloweenVenues = () => {
  return (
    <section className="py-20 bg-zinc-950 border-t border-white/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <MapPin className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold tracking-widest uppercase text-primary">
              DFW Halloween Destinations
            </span>
          </div>
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
            Halloween Stops
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
          {venues.map((venue, i) => (
            <div
              key={i}
              className="p-6 border border-white/5 bg-zinc-900/40 hover:border-primary/30 hover:bg-zinc-900/60 transition-all duration-300 rounded-xl group"
            >
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-primary shrink-0 mt-1 group-hover:scale-110 transition-transform" />
                <div>
                  <h3 className="text-lg font-serif font-bold text-white mb-1">
                    {venue.name}
                  </h3>
                  <p className="text-sm text-white/50 font-light">
                    {venue.detail}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HalloweenVenues;

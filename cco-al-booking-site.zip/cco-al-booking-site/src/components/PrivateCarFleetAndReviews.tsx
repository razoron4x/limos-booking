import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { ChevronRight, ArrowRight, Star, MessageSquare } from "lucide-react";

export const PrivateCarFleetAndReviews = () => {
  return (
    <>
      {/* FLEET SHOWCASE */}
      <section className="py-24 bg-zinc-50 border-t border-zinc-200">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-zinc-900 mb-6">
              Your Choice of{" "}
              <span
                className="bg-clip-text text-transparent"
                style={{
                  backgroundImage:
                    "linear-gradient(135deg, #7a5c22 0%, #d4af37 25%, #f9e79f 50%, #d4af37 75%, #7a5c22 100%)",
                }}
              >
                Premium
              </span>{" "}
              Vehicles
            </h2>
            <p className="text-zinc-600 max-w-2xl mx-auto text-lg font-light">
              Every vehicle in our fleet is meticulously maintained for safety,
              cleanliness, and comfort.
            </p>
          </div>

          <div className="relative py-12">
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent shadow-[0_0_12px_rgba(212,175,55,0.8)]"></div>
            <p className="text-center text-sm text-zinc-400 mb-3 relative z-10">
              Tap the vehicle to expand
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
              {[
                {
                  title: "Lincoln Navigator SUV",
                  capacity: "Up to 6 Passengers",
                  images: [
                    "https://vibe.filesafe.space/1792719026995615993/attachments/fffb1544-09c3-4429-9842-290f8ea2ae8b.webp",
                    "https://vibe.filesafe.space/1792719026995615993/attachments/27acf329-8b3a-41c1-871e-ef4874f9a4b2.webp",
                    "https://vibe.filesafe.space/1792719026995615993/attachments/f1c0a7c7-ce9e-4bd2-a7e0-ab486cf6b158.webp",
                  ],
                  link: "/fleet/lincoln-navigator-suv",
                },
                {
                  title: "Chrysler 300 Stretch Limo",
                  capacity: "Up to 10 Passengers",
                  images: [
                    "https://vibe.filesafe.space/1792719026995615993/attachments/e7319457-c2da-4518-8f5e-f950a8b734ce.webp",
                    "https://vibe.filesafe.space/1792719026995615993/attachments/dab4941e-6dce-4ba2-a571-f2de740dfce0.webp",
                    "https://vibe.filesafe.space/1792719026995615993/attachments/74d38f93-6631-485a-8fd2-95552893cbd7.webp",
                  ],
                  link: "/fleet/luxury-black-stretch-limo",
                },
                {
                  title: "Mercedes Sprinter Limo",
                  capacity: "12–14 Passengers",
                  images: [
                    "https://vibe.filesafe.space/1792719026995615993/attachments/9ff34acc-63df-453e-b227-96dbd4a60267.webp",
                    "https://vibe.filesafe.space/1792719026995615993/attachments/f68e4eb6-cda5-4405-adc7-bf31dfa65f22.webp",
                    "https://vibe.filesafe.space/1792719026995615993/attachments/8d411452-3ffb-48b0-bd27-2ae53f24679d.webp",
                    "https://vibe.filesafe.space/1792719026995615993/attachments/e32b67bf-38a0-495c-8e83-58d74360f910.webp",
                    "https://vibe.filesafe.space/1792719026995615993/attachments/fed850b2-6f8a-4ec8-8842-a09b7dcb29b7.webp",
                    "https://vibe.filesafe.space/1792719026995615993/attachments/1408b09c-2f1b-4d54-87fc-31e2589bafe5.webp",
                    "https://vibe.filesafe.space/1792719026995615993/attachments/82a90cae-e6d8-4cd4-9e16-24d0f3a5e4f6.webp",
                    "https://vibe.filesafe.space/1792719026995615993/attachments/de2d9d48-4e0c-426f-adb0-45ec7da8f173.webp",
                    "https://vibe.filesafe.space/1792719026995615993/attachments/a88a7a57-7f70-4866-b92a-33e0cae981fd.webp",
                  ],
                  link: "/fleet/mercedes-sprinter-limo",
                },
              ].map((vehicle, i) => (
                <Card
                  key={i}
                  className="bg-zinc-800 border-zinc-700 overflow-hidden group rounded-none relative"
                >
                  <div className="aspect-[16/9] overflow-hidden relative group/carousel">
                    <Carousel opts={{ loop: true }} className="w-full h-full">
                      <CarouselContent className="h-full ml-0">
                        {vehicle.images.map((img, idx) => (
                          <CarouselItem
                            key={idx}
                            className="pl-0 h-full relative"
                          >
                            <Link
                              to={vehicle.link}
                              className="block w-full h-full cursor-pointer"
                            >
                              <img
                                src={img}
                                alt={`${vehicle.title} view ${idx + 1}`}
                                loading="lazy"
                                className={`w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105 ${
                                  vehicle.title === "Chrysler 300 Stretch Limo"
                                    ? idx === 1
                                      ? "object-bottom -translate-y-6 sm:-translate-y-8"
                                      : idx === 2 || idx === 3
                                        ? "object-bottom -translate-y-12 sm:-translate-y-16"
                                        : "object-center"
                                    : vehicle.title === "Mercedes Sprinter Limo"
                                      ? idx === 1
                                        ? "object-bottom -translate-y-24 sm:-translate-y-40"
                                        : idx === 2 || idx === 3
                                          ? "object-bottom -translate-y-8 sm:-translate-y-12"
                                          : "object-center"
                                      : "object-center"
                                }`}
                              />
                            </Link>
                          </CarouselItem>
                        ))}
                      </CarouselContent>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent pointer-events-none z-10"></div>
                      <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-zinc-900/80 border-zinc-600 text-white hover:bg-primary hover:text-black z-20" />
                      <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 opacity-100 md:opacity-0 group-hover/carousel:opacity-100 transition-opacity bg-zinc-900/80 border-zinc-600 text-white hover:bg-primary hover:text-black z-20" />
                    </Carousel>
                  </div>
                  <CardContent className="absolute bottom-0 left-0 p-4 pb-2 sm:p-6 w-full z-30 pointer-events-none">
                    <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-1 group-hover:text-primary transition-colors drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                      <Link
                        to={vehicle.link}
                        className="pointer-events-auto hover:text-primary transition-colors"
                      >
                        {vehicle.title}
                      </Link>
                    </h3>
                    <p className="text-sm text-white/90 font-light drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                      {vehicle.capacity}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent shadow-[0_0_12px_rgba(212,175,55,0.8)]"></div>
          </div>

          <div className="mt-10 flex justify-center gap-4">
            <Link to="/fleet" className="max-w-sm">
              <Button className="h-14 px-8 bg-zinc-800 border border-zinc-700 hover:border-primary/40 text-white text-base tracking-wide rounded-none group relative overflow-hidden transition-all duration-500 hover:shadow-[0_0_30px_rgba(212,175,55,0.15)]">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
                <span className="relative z-10 flex items-center justify-center">
                  View Full Fleet
                  <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </span>
              </Button>
            </Link>
            <Link
              to="/quote?service=Private%20Car%20Service"
              className="max-w-sm"
            >
              <Button className="h-14 px-8 bg-primary text-primary-foreground hover:bg-primary/90 text-base tracking-wide rounded-none shadow-[0_0_20px_rgba(212,175,55,0.2)] whitespace-nowrap">
                Get Quote
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* WHERE WOULD YOU LIKE TO GO? */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 lg:mb-16">
            <p className="text-xs sm:text-sm font-bold uppercase tracking-[0.2em] text-primary/80 mb-3">
              Most Popular Private Client Services.
            </p>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-zinc-900 mb-4 lg:mb-6">
              Perfect For Every Occasion
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 lg:gap-5 max-w-7xl mx-auto">
            {/* Card 1: Airport Transfers */}
            <Link
              to="/service-airport"
              className="md:col-span-7 relative overflow-hidden rounded-xl shadow-lg group min-h-[320px] md:min-h-[520px] lg:min-h-[540px] block"
            >
              <img
                src="https://storage.googleapis.com/ai-highly-agent-execution-uploads-bucket-prod/7d79ba2b-8557-4748-8f7a-57d90d25c0c0/standalone/4d3f47f5-2f76-49d9-8a37-a21cd0292ef7-generated-image-1785811775410-0.png"
                alt="Luxury SUV at airport terminal for private car transfers"
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

              <div className="absolute top-5 left-5 lg:top-8 lg:left-8">
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.15em] text-white/80 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                  Most Booked
                </span>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-9">
                <h3 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-white mb-2 lg:mb-3 leading-tight">
                  Airport Transfers
                </h3>
                <span className="inline-flex items-center gap-2 text-sm sm:text-base font-semibold text-white/90 hover:text-primary transition-colors group-hover:gap-3 duration-300">
                  Explore
                  <ArrowRight className="w-4 h-4" />
                </span>
              </div>
            </Link>

            {/* Right Column - Stacked */}
            <div className="md:col-span-5 flex flex-col gap-4 lg:gap-5">
              <Link
                to="/service-events"
                className="relative overflow-hidden rounded-xl shadow-lg group min-h-[240px] md:min-h-[250px] lg:min-h-[270px] block"
              >
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/assets/4a65e081-d0cd-4d3d-846e-eca4baafaecc.jpg"
                  alt="Pristine white Hummer limousine with red carpet arrival at an upscale event"
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

                <div className="absolute top-5 left-5 lg:top-6 lg:left-6">
                  <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.15em] text-white/80 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                    For Occasions
                  </span>
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-5 lg:p-6">
                  <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-2 leading-tight">
                    Special Events
                  </h3>
                  <span className="inline-flex items-center gap-2 text-sm font-semibold text-white/90 hover:text-primary transition-colors group-hover:gap-3 duration-300">
                    Explore
                    <ArrowRight className="w-4 h-4" />
                  </span>
                </div>
              </Link>

              <Link
                to="/service-vip"
                className="relative overflow-hidden rounded-xl shadow-lg group min-h-[240px] md:min-h-[250px] lg:min-h-[270px] block"
              >
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/attachments/fffb1544-09c3-4429-9842-290f8ea2ae8b.webp"
                  alt="Executive in luxury SUV interior with premium leather seating"
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

                <div className="absolute top-5 left-5 lg:top-6 lg:left-6">
                  <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.15em] text-white/80 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                    For Executives
                  </span>
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-5 lg:p-6">
                  <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-2 leading-tight">
                    VIP Chauffeur
                  </h3>
                  <span className="inline-flex items-center gap-2 text-sm font-semibold text-white/90 hover:text-primary transition-colors group-hover:gap-3 duration-300">
                    Explore
                    <ArrowRight className="w-4 h-4" />
                  </span>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* REVIEWS */}
      <section className="py-24 bg-zinc-50 border-y border-zinc-200">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-zinc-900 mb-6">
              Trusted by{" "}
              <span className="bg-gradient-to-b from-[#f5e28a] via-[#d4af37] to-[#9c7a1e] bg-clip-text text-transparent">
                Hundreds
              </span>{" "}
              of Riders
            </h2>
            <p className="text-zinc-600 max-w-2xl mx-auto text-lg font-light">
              See what our clients say about their private car service
              experience.
            </p>

            <div className="flex flex-row items-center justify-center gap-6 sm:gap-8 bg-zinc-800 border border-zinc-700 p-3 sm:p-4 max-w-md mx-auto mt-8">
              <div className="text-center flex-1">
                <div className="text-2xl sm:text-3xl font-serif font-bold text-white mb-0.5">
                  4.8
                </div>
                <div className="flex items-center justify-center gap-0.5 mb-0.5">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-primary fill-primary"
                    />
                  ))}
                </div>
                <div className="text-[8px] sm:text-[9px] text-white/60 uppercase tracking-widest font-semibold">
                  Avg Rating
                </div>
              </div>
              <div className="w-px h-8 sm:h-10 bg-zinc-600 shrink-0"></div>
              <div className="text-center flex-1">
                <div className="text-2xl sm:text-3xl font-serif font-bold text-white mb-0.5">
                  160+
                </div>
                <div className="flex items-center justify-center gap-0.5 mb-0.5">
                  <MessageSquare className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-primary" />
                </div>
                <div className="text-[8px] sm:text-[9px] text-white/60 uppercase tracking-widest font-semibold">
                  Reviews
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {[
              {
                name: "Amy O'Malley",
                text: "I have used Addison Limos twice now to transport customers to and from business dinners in the Grapevine / Coppell area. Both times the experience could not have been better! The Mercedes Sprinters were spotless and perfect for our groups.",
              },
              {
                name: "Betty Becker",
                text: "Once again I cannot say enough good things about Addison car and Limo service. The communication is wonderful, pricing is competitive, car was immaculate and the drivers are fantastic. Dale met me at the airport today and what a genuinely professional experience.",
              },
              {
                name: "Kelli Watkins",
                text: "We have used this company for many years and they will continue to be our go to car service in Dallas. Mr. Sunny and the staff are kind, helpful and aim to please. Thank you Addison Limos!",
              },
            ].map((review, i) => (
              <Card
                key={i}
                className="bg-zinc-800 border-zinc-700 rounded-none"
              >
                <CardContent className="p-6 md:p-8 flex flex-col h-full">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(5)].map((_, idx) => (
                      <Star
                        key={idx}
                        className="w-4 h-4 text-primary fill-primary"
                      />
                    ))}
                  </div>
                  <p className="text-base text-white/90 font-medium leading-relaxed mb-6 italic flex-grow">
                    "{review.text}"
                  </p>
                  <div className="flex items-center gap-3 mt-auto">
                    <div className="w-10 h-10 bg-primary/10 border border-primary/20 flex items-center justify-center text-primary font-bold text-base">
                      {review.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-white font-semibold text-sm">
                        {review.name}
                      </p>
                      <p className="text-white/50 text-xs font-medium">
                        Verified Google Review
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link
              to="/reviews"
              className="inline-flex items-center gap-2 bg-primary hover:bg-primary/90 text-black text-sm font-bold tracking-wide uppercase px-8 py-4 rounded-md shadow-lg shadow-primary/30 hover:shadow-primary/50 transition-all hover:-translate-y-0.5"
            >
              Read All Reviews
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

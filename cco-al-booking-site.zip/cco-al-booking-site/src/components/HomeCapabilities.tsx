import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Phone, Trophy, Clock, Shield, Star, MapPin } from "lucide-react";

const capabilities = [
  {
    title: "Football Transport",
    featured: true,
    link: "/service-football",
    img: "https://vibe.filesafe.space/1792719026995615993/assets/1e2d4c78-44ea-4385-a5a5-6c4b7a9c9038.png",
    icon: Trophy,
  },
  {
    title: "Airport Transfers",
    featured: false,
    link: "/service-airport",
    img: "https://vibe.filesafe.space/1792719026995615993/attachments/105ccb92-8123-4ed8-84a9-4418d97c9941.webp",
    icon: Clock,
  },
  {
    title: "Corporate Travel",
    featured: false,
    link: "/corporate",
    img: "https://vibe.filesafe.space/1792719026995615993/attachments/51e6ee25-b03c-4a29-9660-4da2bb28ed9e.webp",
    icon: Shield,
  },
  {
    title: "Special Events",
    featured: false,
    link: "/service-events",
    img: "https://vibe.filesafe.space/1792719026995615993/attachments/fba40358-8871-45b6-8d55-3e9f4c2c30b1.webp",
    icon: Star,
  },
  {
    title: "VIP Service",
    featured: false,
    link: "/service-vip",
    img: "https://vibe.filesafe.space/1792719026995615993/attachments/e2da65c2-8433-4d38-8dd6-2aa294c3b08b.png",
    icon: Shield,
  },
  {
    title: "City Tours",
    featured: false,
    link: "/service-city-tours",
    img: "https://vibe.filesafe.space/1792719026995615993/attachments/da8cb189-97a1-4aab-a770-94af37245fd4.jpg",
    icon: MapPin,
  },
];

export const HomeCapabilities = () => {
  return (
    <section className="py-24 bg-zinc-950 relative border-t border-white/5">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-4 space-y-6">
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-white leading-tight">
              Premium
              <br />
              Service
              <br />
              Capabilities
            </h2>
            <p className="text-white/60 text-lg font-light leading-relaxed">
              Tailored transportation solutions designed to exceed the
              expectations of the most discerning travelers.
            </p>
            <div className="flex flex-wrap gap-4 pt-2">
              <Link to="/services">
                <Button
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/10 rounded-none h-12 px-6 bg-transparent"
                >
                  All Services
                </Button>
              </Link>
              <a
                href="tel:9726083680"
                onClick={() => (window as any).gtag_report_conversion?.()}
              >
                <Button className="bg-gradient-to-r from-yellow-600 via-primary to-yellow-500 text-black font-bold hover:brightness-110 rounded-none h-12 px-6 shadow-[0_0_20px_rgba(212,175,55,0.3)]">
                  <Phone className="w-4 h-4 mr-2" />
                  Call 972-608-3680
                </Button>
              </a>
            </div>
          </div>

          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {capabilities.map((cap, i) => (
              <Link
                key={i}
                to={cap.link}
                className={`group relative overflow-hidden rounded-xl border transition-all duration-500 aspect-[16/10] flex flex-col justify-end p-5 ${
                  cap.featured
                    ? "border-primary/80 shadow-[0_0_25px_rgba(212,175,55,0.25)] ring-1 ring-primary/40"
                    : "border-white/10 hover:border-primary/40"
                }`}
              >
                <img
                  src={cap.img}
                  alt={cap.title}
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 group-hover:opacity-80 transition-all duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent"></div>

                {cap.featured && (
                  <span className="absolute top-3 right-3 text-[10px] uppercase font-bold tracking-widest bg-primary/20 border border-primary/50 text-primary px-2.5 py-0.5 rounded-full backdrop-blur-sm">
                    Featured
                  </span>
                )}

                <div className="relative z-10 flex items-center gap-2 text-white group-hover:text-primary transition-colors">
                  <cap.icon className="w-5 h-5 text-primary shrink-0" />
                  <h3 className="text-lg font-serif font-bold tracking-wide">
                    {cap.title}
                  </h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

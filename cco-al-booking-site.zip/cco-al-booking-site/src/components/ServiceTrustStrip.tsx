export interface TrustStat {
  value: string;
  label: string;
}

export interface ServiceTrustStripProps {
  stats: TrustStat[];
}

const ServiceTrustStrip = ({ stats }: ServiceTrustStripProps) => {
  return (
    <section className="bg-zinc-900 border-y border-zinc-800 py-5">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((stat, i) => (
            <div key={i} className="text-center">
              <div className="text-2xl md:text-2xl font-serif font-bold text-primary leading-none mb-0.5">
                {stat.value}
              </div>
              <div className="text-[10px] text-white/70 uppercase tracking-wider font-medium">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServiceTrustStrip;

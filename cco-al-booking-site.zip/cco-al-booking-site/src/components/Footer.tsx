export const Footer = () => (
  <footer className="bg-background border-t border-border py-10">
    <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-6 text-sm">
      <div className="flex items-center gap-3">
        <span className="font-serif font-bold tracking-wider text-foreground">
          ADDISON <span className="text-primary">LIMOS</span>
        </span>
        <span className="text-muted-foreground hidden sm:inline">
          · Staff Portal
        </span>
      </div>
      <div className="text-muted-foreground text-xs">
        © {new Date().getFullYear()} Addison Limos · Internal use only
      </div>
    </div>
  </footer>
);

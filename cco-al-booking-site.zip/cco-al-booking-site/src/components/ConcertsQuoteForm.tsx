import { useEffect, useRef } from "react";
import { Phone, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export const ConcertsQuoteForm = () => {
  const scriptRef = useRef<HTMLScriptElement | null>(null);

  useEffect(() => {
    if (
      document.querySelector(
        'script[src="https://link.dreamsapi.com/js/form_embed.js"]',
      )
    ) {
      return;
    }
    const s = document.createElement("script");
    s.src = "https://link.dreamsapi.com/js/form_embed.js";
    s.async = true;
    document.body.appendChild(s);
    scriptRef.current = s;
  }, []);

  return (
    <section className="py-12 lg:py-16 px-4 bg-[#0d0d0d] border-b border-white/5">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 lg:gap-12 items-stretch">
          {/* Left - Headline + CTA with bg image */}
          <div className="relative lg:h-full">
            <div className="relative rounded-t-2xl rounded-b-none lg:rounded-xl overflow-hidden h-[150px] sm:h-[180px] lg:h-full lg:min-h-[575px] lg:absolute lg:inset-x-0 lg:top-0 lg:bottom-[0px] border border-primary/20 border-b-0 lg:border-none">
              {/* Background Image */}
              <div className="absolute inset-0 z-0">
                <img
                  src="https://vibe.filesafe.space/1792719026995615993/assets/237bc4c8-63d3-4fcc-9643-81700734acfe.png"
                  alt="Luxury limo and Sprinter van at a concert venue at night"
                  className="w-full h-full object-cover opacity-90"
                  loading="lazy"
                />
                <div
                  className="absolute inset-0"
                  style={{
                    background:
                      "radial-gradient(circle at 50% 100%, rgba(24,24,27,0.05) 0%, rgba(24,24,27,0.35) 50%, rgba(24,24,27,0.8) 80%, #18181b 100%)",
                  }}
                ></div>
                <div className="absolute inset-0 bg-gradient-to-b from-zinc-900/70 via-zinc-900/35 to-transparent"></div>
              </div>

              {/* Content */}
              <div className="relative z-10 flex flex-col justify-start h-full p-4 sm:p-5 lg:p-8 pt-6 lg:pt-7 space-y-2 lg:space-y-5">
                <div className="hidden lg:inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/15 border border-primary/30 backdrop-blur-sm self-start">
                  <span className="text-xs font-bold tracking-widest uppercase text-primary">
                    Reserve Your Ride
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl md:text-4xl lg:text-5xl font-serif font-bold text-white leading-[1.15] drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]">
                  Concert &amp; Game-Day
                  <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-yellow-400 to-primary">
                    Quote in Seconds
                  </span>
                </h2>
                <p className="hidden lg:block text-white font-semibold leading-relaxed text-lg max-w-md drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]">
                  Instant hourly pricing for concerts, tailgates, and every DFW
                  stadium and arena.
                </p>
                <div className="hidden lg:flex flex-col sm:flex-row gap-2.5 lg:gap-4 sm:max-w-md">
                  <Link
                    to="/quote?service=Sporting%20Events%20%26%20Concerts"
                    className="w-full sm:flex-1"
                  >
                    <Button className="w-full h-14 bg-gradient-to-b from-yellow-500 via-primary to-yellow-600 text-black hover:from-yellow-400 hover:via-yellow-500 hover:to-yellow-500 text-base font-bold rounded-none shadow-[0_0_25px_rgba(212,175,55,0.3)] border border-yellow-400/40">
                      Book Your Ride
                    </Button>
                  </Link>
                  <a
                    href="tel:9726083680"
                    onClick={() => (window as any).gtag_report_conversion?.()}
                    className="w-full sm:flex-1"
                  >
                    <Button
                      variant="outline"
                      className="w-full h-14 border-white/30 text-white hover:bg-white/10 text-base rounded-none bg-white/10 backdrop-blur-sm relative overflow-hidden group/call font-bold"
                    >
                      <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent translate-x-[-150%] group-hover/call:translate-x-[150%] transition-transform duration-700 ease-out"></span>
                      <span className="relative z-10 flex items-center justify-center">
                        <Phone className="w-5 h-5 mr-2" />
                        972-608-3680
                      </span>
                    </Button>
                  </a>
                </div>
                <div className="hidden lg:flex flex-wrap gap-x-6 gap-y-2 pt-2 text-sm text-white font-bold drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]">
                  <span>4-hr minimum</span>
                  <span className="text-primary/70">|</span>
                  <span>Flat-rate pricing</span>
                  <span className="text-primary/70">|</span>
                  <span>Groups up to 18</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right - Embedded Form */}
          <div className="relative bg-zinc-800 border border-zinc-700 rounded-b-2xl rounded-t-none lg:rounded-2xl overflow-hidden w-full shadow-2xl">
            {/* Gold accent stripe */}
            <div className="h-1.5 w-full bg-gradient-to-r from-yellow-600 via-primary to-yellow-600"></div>

            {/* Hourly Title */}
            <div className="flex items-center justify-center gap-3 py-3 px-5 border-b border-white/10 bg-white/[0.02]">
              <Clock className="w-5 h-5 text-primary" />
              <div className="text-center">
                <h3 className="text-sm font-bold tracking-widest uppercase text-white">
                  Hourly Booking
                </h3>
                <p className="text-[11px] text-white/40 font-light mt-0.5">
                  Flat-rate group pricing &middot; 4-hr minimum
                </p>
              </div>
            </div>

            <div className="p-5 lg:p-6">
              <div
                className="w-full overflow-y-auto overflow-x-hidden rounded-xl bg-zinc-800"
                style={{ height: "525px" }}
              >
                <iframe
                  src="https://link.dreamsapi.com/widget/form/MChmKe5LjH5XSWEosk9B"
                  style={{
                    width: "100%",
                    height: "100%",
                    border: "none",
                    borderRadius: "4px",
                    display: "block",
                  }}
                  id="inline-MChmKe5LjH5XSWEosk9B"
                  data-layout="{'id':'INLINE'}"
                  data-trigger-type="alwaysShow"
                  data-trigger-value=""
                  data-activation-type="alwaysActivated"
                  data-activation-value=""
                  data-deactivation-type="neverDeactivate"
                  data-deactivation-value=""
                  data-form-name="General Limo Hourly"
                  data-height="1233"
                  data-layout-iframe-id="inline-MChmKe5LjH5XSWEosk9B"
                  data-form-id="MChmKe5LjH5XSWEosk9B"
                  data-cookie-consent="true"
                  data-cookie-consent-provider="auto"
                  title="General Limo Hourly"
                />
              </div>

              <p className="text-[10px] text-white/40 text-center font-light mt-4">
                Booking for your company?{" "}
                <Link
                  to="/corporate"
                  className="text-primary hover:text-primary/80 underline underline-offset-2"
                >
                  Set up a business account
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

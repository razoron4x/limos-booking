import {
  ShieldCheck,
  BadgeCheck,
  Shirt,
  Car,
  CheckCircle2,
  UserCheck,
  Shield,
} from "lucide-react";

const guarantees = [
  {
    icon: ShieldCheck,
    tag: "Security",
    title: "Background-Checked",
    desc: "Every chauffeur undergoes rigorous multi-state criminal background and driving record screening before ever taking the wheel.",
  },
  {
    icon: BadgeCheck,
    tag: "Safety First",
    title: "100% Drug & Alcohol Screened",
    desc: "Pre-employment and random continuous testing guarantees a strict zero-tolerance, substance-free workplace across our entire team.",
  },
  {
    icon: Shirt,
    tag: "Executive Code",
    title: "Formally Uniformed",
    desc: "Impeccable dark suit-and-tie presentation on every assignment — polished, discreet, and tailored for executive, wedding, or VIP travel.",
  },
  {
    icon: Car,
    tag: "Expertise",
    title: "Defensive Driving Certified",
    desc: "Trained in advanced executive protection, defensive maneuvering, and real-time DFW traffic navigation for total passenger peace of mind.",
  },
];

export const ChauffeurGuarantee = () => {
  return (
    <section className="py-24 px-4 bg-[#09090b] relative border-t border-white/5 overflow-hidden">
      {/* Dynamic Background Glows */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-10 w-80 h-80 bg-amber-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="container mx-auto relative z-10 max-w-6xl">
        {/* Header Badge */}
        <div className="flex flex-col items-center text-center mb-16">
          <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-gradient-to-r from-primary/15 via-amber-500/10 to-primary/15 border border-primary/30 shadow-[0_0_20px_rgba(212,175,55,0.15)] mb-6">
            <ShieldCheck className="w-4 h-4 text-primary" />
            <span className="text-xs font-bold tracking-[0.2em] uppercase text-primary">
              The Addison Limos Chauffeur Guarantee
            </span>
          </div>

          <h2 className="text-3xl md:text-5xl lg:text-6xl font-serif font-bold text-white tracking-tight mb-5">
            Who's Driving You{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-primary/90 to-amber-200">
              Matters
            </span>
          </h2>

          <p className="text-white/70 font-light leading-relaxed text-base md:text-lg max-w-2xl">
            Whether you're booking executive airport transfers, a wedding, or
            your teen's homecoming, our chauffeurs are held to the absolute
            highest vetting and presentation standards in Texas.
          </p>
        </div>

        {/* Editorial Split / Bento Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Column: Featured Luxury Chauffeur Card */}
          <div className="lg:col-span-5 relative rounded-2xl overflow-hidden border border-white/10 bg-zinc-900/60 flex flex-col justify-between group">
            {/* Chauffeur Image */}
            <div className="absolute inset-0 z-0">
              <img
                src="https://vibe.filesafe.space/1792719026995615993/assets/3ff6fd09-bb0e-4381-8afd-1025dc408209.png"
                alt="Professional Uniformed Addison Limos Chauffeur"
                className="w-full h-full object-cover object-center opacity-80 group-hover:scale-105 transition-transform duration-1000 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/60 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-r from-[#09090b]/80 via-transparent to-transparent" />
            </div>

            {/* Top Seal Badge */}
            <div className="relative z-10 p-6 flex justify-between items-start">
              <div className="bg-black/60 backdrop-blur-md border border-primary/40 px-3.5 py-2 rounded-lg flex items-center gap-2 shadow-lg">
                <Shield className="w-4 h-4 text-primary animate-pulse" />
                <span className="text-xs font-semibold text-white tracking-wide">
                  5-Star Vetted Standard
                </span>
              </div>
            </div>

            {/* Bottom Overlay Content */}
            <div className="relative z-10 p-8 space-y-4">
              <div className="flex items-center gap-2 text-primary text-sm font-semibold tracking-wider uppercase">
                <UserCheck className="w-4 h-4" />
                <span>Zero Compromise Chauffeurs</span>
              </div>

              <h3 className="text-2xl md:text-3xl font-serif font-bold text-white leading-tight">
                White-Glove Service & Unmatched Discretion
              </h3>

              <div className="pt-2 border-t border-white/15 grid grid-cols-2 gap-4 text-xs font-medium text-white/80">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
                  <span>100% In-House Vetted</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
                  <span>Full Executive Attire</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
                  <span>DFW Route Experts</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
                  <span>Flight Status Sync</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: High-End Asymmetrical Bento Features */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-5">
            {guarantees.map((item, idx) => {
              const Icon = item.icon;
              return (
                <div
                  key={idx}
                  className="relative p-7 rounded-2xl bg-zinc-900/40 border border-white/10 hover:border-primary/50 hover:bg-zinc-900/80 transition-all duration-500 flex flex-col justify-between group shadow-xl hover:shadow-[0_10px_30px_rgba(212,175,55,0.1)]"
                >
                  {/* Subtle top glow */}
                  <div className="absolute top-0 left-6 right-6 h-px bg-gradient-to-r from-transparent via-primary/0 group-hover:via-primary/50 to-transparent transition-all duration-700" />

                  <div>
                    <div className="flex items-center justify-between mb-5">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center group-hover:bg-primary/20 group-hover:border-primary/60 group-hover:scale-110 transition-all duration-500">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                      <span className="text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-white/50 group-hover:text-primary group-hover:border-primary/30 transition-colors">
                        {item.tag}
                      </span>
                    </div>

                    <h4 className="text-xl font-serif font-bold text-white mb-2.5 group-hover:text-primary transition-colors">
                      {item.title}
                    </h4>

                    <p className="text-white/60 font-light text-sm leading-relaxed">
                      {item.desc}
                    </p>
                  </div>

                  <div className="pt-4 mt-4 border-t border-white/5 flex items-center justify-between text-xs text-white/40 group-hover:text-white/70 transition-colors">
                    <span>Guaranteed Standard</span>
                    <span className="font-mono font-bold text-primary/80">
                      0{idx + 1}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer Guarantee Bar */}
        <div className="mt-12 p-6 rounded-xl bg-gradient-to-r from-zinc-900/80 via-zinc-900 to-zinc-900/80 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-white font-medium text-sm">
                Have specific security or chauffeur requirements for your trip?
              </p>
              <p className="hidden sm:block text-white/50 text-xs font-light">
                We accommodate corporate VIP protocol, non-disclosure requests,
                and family preferences.
              </p>
            </div>
          </div>

          <a
            href="tel:9726083680"
            onClick={() => (window as any).gtag_report_conversion?.()}
            className="shrink-0"
          >
            <span className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary/10 border border-primary/30 text-primary font-semibold text-sm hover:bg-primary/20 hover:border-primary/50 transition-all duration-300">
              Speak with Dispatch — 972-608-3680
            </span>
          </a>
        </div>
      </div>
    </section>
  );
};

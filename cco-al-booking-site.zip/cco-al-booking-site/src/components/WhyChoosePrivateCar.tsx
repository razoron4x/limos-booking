import { Link } from "react-router-dom";
import { Phone, Shield, Clock, CreditCard, ChevronRight } from "lucide-react";

const WhyChoosePrivateCar = () => {
  return (
    <section className="py-20 lg:py-24 bg-zinc-900 border-y border-white/10 relative">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4 lg:mb-6">
            Why Choose Addison Limos?
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto text-base lg:text-lg font-light leading-relaxed">
            DFW's trusted chauffeur service for private car, airport, and
            executive travel — where reliability, privacy, and professionalism
            matter most.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 lg:gap-5 max-w-7xl mx-auto">
          {/* Box 1: Large Chauffeur Image Card */}
          <div className="md:col-span-7 md:row-span-2 relative overflow-hidden rounded-xl shadow-lg group min-h-[300px] md:min-h-[480px] bg-zinc-900">
            <img
              src="https://vibe.filesafe.space/1792719026995615993/assets/089aa3e1-3749-42f6-9c54-d8b1eec70385.png"
              alt="Professional Addison Limos chauffeur in a black suit standing beside an open door of a black Lincoln Navigator SUV at an upscale office plaza"
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-65 transition-opacity duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/50 to-black/70"></div>

            <div className="relative z-10 h-full flex flex-col justify-between p-6 lg:p-9">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/15 border border-primary/30 rounded-lg mb-4 lg:mb-5 backdrop-blur-sm w-fit">
                  <Shield className="w-4 h-4 text-primary" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-primary">
                    Addison Limos
                  </span>
                </div>
                <h3 className="text-xl lg:text-3xl font-serif font-bold text-white mb-2 lg:mb-3 leading-tight">
                  Your Dedicated Chauffeur & Luxury Vehicle
                </h3>
              </div>
              <p className="text-sm lg:text-lg text-white/80 font-medium leading-relaxed max-w-md">
                <span className="sm:hidden">
                  Vetted chauffeur in a luxury vehicle reserved for you. No
                  sharing, no stops, no detours, direct from A to B in comfort
                  across DFW.
                </span>
                <span className="hidden sm:inline">
                  A vetted, professionally trained chauffeur in a pristine
                  luxury vehicle reserved just for you. No sharing, no stops, no
                  detours — direct from A to B in complete comfort across
                  Dallas-Fort Worth.
                </span>
              </p>
            </div>
          </div>

          {/* Box 2: Flight Tracking */}
          <div className="md:col-span-5 bg-zinc-900 border border-white/10 rounded-xl p-5 lg:p-8 shadow-lg hover:border-primary/40 transition-all duration-300 group flex flex-col justify-center min-h-[160px] md:min-h-[232px]">
            <div className="w-11 h-11 lg:w-12 lg:h-12 bg-primary/10 border border-primary/20 rounded-xl flex items-center justify-center mb-3 lg:mb-4 group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300 shrink-0">
              <Clock className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
            </div>
            <h3 className="text-base lg:text-lg font-serif font-bold text-white mb-1.5 lg:mb-2 group-hover:text-primary transition-colors">
              Real-Time Flight Tracking
            </h3>
            <p className="text-white/70 text-xs lg:text-sm leading-relaxed font-medium mb-2.5 lg:mb-3">
              We monitor your DFW, Love Field, and Addison Airport flights
              automatically. Early or delayed, your chauffeur adjusts in
              real-time and always arrives 15 minutes early.
            </p>
            <div className="flex items-center gap-1.5 mt-auto">
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></div>
              <span className="text-[10px] lg:text-xs text-white/50 font-medium uppercase tracking-wider">
                Live Tracking Active
              </span>
            </div>
          </div>

          {/* Box 3: Flat Rate */}
          <div className="md:col-span-5 bg-zinc-900 border border-white/10 rounded-xl p-5 lg:p-8 shadow-lg hover:border-primary/40 transition-all duration-300 group flex flex-col justify-center min-h-[160px] md:min-h-[232px]">
            <div className="w-11 h-11 lg:w-12 lg:h-12 bg-primary/10 border border-primary/20 rounded-xl flex items-center justify-center mb-3 lg:mb-4 group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300 shrink-0">
              <CreditCard className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
            </div>
            <h3 className="text-base lg:text-lg font-serif font-bold text-white mb-1.5 lg:mb-2 group-hover:text-primary transition-colors">
              Flat-Rate Chauffeur Pricing
            </h3>
            <p className="text-white/70 text-xs lg:text-sm leading-relaxed font-medium">
              <span className="sm:hidden">
                Know fare upfront. No surge pricing, no hidden fees, no meter
                running, just transparent limo service.
              </span>
              <span className="hidden sm:inline">
                Know your fare upfront. No surge pricing, no hidden fees, no
                meter running — just transparent, professional limo service.
              </span>
            </p>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="max-w-7xl mx-auto mt-8 lg:mt-10 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
          <Link to="/quote" className="w-full sm:w-auto">
            <button className="w-full sm:w-auto group inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-gradient-to-r from-primary via-yellow-500 to-primary bg-[length:200%_100%] hover:bg-[position:100%_0] text-black font-bold text-sm uppercase tracking-wider rounded-full shadow-lg shadow-primary/20 transition-all duration-500">
              Get a Quote
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </Link>
          <a href="tel:9726083680" className="w-full sm:w-auto">
            <button className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-white/5 border-2 border-white/20 text-white font-bold text-sm uppercase tracking-wider rounded-full hover:bg-white hover:text-zinc-900 transition-all duration-300">
              <Phone className="w-4 h-4" />
              (972) 608-3680
            </button>
          </a>
        </div>
      </div>
    </section>
  );
};

export default WhyChoosePrivateCar;

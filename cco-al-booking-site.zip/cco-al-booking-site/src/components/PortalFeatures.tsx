import {
  CalendarClock,
  Route,
  Car,
  FileText,
  Activity,
  Receipt,
} from "lucide-react";

const features = [
  {
    icon: CalendarClock,
    title: "Book & Schedule",
    desc: "Create reservations, set pickup times, and manage recurring client trips.",
  },
  {
    icon: Route,
    title: "Dispatch & Assignments",
    desc: "Assign chauffeurs to jobs and track live trip status across the metroplex.",
  },
  {
    icon: Car,
    title: "Fleet Management",
    desc: "Monitor vehicle availability, maintenance, and assignments in real time.",
  },
  {
    icon: FileText,
    title: "Client & Trip Records",
    desc: "Access passenger details, trip history, and special requests at a glance.",
  },
  {
    icon: Activity,
    title: "Real-Time Status",
    desc: "Follow active rides from dispatch to drop-off with live updates.",
  },
  {
    icon: Receipt,
    title: "Quotes & Invoicing",
    desc: "Generate quotes and finalize billing for corporate and private accounts.",
  },
];

export const PortalFeatures = () => (
  <section className="relative border-t border-border bg-background py-24">
    <div className="container mx-auto px-4">
      <div className="max-w-2xl mb-14">
        <span className="text-xs font-medium uppercase tracking-[0.25em] text-primary">
          Portal Tools
        </span>
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-foreground mt-3 mb-4">
          Everything your team needs
        </h2>
        <p className="text-muted-foreground text-lg font-light">
          One secure workspace for reservations, dispatch, and fleet operations.
        </p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map(({ icon: Icon, title, desc }) => (
          <div
            key={title}
            className="group rounded-none border border-border bg-card p-8 transition-colors hover:border-primary/40"
          >
            <div className="w-12 h-12 flex items-center justify-center border border-primary/30 bg-primary/10 mb-6">
              <Icon className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-xl font-serif font-bold text-foreground mb-2">
              {title}
            </h3>
            <p className="text-muted-foreground text-sm font-light leading-relaxed">
              {desc}
            </p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

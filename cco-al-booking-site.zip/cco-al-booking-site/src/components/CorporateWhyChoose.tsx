import { Shield, Clock, CreditCard, Briefcase } from "lucide-react";

export const CorporateWhyChoose = () => {
  return (
    <section className="py-20 lg:py-24 bg-white border-y border-zinc-200">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 lg:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Briefcase className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold tracking-widest uppercase text-primary">
              Executive Standards
            </span>
          </div>
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-zinc-900 mb-4 lg:mb-6">
            Why Companies Trust Addison{" "}
            <span className="bg-gradient-to-b from-[#f5e28a] via-[#d4af37] to-[#9c7a1e] bg-clip-text text-transparent">
              Limos
            </span>
          </h2>
          <p className="text-zinc-600 max-w-2xl mx-auto text-base lg:text-lg font-light leading-relaxed">
            Duty-of-care compliance, discretion, and on-time guarantees built
            for C-suite travel programs and executive assistants.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 lg:gap-5 max-w-7xl mx-auto">
          {/* Box 1: Large Corporate Image Card */}
          <div className="md:col-span-7 md:row-span-2 relative overflow-hidden rounded-xl shadow-lg group min-h-[300px] md:min-h-[480px] bg-zinc-900">
            <img
              src="https://vibe.filesafe.space/1792719026995615993/assets/bc0219d5-330c-4587-8b8e-4e47551caae1.png"
              alt="Executive chauffeur assisting a business professional into a luxury sedan in the corporate district"
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-75 transition-opacity duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-black/85 via-black/55 to-black/70"></div>

            <div className="relative z-10 h-full flex flex-col justify-between p-6 lg:p-9">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/15 border border-primary/30 rounded-lg mb-4 lg:mb-5 backdrop-blur-sm w-fit">
                  <Shield className="w-4 h-4 text-primary" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-primary">
                    Executive Grade
                  </span>
                </div>
                <h3 className="text-xl lg:text-3xl font-serif font-bold text-white mb-2 lg:mb-3 leading-tight">
                  Vetted Chauffeurs & Duty-of-Care Compliance
                </h3>
              </div>
              <p className="text-sm lg:text-lg text-white/80 font-medium leading-relaxed max-w-md">
                Background-checked, professionally attired chauffeurs operating
                under $1.5M+ commercial coverage. Every ride meets corporate
                travel risk and compliance standards.
              </p>
            </div>
          </div>

          {/* Box 2: Flight Tracking */}
          <div className="md:col-span-5 bg-zinc-800 border border-zinc-700 rounded-xl p-5 lg:p-8 shadow-lg hover:border-primary/40 transition-all duration-300 group flex flex-col justify-center min-h-[160px] md:min-h-[232px]">
            <div className="w-11 h-11 lg:w-12 lg:h-12 bg-primary/10 border border-primary/20 rounded-xl flex items-center justify-center mb-3 lg:mb-4 group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300 shrink-0">
              <Clock className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
            </div>
            <h3 className="text-base lg:text-lg font-serif font-bold text-white mb-1.5 lg:mb-2 group-hover:text-primary transition-colors">
              Guaranteed On-Time Arrival
            </h3>
            <p className="text-white/70 text-xs lg:text-sm leading-relaxed font-medium mb-2.5 lg:mb-3">
              Live flight tracking with 15-minute early arrival. Early, delayed,
              or rerouted. Your executive's schedule never misses a beat.
            </p>
            <div className="flex items-center gap-1.5 mt-auto">
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></div>
              <span className="text-[10px] lg:text-xs text-white/50 font-medium uppercase tracking-wider">
                Live Tracking Active
              </span>
            </div>
          </div>

          {/* Box 3: Flat Rate */}
          <div className="md:col-span-5 bg-zinc-800 border border-zinc-700 rounded-xl p-5 lg:p-8 shadow-lg hover:border-primary/40 transition-all duration-300 group flex flex-col justify-center min-h-[160px] md:min-h-[232px]">
            <div className="w-11 h-11 lg:w-12 lg:h-12 bg-primary/10 border border-primary/20 rounded-xl flex items-center justify-center mb-3 lg:mb-4 group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300 shrink-0">
              <CreditCard className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
            </div>
            <h3 className="text-base lg:text-lg font-serif font-bold text-white mb-1.5 lg:mb-2 group-hover:text-primary transition-colors">
              Transparent Corporate Billing
            </h3>
            <p className="text-white/70 text-xs lg:text-sm leading-relaxed font-medium">
              Flat-rate fares, no surge pricing. Consolidated invoicing with
              department-level cost allocation for clean monthly reconciliation.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

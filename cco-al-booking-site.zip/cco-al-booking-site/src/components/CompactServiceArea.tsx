import { MapPin, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const popularCities = [
  { name: "Dallas", link: "dallas" },
  { name: "Fort Worth", link: "fort-worth" },
  { name: "Addison", link: "addison" },
  { name: "Plano", link: "plano" },
  { name: "Frisco", link: "frisco" },
  { name: "Irving", link: "irving" },
  { name: "Grapevine", link: "grapevine" },
  { name: "Arlington", link: "arlington" },
  { name: "Richardson", link: "richardson" },
  { name: "Garland", link: "garland" },
  { name: "McKinney", link: "mckinney" },
  { name: "Carrollton", link: "carrollton" },
  { name: "Denton", link: "denton" },
  { name: "Lewisville", link: "lewisville" },
  { name: "Southlake", link: "southlake" },
  { name: "Flower Mound", link: "flower-mound" },
  { name: "Duncanville", link: "duncanville" },
  { name: "Cedar Hill", link: "cedar-hill" },
  { name: "Allen", link: null },
  { name: "Mesquite", link: null },
  { name: "Grand Prairie", link: null },
  { name: "The Colony", link: null },
];

const CompactServiceArea = () => {
  return (
    <section className="py-16 bg-zinc-950 border-t border-white/5">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <MapPin className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold tracking-widest uppercase text-primary">
              Service Areas
            </span>
          </div>
          <h2 className="text-2xl md:text-3xl font-serif font-bold text-white mb-4">
            Proudly Serving the{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-white to-white">
              Dallas-Fort Worth
            </span>{" "}
            Metroplex
          </h2>
          <p className="text-white/60 font-light leading-relaxed mb-6 max-w-2xl mx-auto">
            Addison Limos provides luxury chauffeur transportation across the
            entire DFW area. With 20+ years of experience, our professional
            chauffeurs know every route and neighborhood.
          </p>
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {popularCities.map((city, i) =>
              city.link ? (
                <Link
                  key={i}
                  to={`/limo-service/${city.link}`}
                  className="px-3 py-1.5 text-sm text-white/70 border border-white/10 bg-zinc-900/40 hover:border-primary/30 hover:text-white transition-colors"
                >
                  {city.name}
                </Link>
              ) : (
                <span
                  key={i}
                  className="px-3 py-1.5 text-sm text-white/70 border border-white/10 bg-zinc-900/40"
                >
                  {city.name}
                </span>
              ),
            )}
            <span className="px-3 py-1.5 text-sm text-primary/80 border border-primary/20 bg-primary/5">
              & 50+ more
            </span>
          </div>
          <p className="text-white/50 text-sm font-light mb-6">
            Don't see your city? We serve the entire DFW metroplex and
            surrounding regions.
          </p>
          <a
            href="tel:9726083680"
            className="inline-block"
            onClick={() => (window as any).gtag_report_conversion?.()}
          >
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-none px-8 h-11">
              <Phone className="w-4 h-4 mr-2" />
              Call 972-608-3680
            </Button>
          </a>
        </div>
      </div>
    </section>
  );
};

export default CompactServiceArea;

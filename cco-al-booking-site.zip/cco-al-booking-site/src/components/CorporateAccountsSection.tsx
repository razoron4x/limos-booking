import { CreditCard, FileText, Users, Lock } from "lucide-react";

export const CorporateAccountsSection = () => {
  return (
    <section className="py-24 bg-white border-y border-zinc-200">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          {/* Left: Benefits */}
          <div className="min-w-0">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <CreditCard className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold tracking-widest uppercase text-primary">
                Corporate Accounts
              </span>
            </div>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-zinc-900 mb-6">
              Simplified Billing for Travel Managers & Executive Assistants
            </h2>
            <p className="text-zinc-600 font-normal leading-relaxed text-xl mb-8">
              Streamline company-wide travel with a centralized corporate
              account designed for administrative efficiency and financial
              transparency.
            </p>

            <div className="space-y-4">
              {[
                {
                  icon: FileText,
                  title: "Centralized Billing & Simple Invoicing",
                  desc: "Consolidated invoicing with flexible payment terms for approved corporate accounts.",
                },
                {
                  icon: Users,
                  title: "Multi-Passenger Booking Dashboard",
                  desc: "Book for multiple executives from a single administrative interface. No individual checkout required.",
                },
                {
                  icon: CreditCard,
                  title: "Consolidated Monthly Reporting",
                  desc: "Detailed monthly account reports and receipt management for seamless reconciliation.",
                },
              ].map((item, i) => (
                <div
                  key={i}
                  className="flex items-start gap-4 p-5 border border-zinc-700 bg-zinc-800 hover:border-primary/30 transition-colors rounded-xl"
                >
                  <div className="w-10 h-10 bg-primary/10 flex items-center justify-center border border-primary/20 shrink-0 rounded-lg">
                    <item.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white mb-1">
                      {item.title}
                    </h3>
                    <p className="text-white/70 font-normal text-base leading-relaxed">
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Account Setup Form */}
          <div className="min-w-0 bg-zinc-800 border border-primary/30 overflow-hidden rounded-2xl max-w-full">
            <div className="p-8 lg:p-10 pb-6">
              <div className="flex items-center gap-3 mb-2">
                <Lock className="w-5 h-5 text-primary" />
                <h3 className="text-2xl font-serif font-bold text-white">
                  Open a Corporate Account
                </h3>
              </div>
              <p className="text-white/70 font-normal text-base">
                Set up your company's travel account in minutes. An account
                manager will contact you
                <span className="hidden sm:inline"> within 24 hours.</span>
              </p>
            </div>

            <div
              className="w-full max-w-full overflow-hidden relative"
              style={{ padding: 0, margin: 0 }}
            >
              <iframe
                src="https://link.dreamsapi.com/widget/form/8Pa9PUU9DF6XANgy5FOy"
                style={{
                  width: "100%",
                  maxWidth: "100%",
                  height: "1700px",
                  border: "none",
                  display: "block",
                  padding: 0,
                  margin: 0,
                  marginTop: "-28px",
                }}
                id="inline-8Pa9PUU9DF6XANgy5FOy"
                data-layout="{'id':'INLINE'}"
                data-trigger-type="alwaysShow"
                data-trigger-value=""
                data-activation-type="alwaysActivated"
                data-activation-value=""
                data-deactivation-type="neverDeactivate"
                data-deactivation-value=""
                data-form-name="Addison Limos CORPORATE Form"
                data-height="1672"
                data-layout-iframe-id="inline-8Pa9PUU9DF6XANgy5FOy"
                data-form-id="8Pa9PUU9DF6XANgy5FOy"
                title="Addison Limos CORPORATE Form"
                scrolling="no"
                className="corporate-form-iframe"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

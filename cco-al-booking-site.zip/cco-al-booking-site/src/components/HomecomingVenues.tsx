import { MapPin } from "lucide-react";

const venues = [
  {
    name: "High School Dances",
    detail: "On-site drop-off at every DFW high school venue",
  },
  {
    name: "Hotel Ballrooms",
    detail: "Elegant arrivals at downtown Dallas & Plano venues",
  },
  {
    name: "Country Clubs",
    detail: "Red-carpet service at private club venues",
  },
  {
    name: "Photo Locations",
    detail: "Coordinated stops at DFW's best homecoming backdrops",
  },
  {
    name: "After-Parties",
    detail: "Safe rides to dinners and post-dance gatherings",
  },
  {
    name: "Custom Pickups",
    detail: "Group homes, restaurants & private venues",
  },
];

const HomecomingVenues = () => {
  return (
    <section className="py-20 bg-zinc-950 border-t border-white/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <MapPin className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold tracking-widest uppercase text-primary">
              DFW Homecoming Venues
            </span>
          </div>
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
            Homecoming Stops
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
          {venues.map((venue, i) => (
            <div
              key={i}
              className="p-6 border border-white/5 bg-zinc-900/40 hover:border-primary/30 hover:bg-zinc-900/60 transition-all duration-300 rounded-xl group"
            >
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-primary shrink-0 mt-1 group-hover:scale-110 transition-transform" />
                <div>
                  <h3 className="text-lg font-serif font-bold text-white mb-1">
                    {venue.name}
                  </h3>
                  <p className="text-sm text-white/50 font-light">
                    {venue.detail}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HomecomingVenues;

import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export const CorporateOccasionsGrid = () => {
  return (
    <section className="py-20 lg:py-28 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 lg:mb-16">
          <p className="text-xs sm:text-sm font-bold uppercase tracking-[0.2em] text-primary/80 mb-3">
            Most Popular Corporate Client Services.
          </p>
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-zinc-900 mb-4 lg:mb-6">
            Perfect For Every Occasion
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 lg:gap-5 max-w-7xl mx-auto">
          {/* Card 1: Executive Private Car (Large) */}
          <Link
            to="/service-private-car"
            className="md:col-span-7 relative overflow-hidden rounded-xl shadow-lg group min-h-[320px] md:min-h-[520px] lg:min-h-[540px] block"
          >
            <img
              src="https://vibe.filesafe.space/1792719026995615993/assets/f3ed9479-b792-4733-8ec7-6936c5fbdb58.png"
              alt="Executive private car chauffeur service with luxury sedan at corporate office"
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

            <div className="absolute top-5 left-5 lg:top-8 lg:left-8">
              <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.15em] text-white/80 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                Most Booked
              </span>
            </div>

            <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-9">
              <h3 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-white mb-2 lg:mb-3 leading-tight">
                Executive Private Car
              </h3>
              <span className="inline-flex items-center gap-2 text-sm sm:text-base font-semibold text-white/90 hover:text-primary transition-colors group-hover:gap-3 duration-300">
                Explore
                <ArrowRight className="w-4 h-4" />
              </span>
            </div>
          </Link>

          {/* Right Column - Stacked */}
          <div className="md:col-span-5 flex flex-col gap-4 lg:gap-5">
            <Link
              to="/service-shuttle"
              className="relative overflow-hidden rounded-xl shadow-lg group min-h-[240px] md:min-h-[250px] lg:min-h-[270px] block"
            >
              <img
                src="https://vibe.filesafe.space/1792719026995615993/assets/a757b908-e7a3-4666-85e0-ec77b9616cee.png"
                alt="Corporate group shuttle service with luxury Mercedes Sprinter vans"
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

              <div className="absolute top-5 left-5 lg:top-6 lg:left-6">
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.15em] text-white/80 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                  For Teams
                </span>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-5 lg:p-6">
                <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-2 leading-tight">
                  Group Shuttle Service
                </h3>
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-white/90 hover:text-primary transition-colors group-hover:gap-3 duration-300">
                  Explore
                  <ArrowRight className="w-4 h-4" />
                </span>
              </div>
            </Link>

            <Link
              to="/service-wedding"
              className="relative overflow-hidden rounded-xl shadow-lg group min-h-[240px] md:min-h-[250px] lg:min-h-[270px] block"
            >
              <img
                src="https://vibe.filesafe.space/1792719026995615993/assets/5434dba5-c5ad-4ef4-9588-2ff05a6b4861.png"
                alt="Luxury chauffeur service for corporate galas and formal business events"
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

              <div className="absolute top-5 left-5 lg:top-6 lg:left-6">
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.15em] text-white/80 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10">
                  For Galas
                </span>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-5 lg:p-6">
                <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-2 leading-tight">
                  Formal Event Chauffeur
                </h3>
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-white/90 hover:text-primary transition-colors group-hover:gap-3 duration-300">
                  Explore
                  <ArrowRight className="w-4 h-4" />
                </span>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

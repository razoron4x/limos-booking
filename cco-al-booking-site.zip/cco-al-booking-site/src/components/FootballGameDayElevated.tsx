import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Trophy, Users, Shield, ChevronRight, Phone } from "lucide-react";
import { Link } from "react-router-dom";

const FootballGameDayElevated = () => {
  const [expandedCard, setExpandedCard] = useState<number | null>(null);
  return (
    <section className="pt-8 pb-24 lg:py-24 px-4">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          <div className="order-2 lg:order-1">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6">
              Game Day, Elevated
            </h2>
            <p className="text-white/60 font-medium leading-relaxed text-sm md:text-lg mb-6 md:mb-8 italic">
              <span className="md:hidden">
                "VIP drop-off. Zero parking stress."
              </span>
              <span className="hidden md:inline">
                "VIP drop-off at the gate. Pickup the second it ends."
              </span>
            </p>

            <div className="space-y-6">
              <div
                className={`flex items-start gap-4 p-6 border border-primary/20 bg-gradient-to-br from-primary/5 to-zinc-900/30 transition-all duration-300 hover:shadow-[0_0_30px_rgba(212,175,55,0.15)] hover:border-primary/40 cursor-pointer sm:cursor-default rounded-xl ${expandedCard === 0 ? "border-primary/40" : ""}`}
                onClick={() => setExpandedCard(expandedCard === 0 ? null : 0)}
              >
                <Trophy className="w-6 h-6 text-primary shrink-0 mt-1" />
                <div className="flex-1">
                  <h3
                    className={`text-xl font-bold text-white mb-2 transition-all duration-300 ${expandedCard === 0 ? "text-base sm:text-xl -translate-y-1" : ""}`}
                  >
                    VIP Stadium Drop-Off
                  </h3>
                  <p
                    className={`text-white/60 font-light transition-all duration-300 overflow-hidden ${expandedCard === 0 ? "max-h-40 opacity-100" : "max-h-0 opacity-0 sm:max-h-[200px] sm:opacity-100"}`}
                  >
                    Direct access to the closest stadium entrances. No long
                    walks, no parking fees, no post-game gridlock.
                  </p>
                  <span className="text-xs text-primary/70 sm:hidden cursor-pointer mt-1 select-none block">
                    {expandedCard === 0 ? "Tap to collapse" : "Tap to expand"}
                  </span>
                </div>
              </div>
              <div
                className={`flex items-start gap-4 p-6 border border-white/5 bg-zinc-900/30 transition-all duration-300 hover:shadow-[0_0_25px_rgba(212,175,55,0.12)] hover:border-primary/30 hover:bg-zinc-900/50 cursor-pointer sm:cursor-default rounded-xl ${expandedCard === 1 ? "border-primary/40" : ""}`}
                onClick={() => setExpandedCard(expandedCard === 1 ? null : 1)}
              >
                <Users className="w-6 h-6 text-primary shrink-0 mt-1" />
                <div className="flex-1">
                  <h3
                    className={`text-xl font-bold text-white mb-2 transition-all duration-300 ${expandedCard === 1 ? "text-base sm:text-xl -translate-y-1" : ""}`}
                  >
                    Tailgate Onboard
                  </h3>
                  <p
                    className={`text-white/60 font-light transition-all duration-300 overflow-hidden ${expandedCard === 1 ? "max-h-40 opacity-100" : "max-h-0 opacity-0 sm:max-h-[200px] sm:opacity-100"}`}
                  >
                    Surround sound, LED lighting, wet bars, and cooler bins keep
                    the team spirit going before you even reach the gate.
                  </p>
                  <span className="text-xs text-primary/70 sm:hidden cursor-pointer mt-1 select-none block">
                    {expandedCard === 1 ? "Tap to collapse" : "Tap to expand"}
                  </span>
                </div>
              </div>
              <div
                className={`flex items-start gap-4 p-6 border border-white/5 bg-zinc-900/30 transition-all duration-300 hover:shadow-[0_0_25px_rgba(212,175,55,0.12)] hover:border-primary/30 hover:bg-zinc-900/50 cursor-pointer sm:cursor-default rounded-xl ${expandedCard === 2 ? "border-primary/40" : ""}`}
                onClick={() => setExpandedCard(expandedCard === 2 ? null : 2)}
              >
                <Shield className="w-6 h-6 text-primary shrink-0 mt-1" />
                <div className="flex-1">
                  <h3
                    className={`text-xl font-bold text-white mb-2 transition-all duration-300 ${expandedCard === 2 ? "text-base sm:text-xl -translate-y-1" : ""}`}
                  >
                    Safe Return Home
                  </h3>
                  <p
                    className={`text-white/60 font-light transition-all duration-300 overflow-hidden ${expandedCard === 2 ? "max-h-40 opacity-100" : "max-h-0 opacity-0 sm:max-h-[200px] sm:opacity-100"}`}
                  >
                    Celebrate responsibly with a guaranteed safe ride home. No
                    surge pricing, no rideshare lines, no stress.
                  </p>
                  <span className="text-xs text-primary/70 sm:hidden cursor-pointer mt-1 select-none block">
                    {expandedCard === 2 ? "Tap to collapse" : "Tap to expand"}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="order-1 lg:order-2">
            <div className="aspect-[16/9] md:aspect-[4/3] relative overflow-hidden border border-primary/20 rounded-xl mb-6">
              <img
                src="https://vibe.filesafe.space/1792719026995615993/assets/27d2059c-9841-474b-8b65-d227811da8c5.png"
                alt="Luxury limo interior for football game day"
                className="w-full h-full object-cover opacity-90"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent"></div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link
                to="/quote?service=Football%20Group%20Transportation"
                className="hidden sm:block"
              >
                <Button className="bg-gradient-to-b from-yellow-500 via-primary to-yellow-600 text-black hover:from-yellow-400 hover:via-yellow-500 hover:to-yellow-500 rounded-none px-8 h-14 text-lg font-bold tracking-wide shadow-[0_0_25px_rgba(212,175,55,0.3)] border border-yellow-400/40 w-full sm:w-auto">
                  Get Quote
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <a
                href="tel:9726083680"
                className="inline-block"
                onClick={() => (window as any).gtag_report_conversion?.()}
              >
                <Button
                  variant="outline"
                  className="border-primary/40 text-primary hover:bg-primary/10 hover:text-primary rounded-none px-8 h-14 text-lg font-bold tracking-wide w-full sm:w-auto"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  Call Now
                </Button>
              </a>
            </div>
            <p className="text-white/40 text-sm mt-3 font-light text-center">
              Available 24/7 for game-day bookings
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FootballGameDayElevated;

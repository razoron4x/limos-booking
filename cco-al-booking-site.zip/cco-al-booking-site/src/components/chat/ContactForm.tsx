import { useEffect, useMemo, useRef, useState } from "react";
import {
  parsePhoneNumberFromString,
  getCountries,
  getCountryCallingCode,
  type CountryCode,
} from "libphonenumber-js";

interface ChatField {
  label: string;
  placeholder: string;
  required: boolean;
  dataType: string;
  value: string;
}

interface ContactFormProps {
  chat: any;
  state: any;
}

export const ContactForm = ({ chat, state }: ContactFormProps) => {
  const fields: ChatField[] = state?.config?.contactForm?.fields ?? [];
  const compliance = state?.config?.compliance ?? {};

  // Initialize values with "I want a quote" for message field if present
  const [values, setValues] = useState<Record<string, string>>(() => {
    return { message: "I want a quote" };
  });
  const [clearedFields, setClearedFields] = useState<Record<string, boolean>>(
    {},
  );
  const [consentGiven, setConsentGiven] = useState<boolean>(
    compliance.defaultConsentCheck ?? false,
  );
  const [submitting, setSubmitting] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  useEffect(() => {
    setConsentGiven(compliance.defaultConsentCheck ?? false);
  }, [compliance.defaultConsentCheck]);

  // Ensure default message is set if message field exists in incoming fields and hasn't been cleared
  useEffect(() => {
    if (
      fields.some((f) => f.value === "message" || f.dataType === "TEXTAREA")
    ) {
      setValues((prev) => {
        const msgKey =
          fields.find((f) => f.value === "message" || f.dataType === "TEXTAREA")
            ?.value ?? "message";
        if (prev[msgKey] === undefined) {
          return { ...prev, [msgKey]: "I want a quote" };
        }
        return prev;
      });
    }
  }, [fields]);

  const handleChange = (key: string, value: string) => {
    setValues((prev) => ({ ...prev, [key]: value }));
  };

  const handleFieldFocus = (key: string) => {
    // If user clicks/taps into message field while it still holds the default "I want a quote", clear it
    if ((key === "message" || key === "textarea") && !clearedFields[key]) {
      if (values[key] === "I want a quote") {
        setValues((prev) => ({ ...prev, [key]: "" }));
        setClearedFields((prev) => ({ ...prev, [key]: true }));
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const missing = fields.filter(
      (f) => f.required && !(values[f.value] ?? "").trim(),
    );
    if (missing.length > 0) {
      setValidationError(
        `Please fill in: ${missing.map((f) => f.label).join(", ")}`,
      );
      return;
    }

    if (compliance.consentRequired && !consentGiven) {
      setValidationError("Please accept the consent to continue.");
      return;
    }

    setValidationError(null);
    setSubmitting(true);

    const payload = Object.fromEntries(
      fields.map((f) => [f.value, values[f.value] ?? ""]),
    );

    try {
      await chat.submitContactForm({ ...payload, consentGiven });
    } catch {
      // State will reflect the error via subscription
    } finally {
      setSubmitting(false);
    }
  };

  const captchaRequired = state?.captchaRequired;
  const error = state?.error;
  const requestState = state?.requestState;
  const isSubmitting = submitting || requestState === "in_progress";

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4 p-4">
      {fields.map((field) => (
        <FieldRenderer
          key={field.value}
          field={field}
          value={values[field.value] ?? ""}
          onChange={(v) => handleChange(field.value, v)}
          onFocus={() => handleFieldFocus(field.value)}
          detectedCountry={state?.detectedCountry}
          hasError={error?.field === field.value}
          errorMessage={
            error?.field === field.value ? error?.message : undefined
          }
        />
      ))}

      {compliance.consentText && (
        <div className="text-xs text-muted-foreground">
          {compliance.showConsentCheckbox ? (
            <label className="flex items-start gap-2">
              <input
                type="checkbox"
                checked={consentGiven}
                onChange={(e) => setConsentGiven(e.target.checked)}
                className="mt-0.5 h-4 w-4 rounded border-border"
              />
              <span>{compliance.consentText}</span>
            </label>
          ) : (
            <p>{compliance.consentText}</p>
          )}
        </div>
      )}

      {validationError && (
        <p className="text-sm text-destructive">{validationError}</p>
      )}
      {error?.message && !validationError && (
        <p className="text-sm text-destructive">{error.message}</p>
      )}
      {captchaRequired && (
        <p className="text-sm text-muted-foreground">
          {state?.captchaStatusMessage}
        </p>
      )}

      <button
        type="submit"
        disabled={isSubmitting || !!captchaRequired}
        className="w-full rounded-lg bg-primary px-4 py-2.5 font-medium text-primary-foreground transition-opacity disabled:opacity-50"
      >
        {isSubmitting ? "Sending..." : "Send Message"}
      </button>
    </form>
  );
};

interface FieldRendererProps {
  field: ChatField;
  value: string;
  onChange: (v: string) => void;
  onFocus?: () => void;
  detectedCountry?: string | null;
  hasError?: boolean;
  errorMessage?: string;
}

const FieldRenderer = ({
  field,
  value,
  onChange,
  onFocus,
  detectedCountry,
  hasError,
  errorMessage,
}: FieldRendererProps) => {
  const baseClass = `w-full rounded-lg border bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary ${
    hasError ? "border-destructive" : "border-border"
  }`;

  if (field.dataType === "PHONE") {
    return (
      <PhoneField
        field={field}
        value={value}
        onChange={onChange}
        detectedCountry={detectedCountry}
        hasError={hasError}
        errorMessage={errorMessage}
        baseClass={baseClass}
      />
    );
  }

  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-sm font-medium text-foreground">
        {field.label}
        {field.required && <span className="text-destructive"> *</span>}
      </label>
      {field.dataType === "TEXTAREA" ? (
        <textarea
          name={field.value}
          required={field.required}
          placeholder={field.placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={onFocus}
          onClick={onFocus}
          rows={3}
          className={baseClass}
        />
      ) : (
        <input
          type={field.dataType === "EMAIL" ? "email" : "text"}
          name={field.value}
          required={field.required}
          placeholder={field.placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={onFocus}
          onClick={onFocus}
          className={baseClass}
        />
      )}
      {errorMessage && (
        <p className="text-xs text-destructive">{errorMessage}</p>
      )}
    </div>
  );
};

interface PhoneFieldProps {
  field: ChatField;
  value: string;
  onChange: (v: string) => void;
  detectedCountry?: string | null;
  hasError?: boolean;
  errorMessage?: string;
  baseClass: string;
}

const PhoneField = ({
  field,
  value: _value,
  onChange,
  detectedCountry,
  hasError,
  errorMessage,
  baseClass,
}: PhoneFieldProps) => {
  const [raw, setRaw] = useState("");
  const [country, setCountry] = useState<CountryCode>(
    ((detectedCountry as CountryCode) ?? "US") as CountryCode,
  );
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!raw && detectedCountry) {
      setCountry(detectedCountry as CountryCode);
    }
  }, [detectedCountry, raw]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    const clickHandler = (e: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener("keydown", handler);
    document.addEventListener("mousedown", clickHandler);
    return () => {
      document.removeEventListener("keydown", handler);
      document.removeEventListener("mousedown", clickHandler);
    };
  }, [open]);

  const countries = useMemo(() => {
    const displayNames = new Intl.DisplayNames(["en"], { type: "region" });
    return getCountries()
      .map((c) => ({
        c,
        name: displayNames.of(c) ?? c,
        dial: `+${getCountryCallingCode(c)}`,
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, []);

  const dial = `+${getCountryCallingCode(country)}`;

  const update = (text: string, c: CountryCode = country) => {
    setRaw(text);
    const p = parsePhoneNumberFromString(text, c);
    onChange(p?.isValid() ? p.number : "");
  };

  const filtered = countries.filter(
    (x) => x.name.toLowerCase().includes(q.toLowerCase()) || x.dial.includes(q),
  );

  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-sm font-medium text-foreground">
        {field.label}
        {field.required && <span className="text-destructive"> *</span>}
      </label>
      <div ref={containerRef} className="relative flex gap-2">
        <button
          type="button"
          aria-haspopup="listbox"
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
          className={`flex items-center gap-1 rounded-lg border bg-background px-2.5 py-2 text-sm text-foreground ${
            hasError ? "border-destructive" : "border-border"
          }`}
        >
          <span>{dial}</span>
          <svg
            width="12"
            height="12"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <polyline points="6 9 12 15 18 9" />
          </svg>
        </button>
        {open && (
          <div
            role="listbox"
            className="absolute top-10 z-10 max-h-56 w-64 overflow-y-auto rounded-md border border-border bg-popover shadow-lg"
          >
            <input
              autoFocus
              placeholder="Search countries"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              className="w-full border-b border-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
            />
            {filtered.map((x) => (
              <div
                key={x.c}
                role="option"
                aria-selected={x.c === country}
                onClick={() => {
                  setCountry(x.c);
                  setOpen(false);
                  update(raw, x.c);
                }}
                className={`flex cursor-pointer items-center justify-between px-3 py-2 text-sm text-foreground hover:bg-muted ${
                  x.c === country ? "bg-muted" : ""
                }`}
              >
                <span>{x.name}</span>
                <span className="text-muted-foreground">{x.dial}</span>
              </div>
            ))}
          </div>
        )}
        <input
          type="tel"
          name={field.value}
          required={field.required}
          placeholder={field.placeholder}
          value={raw}
          onChange={(e) => update(e.target.value)}
          className={baseClass}
        />
      </div>
      {errorMessage && (
        <p className="text-xs text-destructive">{errorMessage}</p>
      )}
    </div>
  );
};

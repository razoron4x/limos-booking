import { useEffect, useRef, useState, useCallback } from "react";
import { CHAT_WIDGET_CONFIG } from "@/lib/chat-widget-config";
import { CHAT_WIDGET_COPY } from "@/lib/chat-widget-copy";
import { loadChatCore } from "@/lib/chat-widget-core";
import { ContactForm } from "@/components/chat/ContactForm";

export const ChatWidget = () => {
  const [state, setState] = useState<any>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [showTeaser, setShowTeaser] = useState(false);
  const chatRef = useRef<any>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const openIntentRef = useRef(false);

  // Create chat client on mount
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const core = await loadChatCore(CHAT_WIDGET_CONFIG.coreUrl);
        if (!mounted) return;
        const chat = core.createChatClient({
          locationId: CHAT_WIDGET_CONFIG.locationId,
          widgetId: CHAT_WIDGET_CONFIG.chatWidgetId,
          marketplaceUrl: CHAT_WIDGET_CONFIG.marketplaceUrl,
          source: CHAT_WIDGET_CONFIG.source,
        });
        chatRef.current = chat;
        chat.subscribe(setState);
        if (openIntentRef.current) {
          chat.setPanelOpen(true);
          await chat.open();
          openIntentRef.current = false;
        }
      } catch (e) {
        console.error("[chat-core] Failed to load:", e);
      }
    })();
    return () => {
      mounted = false;
      try {
        chatRef.current?.unsubscribe?.();
        chatRef.current?.close?.();
      } catch {}
    };
  }, []);

  // Auto-select emailChat if type selection is required
  useEffect(() => {
    if (state?.awaitingChatTypeSelection && chatRef.current) {
      chatRef.current.setActiveChatType(CHAT_WIDGET_CONFIG.chatType);
    }
  }, [state?.awaitingChatTypeSelection]);

  // Set captcha anchor when panel is open
  useEffect(() => {
    if (isOpen && panelRef.current && chatRef.current) {
      chatRef.current.setCaptchaAnchor(panelRef.current);
    }
  }, [isOpen, state]);

  // Show teaser bubble after a delay when closed
  useEffect(() => {
    if (!isOpen) {
      const t = setTimeout(() => setShowTeaser(true), 2500);
      return () => clearTimeout(t);
    }
  }, [isOpen]);

  const handleOpen = useCallback(async () => {
    setShowTeaser(false);
    setIsOpen(true);
    if (chatRef.current) {
      chatRef.current.setPanelOpen(true);
      await chatRef.current.open();
    } else {
      openIntentRef.current = true;
    }
  }, []);

  const handleClose = useCallback(() => {
    setIsOpen(false);
    chatRef.current?.setPanelOpen(false);
    chatRef.current?.close();
  }, []);

  const handleRetry = useCallback(async () => {
    if (chatRef.current) {
      await chatRef.current.open();
    }
  }, []);

  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        {showTeaser && (
          <div
            className="group/teaser absolute bottom-2 right-16 w-52 animate-in fade-in rounded-2xl border border-border/80 bg-card/95 backdrop-blur-md px-4 py-3 text-sm text-foreground shadow-2xl pr-7"
            style={{ animationDuration: "300ms" }}
          >
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowTeaser(false);
              }}
              aria-label="Close message"
              className="absolute top-2 right-2 flex h-5 w-5 items-center justify-center rounded-full text-muted-foreground/70 hover:text-foreground hover:bg-muted/60 transition-colors"
            >
              <svg
                width="12"
                height="12"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
            {CHAT_WIDGET_COPY.teaser}
          </div>
        )}
        <button
          onClick={handleOpen}
          aria-label={CHAT_WIDGET_COPY.launcherAriaLabel}
          className="flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-transform hover:scale-105"
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
          </svg>
        </button>
      </div>
    );
  }

  const hasConfig = !!state?.config;
  const hasError = !!state?.error;
  const isSubmitted = !!state?.contactFormSubmitted;
  const showForm = state?.showContactForm !== false;

  return (
    <>
      <button
        onClick={handleClose}
        aria-label={CHAT_WIDGET_COPY.closeAriaLabel}
        className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-transform hover:scale-105"
      >
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <line x1="18" y1="6" x2="6" y2="18" />
          <line x1="6" y1="6" x2="18" y2="18" />
        </svg>
      </button>

      <div
        ref={panelRef}
        className="fixed bottom-24 right-6 z-50 flex w-[calc(100vw-3rem)] max-w-[380px] flex-col overflow-hidden rounded-3xl border border-border bg-card shadow-2xl"
        style={{ height: "min(640px, 100dvh - 7rem)" }}
      >
        {/* Header */}
        <div className="flex items-center gap-3 border-b border-border bg-background p-4">
          <div className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full overflow-visible ring-2 ring-primary/40 shadow-md bg-black">
            <img
              src="https://vibe.filesafe.space/1792719026995615993/attachments/6bdd5aa1-a6cd-4788-a8ee-73b08586fd7c.png"
              alt="Addison Xpress Limo Service"
              className="h-full w-full rounded-full object-cover"
            />
            <span
              className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-background bg-emerald-500"
              aria-label="Online"
            />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-base font-semibold leading-tight text-foreground">
              {CHAT_WIDGET_COPY.heading}
            </h2>
            <p className="text-xs text-muted-foreground">
              {CHAT_WIDGET_COPY.subHeading}
            </p>
          </div>
        </div>

        {/* Body */}
        <div className="min-h-0 flex-1 overflow-y-auto">
          {!hasConfig && hasError && (
            <div className="flex flex-col items-center justify-center gap-3 p-6 text-center">
              <p className="text-sm text-destructive">
                {state?.error?.message ?? "Something went wrong."}
              </p>
              <button
                onClick={handleRetry}
                className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
              >
                Retry
              </button>
            </div>
          )}

          {!hasConfig && !hasError && (
            <div className="flex items-center justify-center p-6">
              <div className="h-8 w-8 animate-spin rounded-full border-2 border-muted border-t-primary" />
            </div>
          )}

          {hasConfig && isSubmitted && (
            <div className="flex flex-col items-center justify-center gap-3 p-6 text-center">
              <svg
                width="48"
                height="48"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-primary"
              >
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                <polyline points="22 4 12 14.01 9 11.01" />
              </svg>
              <p className="text-base font-medium text-foreground">
                {CHAT_WIDGET_COPY.thankYou}
              </p>
            </div>
          )}

          {hasConfig && !isSubmitted && showForm && (
            <ContactForm chat={chatRef.current} state={state} />
          )}

          {hasConfig && !isSubmitted && !showForm && (
            <div className="flex items-center justify-center p-6">
              <div className="h-8 w-8 animate-spin rounded-full border-2 border-muted border-t-primary" />
            </div>
          )}
        </div>
      </div>
    </>
  );
};

import ServiceMosaic from "@/components/ServiceMosaic";
import ServiceTrustStrip from "@/components/ServiceTrustStrip";
import ServiceWhyChoose from "@/components/ServiceWhyChoose";
import ServiceExploreOptions from "@/components/ServiceExploreOptions";
import type { ServicePageConfig } from "@/data/serviceConfigs";

interface ServiceTopSectionsProps {
  config: ServicePageConfig;
}

/**
 * Renders the three top-of-page sections (mosaic, trust strip, why-choose CTA)
 * that sit right after the hero header. Place this immediately after the header section.
 */
export const ServiceTopSections = ({ config }: ServiceTopSectionsProps) => (
  <>
    <ServiceMosaic {...config.mosaic} />
    <ServiceTrustStrip stats={config.trustStats} />
    <ServiceWhyChoose {...config.whyChoose} />
  </>
);

/**
 * Renders the bottom "Explore Other Options" section.
 * Place this right before the CompactServiceArea at the page bottom.
 */
export const ServiceExploreSection = ({ config }: ServiceTopSectionsProps) => (
  <ServiceExploreOptions
    card1={config.explore.card1}
    card2={config.explore.card2}
    card3={config.explore.card3}
  />
);

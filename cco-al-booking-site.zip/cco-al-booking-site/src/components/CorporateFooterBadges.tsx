import { Shield, Plane, CheckCircle2, Clock } from "lucide-react";

export const CorporateFooterBadges = () => {
  return (
    <div className="mt-12 pt-8 border-t border-white/10 flex flex-wrap justify-center gap-6">
      <div className="inline-flex items-center gap-2 text-white/40 text-xs font-light">
        <Shield className="w-4 h-4 text-primary/60" />
        <span>TxDOT Licensed & Insured</span>
      </div>
      <div className="inline-flex items-center gap-2 text-white/40 text-xs font-light">
        <Plane className="w-4 h-4 text-primary/60" />
        <span>DFW Airport Permitted</span>
      </div>
      <div className="inline-flex items-center gap-2 text-white/40 text-xs font-light">
        <CheckCircle2 className="w-4 h-4 text-primary/60" />
        <span>$1.5M+ Commercial Liability Coverage</span>
      </div>
      <div className="inline-flex items-center gap-2 text-white/40 text-xs font-light">
        <Clock className="w-4 h-4 text-primary/60" />
        <span>24/7 Dispatch & Reservations</span>
      </div>
    </div>
  );
};

import { Link } from "react-router-dom";
import { Phone, Shield, Camera, Sparkles, ChevronRight } from "lucide-react";

const HomecomingWhyChoose = () => {
  return (
    <section className="py-20 lg:py-24 bg-[#0d0d0d] border-y border-white/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4 lg:mb-6">
            The Only Way to Arrive on Homecoming Night
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto text-base lg:text-lg font-light leading-relaxed">
            The celebration starts the moment you step onboard.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 lg:gap-5 max-w-7xl mx-auto">
          {/* Box 1: Large Red-Carpet Arrival Image Card */}
          <div className="md:col-span-7 md:row-span-2 relative overflow-hidden rounded-xl shadow-lg group min-h-[260px] md:min-h-[420px] bg-zinc-900">
            <img
              src="https://vibe.filesafe.space/1792719026995615993/assets/ceaa1fe6-0551-4fd3-bb2c-aa6665bd3a0a.png"
              alt="Luxury stretch limousine arriving for a homecoming dance red-carpet drop-off at dusk"
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover object-center opacity-55 group-hover:opacity-70 transition-opacity duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/50 to-black/70"></div>

            <div className="relative z-10 h-full flex flex-col justify-between p-6 lg:p-9">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/15 border border-primary/30 rounded-lg mb-4 lg:mb-5 backdrop-blur-sm w-fit">
                  <Sparkles className="w-4 h-4 text-primary" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-primary">
                    Homecoming Night
                  </span>
                </div>
                <h3 className="text-xl lg:text-3xl font-serif font-bold text-white mb-2 lg:mb-3 leading-tight">
                  Red-Carpet Arrival
                </h3>
              </div>
              <p className="text-sm lg:text-lg text-white/80 font-medium leading-relaxed max-w-md">
                Roll up to the dance in a stretch limo or Hummer and turn every
                head. Our chauffeurs handle the door, the drop-off, and the
                moment.
              </p>
            </div>
          </div>

          {/* Box 2: Photo Stops Built In */}
          <div className="md:col-span-5 bg-zinc-800 border border-zinc-700 rounded-xl p-5 lg:p-8 shadow-lg hover:border-primary/40 transition-all duration-300 group flex flex-col justify-center min-h-[160px] md:min-h-[206px]">
            <div className="w-11 h-11 lg:w-12 lg:h-12 bg-primary/10 border border-primary/20 rounded-xl flex items-center justify-center mb-3 lg:mb-4 group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300 shrink-0">
              <Camera className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
            </div>
            <h3 className="text-base lg:text-lg font-serif font-bold text-white mb-1.5 lg:mb-2 group-hover:text-primary transition-colors">
              Photo Stops Built In
            </h3>
            <p className="text-white/70 text-xs lg:text-sm leading-relaxed font-medium">
              Coordinate scenic group photo stops before the dance. Your
              chauffeur knows the best backdrops across DFW.
            </p>
          </div>

          {/* Box 3: Safe Ride Home */}
          <div className="md:col-span-5 bg-zinc-800 border border-zinc-700 rounded-xl p-5 lg:p-8 shadow-lg hover:border-primary/40 transition-all duration-300 group flex flex-col justify-center min-h-[160px] md:min-h-[206px]">
            <div className="w-11 h-11 lg:w-12 lg:h-12 bg-primary/10 border border-primary/20 rounded-xl flex items-center justify-center mb-3 lg:mb-4 group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300 shrink-0">
              <Shield className="w-5 h-5 lg:w-6 lg:h-6 text-primary" />
            </div>
            <h3 className="text-base lg:text-lg font-serif font-bold text-white mb-1.5 lg:mb-2 group-hover:text-primary transition-colors">
              Safe Ride Home
            </h3>
            <p className="text-white/70 text-xs lg:text-sm leading-relaxed font-medium">
              Parents rest easy with a vetted chauffeur for the entire evening.
              No surge pricing, no rideshare surprises, just a safe ride home.
            </p>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="max-w-7xl mx-auto mt-8 lg:mt-10 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
          <Link
            to="/quote?service=Homecoming%20Limo%20Service"
            className="w-full sm:w-auto"
          >
            <button className="w-full sm:w-auto group inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-gradient-to-r from-primary via-yellow-500 to-primary bg-[length:200%_100%] hover:bg-[position:100%_0] text-black font-bold text-sm uppercase tracking-wider rounded-full shadow-lg shadow-primary/20 transition-all duration-500">
              Get a Quote
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </Link>
          <a
            href="tel:9726083680"
            className="w-full sm:w-auto"
            onClick={() => (window as any).gtag_report_conversion?.()}
          >
            <button className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-white border-2 border-zinc-900 text-zinc-900 font-bold text-sm uppercase tracking-wider rounded-full hover:bg-zinc-900 hover:text-white hover:border-white transition-all duration-300">
              <Phone className="w-4 h-4" />
              (972) 608-3680
            </button>
          </a>
        </div>
      </div>
    </section>
  );
};

export default HomecomingWhyChoose;

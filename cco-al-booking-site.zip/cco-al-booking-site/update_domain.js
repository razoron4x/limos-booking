const fs = require('fs');
const path = require('path');

const replaceInFile = (filePath) => {
  const content = fs.readFileSync(filePath, 'utf8');
  if (content.includes('addisonxpress.com')) {
    fs.writeFileSync(filePath, content.replace(/addisonxpress\.com/g, 'addisonlimos.com'), 'utf8');
    console.log(`Updated ${filePath}`);
  }
};

const walkSync = (dir, callback) => {
  fs.readdirSync(dir).forEach(file => {
    const dirPath = path.join(dir, file);
    const isDirectory = fs.statSync(dirPath).isDirectory();
    isDirectory ? walkSync(dirPath, callback) : callback(dirPath);
  });
};

walkSync('./src', replaceInFile);
replaceInFile('./public/sitemap.xml');
replaceInFile('./public/robots.txt');

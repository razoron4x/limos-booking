import { execSync } from 'child_process';
import fs from 'fs';

const files = [
  "src/pages/ServiceAirport.tsx",
  "src/pages/ServiceCorporate.tsx",
  "src/pages/ServiceEvents.tsx",
  "src/pages/WorldCup.tsx"
];

for (const file of files) {
  let content = fs.readFileSync(file, 'utf8');
  
  content = content.replace(
    /<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">/g,
    '<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-8 mb-12">'
  );
  
  content = content.replace(
    /<CardContent className="p-8 flex flex-col h-full">/g,
    '<CardContent className="p-5 sm:p-8 flex flex-col h-full">'
  );

  content = content.replace(
    /<div className="flex items-center gap-1 mb-6">/g,
    '<div className="flex items-center gap-1 mb-4 sm:mb-6">'
  );

  content = content.replace(
    /<Star key=\{star\} className="w-4 h-4 text-primary fill-primary" \/>/g,
    '<Star key={star} className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-primary fill-primary" />'
  );

  content = content.replace(
    /<p className="text-base text-white\/80 font-light leading-relaxed mb-8 italic flex-grow">/g,
    '<p className="text-sm sm:text-base text-white/80 font-light leading-relaxed mb-6 sm:mb-8 italic flex-grow">'
  );

  content = content.replace(
    /<div className="flex items-center gap-4 mt-auto pt-4 border-t border-white\/5">/g,
    '<div className="flex items-center gap-3 sm:gap-4 mt-auto pt-4 border-t border-white/5">'
  );

  content = content.replace(
    /<div className="w-12 h-12 bg-primary\/10 rounded-full flex items-center justify-center border border-primary\/20 shrink-0">/g,
    '<div className="w-10 h-10 sm:w-12 sm:h-12 bg-primary/10 rounded-full flex items-center justify-center border border-primary/20 shrink-0">'
  );

  content = content.replace(
    /<span className="text-primary font-serif font-bold text-lg">\{review\.name\.charAt\(0\)\.toUpperCase\(\)\}<\/span>/g,
    '<span className="text-primary font-serif font-bold text-base sm:text-lg">{review.name.charAt(0).toUpperCase()}</span>'
  );

  content = content.replace(
    /<div className="text-white font-medium">\{review\.name\}<\/div>/g,
    '<div className="text-white font-medium text-sm sm:text-base">{review.name}</div>'
  );

  content = content.replace(
    /<div className="text-xs text-white\/50">Google Review<\/div>/g,
    '<div className="text-[10px] sm:text-xs text-white/50">Google Review</div>'
  );

  fs.writeFileSync(file, content, 'utf8');
}
console.log("Done");
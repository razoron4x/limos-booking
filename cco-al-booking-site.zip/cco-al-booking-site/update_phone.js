const fs = require('fs');
const path = require('path');

function replaceInFile(filePath) {
  let content = fs.readFileSync(filePath, 'utf8');
  
  // Replace 972-779-5975
  content = content.replace(/972-779-5975/g, '972-608-3680');
  // Replace tel:9727795975
  content = content.replace(/9727795975/g, '9726083680');
  
  // Replace 972-635-4394
  content = content.replace(/972-635-4394/g, '972-608-3680');
  // Replace tel:9726354394
  content = content.replace(/9726354394/g, '9726083680');

  fs.writeFileSync(filePath, content);
}

function walkDir(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      walkDir(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      replaceInFile(fullPath);
    }
  }
}

walkDir('src');
console.log('Done replacing phone numbers.');

import fs from 'fs';

const files = [
  "src/pages/Index.tsx",
  "src/pages/ServiceAirport.tsx",
  "src/pages/ServiceBirthday.tsx",
  "src/pages/ServiceCityTours.tsx",
  "src/pages/ServiceCorporate.tsx",
  "src/pages/ServiceEvents.tsx",
  "src/pages/ServiceFuneral.tsx",
  "src/pages/ServiceGroup.tsx",
  "src/pages/ServiceHolidayLights.tsx",
  "src/pages/ServiceMedicalTransport.tsx",
  "src/pages/ServicePointToPoint.tsx",
  "src/pages/ServiceShuttle.tsx",
  "src/pages/ServiceSportingConcerts.tsx",
  "src/pages/ServiceVIP.tsx",
  "src/pages/WorldCup.tsx"
];

for (const file of files) {
  let content = fs.readFileSync(file, 'utf8');
  
  content = content.replace(
    /<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">/g,
    '<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-8 mb-12">'
  );
  
  content = content.replace(
    /<Card key=\{i\} className=\{`bg-zinc-900\/40 border-white\/5 rounded-none hover:bg-zinc-900\/60 transition-all duration-300 group \$\{i >= 3 \? 'hidden md:block' : ''\}`\}>\s*<CardContent className="p-8 flex flex-col h-full">\s*<div className="flex items-center gap-1 mb-6">\s*\{\[1, 2, 3, 4, 5\]\.map\(\(star\) => \(\s*<Star key=\{star\} className="w-4 h-4 text-primary fill-primary" \/>\s*\)\)\}\s*<\/div>\s*<p className="text-base text-white\/80 font-light leading-relaxed mb-8 italic flex-grow">\s*"\{review\.text\}"\s*<\/p>\s*<div className="flex items-center gap-4 mt-auto pt-4 border-t border-white\/5">\s*<div className="w-12 h-12 bg-primary\/10 rounded-full flex items-center justify-center border border-primary\/20 shrink-0">\s*<span className="text-primary font-serif font-bold text-lg">\{review\.name\.charAt\(0\)\.toUpperCase\(\)\}<\/span>\s*<\/div>\s*<div>\s*<div className="text-white font-medium">\{review\.name\}<\/div>\s*<div className="text-xs text-white\/50">Google Review<\/div>\s*<\/div>\s*<\/div>\s*<\/CardContent>\s*<\/Card>/g,
    `<Card key={i} className={\`bg-zinc-900/40 border-white/5 rounded-none hover:bg-zinc-900/60 transition-all duration-300 group \${i >= 3 ? 'hidden md:block' : ''}\`}>
                <CardContent className="p-5 sm:p-8 flex flex-col h-full">
                  <div className="flex items-center gap-1 mb-4 sm:mb-6">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-primary fill-primary" />
                    ))}
                  </div>
                  <p className="text-sm sm:text-base text-white/80 font-light leading-relaxed mb-6 sm:mb-8 italic flex-grow">
                    "{review.text}"
                  </p>
                  <div className="flex items-center gap-3 sm:gap-4 mt-auto pt-4 border-t border-white/5">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-primary/10 rounded-full flex items-center justify-center border border-primary/20 shrink-0">
                      <span className="text-primary font-serif font-bold text-base sm:text-lg">{review.name.charAt(0).toUpperCase()}</span>
                    </div>
                    <div>
                      <div className="text-white font-medium text-sm sm:text-base">{review.name}</div>
                      <div className="text-[10px] sm:text-xs text-white/50">Google Review</div>
                    </div>
                  </div>
                </CardContent>
              </Card>`
  );
  
  fs.writeFileSync(file, content, 'utf8');
}

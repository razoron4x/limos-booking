const fs = require('fs');
const path = require('path');

const sitemapPath = path.join(process.cwd(), 'public', 'sitemap.xml');
let sitemap = fs.readFileSync(sitemapPath, 'utf8');

sitemap = sitemap.replace(/<lastmod>2026-07-20<\/lastmod>/g, '<lastmod>2026-07-29</lastmod>');

fs.writeFileSync(sitemapPath, sitemap);
console.log('Updated sitemap dates.');

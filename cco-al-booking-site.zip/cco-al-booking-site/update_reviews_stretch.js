const fs = require('fs');

const files = [
  'src/pages/Index.tsx',
  'src/pages/ServiceAirport.tsx',
  'src/pages/ServiceBirthday.tsx',
  'src/pages/ServiceCityTours.tsx',
  'src/pages/ServiceCorporate.tsx',
  'src/pages/ServiceEvents.tsx',
  'src/pages/ServiceFuneral.tsx',
  'src/pages/ServiceGroup.tsx',
  'src/pages/ServiceHolidayLights.tsx',
  'src/pages/ServiceMedicalTransport.tsx',
  'src/pages/ServicePointToPoint.tsx',
  'src/pages/ServiceShuttle.tsx',
  'src/pages/ServiceSportingConcerts.tsx',
  'src/pages/ServiceVIP.tsx',
  'src/pages/WorldCup.tsx'
];

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  
  // Stretch out the grid container
  content = content.replace(
    /<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-8 mb-12">/g,
    '<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-8 mb-12 -mx-2 sm:mx-0">'
  );
  
  // Reduce padding inside CardContent
  content = content.replace(
    /<CardContent className="p-5 sm:p-8 flex flex-col h-full">/g,
    '<CardContent className="p-3 sm:p-8 flex flex-col h-full">'
  );
  
  // Reduce gap and margin for stars
  content = content.replace(
    /<div className="flex items-center gap-1 mb-4 sm:mb-6">/g,
    '<div className="flex items-center gap-0.5 mb-2 sm:mb-6">'
  );
  
  // Fix star size specifically
  content = content.replace(
    /className="w-3\.5 h-3\.5 sm:w-4 sm:h-4 text-primary fill-primary" \/>/g,
    'className="w-3 h-3 sm:w-4 sm:h-4 text-primary fill-primary" />'
  );
  
  // Reduce margin for text
  content = content.replace(
    /<p className="text-sm sm:text-base text-white\/80 font-light leading-relaxed mb-6 sm:mb-8 italic flex-grow">/g,
    '<p className="text-sm sm:text-base text-white/80 font-light leading-relaxed mb-3 sm:mb-8 italic flex-grow">'
  );
  
  // Reduce gap and padding for footer
  content = content.replace(
    /<div className="flex items-center gap-3 sm:gap-4 mt-auto pt-4 border-t border-white\/5">/g,
    '<div className="flex items-center gap-2 sm:gap-4 mt-auto pt-3 sm:pt-4 border-t border-white/5">'
  );
  
  // Reduce avatar size
  content = content.replace(
    /<div className="w-10 h-10 sm:w-12 sm:h-12 bg-primary\/10 rounded-full flex items-center justify-center border border-primary\/20 shrink-0">/g,
    '<div className="w-8 h-8 sm:w-12 sm:h-12 bg-primary/10 rounded-full flex items-center justify-center border border-primary/20 shrink-0">'
  );
  
  // Reduce avatar text size
  content = content.replace(
    /<span className="text-primary font-serif font-bold text-base sm:text-lg">\{review\.name\.charAt\(0\)\.toUpperCase\(\)\}<\/span>/g,
    '<span className="text-primary font-serif font-bold text-sm sm:text-lg">{review.name.charAt(0).toUpperCase()}</span>'
  );

  fs.writeFileSync(file, content);
});

// Now do Reviews.tsx
let revContent = fs.readFileSync('src/pages/Reviews.tsx', 'utf8');
revContent = revContent.replace(/p-3 sm:p-8/g, "p-2.5 sm:p-8");
revContent = revContent.replace(/mb-3 sm:mb-6/g, "mb-2 sm:mb-6");
revContent = revContent.replace(/mb-4 sm:mb-8/g, "mb-2.5 sm:mb-8");
revContent = revContent.replace(/pt-3 sm:pt-4/g, "pt-2 sm:pt-4");
revContent = revContent.replace(/w-8 h-8 sm:w-12/g, "w-6 h-6 sm:w-12");
revContent = revContent.replace(/text-sm sm:text-lg/g, "text-[10px] sm:text-lg");
revContent = revContent.replace(/gap-2 sm:gap-4/g, "gap-1.5 sm:gap-4");
revContent = revContent.replace(/<div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-8">/, '<div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-1.5 sm:gap-8 -mx-1 sm:mx-0">');
fs.writeFileSync('src/pages/Reviews.tsx', revContent);

console.log("Done");
const fs = require('fs');
const path = require('path');

const sitemapPath = path.join(__dirname, 'public', 'sitemap.xml');

if (fs.existsSync(sitemapPath)) {
  let content = fs.readFileSync(sitemapPath, 'utf8');
  content = content.replace(/<lastmod>.*?<\/lastmod>/g, '<lastmod>2026-07-20</lastmod>');
  fs.writeFileSync(sitemapPath, content);
  console.log('Sitemap dates updated to 2026-07-20');
}

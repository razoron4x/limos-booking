const fs = require('fs');

let sitemap = fs.readFileSync('public/sitemap.xml', 'utf8');

// Replace </loc> with </loc>\n    <lastmod>2026-07-17</lastmod>
sitemap = sitemap.replace(/<\/loc>/g, '</loc>\n    <lastmod>2026-07-17</lastmod>');

fs.writeFileSync('public/sitemap.xml', sitemap);

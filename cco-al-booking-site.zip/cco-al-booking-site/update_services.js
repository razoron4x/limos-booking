const fs = require('fs');
const path = require('path');

const pagesDir = path.join(__dirname, 'src', 'pages');
const files = fs.readdirSync(pagesDir);

files.forEach(file => {
  if (file.startsWith('Service') && file.endsWith('.tsx')) {
    const filePath = path.join(pagesDir, file);
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Replace <a href="tel:9727795975"> with <a href="tel:9727795975" onClick={() => (window as any).gtag_report_conversion?.()}>
    content = content.replace(
      /<a href="tel:9727795975">/g, 
      '<a href="tel:9727795975" onClick={() => (window as any).gtag_report_conversion?.()}>'
    );
    
    fs.writeFileSync(filePath, content);
  }
});

console.log('Done');
